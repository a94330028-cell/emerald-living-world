# 🌿 Patch Notes V9.2 — Imagens da Pokédex

- ✅ Miniaturas na Pokédex Quetzal para as 1.025 espécies.
- ✅ Retrato ampliado ao selecionar um Pokémon.
- ✅ Sprites locais preservados e fallback para imagens externas por número da Pokédex.
- ✅ Busca, filtros, paginação e interface mobile mantidos.
- ✅ Batalhas online e Pokédex offline com fallback de imagem aprimorado.
- ⚠️ Formas especiais não confirmadas usam a espécie-base; registros experimentais não possuem retratos próprios.
- ⚠️ As imagens externas dependem de internet e disponibilidade do serviço.
- ⚠️ Sprites Quetzal não foram extraídos; ROM do usuário não foi redistribuída.
- 🧪 66/66 testes automatizados Node + testes de interface no Android e desktop com fonte de imagem externa simulada.
