# 🌿 Emerald Living World 3.4 — Primeiros passos

Esta é uma atualização incremental da versão 3.3, não uma reconstrução. Publique o conteúdo inteiro do ZIP na raiz da hospedagem ou mantenha a mesma estrutura de diretórios de seu site.

## Mudanças

- Tela de entrada com escolhas de aventura menores, legíveis e agrupadas; disposição mobile reorganizada.
- Barra inferior unificada em tons de verde e navegação compacta.
- Removidos links e chamadas públicas ao **multiplayer experimental** (`online.html` não é promovido no menu). O código experimental foi mantido no pacote para não comprometer outros testes e recursos futuros, mas **não está anunciado como disponível**.
- Rank com duas listas de **treinadores**:
  1. **Times mais fortes** — cálculo de `emeraldStrength`, já usado pelo motor, sobre os Pokémon do **time ativo**, sem contar o PC.
  2. **Mais avançados na história** — campeão primeiro, depois etapa da campanha (`stage`), progresso da Liga (`leagueRound`), insígnias e vitórias para desempate.
- Página do seu treinador mostra um resumo das duas classificações, substituindo o antigo Top 6 Pokémon individuais.
- A observação de IAs mantém sua simulação e o painel de acompanhamento.
- Tema escuro mantém mapas e sprites sem escurecimento artificial.

## Dados e serviços

- Os rankings nesta versão são **locais à simulação aberta**, não representam todos os jogadores do mundo nem dependem de conta.
- Salves e a estrutura de dados de treinadores foram preservados.
- O chat comunitário é separado do multiplayer de mapa e precisa de Supabase configurado antes de permitir conversas entre visitantes reais.
- Não houve publicação automática na hospedagem.

## Testes efetuados

- 162 testes automatizados de Node, incluindo os testes novos de prioridade de campanha e pontuação de time.
- Teste offline em Chromium com viewport mobile de 390×844: entrada, rolagem, rank dos treinadores, tema e ações do Rank sem erros JavaScript observados.
- Abertura em Android real, sincronização do Supabase e navegação completa do mapa **não foram validadas** nesta execução.

Guarde um backup do seu save antes de substituir uma versão publicada. Para continuar do mesmo save, mantenha o domínio e armazenamento do navegador.
