# Emerald Living World V8.1 — Correção da navegação em Rustboro

## Relato reproduzido

Captura fornecida pelo criador: treinador em Rustboro City junto a árvores, com alerta **“Procurando passagem”**. O problema no motor de mapas oficiais era compatível com dois casos: (1) uma saída planejada topologicamente mas sem caminho físico alcançável; (2) um save com posição caminável, porém em um componente isolado do terreno.

## Alterações feitas

- `jogo/js/official-runtime.js` — prioridade de saídas com aproximação real e que reduzem distância até a missão; evita tentar sempre uma rota bloqueada ou rodar em círculos por mapas vizinhos.
- `jogo/js/official-runtime.js` — verificação limitada de posições de saída quando uma posição do save ficou isolada. Só após três falhas de rota, em cidades/rotas (não interiores), pode recuperar uma vez por mapa/objetivo/etapa para uma posição caminhável próxima de uma saída verificada. Marca o motivo em `walkObjective`, em vez de falsificar passos caminhados.
- `jogo/index.html` — nova assinatura do JavaScript para evitar que o navegador use versão antiga em cache.
- `tests/maps/official-runtime.test.cjs` — novos testes com cenário sintético de Rustboro City dividido por uma barreira, incluindo caminho válido, região isolada, recálculo manual sem deslocamento e prevenção de desvio circular pela Rota 104.

## Resultados verificáveis

- `node --test` — execução automática completa (resultado no log `tests/v8_1_node_test_log.txt`).
- `node --test tests/maps/*.test.cjs` — testes de navegação, incluindo o novo cenário Rustboro.
- `python tests/browser-smoke.py` — Chromium emulado na largura Android e desktop; a carga de mapas externos é bloqueada de propósito para verificar o modo de recuperação. 20 bots deram passos; os 721 turnos observados não geraram posição fora do mapa; save e restauração passaram; nenhum erro JS observado no navegador.

## O que não foi comprovado

- A captura é do mapa oficial vindo de `pret/pokeemerald` pela internet. A reprodução automatizada de Rustboro usa um mapa **sintético** com barreiras semelhantes, pois os dados oficiais não estavam disponíveis no ambiente de testes.
- Não foram verificados todos os interiores e puzzles do jogo. A recuperação excepcional de save inválido pode reposicionar um treinador: ela não é uma caminhada nem uma solução para um puzzle legítimo.
- A versão hospedada do site não foi atualizada automaticamente. É preciso publicar os arquivos do pacote.

## Atualização e saves

1. Antes de publicar, exporte um backup do save na versão atual do site.
2. Substitua os arquivos do projeto pelos deste ZIP ou, se preferir atualização mínima, substitua `jogo/js/official-runtime.js` e `jogo/index.html`.
3. Atualize o site, recarregue a página e observe o treinador antes preso em Rustboro. Aguarde algumas tentativas da rota: a recuperação não é instantânea.
4. Não apague os dados do navegador ou reinicie o mundo, pois isso pode remover seu progresso. O servidor da V8 permanece preservado.
