# 🌿 PATCH NOTES — 4.0 Beta / Frontier LAB

**Novo:** Battle Frontier LAB com sete desafios experimentais e interface para celular.

**Novo:** modo de treino sem BP, recorde ou símbolo, acessível antes da Liga. Modo oficial continua bloqueado até campeão.

**Batalhas:** Pressure (PP), golpes de múltiplos acertos, novo controle de precisão, Explosion/Selfdestruct e novas interações de habilidades e itens.

**Factory:** Pokémon emprestados separados da equipe capturada; troca de aluguel após vitória.

**Pike/Pyramid:** eventos de sala/andar; Battle Bag limitada na Pyramid, com HP persistente.

**Preservado:** Pokémon e habitats de captura dos bots, catálogo nacional, autonomia dos bots, Arena Competitiva e arquivos Supabase existentes.

**Testado:** 207 testes Node aprovados; fluxo Factory pela API HTTP aprovado.

**Beta:** ainda não é Pokémon Emerald inteiro, nem Battle Frontier fiel à ROM. Os restantes dos estudos precisam de integração, testes e implantação. Nada foi publicado automaticamente.
