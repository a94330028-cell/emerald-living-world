# Checklist de lançamento — Emerald Living World 3.0.1

| Item | Estado | Evidência / pendência |
|---|---|---|
| Aplicação inicia no Node 20+ | Verificação local | `npm run smoke:local` |
| Testes automatizados | Verificado localmente | `npm test` |
| Pokémon e habitats preservados | Verificado | `npm run audit:preservation` |
| Campanha Hoenn adaptada | Jogável local | 8 ginásios, Liga e Hall da Fama |
| Tate e Liza Double | Jogável, parcial | Motor Double não cobre todas as exceções da ROM |
| Battle Frontier LAB | Jogável, adaptada | 7 instalações; sem símbolos oficiais |
| Arena Competitiva | Preservada | Motor separado, testes existentes |
| Supabase Auth em servidor público | Pendente | Teste de tokens reais, RLS e deploy |
| Multiplayer público com carga | Pendente | Processo Node persistente, rede, backup, testes de concorrência reais |
| Android em dispositivos reais | Pendente | Testes de interface e desempenho |
| Reprodução integral da ROM | Não implementada | Eventos/mapas completos e mecânicas ainda exigem trabalho |

**Comandos de auditoria:** `npm run verify:local` para validação local e `npm run audit:production` para apontar bloqueios de lançamento público. Nunca publicar chaves secretas nem arquivos de saves do servidor.
