# 🌿 Emerald Living World V9.2 — Imagens dos Pokémon

## Correção principal
A Pokédex Quetzal da V9.1 cadastrava 1.025 espécies, mas não criava elementos de imagem nas fichas. A V9.2 adiciona retratos em todas as fichas e nas páginas de detalhes, além de melhorar o carregamento das imagens nas batalhas do mundo online e na Pokédex do simulador offline.

## Como as imagens funcionam
1. O jogo tenta usar os sprites locais que já existiam no pacote anterior.
2. Para Pokémon sem arquivo local, o navegador tenta imagens da coleção pública de sprites da PokéAPI por número da Pokédex Nacional. Fonte: https://github.com/PokeAPI/sprites
3. Se uma imagem não existir ou o servidor não responder, o jogo tenta outras variantes de imagem e exibe o placeholder ao final. Portanto **é necessária conexão à internet** para mostrar imagens que não estavam no pacote.
4. Para registros de **formas internas** sem identidade visual confirmada, mostramos **somente uma imagem da espécie-base**, com aviso. Os **9 slots experimentais** continuam com imagem genérica.
5. **Não são sprites extraídos do Quetzal**. O arquivo `.gba` do usuário não foi incluído nem enviado ao servidor. Antes de publicar recursos gráficos de terceiros, verifique suas permissões de uso.

## O que foi alterado
- `jogo/js/pokemon-art.js`: novo módulo central de resolução e fallback de imagens.
- `jogo/quetzal-pokedex.html`, `jogo/js/quetzal-pokedex.js` e `jogo/css/quetzal-pokedex.css`: imagens nas 48 fichas por página, retrato ampliado, layout Android.
- `jogo/online.html` e `jogo/multiplayer/client.js`: imagem do Pokémon em batalha com fallback nacional.
- `jogo/index.html` e `jogo/js/pokedex.js`: fallback nacional nos cartões da Pokédex do simulador.
- `tests/graphics/pokemon-art.test.cjs`: testes de 1.025 espécies, variantes, placeholders e fallback.
- `tests/browser-v9-2-images.py`: fluxo visual no Android e desktop.

## Testes realizados
- **66/66 testes Node aprovados** ao executar todos os testes `.test.cjs`, incluindo regressões anteriores.
- **Android 390 px e desktop 1280 px**: ficha com imagem, pesquisa Pikachu/Tinkaton/Pecharunt, detalhe ampliado, filtros de formas, 48 imagens por página, sem erro JavaScript e sem rolagem horizontal extra.
- O navegador de teste usou **respostas simuladas para o servidor de imagens externas**, por isso não confirma a disponibilidade real da PokéAPI em todas as conexões. O sprite local de Pikachu foi testado com o arquivo real do pacote.
- O modo online depende de um servidor Node.js para as outras funções, assim como na V9.1. **A hospedagem publicada não foi alterada**.

## Instalação
Faça backup dos saves. Publique a pasta `jogo/` em sua hospedagem estática para a simulação offline e configure o backend `server/` na hospedagem Node.js para o mundo online. O jogo deve continuar com as demais funcionalidades da V9.1; não é preciso reiniciar o mundo para que as imagens sejam exibidas.
