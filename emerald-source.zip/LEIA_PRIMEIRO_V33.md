# 🌿 Emerald Living World 3.3 — Imagens e proporções corrigidas

## O que mudou
- O **Top 6 Pokémon** usa imagens maiores (em geral 92–104 px no mobile) em caixas padronizadas e sem cortes.
- A Pokédex, o time do treinador e outros cards importantes receberam melhor enquadramento.
- A opção **Configurações → Visual dos Pokémon** permite alternar entre **Ilustrações detalhadas** e **Pixel art clássico**, sem alterar saves ou batalhas.
- As ilustrações detalhadas são obtidas do **PokeAPI / sprites públicos** quando há internet. Os 432 arquivos gráficos locais continuam disponíveis como alternativa offline.
- Imagens grandes usam interpolação normal (não pixelada); sprites clássicos mantêm pixels nítidos.

## Sobre a ROM Pokémon Quetzal que você enviou
A ROM foi inspecionada e as tabelas de imagens e paletas foram identificadas. **Não foi possível validar a extração dos sprites completos:** este hack utiliza dados gráficos compactados que não são PNG/GIF prontos para uso. Não incluí a ROM no ZIP e não substituí os sprites por imagens corrompidas ou de identidade incerta. As ilustrações detalhadas usadas nesta versão **não foram extraídas da ROM Quetzal**.

Se for essencial usar exatamente a arte do Quetzal, será necessária a exportação validada das imagens (por exemplo, um pacote PNG identificado por espécie) antes de substituir os arquivos.

## Instalação
Publique o conteúdo deste ZIP na hospedagem, preservando as pastas. Os saves locais existentes não foram modificados. Se uma ilustração externa falhar, o navegador tenta os sprites antigos e depois o ícone neutro.

## Limitações
As imagens detalhadas dependem da disponibilidade do CDN e de internet. Não representam o estilo GBA da ROM original. Esta atualização não constitui um port da ROM Quetzal.
