# 🌿 Emerald Living World 3.0.1 — pronto para Railway

**Este ZIP prepara a hospedagem, mas ainda não cria um servidor na conta Railway.** Você precisa autorizar a conexão com Railway no ChatGPT ou conectar seu repositório à Railway.

## O que foi preparado

- `Dockerfile` Node.js 22 e `deploy/entrypoint.sh` para inicializar em produção.
- `AUTH_MODE=required` e `NODE_ENV=production` por padrão: o servidor recusa iniciar sem Supabase configurado, em vez de abrir o jogo sem login.
- O script ajusta as permissões do **volume persistente** `/data` no início e executa o jogo com usuário `node`.
- O servidor já escuta `0.0.0.0` e usa a variável `PORT` fornecida pela Railway.
- O mundo é salvo em `/data/world.json` e há cópia de segurança `/data/world.json.bak`.
- Não há senha nem chave secreta dentro deste pacote.

## Configuração do serviço

1. Conecte sua conta Railway no ChatGPT ou abra https://railway.com e autorize sua conta.
2. Envie a **pasta extraída** para um repositório privado e crie um serviço na Railway usando esse repositório. O Railway detectará o `Dockerfile` automaticamente. Não envie apenas o ZIP como se fosse uma imagem Docker.
3. **Adicione um Volume ao serviço e monte em `/data` antes de iniciar o servidor.** Não altere esse caminho sem alterar `DATA_DIR`.
4. Configure estas variáveis em **Variables** da Railway:

   | Variável | Valor |
   | --- | --- |
   | `SUPABASE_URL` | URL HTTPS do seu projeto Supabase |
   | `SUPABASE_PUBLISHABLE_KEY` | Chave **publicável** do projeto, obtida no painel Supabase |
   | `AUTH_MODE` | `required` |
   | `NODE_ENV` | `production` |
   | `HOST` | `0.0.0.0` |
   | `DATA_DIR` | `/data` |
   | `TRUST_PROXY` | `true` (apenas atrás do proxy HTTPS da Railway) |
   | `BOT_COUNT` | `20` para o primeiro teste; até `100` conforme recursos disponíveis |
   | `BOT_STEPS_PER_TICK` | `10` para começar |
   | `BOT_TICK_MS` | `1000` para começar |

   Não defina `PORT` manualmente: a Railway fornece o valor. Não coloque a **service_role/secret key** em arquivos públicos, no GitHub ou no cliente.

5. Em **Settings**, configure healthcheck para **`/api/health`**. Gere um domínio público HTTPS. Use **apenas 1 instância/replica**: o mundo usa um arquivo local e não suporta várias replicas gravando simultaneamente nele.
6. Abra `https://SEU-DOMINIO/api/health` e confirme que `ok` é `true`, depois `https://SEU-DOMINIO/jogo/online.html`.
7. Faça login pelo Supabase, verifique que dois navegadores têm perfis próprios e teste a preservação do perfil depois de reiniciar o serviço (com o volume ligado).

## Importante sobre o login

O servidor usa Supabase Auth. O modo `required` **não funciona** até as variáveis Supabase estarem definidas. Não desative a autenticação só para colocar o site no ar. O Supabase usado pelo portal precisa ser o mesmo projeto usado pelo mundo compartilhado; verifique configurações de URL autorizada no Auth.

## Limitações de publicação

- A 3.0.1 é **jogável**, mas o motor Gen III e a Frontier LAB ainda não reproduzem integralmente a ROM. Não chame as medalhas LAB de Símbolos oficiais.
- Railway pode cobrar pelo uso de processamento, memória e volume. Confira os limites no painel antes de ativar um plano pago.
- Faça backups de `/data/world.json` e `/data/world.json.bak`; volume não substitui backup externo.
- Este ZIP **não foi publicado** e não modifica o projeto Supabase existente.

## Checklist de falhas

- `AUTH_MODE=required exige ...`: faltam `SUPABASE_URL` e `SUPABASE_PUBLISHABLE_KEY`/`SUPABASE_ANON_KEY` no serviço.
- `EACCES /data`: confirme que o volume está montado **no mesmo caminho** e que a inicialização usa o `Dockerfile` fornecido.
- Erro 502/sem resposta: confira logs e se a aplicação está ouvindo `0.0.0.0` e a porta fornecida pelo Railway.
- Save desapareceu: confira se o volume foi montado em `/data` **antes do primeiro jogo**, e não em `/app/data`.

Referências oficiais: https://docs.railway.com/volumes e https://docs.railway.com/networking/troubleshooting/application-failed-to-respond
