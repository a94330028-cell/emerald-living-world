# 🌿 Emerald Living World — Patch Visual 2.5

**Novo:** visual ilustrado verde-esmeralda inspirado na referência enviada, Pokédex vermelha completa, tema escuro persistente, retrato do treinador com a equipe ao lado no Jogo e no PC, cartões de Rank renovados e ferramentas técnicas recolhíveis.

**Mantido:** código completo da Versão 2.5, sprites 32×48, mapas, 100 bots, batalha, captura, evolução, ranking, saves, páginas secundárias e servidor experimental.

**Testes:** 121/121 testes automatizados passaram. A interface foi avaliada em prévia visual isolada; o navegador automatizado bloqueou o teste do jogo completo.
