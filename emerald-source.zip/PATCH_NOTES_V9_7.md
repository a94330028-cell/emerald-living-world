# 🌿 Patch Notes — Emerald Living World V9.7

**Minha Jornada: decisões e interface simplificada**

- Nova tela de entrada: mapa do jogo, Pokémon e seleção de modo.
- Opção de iniciar com **apenas 1 bot pessoal**; outras simulações preservadas.
- O bot pessoal espera sua decisão antes dos rivais em etapas importantes.
- Treinamento em encontros selvagens nas rotas principais antes de enfrentar o rival.
- Batalhas por turnos com escolha do golpe, troca de Pokémon e uso dos itens disponíveis.
- Alternância entre golpes manuais e automáticos.
- Interface do bot reorganizada para Android; painel de equipe, missão e combate em primeiro plano.
- Outros treinadores pausados e ocultos no mapa durante o modo solo.
- Preservados: Pokédex Nacional, 27 iniciais, saves, evolução, habitats, 100 IAs no modo de simulação, rankings, online experimental e arquivos de sprites V9.6.

**Testes:** a nova interface passou nos cenários Android e desktop. No último conjunto, 91/92 testes gerais passaram; um teste legado de EXP/evolução do bot mostrou instabilidade ao rodar com a suíte completa (mas passou isoladamente). A campanha completa continua em desenvolvimento.
