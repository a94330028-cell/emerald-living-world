# 🌿 Emerald Living World V9.11 — Jogo, equipe e ranking no mesmo lugar

Esta versão parte da V9.10. O objetivo foi resolver a separação indevida entre jogo, time e ranking, e trazer o Top 6 Pokémon mais fortes para a página Rank.

## Como ficou a navegação

- **Jogo:** mapa animado e equipe observada, ranking rápido por insígnias e mini Top 6. No modo “Só meu bot”, aparecem seu time e o mesmo ranking rápido na tela Minha Jornada.
- **Pokémon:** equipe detalhada e Pokédex.
- **Rank:** lista completa por insígnias, times mais fortes, Pokémon mais forte do mundo e Top 6 Pokémon mais fortes, calculados com a potência atual dos Pokémon de cada bot. O Top 6 considera os Pokémon no time e no PC.
- **Outras páginas:** Créditos, Recuperação/saves, Histórico, Hall da Fama, Mapa, Corrida e demais áreas preservadas no menu secundário.

O menu principal continua com somente **Jogo, Pokémon e Rank**.

## O que foi corrigido

1. A página Rank anteriormente mostrava só as insígnias. A comparação de times e o Top 6 ficavam escondidos em “Rankings de força”. Agora também aparecem em Rank, sem precisar procurar outra página.
2. O ranking rápido e o Top 6 aparecem junto do mundo e do time no modo observador e no modo de um único bot.
3. Os dados são computados diretamente das equipes e PCs no estado atual do simulador; não são Pokémon fictícios nem registros inventados.
4. Quando uma imagem externa falhar, o espaço passa a mostrar uma imagem reserva em vez de ficar vazio.

## Testes realizados

- `npm test`: **97/97 testes passaram** na rodada registrada em `tests/v9_11_test_output.log`.
- `python3 tests/browser-v9-11.py`: testou a interface Chromium em 390×844 px nos modos observador e solo usando equipes de exemplo injetadas somente durante o teste. Conferiu 6 Pokémon no Top 6 da página Rank, 6 miniaturas no Jogo, navegação e ausência de erros JavaScript; relatório `tests/v9_11_ui_report.json`.
- Os dados de exemplo do teste visual **não** são inseridos no jogo distribuído.

## Limitações que continuam

- Os mapas oficiais de Hoenn podem exigir dados externos; quando não carregam, usa-se o cenário adaptado da V9.10.
- O modo MMO ainda necessita de servidor Node.js persistente e não reproduz toda a campanha original.
- Sprites externos de Pokémon recentes podem depender de internet; imagens de reserva são exibidas quando necessário.
- O teste visual não é uma validação da campanha inteira, nem garante ausência de bugs em todos os mapas.

**Publicação:** faça backup dos saves antes de atualizar. A V9.11 é um pacote de arquivos completo para substituir os arquivos da hospedagem; ela não altera automaticamente o site publicado.
