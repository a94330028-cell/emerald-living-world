# Emerald Living World — Versão 2.5 | Interface Esmeralda + Tema Escuro

## Alterações incluídas
- **Visual do site baseado na referência enviada:** cabeçalho de Hoenn com Pokémon, molduras verde-esmeralda, equipe do treinador, Pokédex em estilo dispositivo vermelho e Rank em cartões de Liga.
- **Tema Esmeralda** como padrão; **Tema Escuro** opcional no botão do cabeçalho ou em Configurações. A preferência visual fica separada dos saves sob a chave `elw_visual_theme_25` no navegador.
- **Jogo:** mapa real da simulação aparece antes dos controles. Retrato do treinador observado com os Pokémon de sua equipe ao lado; os seis espaços são mantidos e preenchidos com os dados reais.
- **Minha Jornada:** retrato ao lado dos Pokémon também no modo de um único bot.
- **PC:** na página Configurações, o treinador selecionado aparece com a equipe de até seis Pokémon ao lado de seu retrato, antes da lista de Pokémon guardados. Na campanha manual legada, a aba PC também mostra a equipe ao lado da imagem do treinador.
- **Pokédex:** mantém a busca, os filtros, o catálogo de 1.025 espécies e fichas baseadas nos dados reais. A prévia da página Jogo abre a Pokédex completa.
- **Rank:** preserva as insígnias, times e Top 6 já calculados pela simulação. O visual é atualizado, mas não usa placares ou Pokémon fictícios da imagem de referência.
- **Batalhas, câmera e depuração:** continuam disponíveis em seções expansíveis, para que a interface principal não fique sobrecarregada.

## Arquivos modificados
- `jogo/index.html`
- `jogo/js/player.js`
- `jogo/js/pokemon-illustrated-ui.js` (novo)
- `jogo/css/pokemon-illustrated-25.css` (novo)
- `tests/visual/pokemon-illustrated-ui.test.cjs` (novo)

## Validação
- `npm test`: **121/121 testes passaram** na última execução.
- `node --check` passou nos scripts de interface alterados.
- Prévia visual isolada em Chromium com viewport Android (393 × 852): troca de tema funcionou, cartão do treinador mostrou os quatro Pokémon de exemplo ao lado do retrato, sem rolagem horizontal e sem erros de JavaScript no teste. As prévias isoladas usam dados de exemplo e um mapa ilustrativo para validar apenas a disposição visual, não os resultados de uma jornada real.
- Não foi possível fazer um teste completo do jogo no navegador automatizado porque o ambiente bloqueou o acesso à página local. Ainda é necessário conferir o mundo completo no seu navegador Android após publicação.

## Instalação
1. Faça backup do seu save no menu **Recuperação**.
2. Extraia este ZIP mantendo `index.html` na raiz e as pastas `jogo/`, `server/` e `tests/`.
3. Publique a pasta extraída na sua hospedagem. A entrada web começa por `index.html`.
4. Ao abrir o jogo, toque em **🌙 Escuro** no cabeçalho para alternar para o tema noturno; toque em **☀️ Claro** para voltar.
5. O multiplayer continua dependendo de um servidor Node.js ativo. Uma hospedagem estática só executa os recursos offline.

## Limitações preservadas
O visual não resolve automaticamente problemas de colisão ou falta dos mapas oficiais; a campanha compartilhada ainda não reproduz toda a ROM. O gráfico original de cada mapa depende de recursos existentes no projeto e, em certos casos, de carregamento externo. O pacote não contém ROM nem redistribui a ROM do Quetzal.
