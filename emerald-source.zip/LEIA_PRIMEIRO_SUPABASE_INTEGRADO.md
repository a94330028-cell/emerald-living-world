# Emerald Living World — Integração Supabase

## Confirmado no Supabase conectado

- Projeto: Emerald Living World (sa-east-1), com URL pública configurada em `jogo/js/cloud-config.js`.
- As tabelas `elw_saves`, `elw_leaderboard`, `elw_admins`, `elw_profiles` e analytics já existem.
- As políticas RLS de saves limitam o acesso à própria conta; o ranking publica dados de classificação.
- As Edge Functions `admin-dashboard`, `public-stats` e `telemetry` estão publicadas.
- A conta administrativa vinculada ao e-mail autorizado está no banco, mas o e-mail **ainda precisa de confirmação**.

## Mudanças deste pacote

- Liga o frontend ao Supabase existente usando **chave pública anon** (não é segredo).
- Corrige a requisição da página de estatísticas para incluir o cabeçalho Authorization exigido pelo backend publicado.
- Atualiza URLs canônicas e metadados para o endereço atual `emerald-living-dezin.fantasticbell.chatgpt.site`.
- Preserva saves locais, mapas e simulação.

## Para concluir a ativação

1. No Supabase, abra Authentication → URL Configuration e defina Site URL como `https://emerald-living-dezin.fantasticbell.chatgpt.site/jogo/index.html`. Adicione também esse URL como Redirect URL.
2. No Supabase, em Authentication → Providers → Email, mantenha confirmação de e-mail ativada.
3. Confirme o endereço de e-mail da conta ADM pelo link recebido. NÃO precisa criar novo administrador nem alterar os IDs.
4. Publique este ZIP na hospedagem, substituindo os arquivos antigos. **O ZIP local não modifica automaticamente o site remoto**.
5. Teste cadastro, login, recuperação de senha, sincronização e acesso ao `/admin`.
6. As salas de chat dependem de executar `supabase/community_chat.sql` caso ainda não estejam criadas e de moderação humana. Não anuncie chat ativo antes de validar com duas contas confirmadas.

**Segurança:** nunca publique chaves service_role/secret nem senhas. A RLS foi mantida. O ranking mundial não comprova resultados competitivos; a simulação roda no cliente.

## Validação pendente

Sem possibilidade de alterar as configurações de Auth do projeto por este conector ou publicar no host `fantasticbell.chatgpt.site`, a validação ponta a ponta do site remoto depende dos passos acima.
