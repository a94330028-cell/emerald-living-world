# 🌿 PATCH NOTES — V9.3 • NATIONAL AI

- __**Pokédex Nacional aplicada às IAs offline e online.**__
- 1.025 espécies com atributos-base, tipos e experiências disponíveis no simulador; 494 registros de formas alternativas opcionais.
- Encontros variáveis por habitat e progresso, com preservação dos Pokémon tradicionais de Hoenn.
- Mais diversidade nos times dos bots, capturas via batalha e persistência em equipe/PC.
- Evoluções conhecidas dos iniciais de várias gerações e fallback visual para espécies novas.
- Novas opções de encontros nacionais e formas especiais.
- __**72/72 testes aprovados**__; 100 bots testados durante 400 decisões por bot no motor Node.

-# Atenção: ainda faltam learnsets e evoluções completas, efeitos de habilidades, sprites próprios de formas alternativas e os cinco ginásios finais no servidor.
