# 🌿 Emerald Living World V9.14 — 20 sprites 32×48 e NPCs

## Correção solicitada

Todos os 20 personagens enviados foram copiados para `jogo/assets/overworld/characters/` com nomes separados. **Todos os quadros-fonte são 32×48 px**, distribuídos em folhas de 96×192 px com 12 quadros, quatro direções e três quadros por direção. As versões legadas 16×32 foram retiradas das entradas de renderização e dos arquivos ativos.

Os personagens incluídos são: Brendan, May, Red, Leaf, Ethan, Dawn, Rosa, Serena, Lyra, Lucas, Hilbert, Hilda, Nate, Calem, Elio, Selene, Victor, Gloria, Florian, Juliana.

Os três renderizadores (`jogo/js/world.js`, `jogo/js/official-maps.js` e `jogo/multiplayer/client.js`) consultam o catálogo único `jogo/client/animation/trainer-sprites.js`. No mapa de tiles 16×16, a imagem 32×48 é **reduzida somente na exibição** para preservar proporção visual e não ocupar dois blocos de colisão. Isso **não usa arquivos 16×32**; o sprite-fonte continua sempre 32×48.

O modo online oferece os 20 visuais no seletor de personagem. IAs novas distribuem esses visuais sem alterar Pokémon ou progresso. Perfis e saves antigos permanecem compatíveis.

## NPCs de desafio

Foram adicionados **10 treinadores opcionais** nos mapas adaptados de Route 101, Route 102, Route 103, Route 104, Petalburg Woods, Route 104 Norte, Route 116, Route 106, Granite Cave e Route 110. Eles têm visual dos personagens enviados e equipe própria. O motor de batalha exige ações reais para vencer; NPC derrotado fica registrado no save e não pode ser vencido novamente pelo mesmo perfil. As IAs autônomas podem enfrentá-los após obterem a primeira insígnia e avançarem na etapa de evolução inicial.

**Limite importante:** os NPCs estão nos *mapas adaptados do servidor*, não posicionados segundo os dados oficiais da ROM Quetzal. Não são 10 novos eventos para a campanha offline. O motor do online continua simplificado e a campanha compartilhada não está concluída.

## Testes reproduzíveis

- `npm test`: **105/105** testes automatizados passaram na execução final; o teste de evolução de IA tinha falhas intermitentes anteriormente e não constitui garantia de estabilidade total.
- `python3 tests/browser-v9-13-facing.py`: navegador Chromium com tela Android, imagens dos personagens carregadas, marcha nas quatro direções testadas no motor, retenção de direção, sem erro JavaScript observado; snapshot de multiplayer simulado.
- `node --test tests/multiplayer/v9-14-npcs.test.cjs`: NPCs não atravessáveis, batalhas reais, registro de vitória e impossibilidade de captura de Pokémon alheio.

## Como usar

- Abra o modo offline em `jogo/index.html`.
- Para o modo online: `npm start` com Node.js 20+ e acesso a servidor persistente.
- Faça backup de seus saves antes de atualizar.
- A ROM Pokémon Quetzal não está incluída.
- Seu site publicado não é atualizado automaticamente pela entrega deste ZIP.
