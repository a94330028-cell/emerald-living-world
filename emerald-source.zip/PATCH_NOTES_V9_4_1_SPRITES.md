# 🌿 Emerald Living World V9.4.1 — Correção de Sprites e Movimentação

## O que foi implementado

### ✅ Sistema centralizado de sprites
- Novo catálogo único de sprites para **Brendan** e **May**.
- Atlas validado em **48×128** com **12 quadros** (**3 colunas × 4 linhas**, células **16×32**).
- Metadados centralizados: identificador, atlas, hitbox, direção e velocidade.
- Mesmo sistema reaproveitado no:
  - mapa principal (`jogo/js/world.js`)
  - modo online (`jogo/multiplayer/client.js`)
  - visualizador técnico de mapas oficiais (`jogo/js/official-maps.js`)

### ✅ Animação de caminhada corrigida
- Quatro direções padronizadas:
  - cima
  - direita
  - baixo
  - esquerda
- Quadro parado preserva a última direção.
- Alternância de passos centralizada, evitando inconsistências entre telas.

### ✅ Modo de depuração visual
Na tela principal de exploração agora existem controles para visualizar:
- **tiles bloqueados**
- **caminhos**
- **hitboxes**

### ✅ Estrutura preparada para reutilização pelas IAs
- O render dos treinadores agora depende de um catálogo único.
- Brendan e May usam a mesma lógica de atlas, hitbox e seleção de frames.
- Isso evita criar lógica separada para cada treinador/IA.

## Arquivos alterados
- `jogo/client/animation/trainer-sprites.js` **(novo)**
- `jogo/js/world.js`
- `jogo/multiplayer/client.js`
- `jogo/js/official-maps.js`
- `jogo/index.html`
- `jogo/online.html`
- `jogo/mapas-oficiais.html`
- `tests/animations/trainer-sprites.test.cjs` **(novo)**

## Validação executada
- `npm test`
- **82 testes aprovados / 0 falhas**

## Observação
Esta atualização **preserva** os sistemas existentes do projeto e adiciona a base organizada para as correções visuais e de movimentação pedidas, sem remover:
- 100 IAs
- batalhas
- capturas
- evolução
- rankings
- top 6 Pokémon mais fortes
- seleção de iniciais de todas as gerações
