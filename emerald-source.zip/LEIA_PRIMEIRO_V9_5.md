# 🌿 Emerald Living World V9.5 — Sprites, habitats e navegação

**Esta entrega é o projeto completo atualizado, não um patch isolado.** Foi construída sobre os arquivos da V9.4.1 e preserva o sistema offline, o online experimental, o catálogo do Quetzal, batalhas, capturas, evoluções, times, ranking e saves no formato existente.

## Instalar

1. **Faça backup dos saves** antes de substituir a versão antiga.
2. Extraia o ZIP mantendo a estrutura de pastas. O arquivo `index.html` deve ficar na raiz.
3. Para o simulador offline, use uma hospedagem de arquivos estáticos e abra `jogo/index.html` (a raiz redireciona para ele).
4. Para o multiplayer persistente, instale Node.js 20 ou superior, entre na pasta raiz e execute:

   ```sh
   npm start
   ```

   Abra `http://localhost:8787/jogo/online.html` no navegador do dispositivo que executa o servidor. Para oferecer o site a outros usuários, é necessário configurar hospedagem com processo Node persistente, HTTPS e volume de dados persistente.

5. Para iniciar com 100 bots, defina `BOT_COUNT=100` na configuração do ambiente do servidor antes de iniciar. O valor é limitado a 5–100. Mude `BOT_TICK_MS` conforme a capacidade do servidor.

**Importante:** a V9.5 *não foi publicada automaticamente* no seu site. Este ZIP não contém a ROM GBA, nem redistribui os gráficos extraídos do Quetzal. O catálogo contém nomes, tipos, estatísticas-base e localizações **adaptadas** do simulador.

## Principais modificações

- **Sprites/visual:** V9.4.1 mantida: `jogo/client/animation/trainer-sprites.js`, quadros por direção e debug de hitboxes no simulador. O online agora tem controles próprios de colisões, rotas e hitboxes.
- **Habitat individual:** `jogo/game/pokemon/national-habitats.js` contém **1.025 políticas explícitas por espécie**. A Pokédex informa os locais de captura adaptados e a restrição de insígnias. Eles **não são os encontros oficiais do Quetzal**.
- **Áreas seguras:** cidades, laboratórios, Centros Pokémon e Poké Marts continuam sem encontros selvagens comuns. Os primeiros caminhos usam listas curadas e não sorteiam todo o catálogo.
- **Encontros especiais:** espécies especiais (como lendários de baixa taxa de captura) são registradas como `special` e não aparecem em encontros selvagens normais. A captura por eventos ainda precisa ser implementada para elas.
- **Navegação das IAs:** o servidor guarda rotas temporariamente em memória, reutiliza trajetos válidos e recalcula após mudança de destino, mapas, permissão ou passo bloqueado. Não aumenta insígnias nem cria capturas para resolver obstáculos.
- **Mapas do servidor:** ligação adicional Oldale ↔ Route103; NPCs fixos de eventos atuam como obstáculos. **São 28 mapas ADAPTADOS, não a geografia integral da ROM**.
- **Interiores:** Centro Pokémon e Poké Mart compartilhados continuam usando `returnDoor` para retornar à cidade correta. Adicionada auditoria de portas e destinos.
- **Online:** o quadro mostra NPCs de teste e informa quantas espécies podem ser encontradas na área; nova API de habitats e encontros. A simulação offline ainda utiliza mapas oficiais sob demanda e mapas de recuperação.

## Testes executados nesta entrega

- `npm test`: **89 de 89 testes passaram**, incluindo progresso de campanha até Wattson, batalha, EXP, salvamento, NPCs bloqueados, 100 bots caminhando e tabelas de captura.
- `npm run test:maps`: **61 de 61 conexões passaram em 28 mapas adaptados**; relatório `tests/v9_5_map_audit.json`.
- `npm run test:android:offline`: Chromium Android verificou a Pokédex, seleção de 27 iniciais, equipe única e Top 6, sem erro JavaScript observado.
- `npm run test:android:online`: Chromium Android verificou sprites, toggles de depuração, layout e informação de área usando **dados simulados de servidor**, porque o Chromium isolado bloqueou o acesso direto ao `localhost`.
- APIs reais testadas por HTTP nos testes Node (incluindo os habitats `/api/habitats/906` e `/api/encounters`).

## Limitações conhecidas / próximo trabalho técnico

- O **mapa oficial completo** de Hoenn, posições originais dos NPCs, animações de todos os NPCs e todos os interiores da ROM ainda **não** foram importados/validados.
- Os sprites de Brendan/May usam os atlases locais já existentes do projeto. Não houve extração de gráficos dessa ROM Quetzal na V9.5, nem prova de fidelidade quadro a quadro com o jogo original.
- No servidor, os **100 bots ainda podem sobrepor visualmente uns aos outros** ao caminhar pelo mesmo tile. As colisões adicionadas impedem paredes e NPCs fixos; não implementam reserva de tile para toda a multidão.
- O bot online ainda avança pela **campanha funcional até três insígnias**. O caminho até Wallace não foi concluído neste servidor; a simulação offline anterior é um motor distinto.
- O motor online não implementa todos os golpes, efeitos, habilidades e evoluções do Quetzal. 1.025 espécies cadastradas não equivalem a 1.025 espécies com mecânicas completas.
- Encontros dependem do tipo de ambiente e progressão adaptada, **não** das tabelas binárias de encontros do Quetzal.
- O modo online é uma **beta privada**, sem sistema de contas verificadas ou infraestrutura de moderação pública.

## Arquivos centrais

- `jogo/game/pokemon/national-habitats.js` — localizações geradas por espécie.
- `jogo/game/pokemon/national-pools.js` — filtros por mapa/insígnias.
- `tools/build-national-habitats.cjs` — reproduz a tabela a partir do catálogo.
- `server/navigation.cjs` — rotas e cache de navegação.
- `server/world.cjs` — colisões, NPCs, portas e 28 mapas de teste.
- `server/app.cjs` — API do mundo e habitats.
- `jogo/multiplayer/client.js` — render e depuração Android.
- `tools/audit-world.cjs` — auditoria mapa a mapa.
- `tests/v9-5-habitats-navigation.test.cjs` — testes de bloqueios e 100 bots.
- `tests/v9_5_online_android.png` — captura de tela da interface Android de teste.

**Nenhum save foi apagado intencionalmente.** Uma nova publicação não significa que saves locais de outro navegador sejam automaticamente transferidos para o servidor online. Exporte-os antes de atualizar.
