# 🌿 Emerald Living World 2.6 — Hoenn conectado por setores

## Instalação

Extraia este ZIP e publique **todo o conteúdo**, mantendo `index.html` e a pasta `jogo/` na raiz da hospedagem estática. Não basta enviar apenas o HTML. Em navegador Android, abra o endereço público gerado pela hospedagem.

O servidor Node (`server/`) e os recursos experimentais multiplayer continuam no pacote, porém **não são executados por hospedagem puramente estática**. Não alteramos as chaves dos saves locais nem a estrutura do cadastro em nuvem.

## Mapas conectados

**A costura da câmera do modo Jogo** é feita com as conexões e os offsets descritos pelos arquivos oficiais `data/maps/.../map.json` de `pret/pokeemerald`, sem adicionar atalhos artificiais. Há suporte para 52 mapas externos nominalmente elegíveis: as 34 rotas (101–134), as vilas/cidades do roteiro e as áreas externas de Jagged Pass e Mt. Chimney.

- Sul: Littleroot, Route 101, Oldale, Route 102/103, Petalburg, Route 104, Rustboro.
- Centro: Dewford, Slateport, Route 109/110, Mauville, Route 116/117/118, Verdanturf.
- Norte: Route 111–115, Fallarbor, Lavaridge, Jagged Pass, Mt. Chimney.
- Leste: Route 118–123, Fortree, Lilycove.
- Mar: Route 105–109 e 124–134, Mossdeep, Pacifidlog, Ever Grande.
- Sootopolis é um exterior **isolado do mar pela entrada de Dive** e NÃO recebe uma conexão marítima falsa.

**Importante:** locais separados no Emerald continuam sendo transições: Petalburg Woods, Rusturf Tunnel, Fiery Path, Meteor Falls, cavernas, os andares de Mt. Pyre/Sky Pillar, ginásios, casas, bases de vilões, Safari Zone, interiores da Liga/Victory Road, Seafloor Cavern, fundo do mar, etc. O teleférico também continua usando sua transição própria. As duas partes de Route 104 permanecem no mesmo arquivo externo, mas Petalburg Woods é independente.

## Carregamento e Android

- O jogo descobre o mapa externo atual e somente os vizinhos acessíveis pelas **conexões reais** (nunca pelos atalhos abstratos do grafo de missões).
- A renderização usa setores de **16×16 blocos** e desenha apenas setores da câmera e dos arredores; a memória mantém até **56 setores gráficos** reutilizáveis.
- O navegador reutiliza PNGs, tilesets, paletas e sprites carregados anteriormente. Os sprites dos 18 personagens adicionais não são baixados antecipadamente; Brendan e May são aquecidos na abertura.
- O CacheStorage guarda os arquivos oficiais buscados com sucesso para acelerar visitas posteriores. O armazenamento pode ser limpo pelo navegador/Android e depende da quota disponível.
- O motor anterior continua gerenciando 100 IAs fora da câmera por turnos e orçamento de processamento; apenas seus sprites próximos são renderizados. Progresso fora da câmera é distinto de continuar processando quando a aba do navegador está suspensa.
- O botão "Mapa inteiro" no exterior mostra um panorama topológico leve dos setores carregados; não tenta renderizar todos os mapas e imagens de Hoenn de uma só vez.

## Testes efetuados

- `npm test`: **138 de 138** testes Node passaram (inclui seis testes novos do grafo externo, offsets, câmeras, Sootopolis, warps e prefetch).
- `python tests/browser-v9-15.py`: interface móvel, sprites, velocidade e armazenamento, **sem erros JavaScript**.
- `python tests/browser-v26-connected.py`: navegador Chromium móvel simulado 390×844, dois mapas sintéticos adjacentes renderizados no mesmo canvas, sem rolagem horizontal e **sem erros JavaScript**.
- Desempenho **sintético**: 100 objetos de treinadores distribuídos em dois mapas fictícios; 12 chamadas de renderização registraram ~**5,37 ms por quadro** neste ambiente de teste. Esse teste usa chunks gráficos simulados e **não equivale** a testes em telefone Android real com gráficos oficiais baixados.
- O teste existente que verificava um sufixo de versão antigo foi atualizado para validar a presença dos scripts sem depender de um valor fixo da query string.

## Limitações e verificação externa

Os gráficos e os dados oficiais não estão inteiramente embutidos no ZIP: o projeto original os obtém de `raw.githubusercontent.com/pret/pokeemerald` no primeiro acesso. Sem conectividade ou se a fonte estiver indisponível, o sistema existente apresenta mapas adaptados, **não** um substituto idêntico ao Emerald. A costura externa fiel requer que os arquivos oficiais tenham carregado; não foi possível verificar cada conexão de Hoenn contra o repositório remoto neste ambiente.

Os scripts específicos da campanha original (HMs, correntezas, obstáculos de história, cutscenes e warps condicionais) não foram reconstruídos completamente nesta entrega. O novo compositor não altera essas regras nem concede passagem extra. O visualizador técnico separado `mapas-oficiais.html` também continua independente; a câmera contínua foi integrada ao canvas principal da página **Jogo**.

Antes de substituir sua publicação, exporte um backup dos saves quando possível. Recarregue a página para atualizar os scripts em cache.
