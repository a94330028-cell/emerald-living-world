# 🌿 Emerald Living World 3.0 RC7 — Regras e integridade da Frontier

## Battle Dome — torneio consistente

- Chave de 16 inscritos e 15 confrontos (8 quartas de chave iniciais, 4 na segunda rodada, 2 semifinais e final).
- Os adversários dos quatro confrontos do jogador são escolhidos por uma única simulação de chave; não são sorteados novamente entre rodadas.
- As vitórias do jogador só são registradas após o resultado da batalha no servidor. Os confrontos entre NPCs seguem simulação, identificada na interface.
- Tucker ocupa uma **vaga entre os 16 participantes**, quando aparece, e seus três Pokémon inscritos podem ser consultados antes da seleção de dois para o confronto LAB.
- Uma visualização detalhada da chave foi adicionada à página da Frontier, inclusive para celular.

## Battle Pike — contagem original

- Corrigido o tamanho do bloco: **14 salas por sequência** no Emerald original.
- Lucy permanece nos desafios de sala **28 (Prata) e 140 (Ouro)**, sem liberação de Símbolos oficiais.
- Pistas, portas e eventos existentes foram mantidos.

## Integridade dos desafios

- Um desafio ativo agora bloqueia movimentos pelo mapa, troca de canal, compras, curas externas, eventos de história e início de batalhas fora da Frontier.
- Trocar para o modo espectador durante o desafio também é bloqueado, evitando deixar a sessão presa.
- Ao abandonar a sequência, a navegação e o atendimento no Centro Pokémon são liberados.
- Eventos e recursos próprios da Frontier, inclusive a Battle Bag da Pyramid, permanecem acessíveis conforme suas regras.

## Preservação garantida por hash

- Criado `ASSET_PRESERVATION_RC6.json` com os hashes SHA-256 de **8 arquivos protegidos** — seis arquivos de catálogos, habitats, pools e Dex, mais dois arquivos da Arena Competitiva.
- Novo comando `npm run audit:preservation` para verificar que nenhum desses arquivos mudou.
- A campanha, Liga, batalha Double de Tate e Liza, saves, contas, 100 bots configuráveis e Frontier Pass LAB foram mantidos.

## Limitações

Esta versão ainda é candidata de lançamento. Os confrontos da Frontier continuam sendo uma adaptação LAB; sem validação integral do motor Gen III, sem Símbolos oficiais e sem homologação de produção. A simulação entre NPCs do Dome não é um motor completo de batalhas independentes. As espécies capturáveis pelos bots **não foram removidas**.
