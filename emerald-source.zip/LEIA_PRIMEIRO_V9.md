# Emerald Living World V9 — Multiplayer integrado (BETA)

## Propósito

Esta versão parte da **V8.1**, conserva o simulador offline e os arquivos existentes e melhora o encontro entre um visitante e as IAs persistentes do servidor. **Não é o Quetzal rodando no navegador, não usa os mapas/sprites extraídos do Quetzal e não é um MMO completo.**

## O que mudou de verdade

1. **Desafio contra um bot real do servidor:** quando um visitante está perto de um bot no mesmo canal, o motor usa os Pokémon reais do bot (IDs, IVs, EVs, níveis, HP, golpes e time, quando reconhecidos pelo motor). O HP dos adversários durante o duelo é gravado no estado do bot; o bot fica pausado até o fim. Um segundo visitante não pode desafiar o mesmo bot simultaneamente. Batalhas abandonadas expiram sem premiar vitória ou insígnia.
2. **Encontrar uma IA a pé:** botão `🧭 Encontrar IA (explorador)` no observatório, com direção e trilha na tela. A rota é calculada pelo servidor a partir das colisões e das passagens desbloqueadas; não teletransporta nem atravessa portas bloqueadas.
3. **Rotas dos interiores compartilhados:** ao sair de um Centro Pokémon ou Poké Mart, a navegação respeita a cidade pela qual o treinador entrou.
4. **Resiliência da IA contra o rival:** após derrotas repetidas na Route 110, um bot passa a treinar um segundo Pokémon por meio de encontros reais e então tenta novamente, sem ganhar níveis ou vitórias artificiais.
5. **Compatibilidade local Quetzal:** corrigida a fórmula de checksum do cabeçalho GBA (0xE7). A ROM recebida foi identificada localmente como `PKM QUETZAL`, código `BPEE`, 32 MiB. O `rom-lab.html` agora identifica o cabeçalho como Quetzal. **Offsets de sprites, tilesets, metadados de NPCs e mapas NÃO foram verificados.**

## Executar

Requer Node.js 20+ e uma máquina/servidor que rode Node continuamente.

```bash
cd emerald-living-world
npm test
npm start
```

Abrir `http://127.0.0.1:8787/jogo/online.html`. Em outra aba ou navegador, crie outro visitante no mesmo canal. Use o observatório para escolher uma IA, clique em **Encontrar IA**, siga as setas e, a até 3 blocos, use **Desafiar bot** no laboratório de batalha.

Para apenas olhar uma ROM local autorizada: `http://127.0.0.1:8787/jogo/rom-lab.html`; escolha o `.gba` no dispositivo. O arquivo não é enviado ao servidor e NÃO é necessário para a simulação. A ferramenta ainda não identifica offsets gráficos automaticamente.

Configurações do servidor: `BOT_COUNT=5..100`, `BOT_TICK_MS=650` (ajustável), `DATA_DIR` apontando para armazenamento persistente, `HOST` e `PORT` conforme a hospedagem. O backend usa arquivo JSON gravado atomicamente, não banco de dados de produção. Exemplo: `HOST=127.0.0.1 PORT=8787 npm start`.

**Atenção:** antes de atualizar, copie a pasta de dados do servidor e exporte saves locais. Não envie a ROM junto ao ZIP. Um servidor acessível pela internet precisa de autenticação real, moderação do chat, HTTPS, rate limits por IP e armazenamento robusto. Não exponha esta beta publicamente como serviço de produção.

## Testes e evidências

- `npm test`: testes de batalhas, evolução, navegabilidade, visita, concorrência, persistência, 20/100 bots, duelos V9 e cabeçalhos GBA. O resultado atual está em `tests/v9_node_test_log.txt`.
- `python tests/browser-v9.py`: Chromium em resoluções Android e desktop, com API simulada (neste ambiente o Chromium não conecta a localhost). Resultado em `tests/v9_browser_report.json`, capturas `tests/v9_android_spectator.png` e `tests/v9_desktop_online.png`.
- `node --test tests/multiplayer/v9-api.test.cjs`: **API Node real**, duas sessões simultâneas, rota, bloqueio de duelo concorrente, HP da IA persistente no disco.
- Com sua própria ROM disponível: `node tools/inspect-gba.cjs /caminho/arquivo.gba`. Relatório de fingerprint, sem extração, em `tests/v9_quetzal_compatibility.json`. `EMERALD_TEST_ROM=/caminho/arquivo.gba python tests/browser-v9-rom-local.py` valida somente o laboratório visual. A ROM não está incluída no pacote.

## Limitações importantes

- Ainda são **27 áreas adaptadas** no servidor e jornada real demonstrada até Wattson (3 insígnias); mapas oficiais de Hoenn e história completa ainda não foram integrados à camada online.
- O motor online usa um **catálogo parcial** de espécies e golpes, não implementa todas as habilidades, itens e batalhas duplas da terceira geração.
- Os bots exploram por objetivos e batalhas, mas suas ações no duelo contra visitantes usam a seleção de movimentos do motor de batalha, não um controlador estratégico PvP completo.
- A página principal offline preservada continua separada do servidor de mundo compartilhado.
- O Quetzal fornecido não foi incluído nem seus gráficos redistribuídos. Identificar o arquivo não comprova que seu mapa, NPCs ou sprites possam ser importados com segurança. A extração precisa ser analisada especificamente para essa versão, com autorização para usar e distribuir os recursos.

## Próximas prioridades

Resolver e testar os metadados das portas e NPCs em um mapa real, criar um formato canônico de mapa compartilhado para jogador e IA, integrar os frames reais do personagem a partir de recursos autorizados e só então ampliar as jornadas para os ginásios restantes. Nenhum desses itens é declarado concluído na V9.
