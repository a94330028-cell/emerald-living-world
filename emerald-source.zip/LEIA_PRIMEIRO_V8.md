# 🌿 Emerald Living World V8 — Três insígnias verificadas

## Qual é o estado real?

Esta atualização amplia o servidor autônomo da V7 até **Roxanne, Brawly e Wattson**, utilizando *áreas adaptadas* conectadas. **Não é Pokémon Emerald completo nem um MMO pronto para publicação pública.** A interface e os arquivos do simulador offline da V6/V7 continuam presentes e separados do modo online.

### Melhorias concretas

- O backend agora dispõe de **27 mapas adaptados** com geometrias, portas, coordenadas de chegada e travas por evento. Cada passo, inclusive dos bots, passa pela mesma função `world.step` usada por visitantes.
- A jornada autônoma segue Littleroot → Rustboro → Rusturf Tunnel (resgate de Peeko por batalha) → viagem com Mr. Briney → Dewford → Granite Cave (entrega da carta a Steven) → Ginásio de Brawly → Slateport → Route 110 (rival) → Mauville (Wally) → Ginásio de Wattson.
- Todas as três insígnias exigem derrotar **a equipe inteira** do líder utilizando o motor `server/battle.cjs`. Não há insígnias por entrar no prédio, andar um número de passos ou passar o tempo.
- Os bots podem procurar Pokémon de Grama para Roxanne, de tipo Voador para Brawly e de tipo Terra para Wattson. Eles recuperam a equipe, treinam com batalhas, escolhem golpes/trocas e tentam novamente após derrotas.
- Compras de Poké Bolas são debitadas do dinheiro real do treinador no **Poké Mart** (`server/shop.cjs`). Não há reposição gratuita automática de capturas.
- Jogadores podem usar a interface online para enfrentar líderes e treinadores da história, interagir com Steven e comprar itens quando estiverem nos locais corretos.
- Portas bloqueadas por evento/insígnia são identificadas com cor diferente na interface; o servidor recusa travessias não autorizadas.
- O progresso de bots e visitantes, incluindo equipe, insígnias e eventos da história, permanece em `DATA_DIR/world.json` com gravação periódica e no encerramento normal.

### Reproduzindo os testes

Com Node.js **20 ou superior** instalado, no diretório da raiz do ZIP:

```bash
npm test
npm run proof
```

Teste visual opcional (Python + Playwright + Chromium instalados):

```bash
npm run test:browser
```

**Resultados na compilação do pacote:**

- **43/43 testes automáticos**: movimentação, colisões, portas, combates, recompensas, shop, estados independentes, processo real reiniciado, observatório e ROM Lab.
- **Três jornadas completas da V8 até Wattson**, uma com cada inicial. Os registros gerados dinamicamente ficam em `tests/v8_evidence.json`; são simulações de código e mapa adaptado.
- **20 e 100 bots**, cada conjunto executado por **500 turnos** no teste de carga lógico. Não foram detectadas posições inválidas nem insígnias inexplicáveis nessa rodada. Isso não equivale a 100 jogadores conectados nem a uma prova de disponibilidade contínua de 24 horas.
- **Tela Android simulada (390×844) e desktop (1280×800)** em Chromium: sem erros JavaScript observados e sem transbordamento horizontal. As imagens estão em `tests/v8_android_spectator.png` e `tests/v8_desktop_online.png`. A interface visual foi testada com respostas HTTP simuladas porque o navegador automatizado deste ambiente bloqueia acesso a `localhost`; o servidor foi testado separadamente com HTTP real por Node.js.

### Iniciando a simulação online

No terminal, na raiz da pasta, usando Node.js 20+:

```bash
BOT_COUNT=20 BOT_TICK_MS=650 HOST=0.0.0.0 PORT=8787 DATA_DIR=./server/data node server/app.cjs
```

Abrir `http://SEU_HOST:8787/jogo/online.html`.

`BOT_COUNT` aceita **5 a 100**, no início do processo. `BOT_TICK_MS` é o intervalo de atualização, mínimo 100 ms. O servidor continua executando bots com a página fechada enquanto o processo Node estiver ligado. O arquivo `world.json` precisa permanecer em armazenamento persistente. Hospedagem puramente estática não executa esta simulação.

**Faça backup de `DATA_DIR` antes da atualização.** A V8 pode ler saves online da V7, preserva os progressos e retoma as jornadas de bots que haviam parado após Roxanne. Os saves locais do antigo simulador offline não são automaticamente convertidos para o servidor.

### Pendências importantes

1. **Mapas reais:** os 27 layouts online são originais e adaptados, **não** extraídos fielmente de todas as cidades, rotas e interiores da ROM. Faltam mapas de Lavaridge em diante, movimentos especiais, puzzles, NPCs e eventos completos da Geração III. O visual ainda utiliza assets e desenhos experimentais do projeto.
2. **Quarta insígnia até Hall da Fama:** Flannery, Norman, Winona, Tate e Liza, Juan, Elite Four, Wallace, eventos finais de Aqua/Magma e pós-jogo **não** são jogáveis no servidor V8. Nenhum bot foi declarado Campeão sem isso.
3. **Pokémon:** o motor online contém **35 espécies** com subconjunto de movimentos, tipos e estatísticas. Ainda faltam quase todas as habilidades, status, itens de batalha, PP, regras exatas de experiência/captura e batalhas duplas. As fórmulas de atributos usam dados de espécie/IV/EV/Nature, mas o motor não deve ser chamado de compatibilidade total com o Emerald GBA.
4. **Jogadores e bots:** o servidor compartilhado ainda mantém perfis temporários de visitante, sem contas verificadas; desafios contra bots próximos não alteram a equipe real e persistente do bot adversário. PvP, negociação, sincronização de combate entre dois jogadores e moderação precisam de uma nova fase de engenharia.
5. **Infraestrutura:** os saves ficam em um arquivo JSON, não em banco transacional. Não foi realizado teste público com 100 jogadores, teste físico em Android ou estresse de 24 horas. Mantenha o servidor para **testes privados**.

### Arquivos principais alterados

`server/world.cjs`, `server/navigation.cjs`, `server/battle.cjs`, `server/autonomy.cjs`, `server/story.cjs`, `server/shop.cjs`, `server/app.cjs`, `jogo/multiplayer/client.js`, `jogo/online.html`, `tests/multiplayer/v8-journey.test.cjs`, `tests/multiplayer/restart.test.cjs`, `tests/browser-v8.py`, `tests/generate-v8-evidence.cjs`.

**Próxima etapa de qualidade:** substituir cada mapa adaptado por dados de mapa verificáveis, com colisão e transição testadas para todas as portas da região. Não aumentar os contadores de progresso até essas cenas terem batalha e script implementados.
