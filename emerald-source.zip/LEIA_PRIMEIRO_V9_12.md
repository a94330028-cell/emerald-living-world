# Emerald Living World V9.12 — Arte e níveis

A V9.12 foi construída sobre a V9.11, preservando menu **Jogo / Pokémon / Rank**, mapa decorado, páginas extras, modo solo, batalha, IA, capturas, saves e Top 6.

## Por que aparecia uma Poké Bola com UNKNOWN atrás dos Pokémon?

O CSS de `jogo/css/game-rank-v911.css` definia `pokemon_placeholder.png` como **imagem de fundo de todos os retratos** do ranking. Os arquivos PNG dos Pokémon possuem transparência; portanto, essa Poké Bola ficava visível mesmo quando o sprite estava correto.

**Correção:** removi a imagem de fundo. Se o sprite local e as alternativas online falharem, aparece somente um ícone genérico verde original, sem Poké Bola ou a palavra UNKNOWN. O nome da espécie continua visível. Pokémons sem sprite local ainda dependem de internet para mostrar a arte real. Não adicionamos material retirado de ROMs ao pacote.

## Poder por nível

- Os seis atributos da simulação continuam seguindo as fórmulas da **Geração III** (base da espécie, nível, IV, EV e Nature).
- A pontuação do ranking offline agora é a **soma dos seis atributos calculados no nível atual**. Não usa um bônus artificial estático por espécie ou pontos cosméticos por golpes.
- Para a **mesma espécie, IV, EV e Nature**, o Pokémon sobe de força a cada nível. Exemplo Litten (IV/EV 0, Hardy): Lv. 5 = 71, Lv. 6 = 76, Lv. 50 = 405, Lv. 60 = 479 pontos.
- A batalha continua considerando golpes, tipos, habilidades, clima, prioridades e atributos. Um nível mais alto não garante vitória automática.
- Entre **espécies diferentes**, um Pokémon mais baixo pode superar outro mais alto por causa de seus atributos-base, inclusive quando não for lendário. Isso faz parte das regras de Pokémon; não seria fiel impedir esse resultado artificialmente. Os lendários geralmente se destacam por possuírem atributos-base elevados.
- O motor online já usa a soma dos atributos calculados para ordenar os seis mais fortes; foi preservado.

## Testes realizados

- `npm test`: **99/99 testes aprovados na última rodada**. Um teste histórico de evolução por experiência falhou de modo intermitente em uma rodada anterior e passou depois, sem ajustes nesse sistema.
- `python tests/browser-v9-12.py`: teste real em Chromium Android simulado, sem erros de JavaScript. Confirmou Top 6 preenchido, ausência de imagem de fundo e aumento dos atributos Litten entre níveis 5, 6, 50 e 60. Captura em `tests/v9_12_rank_android.png`.
- `node --test tests/pokemon/v9-12-level-power.test.cjs`: crescimento para seis iniciais e teste do visual sem Poké Bola.

## Instalação

1. Faça backup dos saves e dos arquivos anteriores.
2. Substitua os arquivos da V9.11 pelos deste ZIP.
3. Recarregue o jogo (se necessário, atualize a página para limpar o cache de CSS/JS).
4. Os arquivos da versão atual **não foram publicados automaticamente** na hospedagem.

## Limitações

A campanha no servidor, os mapas originais e as mecânicas de todas as espécies ainda não estão completos. O ambiente de teste não comprova o carregamento de sprites de fontes externas na rede do seu celular. Quando a imagem externa não chegar, a interface exibe um ícone neutro sem encobrir outras imagens.
