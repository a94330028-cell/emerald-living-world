# Emerald Living World 3.5 — Tutorial para jogadores

## Como funciona

O site agora oferece um tutorial interativo de sete passos, acessível pelo botão **📖 Como jogar** na navegação e pelo cartão **Primeira vez em Hoenn?** da tela inicial.

Ele ensina:

1. Diferença entre Meu treinador e Assistir às IAs.
2. Escolha do inicial, primeira jornada, continuar e reiniciar.
3. Mapa, câmera e controle de velocidade.
4. Decisões do treinador e batalhas manuais.
5. Pokédex, equipe de seis Pokémon e reservas.
6. Ranking dos times mais fortes e maior avanço na história.
7. Backups de saves, configurações e recursos da comunidade.

## Acessibilidade e celular

- Janela responsiva, legível em Android e desktop.
- Botões de Próximo, Voltar, Pular e Concluir.
- Progresso visual e textual.
- Pode ser reaberto a qualquer momento pelo botão **📖 Como jogar**.
- Não inicia, reinicia ou apaga campanhas durante a explicação.
- O cartão de boas-vindas deixa de aparecer depois que a pessoa conclui ou pula o tutorial, sem alterar o save do jogo.

## Publicação

O projeto é um site estático com outras funcionalidades preexistentes. Substitua os arquivos da versão anterior pelo ZIP completo, mantendo a estrutura `jogo/`. É recomendável guardar um backup do site anterior e testar o tutorial no endereço publicado.
