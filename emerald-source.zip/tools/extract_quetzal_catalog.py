#!/usr/bin/env python3
"""Extract non-art metadata from a locally owned Pokémon Quetzal Alpha 9 v1 ROM.

The GBA file is only read on this computer; never copied into the generated web game.
The resulting catalog contains factual Pokémon species identifiers, types, base
stats, capture rates and base EXP only; no images, game code, or narrative text.
Fails closed when the table layout is not what we verified for Alpha 9 v1.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

TYPES = ['Normal','Fighting','Flying','Poison','Ground','Rock','Bug','Ghost',
         'Steel','???','Fire','Water','Grass','Electric','Psychic','Ice',
         'Dragon','Dark','Fairy']
SPECIAL = {0x00:' ', 0x1b:'é',0xa3:'2',0xad:'.',0xae:'-',0xb4:"'",0xb5:'♂',0xb6:'♀',0xf0:':'}
for num in range(10): SPECIAL[0xa1+num] = str(num)

def decode_name(raw: bytes) -> str:
    name=[]
    for c in raw.split(b'\xff', 1)[0]:
        if 0xbb <= c <= 0xd4: name.append(chr(c-0xbb+ord('A')))
        elif 0xd5 <= c <= 0xee: name.append(chr(c-0xd5+ord('a')))
        elif c in SPECIAL: name.append(SPECIAL[c])
        else: raise ValueError(f'Caractere não reconhecido na tabela: 0x{c:02x}')
    return ''.join(name).strip()

def gba_name(name: str) -> bytes:
    result=bytearray()
    for c in name:
        if 'A'<=c<='Z':result.append(0xbb+ord(c)-ord('A'))
        elif 'a'<=c<='z':result.append(0xd5+ord(c)-ord('a'))
        else:raise ValueError('Nome de busca suporta somente letras ASCII')
    return bytes(result)

def find_names(data: bytes) -> int:
    # First three National Dex entries are contiguous 13-byte records.
    bulba=gba_name('Bulbasaur')+b'\xff'+b'\0'*3
    ivy=gba_name('Ivysaur')+b'\xff'+b'\0'*5
    venus=gba_name('Venusaur')+b'\xff'+b'\0'*4
    pattern=bulba+ivy+venus
    candidates=[]; pos=0
    while True:
        x=data.find(pattern,pos)
        if x<0:break
        pos=x+1
        if decode_name(data[x+24*13:x+25*13])=='Pikachu' and decode_name(data[x+1213*13:x+1214*13])=='Sprigatito' and decode_name(data[x+1377*13:x+1378*13])=='Pecharunt':
            candidates.append(x)
    if not candidates: raise ValueError('Tabela de nomes Quetzal incompatível')
    return min(candidates)  # Main text list; Quetzal also repeats some name tables

def find_stats(data: bytes) -> int:
    # Pokeemerald expansion baseStats records: 36 bytes, speed precedes spAtk.
    first=bytes([45,49,49,45,65,65]);second=bytes([60,62,63,60,80,80])
    matches=[];i=0
    while True:
        i=data.find(first,i)
        if i<0:break
        if data[i+36:i+42]==second and data[i+72:i+78]==bytes([80,82,83,80,100,100]):matches.append(i)
        i+=1
    if len(matches)!=1:raise ValueError(f'Tabela de atributos incompatível: {len(matches)} correspondências')
    return matches[0]

def extract(rom: Path) -> dict:
    raw=rom.read_bytes()
    if len(raw)!=32*1024*1024: raise ValueError('A ROM esperada tem 32 MiB')
    if raw[0xa0:0xac].split(b'\0')[0]!=b'PKM QUETZAL':raise ValueError('A ROM não parece ser Pokémon Quetzal')
    if raw[0xac:0xb0]!=b'BPEE': raise ValueError('Código do cabeçalho GBA não reconhecido')
    names_at=find_names(raw);stats_at=find_stats(raw)
    # Slot 1..1519 = National 1-1025 + their ROM variants; 1520..1528
    # are three new starter evolutionary lines with provisional Quetzal names.
    seen={};records=[];base_count=0;forms=0;experimental=0
    for slot in range(1,1529):
        name=decode_name(raw[names_at+(slot-1)*13:names_at+slot*13])
        b=raw[stats_at+(slot-1)*36:stats_at+slot*36]
        if len(b)!=36 or not name or not all(0<v<=255 for v in b[:6]) or b[6]>18 or b[7]>18:
            raise ValueError(f'Dados de espécie inválidos no slot {slot}')
        if slot<=1519:
            if name not in seen:
                base_count+=1;dex=base_count;seen[name]=dex;kind='species';key=name
            else:
                forms+=1;dex=seen[name];kind='variant';key=f'{name}@{slot:04d}'
        else:
            experimental+=1;dex=None;kind='experimental';key=f'{name}@{slot:04d}'
        types=[TYPES[b[6]]] + ([TYPES[b[7]]] if b[7]!=b[6] else [])
        records.append({'id':slot,'dex':dex,'key':key,'name':name,
                        'kind':kind,'types':types,
                        'base':[b[0],b[1],b[2],b[4],b[5],b[3]],
                        'catch':b[8],'exp':int.from_bytes(b[10:12],'little')})
    assert base_count==1025, f'Esperadas 1025 espécies únicas, recebeu {base_count}'
    assert records[24]['name']=='Pikachu' and records[24]['base']==[35,55,40,50,50,90]
    assert records[1213]['name']=='Sprigatito' and records[1213]['base']==[40,61,54,45,45,65]
    assert records[1377]['name']=='Pecharunt' and records[1377]['base']==[88,88,160,88,88,88]
    return {'metadata':{
        'source':'local-user-supplied-Pokemon-Quetzal-PTBR-Alpha9v1',
        'romSha256':hashlib.sha256(raw).hexdigest(),
        'headerTitle':'PKM QUETZAL','gameCode':'BPEE',
        'records':len(records),'nationalSpecies':base_count,
        'internalVariants':forms,'experimentalFormSlots':experimental,
        'dataFields':['name','types','baseStats','catchRate','baseExp'],
        'unsupported':['complete-move-learnsets','evolution-methods-for-every-species','encounter-tables','form-identities','sprites']},
        'pokemon':records}

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('rom',type=Path);ap.add_argument('output',type=Path)
    args=ap.parse_args();out=extract(args.rom)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(out,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    print(f'Gravado {args.output}: {out["metadata"]["nationalSpecies"]} espécies, {out["metadata"]["internalVariants"]} formas internas, {out["metadata"]["experimentalFormSlots"]} slots experimentais')
