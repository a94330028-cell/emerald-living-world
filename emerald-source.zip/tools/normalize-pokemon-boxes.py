#!/usr/bin/env python3
"""Reframe bundled Pokémon art without distorting species or changing map/overworld sprites.

Source GIF/PNG assets stay unmodified. Pixel art is cropped to the nontransparent
union of all animation frames and is centered on a 64x64 transparent canvas.
Scale is aspect-preserving and nearest-neighbor, with a uniform 52px max footprint.
"""
from pathlib import Path
from PIL import Image, ImageSequence

BASE = Path(__file__).resolve().parent.parent / 'jogo/assets'
DEST = BASE / 'pokemon_fit'
DEST.mkdir(exist_ok=True)
CANVAS = 64
CONTENT = 52


def normalize(path):
    im = Image.open(path)
    frames = [frame.convert('RGBA').copy() for frame in ImageSequence.Iterator(im)]
    assert frames and all(f.size == frames[0].size for f in frames)
    nonempty = [f.getchannel('A').getbbox() for f in frames]
    nonempty = [b for b in nonempty if b]
    if not nonempty:
        (DEST/path.name).write_bytes(path.read_bytes())
        return (0, 0)
    xmin = min(b[0] for b in nonempty)
    ymin = min(b[1] for b in nonempty)
    xmax = max(b[2] for b in nonempty)
    ymax = max(b[3] for b in nonempty)
    w, h = xmax - xmin, ymax - ymin
    scale = CONTENT / max(w, h)
    nw, nh = max(1, round(w * scale)), max(1, round(h * scale))
    # Apply the same crop and scale to all frames to prevent jitter during animation.
    result = []
    for f in frames:
        f = f.crop((xmin, ymin, xmax, ymax)).resize((nw, nh), Image.Resampling.NEAREST)
        base = Image.new('RGBA', (CANVAS, CANVAS), (0, 0, 0, 0))
        base.alpha_composite(f, ((CANVAS - nw)//2, (CANVAS - nh)//2))
        result.append(base)
    dest = DEST / path.name
    if path.suffix == '.png':
        result[0].save(dest, optimize=True)
    else:
        # 'disposal=2' erases each frame; preserve original per-frame timing.
        durations = [int(fr.info.get('duration', 120)) for fr in ImageSequence.Iterator(im)]
        result[0].save(dest, format='GIF', save_all=True,
                       append_images=result[1:], duration=durations,
                       loop=im.info.get('loop', 0), disposal=2,
                       optimize=True, transparency=0)
    return (w, h)

if __name__ == '__main__':
    count = 0
    for category in ['rom_pokemon', 'pokemon']:
        for path in sorted((BASE/category).glob('*')):
            if path.suffix.lower() not in {'.png', '.gif'}:
                continue
            normalize(path)
            count += 1
    print(f'Normalized {count} images to {DEST}')
