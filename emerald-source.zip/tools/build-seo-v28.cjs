'use strict';
/* Execute com: SITE_ORIGIN=https://dominio-publicado.example node tools/build-seo-v28.cjs
 * O domínio padrão é o que foi previamente informado para o projeto; confirme
 * a URL efetivamente publicada antes de cadastrar o Search Console. */
const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const origin=(process.env.SITE_ORIGIN||'https://esmerald-living.netlify.app').replace(/\/+$/,'');
if(!/^https:\/\/[^/\s?#]+$/.test(origin))throw Error('SITE_ORIGIN precisa ser uma origem HTTPS sem caminho');
const pages=[
 ['jogo/index.html','Emerald Living World — Simulador Pokémon com até 100 Treinadores IA','Explore Hoenn em uma simulação Pokémon com até 100 treinadores controlados por IA. Acompanhe batalhas, evolução de times, rankings e jornadas independentes.'],
 ['sobre.html','Sobre o Emerald Living World — Projeto de simulação Pokémon','Conheça a proposta, a história e os recursos de simulação de Pokémon do Emerald Living World.'],
 ['atualizacoes.html','Atualizações do Emerald Living World','Patch notes, novidades, correções de mapas e melhorias de performance do simulador.'],
 ['privacidade.html','Política de privacidade — Emerald Living World','Entenda os saves, as contas e o consentimento para estatísticas no Emerald Living World.'],
 ['jogo/estatisticas.html','Estatísticas mundiais — Emerald Living World','Estatísticas públicas agregadas da comunidade e dos treinadores simulados em Hoenn.']
];
for(const [file,title,desc] of pages){
 const full=path.join(root,file),canonical=origin+'/'+file,og=origin+'/jogo/assets/ui/emerald-share-1200x630.jpg';
 let html=fs.readFileSync(full,'utf8').replace(/<link rel="canonical"[^>]*>/g,'').replace(/<meta property="og:[^>]*>/g,'').replace(/<meta name="twitter:[^>]*>/g,'');
 html=html.replace(/<title>[^<]*<\/title>/,'<title>'+title+'</title>');
 const meta=`<link rel="canonical" href="${canonical}"><meta property="og:type" content="website"><meta property="og:locale" content="pt_BR"><meta property="og:site_name" content="Emerald Living World"><meta property="og:title" content="${title}"><meta property="og:description" content="${desc}"><meta property="og:url" content="${canonical}"><meta property="og:image" content="${og}"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><meta name="twitter:card" content="summary_large_image">`;
 html=html.replace('</head>',meta+'</head>');fs.writeFileSync(full,html);
}
const today='2026-11-06';
fs.writeFileSync(path.join(root,'sitemap.xml'),'<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'+pages.map(([f])=>`  <url><loc>${origin}/${f}</loc><lastmod>${today}</lastmod></url>`).join('\n')+'\n</urlset>\n');
fs.writeFileSync(path.join(root,'robots.txt'),`User-agent: *\nAllow: /\nDisallow: /admin/\nDisallow: /supabase/\nDisallow: /tests/\nSitemap: ${origin}/sitemap.xml\n`);
fs.writeFileSync(path.join(root,'llms.txt'),`# Emerald Living World\n\n> Projeto independente de fã de simulação inspirado em Pokémon Emerald, com até 100 treinadores IA por mundo, exploração de Hoenn, batalhas e evolução de equipes.\n\n- [Jogo e simulação](${origin}/jogo/index.html): inicie, continue ou observe treinadores.\n- [Sobre o projeto](${origin}/sobre.html): conceito inicial, funcionamento e limitações.\n- [Atualizações](${origin}/atualizacoes.html): mudanças e novidades do simulador.\n- [Estatísticas mundiais](${origin}/jogo/estatisticas.html): métricas agregadas da comunidade, quando o backend estiver ativo.\n- [Política de privacidade](${origin}/privacidade.html): saves e coleta opcional de métricas.\n\n## Funcionalidades\n\n- Jornada em Hoenn com mapas externos conectados e interiores independentes.\n- Simulação por regras de IA, eventos, capturas e batalhas.\n- Pokédex, PC, ranking, Hall da Fama e progresso local.\n- Login, sincronização na nuvem e estatísticas somente quando configurados no Supabase.\n\nProjeto não oficial, sem relação com Nintendo, Game Freak ou Creatures. Não divulgar dados pessoais ou conteúdo privado.\n`);
console.log('SEO gerado com',origin);
