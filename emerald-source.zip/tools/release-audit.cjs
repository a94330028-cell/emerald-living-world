'use strict';
/** Repeatable local readiness report. Does not modify a server or Supabase. */
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..');
const read=file=>fs.readFileSync(path.join(root,file),'utf8');
const manifest=JSON.parse(read('ASSET_PRESERVATION_RC6.json')).protectedFiles;
const preservation=Object.entries(manifest).map(([file,expected])=>{
 const actual=crypto.createHash('sha256').update(fs.readFileSync(path.join(root,file))).digest('hex');
 return {file,unchanged:actual===expected};
});
const Battle=require('../server/battle.cjs');
const Frontier=require('../server/frontier.cjs');
const checks={
 preservedNationalCapturesAndArena:preservation.every(entry=>entry.unchanged),
 eightGyms:Object.keys(Battle.GYMS).length===8,
 fiveLeagueMembers:Battle.LEAGUE.length===5,
 tateAndLizaDouble:Battle.GYMS.MossdeepGym?.format==='double'&&fs.existsSync(path.join(root,'server/gen3-double-runtime.cjs')),
 sevenFrontierLabs:Object.keys(Frontier.FACILITIES).length===7,
 sevenFrontierBrainExhibitions:Object.keys(require('../server/frontier-brains.cjs').BRAINS).length===7,
 palaceNaturePreferences:Object.keys(require('../server/frontier-palace.cjs').NATURE_WEIGHTS).length===25,
 arenaMindSkillBodyJudging:typeof require('../server/frontier-arena.cjs').judge==='function',
 domeAndFactoryLineupSelection:typeof Frontier.selectLineup==='function',
 pikeThreeDoorChoices:typeof require('../server/frontier-adventures.cjs').makePikeDoors==='function',
 domeSixteenEntrantBracket:(()=>{const b=require('../server/frontier-adventures.cjs').createDomeTournament(5,50,Frontier.CLASSIC_POOL,{name:'Tucker',team:['Swampert','Salamence','Charizard']});return b.entrants.length===16&&b.matches.flat().length===15&&b.entrants.filter(e=>e.id==='frontier-brain').length===1;})(),
 pikeFourteenRoomsPerBlock:Frontier.FACILITIES.pike.block===14,
 frontierExternalActionLock:read('server/app.cjs').includes('Desafio Frontier em andamento')&&read('server/battle.cjs').includes('A cura externa é bloqueada'),
 pyramidNavigableFloors:typeof Frontier.explore==='function',
 accountSessionExpiryEnforced:read('server/app.cjs').includes('accountAuthUntil'),
 frontierLabRewardsSeparateFromOfficial:true,
 frontierPassLabReadOnly:require('../server/frontier-pass-lab.cjs').calculate().official===false,
 selfTargetMovesClassified:require('../server/gen3-doubles.cjs').targetClass('Recover')==='self',
 nodeServerFilesPresent:fs.existsSync(path.join(root,'server/app.cjs')),
 supabaseServerAuthBridgeImplemented:fs.existsSync(path.join(root,'server/auth-provider.cjs'))&&fs.existsSync(path.join(root,'jogo/multiplayer/online-auth.js')),
 productionAuthConfigured:process.env.AUTH_MODE==='required'&&!!process.env.SUPABASE_URL&&!!(process.env.SUPABASE_ANON_KEY||process.env.SUPABASE_PUBLISHABLE_KEY),
 browserVisualValidationCompleted:false, // Chromium navigation was blocked by the execution environment
 officialFrontierBrainBattlesCompleted:false,
 modernAccountAuthenticationCompleted:false,
 fullOriginalEmeraldStoryCompleted:false,
 fullGen3MoveAccuracyValidated:false
};
const blockers={
 publicAuthentication:'Integração com Supabase Auth implementada e testada com API simulada; autenticação real e configuração pública ainda não foram verificadas em produção.',
 frontierBrains:'Sete Brains LAB, Dome com 16 vagas e 15 confrontos simulados/registrados, Pike de 14 salas por bloco, Pyramid navegável, Palace e Arena aprimorados. Ainda não há fidelidade suficiente para premiar Símbolos oficiais.',
 originalStory:'A campanha tem oito ginásios e Liga, mas faltam eventos originais e mapas oficiais completos.',
 faithfulGen3Engine:'Motor Gen III e Double são subconjuntos testados, não equivalência completa à ROM.',
 visualAndLoad:'Chromium iniciou, mas a navegação foi bloqueada por ERR_BLOCKED_BY_ADMINISTRATOR no ambiente; falta validar visualmente em dispositivos e executar carga real com jogadores.'
};
const result={project:'Emerald Living World',version:require('../package.json').version,checkedAt:new Date().toISOString(),readyForPublicStableRelease:false,
 checks,preservation,blockers,localTestCommand:'npm test',localStartCommand:'npm start'};
console.log(JSON.stringify(result,null,2));
if(process.argv.includes('--strict')&&!result.readyForPublicStableRelease)process.exitCode=1;
