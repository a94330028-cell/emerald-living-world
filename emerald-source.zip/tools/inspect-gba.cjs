#!/usr/bin/env node
'use strict';
/** Inspection only. Reads bytes from a user-owned local file. Never copies,
 * extracts, uploads, stores or serves a ROM or its graphics. */
const fs=require('node:fs'),crypto=require('node:crypto');
const {readGbaHeader}=require('../jogo/rom/validation/gba-header.js');
const file=process.argv[2];if(!file){console.error('Uso: node tools/inspect-gba.cjs /caminho/arquivo.gba');process.exit(2)}
const info=readGbaHeader(new Uint8Array(fs.readFileSync(file).subarray(0,192)));
const st=fs.statSync(file);
if(!info.valid){console.error(JSON.stringify({valid:false,error:info.error}));process.exit(1)}
const hash=crypto.createHash('sha256');const stream=fs.createReadStream(file);
stream.on('data',chunk=>hash.update(chunk));stream.on('end',()=>{
 console.log(JSON.stringify({name:info.title,gameCode:info.gameCode,revision:info.revision,bytes:st.size,
  quetzal:info.quetzal,emerald:info.emerald,headerValid:info.valid,sha256:hash.digest('hex'),
  graphicsExtracted:false,romUploaded:false,notes:'Detecção do cabeçalho NÃO comprova offsets nem mapas compatíveis.'},null,2));
});
