'use strict';
/* Deterministic, editable SIMULATOR location table. These are original
 * adaptations based on type/biome, NOT cartridge encounter data. */
const fs=require('node:fs');
const path=require('node:path');
const {PRIMARY}=require('../server/dex.cjs');
const {AREA_DEFS,TYPE_BIOMES,FIXED}=require('../jogo/game/pokemon/national-pools.js');
const EARLY=new Set(['Route101','Route102','Route103','Route104','Route104North','Woods','Route116','RusturfTunnel','GraniteCave','Route106']);
const OVERRIDE={
 Bulbasaur:['Woods','Route119'],Charmander:['FieryPath','MtChimney'],Squirtle:['Route106','Route125'],
 Chikorita:['Route117','Route119'],Cyndaquil:['FieryPath','Route112'],Totodile:['Route106','Route127'],
 Treecko:['Woods','Route119'],Torchic:['Route112','JaggedPass'],Mudkip:['Route106','Route118'],
 Turtwig:['Route117','SafariZone'],Chimchar:['FieryPath','MtChimney'],Piplup:['Route106','ShoalCave'],
 Snivy:['Route117','Route119'],Tepig:['Route112','JaggedPass'],Oshawott:['Route106','Route124'],
 Chespin:['Woods','Route119'],Fennekin:['Route112','FieryPath'],Froakie:['Route106','Route118'],
 Rowlet:['Woods','Route119'],Litten:['FieryPath','JaggedPass'],Popplio:['Route106','Route125'],
 Grookey:['Woods','SafariZone'],Scorbunny:['Route112','JaggedPass'],Sobble:['Route106','Route124'],
 Sprigatito:['Woods','Route119'],Fuecoco:['FieryPath','Route112'],Quaxly:['Route106','Route125'],
 Zigzagoon:['Route101','Route102','Route104'],Poochyena:['Route101','Route102','Woods'],
 Wurmple:['Route101','Woods'],Shroomish:['Woods','Route104North'],
 Ralts:['Route102','Route117'],Lotad:['Route102','Route104North'],Seedot:['Route102','Route104North'],
 Taillow:['Route104North','Route116'],Wingull:['Route104North','Route106','Route110'],
 Geodude:['GraniteCave','Route116'],Zubat:['GraniteCave','RusturfTunnel'],Aron:['GraniteCave','Route116'],
 Whismur:['Route116','RusturfTunnel'],Nincada:['Route116','Route117'],
 Electrike:['Route110','Route118'],Magnemite:['Route110','NewMauville'],
 Abra:['GraniteCave','Route117'],Makuhita:['GraniteCave','Route116'],
 Magikarp:['Route106','Route118','Route124'],Tentacool:['Route106','Route124','Route125'],
 Tropius:['Route119','SafariZone'],Kecleon:['Route119','Route120'],
 Bidoof:['Route101','Route117'],Starly:['Route101','Route104'],Sentret:['Route101','Route104']
};
function hash(text){let n=2166136261;for(const c of text)n=Math.imul(n^c.charCodeAt(0),16777619)>>>0;return n;}
const allLocs=Object.keys(AREA_DEFS);
const map=Object.create(null);
for(const record of PRIMARY){
 const n=record.key,b=record.base.reduce((a,v)=>a+v,0),rate=Number(record.catch)||0;
 const special=rate<10;
 const types=record.types;
 const locs=allLocs.filter(a=>types.some(t=>TYPE_BIOMES[AREA_DEFS[a][0]].includes(t)));
 const pinned=(OVERRIDE[n]||Object.keys(FIXED).filter(a=>FIXED[a].includes(n))).filter(a=>AREA_DEFS[a]);
 const later=locs.filter(a=>!EARLY.has(a));
 const h=hash(n+'|'+record.dex);
 // Always pin early locations manually; remaining species enter a later themed
 // location. A small curated early pool prevents 1,000 Pokémon on Route 101.
 const chosen=[...pinned];
 const candidates=later.length?later:locs;
 for(const shift of [0,8,16])if(candidates.length)chosen.push(candidates[(h>>>shift)%candidates.length]);
 const locations=special?[]:[...new Set(chosen)].sort((a,b)=>allLocs.indexOf(a)-allLocs.indexOf(b));
 const tier=b<=330?0:b<=400?1:b<=450?2:b<=500?3:b<=540?5:b<=580?6:8;
 map[n]={locations,minBadges:Math.min(tier,8),method:special?'special':'wild'};
}
const script=`/* Adapted Emerald Living World encounter locations, not original ROM tables. */\n(function(root){'use strict';\nconst ENTRIES=${JSON.stringify(map)};\nconst BY_DEX=${JSON.stringify(Object.fromEntries(PRIMARY.map(r=>[r.dex,r.key])))};\nconst api=Object.freeze({source:'adapted-simulator-not-quetzal',version:1,ENTRIES:Object.freeze(ENTRIES),BY_DEX:Object.freeze(BY_DEX)});\nif(typeof module==='object'&&module.exports)module.exports=api;\nif(root)root.EmeraldNationalHabitats=api;\n})(typeof window==='object'?window:undefined);\n`;
const output=path.join(__dirname,'../jogo/game/pokemon/national-habitats.js');fs.writeFileSync(output,script);
console.log('Wrote '+Object.keys(map).length+' species location entries to '+output);
