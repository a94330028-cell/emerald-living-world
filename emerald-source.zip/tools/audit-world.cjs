'use strict';
/* Test original server fixture geometry without claiming it is the actual ROM. */
const fs=require('node:fs');
const path=require('node:path');
const World=require('../server/world.cjs');
const Nav=require('../server/navigation.cjs');
const results=[];
function testPortal(name,p){
 const bot={area:name,x:14,y:10,channel:1,badges:8,story:{peeko:true,steven:true,wally:true,rival110:true}};
 const directions=Nav.localDirections(name,14,10,p.x,p.y,true);
 const test={source:name,destination:p.to,from:{x:p.x,y:p.y},landing:{x:p.tx,y:p.ty},steps:directions?.length??null,accessible:directions!==null,transition:false,returnVerified:null};
 if(directions){
  for(const dir of directions){if(!World.step(bot,dir)){test.error='Step blocked before or at portal';break}}
  test.transition=bot.area===p.to;
  if(!test.transition)test.error='Portal did not reach destination';
  if(test.transition&&['Center','Mart'].includes(p.to)){
   const back=Nav.localDirections(bot.area,bot.x,bot.y,14,19,true);
   if(!back){test.returnVerified=false;test.error='Shared interior has no reachable return door';}
   else{
    for(const dir of back){if(!World.step(bot,dir)){test.error='Shared return step blocked';break}}
    test.returnVerified=bot.area===name;
    if(!test.returnVerified)test.error='Shared room returned to wrong city';
   }
  }
 }
 return test;
}
for(const [name,m] of Object.entries(World.MAPS)){
 for(const p of m.portals)results.push(testPortal(name,p));
}
const errors=World.validateWorld();
for(const r of results)if(!r.accessible||!r.transition||r.returnVerified===false)errors.push(`${r.source}->${r.destination}: ${r.error||'unreachable'}`);
const report={version:'V9.5',scope:'adapted-server-fixtures-not-original-ROM',maps:Object.keys(World.MAPS).length,doors:results.length,passed:results.filter(r=>r.accessible&&r.transition&&r.returnVerified!==false).length,failed:errors.length,errors,results};
const out=path.resolve(__dirname,'../tests/v9_5_map_audit.json');fs.writeFileSync(out,JSON.stringify(report,null,2));
console.log(`${report.maps} adapted maps, ${report.passed}/${report.doors} doors tested, ${report.failed} failures. ${out}`);
if(errors.length)process.exitCode=1;
