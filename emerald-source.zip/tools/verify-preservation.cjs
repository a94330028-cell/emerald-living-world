#!/usr/bin/env node
'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..');
const manifest=JSON.parse(fs.readFileSync(path.join(root,'ASSET_PRESERVATION_RC6.json'),'utf8'));
let failures=0;
for(const [name,reference] of Object.entries(manifest.protectedFiles)){
 const target=path.join(root,name);
 if(!fs.existsSync(target)){console.error('AUSENTE: '+name);failures++;continue;}
 const current=crypto.createHash('sha256').update(fs.readFileSync(target)).digest('hex');
 if(current!==reference){console.error('ALTERADO: '+name);failures++;}
 else console.log('OK: '+name);
}
if(failures){console.error(failures+' arquivos protegidos mudaram.');process.exitCode=1;}
else console.log('Proteção verificada: '+Object.keys(manifest.protectedFiles).length+' arquivos preservados.');
