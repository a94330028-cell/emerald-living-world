# 🌿 Emerald Living World — Versão 2.8

## Visual de Hoenn
- Substituído o preenchimento de borda artificial por continuidade visual baseada nos pixels dos chunks oficiais disponíveis.
- Preservadas grade, colisões, caminhos, interiores e transições originais.

## Celular
- Qualidade gráfica ajustável: automática, econômica e alta.
- Novos ajustes para reduzir renderização e processamento visual desnecessário.

## Site e comunidade
- Nova imagem de compartilhamento, tags sociais, apresentação pública, privacidade e atualizações.
- `sitemap.xml`, `robots.txt` e `llms.txt`.
- Discord oficial permanece vinculado: https://discord.gg/6r9w3kA4sh.

## Nuvem e administração
- Integração preparada com Supabase para eventos de jogo consentidos, estatísticas agregadas e painel `/admin` protegido por checagem de UUID e papel no servidor.
- Banco com tabelas protegidas por RLS, políticas separadas e funções administrativas.
- Os dados online somente funcionarão depois da configuração e publicação do backend descritas em `LEIA_PRIMEIRO_V28.md`.

## Validação
- 151 testes automatizados Node aprovados.
- Smoke Chromium offline limitado às bordas e à tela de bloqueio administrativo.
- Desempenho em aparelhos reais e integração Supabase de produção ainda pendentes de teste.
