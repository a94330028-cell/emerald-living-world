# Emerald Living World 3.7 — Primeiro módulo Gen III

## O que foi aplicado
- Adicionado `server/gen3-turn.cjs` com tabela de prioridades de movimentos, divisão físico/especial por tipo, paralisia sobre velocidade, desempate aleatório, utilitários de dano fixo e multiplicador de golpes em área.
- `server/battle.cjs` passou a usar o resolvedor básico para ordenar **movimentos** nas batalhas do servidor, eliminando a vantagem fixa do jogador nos empates.
- Adicionados testes automatizados em `tests/multiplayer/gen3-turn.test.cjs`.

## O que ainda NÃO foi implementado
- Motor Gen III integral: todos os movimentos, PP, status, clima, habilidades, itens, efeitos residuais, trocas completas, Pursuit, Double/Multi, Frontier, Frontier Brains e sincronização integral dos 100 bots.
- O módulo de dano fixo e o modificador de golpes em área estão preparados, mas **ainda não são utilizados** nas batalhas existentes.
- A Arena competitiva moderna permanece independente e com suas regras simplificadas.
- O ZIP não atualiza automaticamente o site hospedado nem implanta funções Supabase.

## Testar
`node --test tests/multiplayer/gen3-turn.test.cjs`
`cd server && npm test`

Este pacote é uma atualização incremental verificável, não uma implementação completa dos estudos 01.01–01.54.
