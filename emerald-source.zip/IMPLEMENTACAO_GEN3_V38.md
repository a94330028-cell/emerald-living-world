# Emerald Living World 3.8 — Estudo 01.55: auditoria e módulo residual isolado

## Diagnóstico da versão 3.7
- `server/battle.cjs`: batalhas online ainda simplificadas, sem PP, habilidades, itens, status completo, Double/Multi ou Frontier.
- `server/gen3-turn.cjs`: prioridade e velocidade básicas, com auxiliares ainda não integrados ao cálculo de dano.
- A Arena moderna e o jogo legado possuem regras e arquivos próprios; não foram substituídos.
- O catálogo do servidor inclui espécies/movimentos modernos (inclusive Fairy). Isso NÃO é fiel a Emerald e requer separação explícita por ruleset.

## Implementado nesta atualização
- `server/gen3-residual.cjs`: módulo isolado e testável de efeitos de clima, Leftovers, Leech Seed (somente dano), Poison, Burn e Toxic.
- O módulo registra eventos de dano, recuperação e desmaio, interrompendo o processamento quando HP chega a zero.
- Contador de Toxic reiniciável em trocas, com testes automatizados.
- `tests/multiplayer/gen3-residual.test.cjs`: novos testes de sequência, desmaios e reinicialização.

## Limites explícitos
- **Não conectado ainda à batalha online**: faltam mecanismos de status, clima e itens persistidos e sua validação.
- Não implementa Wish, recuperação de Leech Seed, Shed Skin, Speed Boost, habilidades de imunidade, eventos de múltiplos participantes, substituições ou ordem exata completa de Emerald.
- Não implementa ainda a Battle Frontier nem sincroniza os 100 bots.
- A aplicação em produção exige testes de integração e deploy separado; este ZIP não atualiza o site nem o Supabase.

## Executar testes
`node --test tests/multiplayer/gen3-turn.test.cjs tests/multiplayer/gen3-residual.test.cjs`
`cd server && npm test`

## Próximo módulo
Criar `ruleset: gen3_emerald` isolado, esquema de batalha com PP/status/held item/ability e integrar o processamento residual ao fluxo de turnos sob feature flag, sem afetar a Arena moderna.
