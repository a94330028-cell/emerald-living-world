# Patch Notes · Emerald Living World 3.6

## Arena Competitiva

- Novo acesso pela página inicial, navegação e `jogo/arena.html`.
- Construção manual de times e gerador aleatório: 1.025 espécies base.
- Formatos 1×1, 3×3 e 6×6.
- Batalhas contra bots por turnos com golpes, tipos, HP e troca.
- Elo local, ranking PvP online preparado e função publicada no Supabase, resultados separados.
- Sistema de fila PvP com autenticação e pontuação autoritativa no servidor: SQL e código da função incluídos.
- Interface mobile e temas claro/escuro.
- Campanha, saves e simulação das 100 IAs não foram substituídos.

## Limites

- A mecânica da Arena é adaptada e simplificada.
- A função de PvP já está implantada no Supabase. Ainda são necessários dois jogadores com contas confirmadas para validar partidas ponta a ponta.
- Publicação no domínio do usuário ainda é uma etapa separada.
