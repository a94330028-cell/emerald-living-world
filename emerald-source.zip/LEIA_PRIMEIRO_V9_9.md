# 🌿 Emerald Living World V9.9 — Navegação limpa

Esta versão **continua o projeto V9.8**, preservando os arquivos do mundo, os sprites, o motor de batalhas, os saves e a simulação de IAs.

## O que mudou

- Menu principal de **apenas três abas**: **Jogo**, **Pokémon**, **Rank**.
- No celular existe **uma única barra de três abas na parte inferior**. No desktop, a barra aparece no topo.
- No modo **Só meu bot**, os Pokémon do treinador aparecem **antes do mapa**.
- No modo de observação, um resumo compacto da equipe aparece acima do mapa.
- **Pokémon** inclui o time do treinador (com imagem, nível e HP), seletor de treinador no modo observador e acesso à Pokédex existente.
- **Rank** ordena os treinadores pelo **número de insígnias**. Nenhuma pontuação de força é usada na ordenação principal.
- Um botão em Rank abre a página secundária **Força dos treinadores**, contendo:
  - **Times mais fortes** (Top 5 equipes por poder calculado)
  - **Pokémon mais forte** (entre os Pokémon dos treinadores)
  - **Top 6 Pokémon mais fortes** (equipe e PC)
- As telas antigas seguem presentes no código para compatibilidade, mas **não aparecem no menu principal**.
- A página Jogo conserva o mapa V9.8, a escolha entre treinar ou enfrentar o rival e a seleção manual dos golpes.

## Onde abrir

Abra `index.html` ou `jogo/index.html` usando um servidor estático ou uma hospedagem de arquivos estáticos. O botão "Jogar só com meu bot" mantém a campanha solo; "Observar as IAs" mantém a simulação.

Para abrir a página de força: **Rank → Ver rankings de força**. Ela não ocupa uma quarta aba no menu.

## Arquivos principais alterados

- `jogo/index.html` — estrutura das três abas, Pokémon e força
- `jogo/css/clean-navigation-v99.css` — layout e navegação para Android e desktop
- `jogo/js/clean-navigation-v99.js` — equipes e rankings com dados reais do motor
- `jogo/js/my-bot.js` — time no topo, sem duplicar o time
- `jogo/js/pages.js` — navegação compartilhada, compatibilidade de rotas
- `jogo/js/engine.js` — rank por insígnias sem pontuação de força
- `jogo/js/personal-landing.js`, `jogo/js/start-setup.js`, `jogo/js/refresh.js`, `jogo/js/world.js` — compatibilidade de modos, botões e mapa
- `tests/ui/clean-navigation.test.cjs` e `tests/browser-v9-9.py` — testes novos

## Validação

- 3 testes automáticos novos de navegação/estrutura aprovados.
- Navegação testada em Chromium Android (390×844) e desktop (1280×800), com alternância de páginas, time no topo, Rank, página de força e retorno ao Jogo.
- Nenhum erro de JavaScript observado no teste de interface. Sem rolagem horizontal inesperada nas páginas testadas.
- Rodada geral final do motor: **95/95 testes aprovados** (`tests/v9_9_all_tests_final.log`). Em duas rodadas anteriores, houve uma falha intermitente no teste antigo de experiência acumulada após evolução (`tests/v9_9_all_tests.log`). A suíte de IA isolada também passou com **5/5**. Isso não elimina a possibilidade de a instabilidade se repetir.

## Limitações que permanecem

- Os gráficos oficiais dos mapas ainda dependem de fontes externas. Quando estas falham, o jogo pode mostrar os mapas de recuperação, visualmente mais simples. **A V9.9 não altera o motor nem os assets de mapas**.
- O projeto ainda não reproduz integralmente a campanha de Pokémon Emerald no servidor online.
- Os mapas de recuperação não são equivalentes às colisões e gráficos oficiais.
- O ranking de força utiliza o índice de poder do próprio simulador, não um valor oficial do jogo.

## Saves e atualização

Faça **backup/exporte o save** antes da publicação. A V9.9 não muda o formato do save. Envie a pasta completa da versão para sua hospedagem. A versão publicada anteriormente não se atualiza automaticamente.
