# Emerald Living World 2.5 — equipe completa na página inicial

- **Jogo / Observador:** mantém retrato e os seis sprites rápidos, e exibe fichas completas dos seis espaços logo abaixo, com espécie, nível, HP, barra de vida, poder, atributos principais, golpes e detalhes expandidos de atributos e PP.
- **Só meu bot:** os cards existentes ficam maiores e mais legíveis no Android; ataques aparecem nas fichas e os detalhes dos atributos continuam disponíveis.
- **Pokédex e PC:** mantidos, sem alterar espécies, atributos, batalhas, partidas, mapas ou saves.
- **Temas:** claro/esmeralda e escuro.
- **Observação:** os dados refletem o treinador observado; a lista se atualiza conforme os turnos avançam. Os espaços vazios são mostrados quando a equipe tem menos de seis Pokémon.

Para abrir, use `index.html` na raiz com a pasta `jogo/` inteira. Para online é necessário backend Node.js; o simulador offline funciona em hospedagem estática. Faça backup dos saves antes de publicar.
