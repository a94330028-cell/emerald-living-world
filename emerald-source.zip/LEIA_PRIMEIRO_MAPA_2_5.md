# Emerald Living World — Versão 2.5: mapa sempre visível

## Alteração
A janela real do jogo (`canvas#liveWorld`) aparece primeiro em Jogo, antes das opções de câmera/colisões. A estrutura foi corrigida no HTML, sem depender de JavaScript para reordenar o mapa.

As ferramentas avançadas foram colocadas em um painel recolhido e continuam disponíveis em **Câmera, colisões e ferramentas do mapa**.

A Pokédex, o tema escuro, o retrato do treinador, o PC, as batalhas e os saves continuam presentes. Nenhum dado salvo foi apagado.

## Instalação
Publique o conteúdo extraído do ZIP; mantenha `index.html` e `jogo/` na raiz da publicação. Não envie o ZIP fechado como se fosse um HTML. Atualize a página do navegador após publicar, para receber a nova versão do CSS e JavaScript.

## Escopo de validação
O ajuste é de layout/ordem dos painéis: ele não substitui os mapas oficiais nem modifica suas colisões. A disponibilidade dos gráficos oficiais externos continua dependente das fontes usadas no projeto.
