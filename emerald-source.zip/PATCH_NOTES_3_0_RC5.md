# 🌿 Emerald Living World — Versão 3.0 RC5

## 🏆 Frontier com exploração e torneios reais no servidor

- **Battle Pike:** três portas para escolher por sala, com uma pista sobre uma das portas. O conteúdo das outras portas não é revelado antecipadamente pela API. As escolhas persistem até serem usadas, e eventos de batalha, recuperação e status não concedem automaticamente vitórias em combate.
- **Battle Dome:** torneio com 16 participantes gerados no início de cada chave, quatro rodadas, adversários persistentes e registro das classificações do jogador. A escolha de dois dos três Pokémon registrados permanece disponível antes das partidas. Tucker aparece na final das chaves de cinco e dez torneios consecutivos.
- **Battle Pyramid:** mapa navegável 5×5 por andar, células ocultas até a aproximação, corredores, saída azul, itens da Battle Bag e encontros ocasionais. Não é mais possível conquistar um andar simplesmente acionando o botão “próxima batalha”; é necessário caminhar até a saída. Brandon continua obrigatório no 21º e 70º andares.
- **Battle Tower, Palace, Arena, Factory:** sistemas da RC4 preservados, incluindo os sete Frontier Brains, natureza no Palace, Mind/Skill/Body na Arena, aluguel e trocas na Factory.
- **Interface mobile:** portas, visualização da chave do Dome, minimapa da Pyramid e botões de caminhada por toque.
- **Servidor:** nova rota autenticada `POST /api/frontier/explore`, escolhas validadas e estado de exploração persistente entre ações. `POST /api/frontier/next` aceita `{"door":0|1|2}` na Pike.

## 🛡️ Proteção do projeto

Foram mantidos sem modificações os seis arquivos protegidos do catálogo nacional, habitats, encontros dos bots e módulos principais da Arena. Nenhum Pokémon já disponível para captura pelos bots foi apagado.

## ✅ Validação executada

- 253 testes automatizados aprovados, 0 reprovados.
- Quatro testes novos de regressão cobrem a Pike, o torneio de 16 treinadores, caminhos alcançáveis e progressão não gratuita da Pyramid, e confrontos Brain.
- Smoke test HTTP: criação de sessão, stream, Factory, seleção de três aluguéis e abertura de batalha.
- Inspeção visual estática em Chromium mobile (390 px): sete instalações renderizadas, sem erros de JavaScript nem overflow horizontal.
- Navegação visual automatizada real no servidor bloqueada por `ERR_BLOCKED_BY_ADMINISTRATOR` neste ambiente.

## ⚠️ Escopo e limites

Esta versão é jogável localmente, mas a Battle Frontier **ainda é uma adaptação, não uma reprodução 100% fiel do Pokémon Emerald**. O mapa da Pyramid é criado para este projeto; não é o labirinto da ROM. O motor não implementa todas as habilidades, movimentos, efeitos e regras originais. As conquistas exibidas são do LAB; recompensas e Símbolos oficiais continuam desativados para não conceder troféus indevidos. A autenticação real e o desempenho com jogadores simultâneos precisam de validação em produção.

Nenhuma alteração foi publicada no site ou implantada no Supabase.
