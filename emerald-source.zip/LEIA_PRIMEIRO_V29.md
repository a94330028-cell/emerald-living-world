# 🌿 Emerald Living World 2.9 — correções de bordas e estabilidade

**Esta versão é uma correção incremental da 2.8, não uma recriação do projeto.** A estrutura de arquivos, os saves e os sistemas de IAs, mapas, login preparado e batalhas foram mantidos.

## Mudanças efetuadas

1. `jogo/game/world/edge-scenery.js`: **remoção total do espelhamento das bordas**. Antes, qualquer bloco do mapa podia reaparecer no espaço vazio (casas, caminhos, flores). Agora, quando estão disponíveis, são utilizados **somente blocos de uma amostra de vegetação validada** de um chunk oficial da Route 101. A detecção exige predominância de cores verdes, variedade de luz/sombra e blocos intransponíveis; rejeita asfalto/telhados/caminhos claros. Se os dados oficiais não carregarem ou não houver amostra validada, mostra uma cor neutra em vez de gráficos errados.
2. O renderizador continua pintando os mapas reais acima do fundo. Nada muda em colisões, caminho, Surf, Dive, warps ou progresso das IAs.
3. `jogo/js/refresh.js`: inicialização da interface após a criação do DOM, com botões opcionais protegidos para evitar exceções ao carregar em ordem diferente.
4. `jogo/js/start-setup.js` e `jogo/js/telemetry-v28.js`: acesso ao armazenamento local mais resistente a navegadores que o bloqueiam (por exemplo, algumas prévias locais). A telemetria continua opt-in.
5. `jogo/css/v29-contrast.css`: texto escuro no cartão claro de equipe Pokémon e texto claro no tema escuro.
6. Links de scripts atualizados com nova versão para reduzir reutilização de cache antigo na hospedagem.
7. Página pública Atualizações revisada para explicar a mudança.

## Testes realmente executados

- `npm test`: **150/150 testes Node passaram** (`tests/v29_node_tests.log`).
- Chromium headless, viewport 390×844: carregamento de interface e scripts, inicialização dos treinadores, abertura de jornada e teste de ausência de erros JS/overflow (`tests/v29_browser_report.json`). Teste offline com scripts e CSS carregados em linha; não equivale a hospedagem real.
- Chromium headless, cenário sintético com floresta verde e telhado cinza: **70 células de fundo renderizadas sem copiar telhado** (`tests/v29_forest_report.json`).
- Imagens para conferência: `tests/v29_inline_home.png`, `tests/v29_inline_jornada.png` e `tests/v29_forest_mock.png`.

## Limitações e próximos passos

- Os dados gráficos oficiais da Route 101 são solicitados via `raw.githubusercontent.com` pelo motor existente. A **aparência definitiva das árvores reais depende da disponibilidade desses arquivos**. Sem rede, a borda verde lisa é intencional para não repetir partes incorretas do cenário.
- A navegação integral por Hoenn, performance real de 100 IAs e compatibilidade em celulares físicos não foram verificadas nesta atualização.
- **Não foi feito deploy**. Para atualizar o site publicado, enviar o conteúdo deste ZIP preservando diretórios. Fazer backup antes. Se aparecer código antigo após publicar, atualizar a página/reabrir o navegador para limpar o cache.
- Supabase e painel ADM permanecem dependentes da configuração segura documentada em `LEIA_PRIMEIRO_V28.md`.
- Problemas específicos adicionais do site que dependam de internet, conta ou hospedagem só podem ser confirmados quando testados no ambiente publicado.
