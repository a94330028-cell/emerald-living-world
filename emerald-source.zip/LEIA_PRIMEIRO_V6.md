# 🌿 Emerald Living World V6 — Jornada Definitive, atualização experimental

**Estado honesto:** esta atualização continua o projeto V5, com novas funcionalidades e
novos testes. **Não é o MMO definitivo** e não conclui todas as fases do planejamento.
O desenvolvimento foi feito sobre os arquivos do usuário; nenhum site externo foi publicado.

## O que foi feito nesta atualização

### Fase 1 — Estabilidade / mapas
- Mantidos os módulos da V5 de colisão, navegação, animação e saída segura.
- Adicionado modo **Caminhada experimental** em `jogo/mapas-oficiais.html`.
- Personagem Brendan/May pode andar com setas, WASD e botões Android no mapa
  carregado pelo visualizador oficial.
- Movimento usa `EmeraldNavigation.canStep`, respeitando tiles bloqueados, água e
  barreiras direcionais onde o comportamento é conhecido.
- Portas somente mudam de mapa quando destino, índice do warp recíproco e
  pouso próximo caminhável puderem ser confirmados. Se o carregamento falhar,
  o mapa e a posição atuais permanecem.
- Limitação: conexões contínuas entre rotas, scripts, eventos, NPCs móveis,
  escadas especiais e puzzles **não estão integrados** à caminhada manual.
  A navegação automática das IAs mantém as regras e os mapas adaptados da V5.

### Fase 2 — Visual / Android
- Criado jogo visual separado em `jogo/online.html`, com câmera de área de teste,
  sprites de Brendan/May já existentes no projeto e controles para celular.
- A interface mobile foi executada em Chromium com viewport emulado de 390×844.
- Não houve refatoração integral de todos os componentes do renderizador original.

### Fase 3 — Pokémon
- O motor offline de combate, experiência, atributos, level caps, evolução e
  treinadores do V4/V5 permanece incluído. Novo teste de regressão do aplicativo
  confirmou carregamento, movimento e preservação do save.
- Novo módulo independente `server/battle.cjs` permite, **na área online experimental**,
  batalhar contra Pokémon selvagens e bots próximos, escolher golpes, capturar,
  ganhar experiência, evoluir alguns Pokémon e curar a equipe no Centro Pokémon.
  Ações, inventário, dano e experiência são validados **pelo servidor**.
- Há 15 espécies de teste, danos físicos/especiais conforme o tipo do golpe,
  fórmulas baseadas em nível/IV/EV/Nature e um sistema limitado de movimentos.
  **Não é o motor completo Gen III**: a curva de experiência é simplificada,
  faltam a maioria das espécies, golpes, PP, habilidades, itens, status,
  duplas, troca de Pokémon em combate, compra de Poké Bolas, PvP e ginásios
  online. Os dois motores de combate (online e offline) ainda são separados.

### Fase 4 — Bots
- Mantido o simulador local V5 de 5 a 100 bots com ações de campanha.
- O servidor V6 inclui **12 bots de teste**, distribuídos em 3 canais, que
  caminham independentemente enquanto o processo Node está ativo. A posição e
  o nível simplificado deles são salvos.
- Esses bots do servidor **podem ser desafiados por visitantes em batalhas simples**,
  mas ainda não completam a campanha, capturam Pokémon, tomam decisões reais de
  batalha ou usam a IA avançada dos bots locais. As duas simulações **não estão
  sincronizadas**.

### Fase 5 — Multiplayer experimental real
- Backend Node.js nativo, sem dependências npm de terceiros, em `server/`.
- Perfis temporários por sessão de visitante com identificador aleatório armazenado
  em cookie HttpOnly; o hash da sessão é persistido no disco.
- 3 canais e 9 áreas de teste independentes, com portas, colisões e mudança de área
  validadas pelo servidor (não pelas coordenadas enviadas pelo navegador).
  O interior compartilhado do Centro Pokémon retorna à cidade em que o visitante
  entrou, sem teletransportá-lo por engano para outra cidade.
- Outras pessoas são exibidas quando estão **no mesmo canal e na mesma área**.
  O cliente interpola visualmente os passos autorizados pelo servidor e usa quadros
  de caminhada direcionais; mudanças de área não são interpoladas como passos.
- Transmissão em tempo quase real por Server-Sent Events (SSE) e comandos HTTPS
  por POST, chat básico com rate limit e bloqueio de links, modo espectador.
- Estado dos visitantes e bots (incluindo Pokémon e batalhas em andamento) salvo
  em arquivo JSON com escrita substitutiva atômica. Para produção é obrigatório
  configurar diretório persistente. **Não substitui banco transacional**.
- O sistema de perfis é **guest**, não possui senha, login seguro por email,
  sistema de banimentos, denúncia, bloqueio, moderação nem proteção de inventário
  ou batalhas. **Use apenas em testes privados**, não libere chat público antes
  desses controles.
- Os nove mapas online são desenhos originais simplificados para testar
  infraestrutura. **Não** são as áreas oficiais completas de Hoenn.

### Fase 6 — ROM local opcional
- Mantida a verificação de cabeçalho `.gba` da V5.
- Novo `jogo/rom-lab.html` e módulo puro `rom/readers/gba-graphics.js`:
  paletas GBA BGR555, tiles 4bpp de 8×8 e descompressor LZ77 (tipo 0x10),
  com controle de tamanho e erros de formato.
- Prévia por **offsets manuais**, processada somente no navegador. A ROM não é
  enviada ao backend, salva nem colocada no ZIP.
- NÃO identifica automaticamente offsets, não extrai animações/mapas completos,
  não aplica sprites no simulador e não emula a ROM.

### Fase 7 — Testes e acabamento
- Testes Node unitários e de API, incluindo início/turnos de batalha,
  captura, cálculo de atributos, evolução, colisões e retorno ao Centro Pokémon;
  testes do motor legado e navegador Chromium com endpoints online simulados
  e mapas sintéticos.
- A execução em Android físico e a campanha completa em mapas oficiais **ainda
  não foram testadas**.

## Como abrir a versão normal (modo local)

Publique **todo o conteúdo do ZIP**, preservando `index.html` na raiz e a pasta
`jogo/`. Abra `/jogo/index.html` ou `/jogo/#jogo`. As páginas `online.html` e
`rom-lab.html` ficam na pasta `jogo/`. Um host estático continua suficiente para
os modos locais — **mas não executa o backend online**.

Antes de trocar de domínio/hospedagem, faça backup dos saves com o botão de
exportar. Saves no `localStorage` ficam separados por domínio.

## Como testar o servidor online

É preciso **Node.js 20 ou superior**. No diretório raiz descompactado:

```sh
HOST=127.0.0.1 PORT=8787 node server/app.cjs
```

Abra `http://127.0.0.1:8787/jogo/online.html` no mesmo aparelho. Para um host
remoto, configure `HOST=0.0.0.0`, uma porta fornecida pela hospedagem, HTTPS e
um diretório persistente em `DATA_DIR`. Se o proxy terminar HTTPS à frente do
Node, configure `TRUST_PROXY=true` **somente se** você confiar no proxy.
Exemplo de configuração de ambiente:

```sh
HOST=0.0.0.0 PORT=8787 DATA_DIR=/persistent/emerald node server/app.cjs
```

Não existe `npm install` obrigatório. O servidor também fornece as páginas
estáticas do projeto. Hospedagens puramente estáticas, como configuração
estática do Netlify/Cloudflare Pages, não mantêm um processo Node.js SSE ativo,
portanto não podem hospedar esse multiplayer sem serviço separado.

**Importante:** a execução do servidor precisa de uma máquina ou serviço que
permaneça ligado. O código não garante funcionamento 24 horas por dia e não
foi publicado em servidor externo nesta entrega.

## Testes executados

| Teste | Resultado | Escopo |
|---|---|---|
| `node --test tests/**/*.test.cjs tests/*.test.cjs` | **28/28** aprovados | Regras e regressões em cenários unitários/sintéticos |
| Teste HTTP real (`server.test.cjs`) | Aprovado | Dois visitantes, canais, sessão, passos, chat, batalha, save em disco |
| `python tests/browser-smoke.py` | Aprovado | V5 offline, Chromium, 20 IAs, 721 turnos, save/reload |
| `python tests/browser-v6-mock.py` | Aprovado | Interface online/ROM/warp sintético, navegador Chromium |
| Navegador -> localhost real | **Bloqueado pelo ambiente de testes** | Integração HTTP foi validada em Node, UI separadamente com mock |
| Android físico | **Não testado** | Apenas viewport emulado 390×844 |
| Campanha integral em todos os mapas oficiais | **Não testada** | Não é possível certificar que todas as áreas estejam livres de travamentos |

Artefatos: `tests/browser_report.json`, `tests/v6_browser_report.json`,
`tests/smoke_android.png`, `tests/smoke_desktop.png`,
`tests/v6_online_android.png`, `tests/v6_online_desktop.png`,
`tests/v6_walking_fixture.png`, `tests/v6_rom_lab.png`.

## Próximas correções necessárias (antes de chamar de MMO completo)

1. Baixar/fornecer de forma autorizada uma base de mapas, camadas, passagens,
   NPCs e scripts verificáveis; criar teste de ida-e-volta para **todas** as portas.
2. Unificar caminhada humana, bot e servidor numa camada de mundo autoritativa,
   com HM, surf, escadas, eventos e interiores.
3. Unificar os motores online e offline e completar Pokémon Gen III: catálogo,
   curvas de EXP, habilidades, golpes, PP, duplas, captura, itens, regras de
   status, times, PC e evolução; testar com resultados de referência.
4. Migrar a IA avançada para o backend, com rotas, objetivos, batalhas,
   inventário e salvamento individual que continuam com a página fechada.
5. Adicionar contas verificadas, moderação/denúncias e bloqueios, proteção
   contra abuso, banco de dados de produção, sincronização de batalha e carga.
6. Implementar leitura de recursos da ROM para versões conhecidas com offsets
   verificados e controle de permissões; sem redistribuir ROMs.
7. Validar em dispositivos Android reais e rodar campanhas completas repetidas
   do começo à Liga e ao pós-jogo em mapas oficiais.

**Licenças:** este pacote não traz ROMs adicionais. O modo local mantém os
arquivos e artes do projeto fornecido. Para distribuir publicamente qualquer
recurso gráfico, som ou ROM, verifique os direitos de uso aplicáveis.
