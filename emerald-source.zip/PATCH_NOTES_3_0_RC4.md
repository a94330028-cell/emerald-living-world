# 🌿 Emerald Living World — Patch Notes 3.0 RC4

## Melhorias nesta compilação

- **Battle Palace:** 25 naturezas com preferências originais de ataque, defesa e suporte, alteradas abaixo da metade do HP. Os dois lados escolhem golpes automaticamente; a chance de não conseguir agir foi incluída. O sistema permanece um subconjunto do motor Emerald.
- **Battle Arena:** a avaliação após três turnos agora considera **Mind, Skill e Body**, em vez de somente o HP. Desempates são identificados e os resultados aparecem no registro da batalha. A contagem de Skill usa mensagens do motor reduzido, portanto ainda exige validação contra a ROM.
- **Battle Factory:** seleção pelo jogador de **3 dos 6 aluguéis** antes da primeira batalha, com verificação no servidor. O time original não é alterado.
- **Battle Dome:** seleção pelo jogador de **2 dos 3 Pokémon registrados** entre partidas, com validação no servidor.
- **Treinadores IA:** após derrotas sucessivas em ginásios posteriores, passam a buscar treinamento adicional legítimo. Podem priorizar um Pokémon do tipo adequado já capturado. Não há níveis, insígnias ou vitórias concedidos gratuitamente.
- **Sessão protegida:** no modo `AUTH_MODE=required`, o cookie do jogo vale até uma hora e exige nova verificação do token Supabase para renovação. O progresso continua pertencendo à mesma conta.
- **Interface:** controles de seleção de equipes na Frontier; notas e informações de batalha atualizadas.

## Proteções mantidas

- **Sem alteração** nos habitats, encontros e catálogo nacional dos bots, inclusive Pokémon de outras gerações.
- **Sem alteração** nos dois módulos protegidos da Arena Competitiva.
- Nenhum Símbolo oficial ou BP oficial concedido pelo Frontier LAB.
- Nenhuma operação de escrita realizada no banco Supabase remoto, nenhuma publicação na hospedagem.

## Verificação

- `npm test`: 249 testes aprovados na suíte de validação desta compilação.
- `npm run audit:release`: conferência dos arquivos nacionais e da Arena.
- O teste em Chromium tentou abrir a página local, mas o ambiente bloqueou a navegação com `ERR_BLOCKED_BY_ADMINISTRATOR`. Não há aprovação visual.

## O que ainda impede declarar o lançamento estável completo

Fidelidade exata da Gen III, formatos e instalações da Frontier originais, todos os eventos e mapas oficiais da história de Emerald, autenticação Supabase validada em produção, segurança do servidor e testes de interface/carga em dispositivos reais.
