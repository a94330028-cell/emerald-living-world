# 🌿 Emerald Living World 3.0 — Interface e chat da comunidade

## O que mudou
- Faixa de navegação rápida com mapas, Pokédex, multiplayer Beta, Discord e novo chat comunitário.
- Botão de chat acessível na tela inicial e dentro do jogo, sem fechar a jornada.
- Visual Pokémon/Esmeralda: cartões mais consistentes, espaços bem definidos, mensagens em balões, layouts adequados para toque e texto mais legível.
- Tema escuro aplicado também à tela inicial, controles, formulários, cartões, Pokédex e modais. Os gráficos do jogo e os sprites não são escurecidos, para preservar as cores dos mapas.
- Chat global com salas Geral, Ajuda e Times e estratégias; opção de ocultar um treinador e denunciar mensagens. Chat separado do chat do multiplayer Node (o multiplayer mantém seu canal próprio).
- O multiplayer Node também recebeu apresentação de mensagens mais legível.

## Ativar o chat entre pessoas reais (obrigatório)
1. Use seu projeto **Supabase** com login por e-mail e confirmação de e-mail habilitada. Se ainda não configurou, configure a URL pública e chave `anon` em `jogo/js/cloud-config.js`. NUNCA inclua service_role no navegador.
2. No SQL Editor do Supabase, execute `supabase/setup.sql` (contas/saves) se necessário, depois **`supabase/community_chat.sql`**.
3. Configure os URLs autorizados e redirecionamento de autenticação para o domínio real de produção.
4. Refaça o deploy do conteúdo do ZIP no seu host (Netlify/Vercel, ou outro estático). Confirme que o chat abre, que somente uma conta autenticada envia, e teste com **duas contas reais diferentes**.
5. Configure pessoas responsáveis por moderação; consulte denúncias na tabela `elw_chat_reports` pelo painel privado do Supabase e remova conteúdo abusivo pela administração do banco. Revise retenção, proteção de menores e privacidade antes de abrir o chat publicamente.

O site continua funcionando offline SEM Supabase, mas o chat mostrará **“Aguardando configuração do servidor”** e não aceitará mensagens. Não há mensagens inventadas, contadores falsos nem uma simulação de usuários.

## Segurança
- Supabase valida contas autenticadas e e-mails confirmados no servidor para publicar.
- RLS: histórico de chat visível apenas para contas autenticadas; clientes não têm INSERT/UPDATE/DELETE diretos.
- A função SQL restringe a frequência (4 segundos entre mensagens e até 10 por minuto), limita texto a 280 caracteres e rejeita links/e-mails. Mensagens usam `textContent` para impedir HTML enviado por usuários.
- Denúncias não são exibidas ao público. Ocultar treinador funciona apenas no navegador do próprio usuário.
- Chat é público entre usuários autenticados, sem mensagens privadas. Evite compartilhar informações pessoais.

## Testes e limitações
- `npm test`: testes locais do jogo e das alterações (veja `tests/v30_node_suite.log`).
- `python tests/browser-v30-ui-chat.py`: teste Chromium mobile offline com API Supabase **simulada**, não comprova conexão com serviço real.
- Não foi possível testar a produção Supabase sem URL/chave/projeto configurados, nem validar a aparência em um Android/iPhone físico.
- Não removi saves, mapas, sprites nem a simulação das IAs. Nenhum ZIP altera sozinho sua hospedagem publicada.
