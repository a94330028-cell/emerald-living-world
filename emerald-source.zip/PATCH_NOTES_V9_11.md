# PATCH NOTES V9.11 — Ranking no Jogo e Top 6 visível

- Rank rápido por insígnias integrado à página Jogo.
- Time do treinador e mapa preservados na mesma tela.
- Mini Top 6 Pokémon mais fortes no Jogo, com link ao ranking completo.
- Página Rank expandida: insígnias, times mais fortes, melhor Pokémon e Top 6.
- Modo Só meu bot também exibe ranking e Top 6 na própria jornada.
- Tratamento de imagens indisponíveis com ícone de reserva.
- Mantidos menu principal de três páginas e áreas extras no menu secundário.
- Testes de motor 97/97; teste de interface com 6 entradas no Top 6 e 0 erros JS observados.
