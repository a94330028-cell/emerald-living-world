import {backend,cors,reply,authorized} from '../_shared/security.ts';
Deno.serve(async req=>{
 const h=cors(req);if(!h)return reply({error:'Origem nao autorizada'},403,{});
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers:h});
 if(req.method!=='GET')return reply({error:'Metodo invalido'},405,h);
 try{
  const sb=backend(),user=await authorized(req,sb);
  if(!user?.id||!user.email_confirmed_at)return reply({error:'Login e e-mail confirmado necessarios'},401,h);
  const {data:member,error:roleError}=await sb.from('elw_admins').select('role').eq('user_id',user.id).maybeSingle();
  if(roleError||member?.role!=='admin')return reply({error:'Acesso restrito'},403,h);
  const days=Math.max(1,Math.min(90,Number(new URL(req.url).searchParams.get('days'))||7));
  const {data,error}=await sb.rpc('elw_admin_report',{p_days:days});
  if(error)throw error;
  return reply({ok:true,generatedAt:new Date().toISOString(),...data},200,h);
 }catch(e){console.error(e instanceof Error?e.message:'erro');return reply({error:'Falha ao consultar estatisticas'},503,h);}
});
