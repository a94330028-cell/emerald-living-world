import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.49.3';
export function backend(){
 const url=Deno.env.get('SUPABASE_URL'),key=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
 if(!url||!key)throw new Error('Backend nao configurado');
 return createClient(url,key,{auth:{autoRefreshToken:false,persistSession:false}});
}
export function cors(req:Request){
 const origin=req.headers.get('origin')||'';
 const allowed=(Deno.env.get('SITE_ORIGINS')||'').split(',').map(x=>x.trim()).filter(Boolean);
 if(!origin||!allowed.includes(origin))return null;
 return {'Access-Control-Allow-Origin':origin,'Vary':'Origin',
  'Access-Control-Allow-Headers':'authorization,apikey,content-type,x-client-info',
  'Access-Control-Allow-Methods':'GET,POST,OPTIONS','Access-Control-Max-Age':'300'};
}
export const reply=(data:unknown,status:number,h:Record<string,string>)=>new Response(JSON.stringify(data),{
 status,headers:{...h,'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}});
export async function authorized(req:Request,sb:ReturnType<typeof backend>){
 const match=/^Bearer (\S+)$/i.exec(req.headers.get('authorization')||'');
 if(!match)return null;
 const {data,error}=await sb.auth.getUser(match[1]);
 return error?null:data.user;
}
