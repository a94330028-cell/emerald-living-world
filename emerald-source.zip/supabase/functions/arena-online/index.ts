// Emerald Living World 3.6 — PvP server-authoritative, fila real e Elo.
import {createClient} from 'https://esm.sh/@supabase/supabase-js@2.49.3';
import species from './species.mjs';
import {validTeam,createBattle,validateAction,resolveTurn} from './core.mjs';
const originAllow=(Deno.env.get('SITE_ORIGINS')||'https://emerald-living-dezin.fantasticbell.chatgpt.site').split(',').map(s=>s.trim());
const headers=(origin:string)=>({'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','Access-Control-Allow-Origin':origin,'Vary':'Origin','Access-Control-Allow-Methods':'GET,POST,OPTIONS','Access-Control-Allow-Headers':'apikey,authorization,content-type,x-client-info','Access-Control-Max-Age':'600'});
const say=(body:unknown,status=200,origin='')=>new Response(JSON.stringify(body),{status,headers:headers(origin)});
const db=()=>createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{autoRefreshToken:false,persistSession:false}});
const uuid=/^[\da-f]{8}-[\da-f]{4}-[1-8][\da-f]{3}-[89ab][\da-f]{3}-[\da-f]{12}$/i;
function nick(s:unknown){const t=String(s||'Treinador').replace(/[<>\n\r\t]/g,'').trim().slice(0,24);return t.length>=2?t:'Treinador'}
async function identity(req:Request,sb:ReturnType<typeof db>){
 const bearer=/^Bearer (\S+)$/i.exec(req.headers.get('authorization')||'');
 if(!bearer)return null;
 const {data,error}=await sb.auth.getUser(bearer[1]);return error||!data.user?.email_confirmed_at?null:data.user;
}
async function findMatch(sb:ReturnType<typeof db>,userId:string,id?:string){
 let q=sb.from('elw_arena_matches').select('*').or(`player1.eq.${userId},player2.eq.${userId}`).order('created_at',{ascending:false}).limit(1);
 if(id&&uuid.test(id))q=q.eq('id',id);
 else q=q.eq('status','active');
 const {data,error}=await q.maybeSingle();if(error)throw error;return data;
}
async function initBattle(sb:ReturnType<typeof db>,m:any){
 for(let i=0;i<4;i++){
  if(m.battle?.turn>0)return m;
  const b=createBattle(m.battle.team1Ids,m.battle.team2Ids,species);
  const {data,error}=await sb.from('elw_arena_matches').update({battle:b,version:m.version+1,updated_at:new Date().toISOString()}).eq('id',m.id).eq('version',m.version).select('*').maybeSingle();
  if(error)throw error;if(data)return data;
  const {data:next}=await sb.from('elw_arena_matches').select('*').eq('id',m.id).single();m=next;
 }
 throw Error('Estado da partida ocupado. Tente novamente.');
}
async function finishRating(sb:ReturnType<typeof db>,matchId:string){
 const {error}=await sb.rpc('elw_arena_finalize',{p_match:matchId});if(error)throw error;
}
async function describe(sb:ReturnType<typeof db>,m:any,uid:string){
 m=await initBattle(sb,m);
 if(m.status==='finished'&&!m.rating_done){await finishRating(sb,m.id);const {data:latest}=await sb.from('elw_arena_matches').select('*').eq('id',m.id).single();m=latest||m;}
 const side=m.player1===uid?0:1;
 const {data:rows}=await sb.from('elw_arena_ratings').select('user_id,display_name,rating').in('user_id',[m.player1,m.player2]);
 const users=[m.player1,m.player2].map(id=>{const x=rows?.find(y=>y.user_id===id);return {name:x?.display_name||'Treinador',rating:x?.rating||1000};});
 return {status:'matched',id:m.id,format:m.format,side,users,battle:m.battle,waitingFor:m.action1===null?0:m.action2===null?1:-1,hasSubmitted:side===0?m.action1!==null:m.action2!==null,finished:m.status==='finished',ratingDelta:side===0?m.rating_delta1:m.rating_delta2};
}
Deno.serve(async req=>{
 const origin=req.headers.get('origin')||'';if(!originAllow.includes(origin))return say({error:'Origem não autorizada'},403,'');
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers:headers(origin)});
 const sb=db();const url=new URL(req.url);const action=req.method==='GET'?(url.searchParams.get('action')||'leaderboard'):'post';
 try{
  if(action==='leaderboard'){
   const {data,error}=await sb.from('elw_arena_ratings').select('display_name,rating,wins,losses,draws').order('rating',{ascending:false}).limit(30);
   if(error)throw error;return say({ok:true,players:data||[]},200,origin);
  }
  const user=await identity(req,sb);if(!user)return say({error:'Entre em uma conta e confirme o e-mail para jogar PvP.'},401,origin);
  if(action==='status'){
   let m=await findMatch(sb,user.id,url.searchParams.get('id')||undefined);
   if(m)return say(await describe(sb,m,user.id),200,origin);
   const {data:q}=await sb.from('elw_arena_queue').select('created_at,format').eq('user_id',user.id).maybeSingle();
   return say({status:q?'waiting':'idle',format:q?.format||null},200,origin);
  }
  if(req.method!=='POST')return say({error:'Método inválido'},405,origin);
  if(Number(req.headers.get('content-length')||0)>2048)return say({error:'Pedido muito grande'},413,origin);
  const body=await req.json();const operation=String(body.action||'');
  if(operation==='join'){
   const ids=body.team,format=Number(body.format);
   if(!validTeam(ids,format,species))return say({error:'Escolha uma equipe de espécies diferentes para o formato selecionado.'},400,origin);
   const name=nick(body.name);const {data,error}=await sb.rpc('elw_arena_join',{p_user:user.id,p_team:ids,p_format:format,p_name:name});
   if(error)throw error;
   if(data.status==='matched'){
    const m=await findMatch(sb,user.id,data.matchId);return say(await describe(sb,m,user.id),200,origin);
   }
   return say({status:'waiting',format},200,origin);
  }
  if(operation==='cancel'){
   const {error}=await sb.from('elw_arena_queue').delete().eq('user_id',user.id);
   if(error)throw error;return say({status:'idle'},200,origin);
  }
  if(operation==='move'||operation==='concede'){
   if(!uuid.test(String(body.id||'')))return say({error:'Partida inválida'},400,origin);
   for(let tries=0;tries<6;tries++){
    let m=await findMatch(sb,user.id,String(body.id));
    if(!m)return say({error:'Partida não encontrada para esta conta'},404,origin);
    if(m.status!=='active')return say(await describe(sb,m,user.id),200,origin);
    m=await initBattle(sb,m);const side=m.player1===user.id?0:1;
    let data:any={version:m.version+1,updated_at:new Date().toISOString()};
    if(operation==='concede'){
      const battle={...m.battle,winner:1-side,log:[...m.battle.log,'Um treinador desistiu da partida.']};
      data={...data,battle,status:'finished',winner:1-side};
    }else{
      const chosen=body.move;
      if(!validateAction(m.battle,side,chosen))return say({error:'Ação não permitida'},400,origin);
      const mine=side===0?'action1':'action2';
      if(m[mine])return say(await describe(sb,m,user.id),200,origin);
      const actions=[m.action1,m.action2];actions[side]=chosen;
      if(actions[0]&&actions[1]){
       const next=resolveTurn(m.battle,actions[0],actions[1]);
       data={...data,battle:next,action1:null,action2:null};
       if(next.winner!==null){data.status='finished';data.winner=next.winner;}
      }else data[mine]=chosen;
    }
    const {data:updated,error}=await sb.from('elw_arena_matches').update(data).eq('id',m.id).eq('version',m.version).select('*').maybeSingle();
    if(error)throw error;if(updated){if(updated.status==='finished')await finishRating(sb,updated.id);return say(await describe(sb,updated,user.id),200,origin);}
   }
   return say({error:'Conflito de atualização: toque novamente.'},409,origin);
  }
  return say({error:'Operação inválida'},400,origin);
 }catch(err){console.error('arena-online',err instanceof Error?err.message:'erro');return say({error:'Não foi possível concluir. Tente novamente.'},503,origin);}
});
