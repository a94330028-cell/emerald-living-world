import {backend,cors,reply} from '../_shared/security.ts';
Deno.serve(async req=>{
 const h=cors(req);if(!h)return reply({error:'Origem nao autorizada'},403,{});
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers:h});
 if(req.method!=='GET')return reply({error:'Metodo invalido'},405,h);
 try{const {data,error}=await backend().rpc('elw_public_report');if(error)throw error;
  return reply({ok:true,generatedAt:new Date().toISOString(),...data},200,h);
 }catch(e){console.error(e instanceof Error?e.message:'erro');return reply({error:'Estatisticas indisponiveis'},503,h);}
});
