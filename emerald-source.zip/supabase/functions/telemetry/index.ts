import {backend,cors,reply,authorized} from '../_shared/security.ts';
const events=new Set(['session_play','campaign_start','starter_choose','pokemon_capture','gym_win','gym_loss','elite_four_win','campaign_complete','save','session_end']);
const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
// Best effort por instancia; em produção, adicionar rate limit no gateway/WAF.
const last=new Map<string,number>();
Deno.serve(async req=>{
 const headers=cors(req);if(!headers)return reply({error:'Origem nao autorizada'},403,{});
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers});
 if(req.method!=='POST')return reply({error:'Metodo invalido'},405,headers);
 if(Number(req.headers.get('content-length')||0)>2048)return reply({error:'Payload grande'},413,headers);
 let body:Record<string,unknown>;
 try{body=await req.json();}catch{return reply({error:'JSON invalido'},400,headers);}
 const kind=String(body.kind||''),sessionId=String(body.sessionId||''),visitorId=String(body.visitorId||'');
 const page=String(body.page||'/jogo/').replace(/[^a-zA-Z0-9_/#.-]/g,'').slice(0,140);
 if(!['open','heartbeat','close','event','error'].includes(kind)||!uuid.test(sessionId)||!uuid.test(visitorId))
  return reply({error:'Evento invalido'},400,headers);
 const now=Date.now(),rateKey=sessionId+':'+kind;
 if(now-(last.get(rateKey)||0)<(kind==='heartbeat'?15000:800))return reply({ok:true,limited:true},200,headers);
 last.set(rateKey,now);if(last.size>2000)last.clear();
 try{
  const sb=backend(),user=await authorized(req,sb);
  const {data:existing,error:checkError}=await sb.from('elw_analytics_sessions')
   .select('is_playing').eq('session_id',sessionId).maybeSingle();
  if(checkError)throw checkError;
  const playing=kind==='close'?false:kind==='event'?true:Boolean(existing?.is_playing);
  const payload={visitor_id:visitorId,user_id:user?.id||null,page,
   last_seen:new Date().toISOString(),is_playing:playing};
  // UPDATE não toca em first_seen: métricas de permanência não são zeradas.
  const result=existing?await sb.from('elw_analytics_sessions').update(payload).eq('session_id',sessionId):
   await sb.from('elw_analytics_sessions').insert({session_id:sessionId,...payload});
  if(result.error)throw result.error;
  if(kind==='event'||kind==='close'){
   const type=kind==='close'?'session_end':String(body.eventType||'');
   if(!events.has(type))return reply({error:'Tipo desconhecido'},400,headers);
   let detail=String(body.detail||'').replace(/[^\p{L}\p{N} _.-]/gu,'').slice(0,42);
   if(type==='starter_choose'&&!['Treecko','Torchic','Mudkip'].includes(detail))detail='Outros';
   const {error}=await sb.from('elw_analytics_events').insert({session_id:sessionId,event_type:type,detail});
   if(error)throw error;
  } else if(kind==='error'){
   // Mensagem curta, não incluir dados de conta, credenciais ou stacktraces.
   const msg=String(body.message||'Erro na interface').replace(/[\r\n<>]/g,' ').slice(0,180);
   const {error}=await sb.from('elw_error_reports').insert({session_id:sessionId,message:msg,page});
   if(error)throw error;
  }
  return reply({ok:true},200,headers);
 }catch(e){console.error('telemetry backend:',e instanceof Error?e.message:'erro');return reply({error:'Servico indisponivel'},503,headers);}
});
