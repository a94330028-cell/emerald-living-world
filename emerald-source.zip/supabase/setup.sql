-- EMERALD LIVING WORLD — executar no SQL Editor de um projeto Supabase.
-- Os saves são privados; o ranking é público sem emails, senhas nem dados de save.
create table if not exists public.elw_saves (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null,
  updated_at timestamptz not null default now(),
  constraint elw_payload_object check (jsonb_typeof(payload) = 'object'),
  constraint elw_payload_limit check (octet_length(payload::text) <= 10485760)
);
create table if not exists public.elw_leaderboard (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  team_power integer not null default 0,
  badges smallint not null default 0,
  is_champion boolean not null default false,
  best_ticks integer,
  team jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now(),
  constraint elw_name_length check (char_length(display_name) between 2 and 24),
  constraint elw_power_limit check (team_power between 0 and 100000),
  constraint elw_badges_limit check (badges between 0 and 8),
  constraint elw_time_limit check (best_ticks is null or best_ticks between 1 and 100000000),
  constraint elw_team_array check (jsonb_typeof(team)='array' and jsonb_array_length(team) <= 6)
);
alter table public.elw_saves enable row level security;
alter table public.elw_leaderboard enable row level security;
-- Reinicialização idempotente de políticas.
drop policy if exists "elw_save_select_own" on public.elw_saves;
drop policy if exists "elw_save_insert_own" on public.elw_saves;
drop policy if exists "elw_save_update_own" on public.elw_saves;
drop policy if exists "elw_save_delete_own" on public.elw_saves;
create policy "elw_save_select_own" on public.elw_saves for select to authenticated using ((select auth.uid())=user_id);
create policy "elw_save_insert_own" on public.elw_saves for insert to authenticated with check ((select auth.uid())=user_id);
create policy "elw_save_update_own" on public.elw_saves for update to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
create policy "elw_save_delete_own" on public.elw_saves for delete to authenticated using ((select auth.uid())=user_id);
drop policy if exists "elw_rank_public_read" on public.elw_leaderboard;
drop policy if exists "elw_rank_insert_own" on public.elw_leaderboard;
drop policy if exists "elw_rank_update_own" on public.elw_leaderboard;
drop policy if exists "elw_rank_delete_own" on public.elw_leaderboard;
create policy "elw_rank_public_read" on public.elw_leaderboard for select to anon, authenticated using (true);
create policy "elw_rank_insert_own" on public.elw_leaderboard for insert to authenticated with check ((select auth.uid())=user_id);
create policy "elw_rank_update_own" on public.elw_leaderboard for update to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
create policy "elw_rank_delete_own" on public.elw_leaderboard for delete to authenticated using ((select auth.uid())=user_id);
grant usage on schema public to anon, authenticated;
grant select, insert, update, delete on public.elw_saves to authenticated;
revoke all on public.elw_saves from anon;
grant select on public.elw_leaderboard to anon;
grant select, insert, update, delete on public.elw_leaderboard to authenticated;
-- Observação: recordes do jogo são enviados pelos navegadores, NÃO verificados no servidor.
