-- EMERALD LIVING WORLD 3.0 · Chat público por salas (para Supabase SQL Editor)
-- Execute após supabase/setup.sql. Nenhuma secret/service_role deve ir para o navegador.
-- As mensagens são públicas PARA CONTAS AUTENTICADAS, não para visitantes anônimos.
create table if not exists public.elw_chat_messages (
 id bigint generated always as identity primary key,
 room text not null check (room in ('geral','ajuda','trocas')),
 author_id uuid not null references auth.users(id) on delete cascade,
 nickname text not null check (char_length(nickname) between 2 and 24),
 body text not null check (char_length(btrim(body)) between 1 and 280),
 created_at timestamptz not null default now()
);
create index if not exists elw_chat_room_latest on public.elw_chat_messages(room, id desc);
create index if not exists elw_chat_author_time on public.elw_chat_messages(author_id, created_at desc);

create table if not exists public.elw_chat_reports (
 id bigint generated always as identity primary key,
 message_id bigint not null references public.elw_chat_messages(id) on delete cascade,
 reporter_id uuid not null references auth.users(id) on delete cascade,
 reason text not null check (reason in ('spam','ofensa','dados_pessoais','outro')),
 created_at timestamptz not null default now(),
 unique(message_id, reporter_id)
);
create index if not exists elw_chat_reports_time on public.elw_chat_reports(reporter_id, created_at desc);

alter table public.elw_chat_messages enable row level security;
alter table public.elw_chat_reports enable row level security;
drop policy if exists elw_chat_read_authenticated on public.elw_chat_messages;
create policy elw_chat_read_authenticated on public.elw_chat_messages for select to authenticated
 using ((select auth.uid()) is not null);
-- Não há policies de INSERT/UPDATE/DELETE: escrita somente via função segura.
revoke all on public.elw_chat_messages from public, anon, authenticated;
revoke all on public.elw_chat_reports from public, anon, authenticated;
grant select on public.elw_chat_messages to authenticated;

create or replace function public.elw_send_chat_message(p_room text,p_message text)
returns bigint language plpgsql security definer set search_path = '' as $$
declare
 uid uuid := auth.uid();
 nick text;
 content text := btrim(coalesce(p_message,''));
 new_id bigint;
begin
 if uid is null then raise exception 'Entre na sua conta para enviar.' using errcode='P0001'; end if;
 if not exists(select 1 from auth.users u where u.id=uid and u.email_confirmed_at is not null) then
   raise exception 'Confirme seu e-mail antes de conversar.' using errcode='P0001';
 end if;
 if p_room not in ('geral','ajuda','trocas') or p_room is null then raise exception 'Sala inválida.' using errcode='P0001'; end if;
 if char_length(content)<1 or char_length(content)>280 then raise exception 'Use de 1 a 280 caracteres.' using errcode='P0001'; end if;
 if content ~* '(https?://|www\.|[[:alnum:]._%+\-]+@[[:alnum:].\-]+\.[[:alpha:]]{2,})' then
   raise exception 'Não envie links nem e-mails pessoais no chat.' using errcode='P0001';
 end if;
 if content ~ '[[:cntrl:]]' then raise exception 'Mensagem contém caracteres não permitidos.' using errcode='P0001'; end if;
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(uid::text, 2930));
 if exists(select 1 from public.elw_chat_messages where author_id=uid and created_at > now()-interval '4 seconds') then
   raise exception 'Aguarde alguns segundos entre mensagens.' using errcode='P0001';
 end if;
 if (select count(*) from public.elw_chat_messages where author_id=uid and created_at>now()-interval '1 minute')>=10 then
   raise exception 'Limite de 10 mensagens por minuto.' using errcode='P0001';
 end if;
 select left(btrim(regexp_replace(coalesce(u.raw_user_meta_data->>'display_name',u.raw_user_meta_data->>'nickname','Treinador'),'[^[:alnum:] _-]','','g')),24)
 into nick from auth.users u where u.id=uid;
 if char_length(coalesce(nick,''))<2 then nick:='Treinador'; end if;
 insert into public.elw_chat_messages(room,author_id,nickname,body) values(p_room,uid,nick,content) returning id into new_id;
 return new_id;
end $$;
create or replace function public.elw_report_chat_message(p_message_id bigint,p_reason text)
returns boolean language plpgsql security definer set search_path = '' as $$
declare uid uuid:=auth.uid();begin
 if uid is null then raise exception 'Entre na sua conta.' using errcode='P0001';end if;
 if p_reason not in ('spam','ofensa','dados_pessoais','outro') or p_reason is null then raise exception 'Motivo inválido.' using errcode='P0001'; end if;
 if not exists(select 1 from auth.users u where u.id=uid and u.email_confirmed_at is not null) then raise exception 'E-mail não confirmado.' using errcode='P0001';end if;
 if not exists(select 1 from public.elw_chat_messages where id=p_message_id and author_id<>uid) then raise exception 'Mensagem não disponível para denúncia.' using errcode='P0001'; end if;
 if (select count(*) from public.elw_chat_reports where reporter_id=uid and created_at>now()-interval '1 day')>=10 then raise exception 'Limite diário de denúncias atingido.' using errcode='P0001'; end if;
 insert into public.elw_chat_reports(message_id,reporter_id,reason) values(p_message_id,uid,p_reason)
 on conflict (message_id, reporter_id) do nothing;
 return true;
end $$;
revoke all on function public.elw_send_chat_message(text,text) from public,anon;
revoke all on function public.elw_report_chat_message(bigint,text) from public,anon;
grant execute on function public.elw_send_chat_message(text,text) to authenticated;
grant execute on function public.elw_report_chat_message(bigint,text) to authenticated;
-- Opcional: para atualizações instantâneas no Supabase Realtime (polling funciona mesmo sem isso)
do $$ begin
 if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='elw_chat_messages') then
  alter publication supabase_realtime add table public.elw_chat_messages;
 end if;
exception when undefined_object then raise notice 'Realtime não disponível: atualizações periódicas continuam funcionando.';
end $$;
