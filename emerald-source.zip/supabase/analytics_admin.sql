-- Emerald Living World 2.8 — executar DEPOIS de setup.sql no SQL Editor.
-- Nenhum privilégio administrativo é decidido pelo navegador ou por e-mail nele.
create schema if not exists elw_private;

create table if not exists public.elw_admins (
 user_id uuid primary key references auth.users(id) on delete cascade,
 role text not null default 'admin' check(role in ('admin')),
 created_at timestamptz not null default now()
);
create table if not exists public.elw_profiles (
 user_id uuid primary key references auth.users(id) on delete cascade,
 created_at timestamptz not null default now()
);
create table if not exists public.elw_analytics_sessions (
 session_id uuid primary key,
 visitor_id uuid not null, -- ID aleatório; só enviado após consentimento
 user_id uuid references auth.users(id) on delete set null,
 first_seen timestamptz not null default now(),
 last_seen timestamptz not null default now(),
 page text not null default '/jogo/' check (char_length(page) <= 140),
 is_playing boolean not null default false
);
create index if not exists elw_sessions_seen_idx on public.elw_analytics_sessions (last_seen desc);
create index if not exists elw_sessions_visitor_idx on public.elw_analytics_sessions (visitor_id);
create table if not exists public.elw_analytics_events (
 event_id uuid primary key default gen_random_uuid(),
 session_id uuid not null references public.elw_analytics_sessions(session_id) on delete cascade,
 event_type text not null check (event_type in (
  'session_play','campaign_start','starter_choose','pokemon_capture','gym_win','gym_loss','elite_four_win','campaign_complete','save','session_end'
 )),
 detail text not null default '' check(char_length(detail) <= 42),
 created_at timestamptz not null default now()
);
create index if not exists elw_events_created_idx on public.elw_analytics_events (created_at desc);
create index if not exists elw_events_type_created_idx on public.elw_analytics_events (event_type,created_at desc);
create table if not exists public.elw_error_reports (
 id uuid primary key default gen_random_uuid(),
 session_id uuid references public.elw_analytics_sessions(session_id) on delete set null,
 message text not null check(char_length(message) <= 180),
 page text not null default '/' check(char_length(page) <= 140),
 created_at timestamptz not null default now()
);
create index if not exists elw_errors_time_idx on public.elw_error_reports (created_at desc);

-- RLS: somente Edge Functions com service_role podem ler/escrever telemetria.
alter table public.elw_admins enable row level security;
alter table public.elw_profiles enable row level security;
alter table public.elw_analytics_sessions enable row level security;
alter table public.elw_analytics_events enable row level security;
alter table public.elw_error_reports enable row level security;
revoke all on public.elw_admins, public.elw_profiles, public.elw_analytics_sessions,
 public.elw_analytics_events, public.elw_error_reports from anon, authenticated;
grant select, insert, update, delete on public.elw_admins, public.elw_profiles,
 public.elw_analytics_sessions, public.elw_analytics_events, public.elw_error_reports to service_role;

-- Contas existentes + próximas contas; jamais disponibilizar emails via analytics.
insert into public.elw_profiles(user_id,created_at)
 select id, created_at from auth.users on conflict (user_id) do nothing;
create or replace function elw_private.on_new_user() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
 insert into public.elw_profiles(user_id,created_at) values(new.id,new.created_at)
 on conflict (user_id) do nothing;
 return new;
end; $$;
drop trigger if exists elw_new_user_profile on auth.users;
create trigger elw_new_user_profile after insert on auth.users
 for each row execute function elw_private.on_new_user();
revoke all on function elw_private.on_new_user() from public,anon,authenticated;

-- Consultas agregadas: SECURITY INVOKER, acesso RPC apenas com service_role.
create or replace function public.elw_admin_report(p_days integer default 7)
returns jsonb language sql stable security invoker set search_path = '' as $$
with window_args as (select greatest(1,least(90,p_days)) as days),
 sessions as (select * from public.elw_analytics_sessions
  where first_seen >= now()-(select days from window_args)*interval '1 day'),
 events as (select * from public.elw_analytics_events
  where created_at >= now()-(select days from window_args)*interval '1 day'),
 pages as (select page,count(*) as visits from sessions group by page order by visits desc limit 12),
 byday as (select to_char(first_seen at time zone 'UTC','YYYY-MM-DD') as day,
  count(*) as visits,count(distinct visitor_id) as visitors
  from sessions group by 1 order by 1),
 kinds as (select event_type,count(*) as total from events group by event_type),
 starters as (select detail as starter,count(*) as total from events where event_type='starter_choose'
  and detail in ('Treecko','Torchic','Mudkip') group by detail order by total desc),
 gyms as (select detail as gym,count(*) as defeats from events where event_type='gym_loss'
  and char_length(detail)>0 group by detail order by defeats desc limit 8)
select jsonb_build_object(
 'days',(select days from window_args),
 'uniqueVisitors',(select count(distinct visitor_id) from sessions),
 'visits',(select count(*) from sessions),
 'activePlayers',(select count(*) from public.elw_analytics_sessions where is_playing and last_seen>now()-interval '2 minutes'),
 'registeredAccounts',(select count(*) from public.elw_profiles),
 'averageMinutes',(select coalesce(round(avg(extract(epoch from last_seen-first_seen)/60)::numeric,1),0) from sessions),
 'campaignStarts',(select count(*) from events where event_type='campaign_start'),
 'campaignFinishes',(select count(*) from events where event_type='campaign_complete'),
 'errors',(select count(*) from public.elw_error_reports where created_at>=now()-(select days from window_args)*interval '1 day'),
 'pages',(select coalesce(jsonb_agg(to_jsonb(pages)),'[]'::jsonb) from pages),
 'daily',(select coalesce(jsonb_agg(to_jsonb(byday)),'[]'::jsonb) from byday),
 'events',(select coalesce(jsonb_agg(to_jsonb(kinds)),'[]'::jsonb) from kinds),
 'starters',(select coalesce(jsonb_agg(to_jsonb(starters)),'[]'::jsonb) from starters),
 'gymDefeats',(select coalesce(jsonb_agg(to_jsonb(gyms)),'[]'::jsonb) from gyms),
 'countriesAvailable',false
); $$;
create or replace function public.elw_public_report()
returns jsonb language sql stable security invoker set search_path = '' as $$
select jsonb_build_object(
 'accounts',(select count(*) from public.elw_profiles),
 'participatingTrainers',(select count(*) from public.elw_leaderboard),
 'aiTrainersPerSimulation',100,
 'reportedBattles',null,
 'captures',(select count(*) from public.elw_analytics_events where event_type='pokemon_capture'),
 'finishedCampaigns',(select count(*) from public.elw_analytics_events where event_type='campaign_complete'),
 'topStarters',(select coalesce(jsonb_agg(row_to_json(s)),'[]'::jsonb) from (
  select detail as name,count(*) as total from public.elw_analytics_events
  where event_type='starter_choose' and detail in ('Treecko','Torchic','Mudkip')
  group by detail order by total desc) s)
); $$;
revoke all on function public.elw_admin_report(integer),public.elw_public_report() from public,anon,authenticated;
grant execute on function public.elw_admin_report(integer),public.elw_public_report() to service_role;
-- Não conceder permissões a nenhuma conta aqui automaticamente.
-- Após registrar-se e confirmar o e-mail, executar MANUALMENTE:
-- insert into public.elw_admins(user_id)
-- select id from auth.users where email = '<EMAIL_DO_ADMIN>' and email_confirmed_at is not null
-- on conflict (user_id) do nothing;
-- Recomenda-se habilitar MFA no Supabase Auth para a conta administradora.
