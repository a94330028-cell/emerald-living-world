-- Emerald Living World v3.6: Arena PvP, fila por formato e Elo sob controle do servidor.
-- Tabelas privadas: nenhuma política para anon/authenticated. Somente Edge Function acessa com service_role.
create table if not exists public.elw_arena_ratings (
 user_id uuid primary key references auth.users(id) on delete cascade,
 display_name text not null check (char_length(display_name) between 2 and 24),
 rating integer not null default 1000 check (rating between 100 and 5000),
 wins integer not null default 0 check (wins>=0),
 losses integer not null default 0 check (losses>=0),
 draws integer not null default 0 check (draws>=0),
 updated_at timestamptz not null default now()
);
create table if not exists public.elw_arena_queue (
 user_id uuid primary key references auth.users(id) on delete cascade,
 format smallint not null check (format in (1,3,6)),
 team jsonb not null check(jsonb_typeof(team)='array' and jsonb_array_length(team) in (1,3,6)),
 created_at timestamptz not null default now()
);
create table if not exists public.elw_arena_matches (
 id uuid primary key default gen_random_uuid(),
 player1 uuid not null references auth.users(id) on delete cascade,
 player2 uuid not null references auth.users(id) on delete cascade,
 format smallint not null check (format in (1,3,6)),
 battle jsonb not null,
 action1 jsonb,
 action2 jsonb,
 status text not null default 'active' check(status in ('active','finished')),
 winner smallint check(winner in (-1,0,1)),
 version integer not null default 1,
 rating_done boolean not null default false,
 rating_delta1 integer,
 rating_delta2 integer,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now(),
 constraint different_arena_users check(player1 <> player2)
);
create index if not exists elw_arena_queue_match_idx on public.elw_arena_queue(format,created_at);
create index if not exists elw_arena_player1_idx on public.elw_arena_matches(player1,created_at desc);
create index if not exists elw_arena_player2_idx on public.elw_arena_matches(player2,created_at desc);
create index if not exists elw_arena_rating_idx on public.elw_arena_ratings(rating desc);
alter table public.elw_arena_ratings enable row level security;
alter table public.elw_arena_queue enable row level security;
alter table public.elw_arena_matches enable row level security;
revoke all on public.elw_arena_ratings,public.elw_arena_queue,public.elw_arena_matches from anon,authenticated;
grant select,insert,update,delete on public.elw_arena_ratings,public.elw_arena_queue,public.elw_arena_matches to service_role;

create or replace function public.elw_arena_join(p_user uuid,p_team jsonb,p_format smallint,p_name text)
returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare rival uuid; newmatch uuid; rivalteam jsonb; existingmatch uuid;
begin
 if p_user is null or p_format not in (1,3,6) or jsonb_typeof(p_team)<>'array' or jsonb_array_length(p_team)<>p_format
   or char_length(p_name) not between 2 and 24 then raise exception 'Parâmetros inválidos'; end if;
 perform pg_advisory_xact_lock(hashtextextended('elw_arena_queue_'||p_format::text,0));
 insert into public.elw_arena_ratings(user_id,display_name) values(p_user,p_name)
 on conflict(user_id) do update set display_name=excluded.display_name;
 select id into existingmatch from public.elw_arena_matches where status='active' and (player1=p_user or player2=p_user)
 order by created_at desc limit 1;
 if existingmatch is not null then return jsonb_build_object('status','matched','matchId',existingmatch); end if;
 select user_id,team into rival,rivalteam from public.elw_arena_queue
 where format=p_format and user_id <> p_user and created_at > now()-interval '15 minutes'
 order by created_at asc for update skip locked limit 1;
 if rival is null then
   insert into public.elw_arena_queue(user_id,format,team,created_at) values(p_user,p_format,p_team,now())
   on conflict(user_id) do update set format=excluded.format,team=excluded.team,created_at=now();
   return jsonb_build_object('status','waiting');
 end if;
 -- Battle body is supplied only by the verified Edge Function with normalized teams.
 insert into public.elw_arena_matches(player1,player2,format,battle)
 values(rival,p_user,p_format,jsonb_build_object('team1Ids',rivalteam,'team2Ids',p_team,'turn',0)) returning id into newmatch;
 delete from public.elw_arena_queue where user_id in (p_user,rival);
 return jsonb_build_object('status','matched','matchId',newmatch);
end $$;

-- Complete an already-finished match exactly once; both rating updates are in one transaction.
create or replace function public.elw_arena_finalize(p_match uuid)
returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare m record; a integer; b integer; e1 double precision; e2 double precision; score1 double precision; score2 double precision; d1 integer; d2 integer;
begin
 select * into m from public.elw_arena_matches where id=p_match for update;
 if not found then raise exception 'Partida não encontrada'; end if;
 if m.status<>'finished' then return jsonb_build_object('applied',false); end if;
 if m.rating_done then return jsonb_build_object('applied',false,'delta1',m.rating_delta1,'delta2',m.rating_delta2); end if;
 insert into public.elw_arena_ratings(user_id,display_name) values(m.player1,'Treinador') on conflict(user_id) do nothing;
 insert into public.elw_arena_ratings(user_id,display_name) values(m.player2,'Treinador') on conflict(user_id) do nothing;
 select rating into a from public.elw_arena_ratings where user_id=m.player1 for update;
 select rating into b from public.elw_arena_ratings where user_id=m.player2 for update;
 score1:=case m.winner when 0 then 1.0 when 1 then 0.0 else 0.5 end;score2:=1-score1;
 e1:=1.0/(1.0+power(10.0,(b-a)/400.0));e2:=1-e1;
 d1:=round(24*(score1-e1));d2:=round(24*(score2-e2));
 update public.elw_arena_ratings set rating=greatest(100,rating+d1),wins=wins+(case when score1=1 then 1 else 0 end),losses=losses+(case when score1=0 then 1 else 0 end),draws=draws+(case when score1=.5 then 1 else 0 end),updated_at=now() where user_id=m.player1;
 update public.elw_arena_ratings set rating=greatest(100,rating+d2),wins=wins+(case when score2=1 then 1 else 0 end),losses=losses+(case when score2=0 then 1 else 0 end),draws=draws+(case when score2=.5 then 1 else 0 end),updated_at=now() where user_id=m.player2;
 update public.elw_arena_matches set rating_done=true,rating_delta1=d1,rating_delta2=d2 where id=p_match;
 return jsonb_build_object('applied',true,'delta1',d1,'delta2',d2);
end $$;

revoke all on function public.elw_arena_join(uuid,jsonb,smallint,text) from public,anon,authenticated;
revoke all on function public.elw_arena_finalize(uuid) from public,anon,authenticated;
grant execute on function public.elw_arena_join(uuid,jsonb,smallint,text) to service_role;
grant execute on function public.elw_arena_finalize(uuid) to service_role;
