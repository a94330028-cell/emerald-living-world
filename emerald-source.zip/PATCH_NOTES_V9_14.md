# Patch Notes V9.14

- Padronizados 20 personagens em **spritesheets 32×48 por quadro**, sem versão compacta 16×32.
- Centralizados seleção, direção e desenho para mapa principal, mapa técnico e modo online.
- Bots novos usam a coleção completa; perfis podem escolher 20 avatares.
- Adicionados 10 NPCs opcionais desafiáveis em áreas adaptadas, com times e vitórias persistentes.
- Mantidos os sistemas de combate, Pokédex, save e rankings.
- 105 testes automáticos aprovados na rodada final, além do teste de navegador Android.
