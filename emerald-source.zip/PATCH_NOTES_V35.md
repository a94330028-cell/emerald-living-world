# 🌿 Emerald Living World — Patch Notes 3.5

- 📖 Tutorial interativo de 7 etapas para novos jogadores.
- 🌱 Acesso ao tutorial direto da tela inicial, navegação e rodapé.
- 🧭 Explicações de controle de jornada, escolhas manuais e batalhas.
- 🎒 Orientação sobre time Pokémon, Pokédex e PC.
- 🏆 Explicação dos dois rankings de treinadores.
- 💾 Orientações para proteger saves locais e usar configurações.
- 🌙 Tema visual adaptado ao modo escuro.
- 📱 Interface de tutorial responsiva e navegável por teclado.
- 🎮 Nenhuma modificação nas regras, saves, dados de treinador ou motor de batalha.
