# 🌿 Emerald Living World V9.3 — Pokémon Nacional nas IAs

## Resultado principal
Agora o simulador **offline** reconhece os **1.025 Pokémon da Pokédex Nacional**, 494 formas internas com chaves próprias e 9 entradas experimentais do catálogo da V9.1. As 1.025 espécies podem entrar em batalhas, atributos, equipes, capturas e saves. O servidor Node.js também usa encontros nacionais para bots, com o mesmo motor de combate dos jogadores.

### O que mudou
- `jogo/game/pokemon/national-catalog.js`: estatísticas-base compactas do catálogo que o projeto já tinha, sem ROM, mapas ou sprites da ROM.
- `jogo/game/pokemon/national-pools.js`: filtro de fauna por habitat, insígnias, força e raridade; compartilhado pelos sistemas offline e online. **Essas tabelas de encontros são adaptadas, não são tabelas oficiais da ROM Quetzal.**
- `jogo/js/engine.js`: registra as espécies e os tipos secundários na IA offline; adiciona encontros nacionais em 65% das tentativas elegíveis, preservando os encontros clássicos nas demais; acrescenta alguns métodos **confirmados** de evolução por nível (principalmente iniciais); usa imagens locais com fallback externo numerado para as novas espécies.
- `jogo/js/pages.js`: duas configurações novas na aba avançada: **Pokédex Nacional nos encontros das IAs** (ativada por padrão) e **Formas alternativas** (desativada por padrão).
- `server/autonomy.cjs`: bots passam a buscar e capturar espécies de várias gerações em batalhas de verdade, mas mantêm os encontros específicos exigidos para derrotar Roxanne, Brawly e Wattson. Capturas também podem ser enviadas ao PC se a equipe tiver seis Pokémon.
- `server/battle.cjs`: o modo nacional do servidor passa a reutilizar o seletor compartilhado e continua usando os mesmos atributos/captura/EXP do motor já existente.
- O modo **Colecionador** não bloqueia a entrada na Liga pelo aumento do catálogo. O catálogo total pode ser completado no pós-jogo, quando houver as condições de encontro.

## Entendendo 'todos os Pokémon'
- **1.025 espécies:** registradas e utilizáveis; todas entram no conjunto de encontros nacionais possíveis após alcançar condições suficientes de progressão. A probabilidade de encontrar cada uma é diferente e nenhuma é dada automaticamente aos bots.
- **494 formas internas:** dados registrados separadamente; podem ser incluídas nos encontros offline pelo ajuste *Formas alternativas*. A identidade exata e os sprites de muitas formas **não foram verificados** — por padrão ficam fora dos encontros aleatórios.
- **9 registros experimentais:** preservados no catálogo, mas **não** inseridos aleatoriamente por terem identidade e disponibilidade não confirmadas.
- Espécies raras ou de poder elevado só ficam elegíveis em fases avançadas ou pós-jogo. Os Pokémon tradicionais de Hoenn continuam aparecendo.

## Evidências de testes
- `node --test` → **72/72 testes aprovados** (66 regressões anteriores + 6 de simulação nacional).
- `python tests/browser-smoke.py` → **20 bots se moveram durante 721 turnos**, sem erros de JavaScript, sem posição inválida, com restauração de save e sem rolagem horizontal inesperada em viewport Android.
- `python tests/browser-v9-3-national.py` → motor offline carregou todos os 1.528 registros; Sprigatito teve atributos maiores no nível 20 que no nível 5; **uma IA capturou Sprigatito em batalha** e o adicionou à sua equipe junto a Mudkip. Captura repetida até ocorrer, sem conceder Pokémon de graça.
- `tests/v9_3_load_report.json` → **100 bots por 400 decisões cada no Node**: 118 eventos de captura, 70 espécies diferentes presentes, incluindo 39 espécies das gerações 4–9. Nenhum Pokémon resultante sem IV/EV ou nível válido. **Esse é um teste lógico do servidor, não uma campanha inteira.**

## Limitações importantes
- Apenas métodos de evolução por nível explicitamente cadastrados foram adicionados; **a maioria das evoluções por pedra, troca, item e amizade de outras gerações ainda precisa de dados corretos.**
- Os golpes dos Pokémon novos usam conjuntos genéricos do motor existentes, **não os learnsets completos da versão Quetzal**. Habilidades individuais e formas especiais também não foram integradas integralmente.
- O motor de combate permanece simplificado para gerações posteriores (por exemplo, não reproduz todos os efeitos específicos de golpes e habilidades modernas).
- Algumas fotos ainda dependem de imagens externas e conexão à internet; isso não são sprites originais extraídos do Quetzal.
- No online, **a história do servidor ainda termina após Wattson**. A V9.3 amplia os Pokémon dos bots; não conclui os cinco ginásios restantes.
- A simulação offline executa no navegador e para quando a página não está rodando. Para bots persistirem sem ninguém assistindo, inicie o servidor Node.js em uma hospedagem persistente.
- A V9.3 **não foi publicada automaticamente** no site. Faça backup dos saves e publique a pasta `jogo/`, com o backend `server/` para a versão online.

## Configuração
1. Abra o jogo, navegue até **Configurações avançadas**.
2. Em Capturas, marque **Pokédex Nacional nos encontros das IAs**.
3. Ajuste opcionalmente **Formas alternativas**. O ajuste padrão preserva as formas especiais fora dos encontros aleatórios.
4. Seus saves V9.2 continuam na mesma chave e não precisam ser apagados.
