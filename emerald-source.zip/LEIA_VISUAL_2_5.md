# Emerald Living World — Versão 2.5 · Edição Visual Clássica

Esta edição mantém a **estrutura completa** da versão 2.5: `index.html` na raiz, pasta `jogo/`, servidor `server/`, testes e documentos de versões anteriores. Não substitui a simulação por uma imagem.

## Visual atualizado

- Cabeçalho com paisagem em pixel art, logotipo escrito em HTML e controles originais.
- Paleta inspirada nos jogos clássicos: verde-esmeralda, creme, dourado e vermelho da Pokédex.
- Tela **Jogo**: mapa animado e controles originais, equipe do treinador e classificação por insígnias / Top 6, com painéis renovados.
- Tela **Pokédex**: dispositivo vermelho de aparência clássica, pesquisa funcional por nome e número, filtros por geração, lista paginada e fichas com sprites, tipos, atributos-base, BST, taxa de captura e locais **adaptados do simulador**.
- Tela **Rank**: insígnias, times mais fortes, Pokémon mais forte e Top 6 com identidade visual atualizada.
- Créditos, Histórico, Recuperação, Mapa, Configurações e outras páginas permanecem acessíveis pelo menu secundário.
- As fichas técnicas anteriores da Pokédex permanecem acessíveis em **Abrir fichas técnicas do simulador**.

## Como abrir

Em hospedagem estática, extraia o ZIP preservando as pastas e publique o conteúdo da raiz. Acesse `index.html`; ele direciona para `jogo/index.html`. Para uso local, sirva os arquivos com um servidor HTTP em vez de abrir `file://`, pois a Pokédex busca um JSON local. O multiplayer online continua exigindo o servidor Node.js.

## O que foi testado

- Testes automatizados do projeto com `npm test`.
- Teste visual **isolado** em Chromium com largura Android e desktop, incluindo busca por Sprigatito, seleção de Pikachu e filtro da geração III. Esse teste utilizou os HTML/CSS/JS reais da Pokédex com os dados locais, mas **não foi uma execução completa do mundo ou do servidor**.
- O navegador desta sessão bloqueou a navegação HTTP local para o site inteiro; por isso a tela completa com simulação em execução não foi validada visualmente nesta rodada.

## Recursos e limites

Os sprites locais disponíveis são usados em primeiro lugar. Para outras espécies, o projeto mantém os carregadores externos com fallback neutro, e imagens externas dependem de internet. O catálogo nacional tem 1.025 espécies, mas o motor de jogo não implementa todas as regras individuais de golpes e evolução. A campanha online também permanece parcial.

Os exemplos da imagem-conceito anterior (equipes, níveis, pontos e capturas) **não foram copiados** como dados fictícios para o jogo. Contagens e rankings vêm do estado real da simulação.

Faça backup dos saves antes de publicar qualquer versão nova.
