# 🌿 Emerald Living World — Patch Notes 3.0 Beta (Revisão 2)

**⚔️ Batalhas Gen III** — Reorganização dos modificadores de dano, críticos, clima, STAB, tipos, arredondamentos e Explosion no núcleo do mundo compartilhado.

**🔴 Poké Bolas** — Captura com taxa por espécie, HP, bônus de status e quatro verificações, seguindo o modelo clássico da terceira geração.

**🧬 Tipos históricos** — Pokémon das três primeiras gerações que receberam Fairy posteriormente agora usam a tipagem original quando o formato é `gen3_emerald`. A Arena separada foi mantida.

**🤖 Autonomia dos bots** — Melhoria no planejamento de treino para Wattson. As equipes, capturas e insígnias continuam sendo conquistadas por ações da simulação, não adicionadas automaticamente.

**📱 Android** — Interface de combate mostra status e PP, indica golpes sem PP e aumenta a área dos botões para toque.

**💾 Salvamento** — Backup local de segurança para o mundo persistente e possibilidade de recuperar uma cópia válida em caso de corrupção do arquivo principal.

**🛡️ Preservação** — Todos os habitats, espécies e encontros nacionais permanecem intactos. Módulos centrais da Arena mantidos sem modificação, com validação SHA-256 portátil.

**⚠️ Beta** — Campanha, Battle Frontier, Double/Multi e Supabase ainda precisam de desenvolvimento adicional; não houve publicação no site.
