# 🌿 Emerald Living World 2.5 — Login e Top Mundial

Este ZIP mantém o jogo, com autenticação por e-mail + senha, confirmação de e-mail opcional, recuperação de senha, save online por usuário, isolamento de saves no mesmo navegador, placar mundial de equipes e ranking de campeões por **rodadas simuladas** e página **Sobre o Projeto**.

## ⚙️ Ativar login e placar mundial (obrigatório)

O ZIP é estático e **não inclui um banco de dados ou contas já funcionando**. Para que contas/saves sejam compartilhados entre dispositivos:

1. Crie um projeto gratuito no [Supabase](https://supabase.com/).
2. Em **SQL Editor**, execute o conteúdo de `supabase/setup.sql`.
3. Em **Project Settings → API / Data API**, copie a **Project URL** e uma chave **publishable** (`sb_publishable_...`) ou a antiga `anon public` (NUNCA `service_role` / chave secreta).
4. Abra `jogo/js/cloud-config.js` e preencha `supabaseUrl` e `supabaseAnonKey`, mantendo as aspas.
5. Em **Authentication → URL Configuration**, defina **Site URL** como `https://SEU-SITE/jogo/index.html` e adicione esse endereço a **Redirect URLs**. Se publicar o site em subpasta, ajuste o caminho. Use HTTPS.
6. Em **Authentication → Providers → Email**, habilite login por e-mail e, de preferência, confirmação de e-mail. Teste e-mails de confirmação e recuperação.
7. Publique o ZIP inteiro (ex.: Vercel/Netlify); abra `jogo/index.html`, clique em **Conta**, crie uma conta e faça login. Use uma segunda conta/navegador para testar o top global.

Uma hospedagem estática é suficiente para o jogo **desde que o Supabase esteja configurado**. Sem isso, o jogo continua local e a tela informa que os recursos online estão desativados.

## 💾 Como funcionam os saves

- Cada conta possui um save completo do mundo + campanha manual + opções relevantes. Salvamento local continua e, com login, ocorre sincronização remota periódica de aproximadamente um minuto, além de botão **Salvar na nuvem**.
- No primeiro login, se houver save de visitante, você escolhe entre usá-lo na conta ou iniciar do zero. Se há save remoto e local diferentes, é exibida uma escolha antes de sobrescrever qualquer um.
- Ao sair, os saves locais são separados por conta e o save do visitante é restaurado.
- Evite jogar simultaneamente com a mesma conta em dois dispositivos: o último save enviado pode substituir progresso. Faça backups locais em Configurações.
- O app usa armazenamento local do navegador para a sessão. Não coloque senhas em links, chats ou repositórios.

## 🏆 Regras do top mundial

- **Melhores equipes**: soma dos 6 atributos atuais de cada Pokémon da equipe (mesma fórmula de `emeraldPower` no jogo), com um time próprio de cada conta; não conta o time de IAs de terceiros apenas observadas.
- **Mais rápidos**: menor número de rodadas simuladas para o **seu bot** vencer a Liga. Não é relógio real e a velocidade de execução do navegador não altera esse número. A campanha manual antiga não participa do tempo global pois não registra rodadas equivalentes.
- Cada conta publica apenas apelido, até 6 Pokémon, nível, pontuação, insígnias e recorde. Os saves completos só podem ser acessados pelo próprio dono mediante políticas RLS.
- **Não é um placar competitivo antitrapaça**: como o jogo roda no aparelho do jogador, os valores enviados podem ser alterados localmente. Para uma competição oficial seria necessário validar partidas em um servidor autoritativo.

## ✨ Arquivos adicionados

- `jogo/js/cloud-bootstrap.js`: isolamento de saves por conta antes de carregar o jogo.
- `jogo/js/cloud-config.js`: URL e chave pública do Supabase.
- `jogo/js/cloud-account.js`: login, cadastro, sessão, recuperação, backup e rankings.
- `jogo/css/cloud-account.css`: interface dark responsiva.
- `supabase/setup.sql`: tabelas, permissões e RLS.
- `jogo/index.html` e `jogo/js/pages.js`: novas páginas de conta, ranking mundial e Sobre o Projeto.

**Atenção:** sites publicados previamente podem servir arquivos do cache. Depois de atualizar, recarregue completamente o site.
