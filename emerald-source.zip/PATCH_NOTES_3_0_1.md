# 🌿 Patch Notes — Emerald Living World 3.0.1

## Correções do motor de batalha

- Fake Out: flinch garantido quando atinge um alvo suscetível, respeitando Inner Focus e Shield Dust; efeito restrito ao primeiro turno em campo; não é movimento de contato na Gen III.
- Struggle: substituído o dano fixo simplificado pela fórmula de força física 50, sem efetividade de tipo; agora atinge Fantasma, causa recuo equivalente a 1/4 do dano efetivo, respeita Protect e a checagem de precisão da Gen III.
- Aerial Ace: acerto não depende de modificadores de precisão/evasão.
- Status e PP: golpes impedidos por sono, congelamento, paralisia, confusão ou flinch não consomem PP. Pressure custa 2 PP quando o golpe é de fato executado e mira o alvo; Fake Out usado fora do primeiro turno falha e gasta PP.

## Organização e experiência

- Títulos/versões de portal, lobby, campanha e Frontier padronizados em 3.0.1.
- Documentação de instalação reunida; modelo separado para ambiente local com menos bots.
- Scripts de testes locais, auditoria de preservação e verificação HTTP mantidos.
- Testes específicos de mecânicas Gen III e interface adicionados.

## O que NÃO foi alterado

- Oito arquivos nacionais de Pokémon, habitats, catálogos e Arena Competitiva permanecem idênticos aos registros da RC6, conforme SHA-256.
- O banco Supabase e o site hospedado não receberam nenhuma alteração. Os saves existentes não foram substituídos.

## Limites

Faltam mecânicas completas da ROM, Símbolos oficiais, todos os eventos da história e homologação do MMO público. Esta é uma revisão jogável local, não a declaração de fidelidade total à ROM.
