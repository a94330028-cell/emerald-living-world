# Guia de instalação e limites — Emerald Living World 3.0.0

**Edição jogável local**. Não confunda a etiqueta do pacote com a homologação de um MMO público.

## Instalação segura

1. Faça backup de `server/data/world.json` e do `.bak` anterior. Mantenha o ZIP RC7 separado.
2. Extraia o ZIP 3.0 em uma pasta nova. Se for migrar o save, copie apenas o `world.json` antigo e o backup para `server/data/` (ou configure `DATA_DIR`).
3. Instale Node 20+ e execute `npm run verify:local` no diretório raiz.
4. Execute `npm start` (o servidor abre em `http://127.0.0.1:8787`).
5. Abra `jogo/online.html`, `jogo/jornada.html`, `jogo/frontier.html` ou `jogo/arena.html` pelo servidor.
6. Para parar, use Ctrl+C, permitindo ao servidor salvar o progresso. Guarde backups periódicos.

## Comandos

- `npm test`: regressão automatizada.
- `npm run audit:preservation`: hashes SHA-256 dos oito arquivos nacionais e da Arena.
- `npm run audit:release`: relatório de prontidão e limitações.
- `npm run audit:production`: validação estrita; pode terminar em erro porque a homologação pública não foi executada.

## Publicar futuramente

É necessário hospedagem com processo Node contínuo, disco persistente, HTTPS e `AUTH_MODE=required` com `SUPABASE_URL` e chave **publicável/anon**, além de testes reais de login e RLS. Não publique `service_role`, secrets ou dados privados no cliente. Verifique logs, controles de acesso, backup/restore, latência e funcionamento em celular antes de abrir a comunidade.

## Recorte funcional

Campanha de Hoenn adaptada, bots, capturas nacionais, Arena separada e Frontier LAB de sete instalações. O modo LAB tem medalhas e pontos próprios, não permite Símbolos oficiais. O motor de batalha é um subconjunto de Gen III. Nem todas as regras e eventos originais foram concluídos.
