# 🌿 Emerald Living World — 3.0 RC1

Esta compilação é **candidata à versão final** e não está marcada como Beta no número de versão. Isso **não significa** que o MMO esteja homologado para produção pública. O status final depende de autenticação, compatibilidade de batalha, Battle Frontier real, testes visuais e carga.

## Concluído nesta atualização

- Ginásio de **Tate e Liza jogável como Double Battle**, com dois Pokémon por lado, prioridades, velocidade, escolhas independentes de golpes do jogador, seleção de alvos, ataques em área, Helping Hand e Follow Me nos conjuntos de golpes suportados, desmaios e substituições durante o turno.
- A simulação dos bots agora escolhe ações Double sem bloquear a progressão para a Liga.
- A interface web permite escolher o golpe do segundo Pokémon e selecionar os alvos de ambos.
- Regressões automatizadas para insígnia, golpes duplos, seleção de alvos e preservação dos dados nacionais.
- Os arquivos de **habitats, encontros e catálogo nacional** e os principais arquivos da **Arena** continuam idênticos à base 3.0 Beta R2. Consulte `tests/fixtures/preserved-v3-content.sha256.json`.
- Script `npm run audit:release` identifica requisitos ainda pendentes para publicação.

## Situação dos sistemas

| Área | Situação |
|---|---|
| Oito líderes e Elite Four + Wallace | Fluxo de batalha de teste disponível; história completa ainda incompleta |
| Tate e Liza Double | Jogável, conjunto de regras Gen III parcial |
| 100 bots | Quantidade configurável até 100; longa carga em produção ainda sem validação |
| Encontros nacionais e capturas dos bots | Preservados sem alterações nos arquivos originais |
| Arena Competitiva | Arquivos existentes preservados; online precisa de validação pública |
| Battle Frontier | Sete protótipos LAB; sem certificação das regras e símbolos originais |
| Login e saves | Sessões de visitante no servidor; Supabase Auth definitivo **não implementado** |
| Motor de batalha | Subconjunto Gen III; não é emulação completa de Emerald |
| Teste Android/Chromium visual | Inconclusivo no ambiente de testes; erro `ERR_BLOCKED_BY_ADMINISTRATOR` |

## Instalação local

Instale Node.js 20+, extraia o ZIP e execute:

```bash
npm test
npm run audit:release
npm start
```

Abra `http://localhost:8787/jogo/online.html`. Acesse a campanha, ganhe seis insígnias e desafie Tate e Liza em Mossdeep. O jogador escolhe o movimento e o alvo do primeiro Pokémon, além do movimento e do alvo do segundo. Se somente um Pokémon permanecer apto, ele poderá continuar combatendo.

**Não publique como MMO aberto ainda:** contas de visitante, protótipos de Frontier, fidelidade parcial e testes de carga pendentes são riscos conhecidos. A opção `npm run audit:production` falha deliberadamente enquanto houver impedimentos. Nenhuma alteração foi implantada no Supabase nem em hospedagem remota.
