# Patch notes 2.5 — Continuar e atributos
- Simulação inicia pausada, inclusive com saves existentes.
- Botão Continuar Jornada com validação de save.
- Botão Nova Jornada abre configuração com confirmação de reinício.
- Sem criação automática de save ao simplesmente visitar a página pela primeira vez.
- Removida a mudança de cidade durante migração de saves antigos.
- Fichas completas de atributos e ataques da equipe, bot solo e PC.
- Detalhes de golpes disponíveis na Pokédex Nacional, diferenciados de learnsets completos.
- Novos testes de boot e Pokémon; nomes/caminhos de arquivos invalidados para cache.
