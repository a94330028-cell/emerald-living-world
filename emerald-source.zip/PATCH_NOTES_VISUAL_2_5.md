# Patch Notes — Edição Visual Clássica 2.5

- Adicionado `jogo/css/emerald-classic-25.css` com tema consistente para Jogo, Pokédex, Rank, controles e cards.
- Adicionado banner pixelado local `jogo/assets/ui/hoenn-pixel-banner.png`.
- Adicionado `jogo/js/emerald-classic-dex.js`: Pokédex navegável de 1.025 espécies, com filtros e fichas individuais.
- `jogo/index.html` recebeu os elementos da Pokédex e a carga do tema e do script.
- Preservada a Pokédex técnica anterior dentro de uma seção recolhível.
- Nenhum módulo de colisão, batalha, progressão, navegação, servidor ou persistência foi alterado.
