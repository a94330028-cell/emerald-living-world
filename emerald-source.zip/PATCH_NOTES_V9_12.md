# V9.12 — Corrigido o Top 6 e melhorada a escala de poder

- Removida a Poké Bola `UNKNOWN` como imagem de fundo permanente no Top 6.
- Novo ícone neutro para as espécies cujos sprites realmente não puderem ser carregados.
- Mantidas prioridades de imagens locais e sprites nacionais da fonte externa.
- Top 6, rankings offline e pontuação individual agora usam os seis atributos reais de cada Pokémon calculados por nível/IV/EV/Nature.
- Desempenho das batalhas e fórmulas da Geração III preservados.
- Revalidação em Android com testes de níveis e visual.
