# 📗 Guia — Emerald Living World 3.0 RC5

## Como testar

Requisitos: Node.js 20+ e computador/servidor com Node. Extraia o ZIP e execute a partir da pasta principal:

```bash
npm test
npm run audit:release
npm start
```

No navegador, abra `http://localhost:8787/jogo/online.html`. Crie uma sessão e entre em `http://localhost:8787/jogo/frontier.html`.

A hospedagem exclusivamente estática não executa o servidor multiplayer. Para publicar, use um serviço compatível com Node.js e configure autenticação e armazenamento persistente. Consulte o guia de publicação segura incluído.

## O que testar em cada instalação

| Instalação | Verificação |
|---|---|
| Tower | Sequências de sete batalhas e Anabel nos marcos respectivos |
| Dome | Visualize a chave com 16 participantes; escolha dois dos três Pokémon; vença quatro partidas por torneio |
| Palace | Use o comando para avançar e observe a escolha de golpes influenciada pela natureza |
| Arena | Sem troca voluntária; julgamento Mind, Skill, Body após três turnos |
| Factory | Escolha três de seis Pokémon alugados; após uma vitória, troque um por uma espécie disponibilizada |
| Pike | Leia a pista; escolha uma das três portas por sala; resolva batalha, recuperação ou status |
| Pyramid | Abra um andar, mova-se com as setas para encontrar a saída azul; batalhas e itens estão no caminho; use a Battle Bag |

A Frontier original só é acessível após a Liga. O treino livre é acessível antes e não concede recompensas. O progresso de laboratório não deve ser confundido com Símbolos oficiais da ROM.

## Preservação dos Pokémon dos bots

Os catálogos e habitats nacionais continuam **intocados**. O teste `npm run audit:release` valida os hashes SHA-256 de seis arquivos, incluindo os módulos-base da Arena Competitiva. Não remova ou substitua as pastas de `jogo/game/pokemon/`.

## Limitações do lançamento

`npm run audit:production` ainda bloqueia a publicação estável: existem diferenças entre as batalhas do projeto e a ROM Emerald, eventos da história por completar, segurança e autenticação a homologar no Supabase, e a ausência de teste de carga prolongado. O minimapa da Pyramid é uma adaptação original de 5×5, não uma extração da ROM.

Nenhuma atualização foi enviada automaticamente ao site ou ao Supabase.
