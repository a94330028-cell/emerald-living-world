# 🌿 Emerald Living World — Versão 2.5 | Equipe Completa na Página Inicial

## O que mudou

A página **Jogo** agora mostra o cartão do treinador e, logo abaixo, **as fichas dos até seis Pokémon da equipe**, com:

- Sprite do Pokémon, espécie, nível e poder calculado pelo simulador.
- HP atual / máximo, com barra de vida.
- Ataque, Defesa e Velocidade já visíveis.
- Até quatro golpes conhecidos.
- Painel expansível **Atributos e ataques** com os seis atributos, PP e dados dos golpes, quando disponíveis.
- Vagas vazias quando a equipe ainda tem menos de seis Pokémon.

No modo **Só meu bot**, as cartas da equipe que já existiam foram ampliadas e os golpes também aparecem logo na ficha. A mesma Pokédex vermelha, o PC, mapas, rankings, sistema de batalha e saves foram preservados.

## Instalando

1. Guarde/exporte um backup do save.
2. Descompacte **todo o ZIP** e mantenha as pastas no lugar original: `index.html`, `jogo/`, `server/`, etc.
3. Publique os arquivos no seu site. Hospedagem estática funciona para o simulador offline; recursos online exigem servidor compatível.
4. Recarregue a página para evitar o cache de versões anteriores.
5. Escolha **Continuar Jornada**. A equipe exibida corresponde ao treinador selecionado (ou ao seu bot, no modo solo).

## Testes de validação

- `npm test`: **131 testes aprovados**.
- Chromium simulando Android: 6 fichas renderizadas, detalhes de 6 atributos e golpes acessíveis, nenhum erro de JavaScript ou rolagem horizontal no cenário de teste.
- A prévia Android usa **dados sintéticos apenas na memória do navegador de teste**, para mostrar seis posições preenchidas; não representa uma jornada real nem altera o arquivo de save do jogo.

## Limitações mantidas

A campanha, os mapas e os movimentos que ainda não estavam completos continuam em desenvolvimento. Esta atualização é uma melhoria de interface e **não adiciona ataques ou Pokémon aos times artificialmente**. O painel mostra somente os dados que o motor realmente possui.
