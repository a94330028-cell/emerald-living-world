# 🌿 Emerald Living World V7 — True Living World (marco verificável)

**Estado do projeto:** esta V7 é uma atualização real sobre os arquivos da V6, com um percurso autônomo **até a primeira insígnia** integrado no servidor. **Não é o Pokémon Emerald completo, nem o MMO definitivo.** Não foi publicada na hospedagem.

## O que esta V7 realmente faz

1. **Bots como treinadores na primeira parte da jornada:** agora o servidor cria de 5 a 100 perfis independentes. Cada um escolhe Treecko, Torchic ou Mudkip, começa em Littleroot, sai pela Route 101, procura Pokémon selvagens, captura usando Poké Bolas, ganha EXP ao vencer batalhas, atravessa as áreas conectadas e se prepara para Roxanne. Após vencer os três Pokémon dela de verdade, recebe a Stone Badge e pode atingir o nível 16 e evoluir. Quando o primeiro capítulo acaba, a IA exibe o objetivo *Dewford não implementado*, sem inventar novas insígnias.
2. **Sem progresso artificial no backend V7:** foi removida a regra V6 que concedia nível a cada 150 passos. Os níveis agora vêm das batalhas por `server/battle.cjs`, também usado por visitantes online. As vitórias, capturas, evoluções e insígnias são consequência de `Battle.act`. As curvas de EXP, movesets e parte das mecânicas ainda são simplificadas, não uma cópia completa da Geração III.
3. **Caminhos reais dentro dos mapas de teste:** `server/navigation.cjs` faz busca por caminho e usa a mesma função `world.step()` que valida passos de jogadores. Foram adicionados Route 104 sul, Petalburg Woods, Route 104 norte, Rustboro e Rustboro Gym aos mapas de teste; há **14 áreas sintéticas em vez de 9**. Essas áreas NÃO equivalem aos mapas originais completos de Emerald.
4. **Roxanne no servidor:** equipe de Geodude nível 12, Geodude nível 12 e Nosepass nível 15, com batalha sequencial de três Pokémon; a Stone Badge só é entregue após vencer os três. Visitantes podem enfrentá-la no mapa `RustboroGym`. Ela não concede insígnias por simples chegada à cidade.
5. **Treinamento mais inteligente:** a IA observa tipos de ataques, tenta enfraquecer antes de capturar, faz curas em Centros Pokémon e busca Shroomish em Petalburg Woods quando escolheu Torchic. Treinadores podem trocar Pokémon em batalha, e a EXP de vitória é dividida entre os participantes vivos. A IA ainda não possui todo o repertório estratégico de um treinador humano.
6. **Observatório:** `/jogo/online.html` agora permite consultar os bots, sua equipe, objetivo, vitórias, derrotas, decisões e ranking. Em modo **Espectador** é possível seguir a câmera de um bot mesmo quando ele está em outra área/canal. O Hall da Fama só registra Campeões reais — como a Liga inteira ainda não foi implementada no servidor, permanece vazio.
7. **Simulação sem espectadores e persistência:** a simulação Node continua rodando com a página fechada enquanto o processo está ativo. Bot, Pokémon, IVs, EVs, Nature, EXP, equipe, objetivo, eventos importantes e localização são gravados em `DATA_DIR/world.json` a cada 5 segundos e no desligamento normal. Reiniciar o **processo Node** com o mesmo `DATA_DIR` restaura esse estado. O backend mantém três canais separados para visitantes.
8. **Preservação:** `jogo/index.html`, o simulador offline existente, a ROM opcional de testes, gráficos, arquivos da V6 e recursos anteriores foram mantidos. O simulador offline e o novo servidor **não compartilham save**: são sistemas separados e a unificação integral está pendente.

## Testes reproduzíveis

No diretório onde está este `LEIA_PRIMEIRO_V7.md`, com Node.js 20 ou superior:

```sh
npm test
npm run proof
```

Para o teste visual Chromium (exige Python, Playwright e Chromium instalados):

```sh
npm run test:browser
```

**Resultados registrados na compilação desta entrega:**

| Comprovação | Resultado | Limitação |
|---|---|---|
| Testes automatizados | **34/34 passaram** | Regras de servidor, rotas e fixtures sintéticas |
| Um bot completo | Escolheu Treecko, capturou parceiro, atravessou 11 áreas de teste, venceu os três Pokémon de Roxanne, ganhou Stone Badge, evoluiu a Grovyle Nv. 16 | Não corresponde à campanha completa da ROM |
| Vinte bots | 20 × 500 turnos, 19 capturas no ensaio registrado | Não significa 20 Campeões |
| Cem bots | 100 × 500 turnos, 99 capturas no ensaio registrado, nenhuma posição fora das colisões e nenhuma insígnia artificial detectada | Teste de lógica em máquina local, não prova 100 jogadores conectados nem 24h |
| Reinício do servidor | Processo Node parado e iniciado novamente; time, objetivo, eventos e sessão de visitante restaurados; turnos continuaram | Persistência em arquivo JSON, não banco transacional |
| Navegador | Chromium em 390 × 844 e 1280 × 800 sem exceções JS ou overflow | UI usou respostas HTTP simuladas: o navegador deste ambiente bloqueou `localhost` |
| Simulação offline antiga | 20/20 bots andaram em 720 turnos com exportar/importar save | Teste em mapas adaptados, não todos os mapas oficiais |

Evidências e logs: `tests/v7_evidence.json` (inclui etapas de uma batalha de ginásio), `tests/v7_browser_report.json`, `tests/v7_android_spectator.png`, `tests/v7_desktop_online.png`, `tests/generate-v7-evidence.cjs`, `tests/multiplayer/autonomy.test.cjs`, `tests/multiplayer/restart.test.cjs`.

## Como iniciar os modos

**Simulação offline anterior (sem servidor):** abra `jogo/index.html` em uma hospedagem estática. O funcionamento é o mesmo que na V6.

**V7 — servidor com bots e visitantes:**

```sh
BOT_COUNT=20 BOT_TICK_MS=650 HOST=0.0.0.0 PORT=8787 DATA_DIR=./server/data node server/app.cjs
```

Acesse `http://SEU_HOST:8787/jogo/online.html` no navegador. Em hospedagem externa utilize HTTPS (proxy confiável), armazenamento persistente para `DATA_DIR` e um processo Node que continue ativo. **O comando em si não publica o projeto na internet**. O exemplo em shell acima foi escrito para Linux/macOS; em Windows defina variáveis de ambiente com a sintaxe do sistema ou com um arquivo de configuração do seu host.

`BOT_COUNT` aceita valores de **5 a 100**. O limite é aplicado no início do processo. Para alterá-lo, reinicie o servidor com o novo valor, mantendo `DATA_DIR`. Bots existentes que excederem a nova contagem ficam guardados no save e podem ser retomados ao aumentar a contagem. `BOT_TICK_MS` controla o intervalo de atualização em milissegundos (mínimo 100), respeitando recursos do host; o sistema não acelera a taxa de usuários humanos.

**Backup:** preserve o diretório `DATA_DIR` e exporte seus saves do modo offline antes de atualizar. Uma migração de bots da V6 mantém as equipes antigas, mas sinaliza níveis históricos como *não verificados*, pois a V6 concedia níveis automaticamente por passos. O jogo publicado anterior não foi modificado.

## Pendências importantes — não chamar de “pronto”

- **Hoenn oficial:** faltam cidades, rotas, eventos, HMs, interiores, entradas, saídas, scripts e puzzles da ROM em formato validado. Os 14 mapas online são feitos para testar lógica e caminhos, não um substituto gráfico da região. Não testamos fisicamente todos os mapas oficiais nem um aparelho Android real.
- **Campanha:** apenas a primeira insígnia tem batalha/autonomia verificáveis no backend. Brawly, os outros ginásios, equipes Aqua/Magma, Elite Four, Wallace, Hall da Fama e pós-jogo ainda não podem ser completados pelos bots do servidor. A simulação offline antiga continua existindo, mas não deve ser confundida com isso.
- **Gen III completo:** faltam quase todas as espécies, habilidades, ataques, PP, condições de status, condições de evolução por item/troca, cálculo perfeito de EXP e dano, batalhas em dupla e regras completas de captura.
- **Gráficos:** o jogo ainda usa os sprites e sistemas de desenho da V6; não foram produzidos nem validados atlas definitivos para Brendan, May e cada NPC na ROM original. O ROM Lab continua uma ferramenta experimental de leitura local.
- **Multiplayer de produção:** visitantes ainda usam perfis por cookie, sem contas verificadas, moderação, anti-abuso abrangente ou banco transacional. Desafiar um bot próximo ainda utiliza o combate simplificado V6 e **não interrompe nem altera a jornada desse bot**. O PvP real e as interações persistentes entre bots/jogadores continuam pendentes. Mantenha **testes privados**.
- **Performance:** 100 bots × 500 turnos foram testados em lógica sem clientes online; não houve teste de resistência de 24 horas, carga de 100 usuários reais, ou failover após queda abrupta. JSON em arquivo pode não ser suficiente em produção.

## Arquivos novos e relevantes

- `server/autonomy.cjs`: comportamento de jornada, objetivos, decisões e histórico.
- `server/navigation.cjs`: caminho entre mapas e colisões usando o motor autoritativo.
- `server/battle.cjs`: mesmos cálculos/ações para bots e visitantes; time de Roxanne e EXP entre participantes.
- `server/world.cjs`: 14 áreas de teste e transições validadas.
- `server/app.cjs`: simulação persistente, observatório, ranking, câmera e APIs.
- `jogo/online.html`, `jogo/multiplayer/client.js`, `jogo/multiplayer/online.css`: interface de observação e ginásio.

**Princípio da V7:** uma jornada realmente simulada e verificável é mais valiosa do que declarar oito insígnias ou um mundo completo sem implementar os eventos. A primeira insígnia é uma prova concreta; as etapas posteriores devem seguir o mesmo padrão.
