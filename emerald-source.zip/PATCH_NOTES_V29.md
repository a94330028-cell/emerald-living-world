# 🌿 Emerald Living World 2.9 — Patch Notes

- 🌳 Removido o espelhamento incorreto de tiles de borda, que repetia caminhos, edifícios e outros objetos.
- 🌲 Fundo terrestre usa apenas amostras verificadas de vegetação oficial quando disponíveis; caso contrário, cor neutra temporária.
- 🌊 Mar e montanha permanecem com fundo discreto sem objetos falsos.
- 🛠️ Interface inicializa com mais segurança e ignora bloqueios opcionais de armazenamento sem derrubar a tela.
- 📱 Legibilidade corrigida no cartão claro da equipe Pokémon.
- 🧭 Saves, batalhas, continuação da jornada, simulação e conexões mantidos.
- ✅ 150 testes automatizados aprovados + testes offline de navegador e de bordas.

**Ainda não testado:** gráficos reais de todas as rotas, Android físico, servidor Supabase real e site após deploy. A versão publicada só muda depois que o ZIP é enviado à hospedagem.
