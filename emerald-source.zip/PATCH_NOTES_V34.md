# Patch Notes — Emerald Living World 3.4

## 🎨 Interface
- Entrada mobile mais compacta e organizada.
- Removidos links redundantes e acessos públicos ao multiplayer experimental.
- Navegação inferior com estilo coerente, sem Pokédex vermelha isolada.
- Melhorias de contraste e espaçamento no tema escuro.

## 🏆 Ranking
- Substituído Top 6 de Pokémon individuais por dois rankings de treinadores.
- Times mais fortes: pontuação do motor para equipe ativa, até seis Pokémon.
- História: campeão, etapa atingida, progresso na Liga, insígnias.
- Resumo equivalente integrado à página do treinador.
- Sem alterar fichas, saves ou estado das IAs.

## 🧪 Validação
- 162/162 testes automatizados aprovados.
- Chromium mobile offline: entrada e rank responsivos, ranking atualizado com dados de teste, sem erros JS.

## ⚠️ Limitações
- O Top Mundial por contas, o chat em produção e o multiplayer real exigem backend separado; os dois rankings novos mostram os participantes da simulação local.
