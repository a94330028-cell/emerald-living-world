# Emerald Living World — Versão 2.5

## Como abrir

**Para hospedar o site (Netlify, Cloudflare Pages, Vercel estático):** extraia este ZIP e envie **o conteúdo inteiro**, incluindo `index.html` e a pasta `jogo/`, para a raiz da hospedagem. Não envie apenas o arquivo HTML, pois ele precisa dos diretórios de sprites, CSS, JavaScript e dados.

**Em Android:** extraia o ZIP pelo gerenciador de arquivos. Um visualizador de arquivos compactados pode não executar o jogo. Para abrir com confiabilidade, publique o conteúdo extraído em uma hospedagem estática ou sirva-o por HTTP local. O endereço de entrada é `index.html`, que leva a `jogo/index.html`.

**Modo online:** requer Node.js 20+ em um serviço que execute o servidor continuamente; hospedagem puramente estática não ativa o multiplayer. Execute `npm start` em um ambiente com Node.js.

## Inclusos
- `index.html` — entrada na raiz
- `jogo/` — cliente completo, imagens de personagens, sprites Pokémon, páginas e assets
- `server/` — backend experimental Node.js
- `tests/` — testes automatizados
- `tools/` — utilitários
- `package.json` — scripts do servidor e testes

## Alterações desta entrega
- Marca **Emerald Living World — Versão 2.5** no título, abertura, rodapé, configuração e créditos.
- Pacote recomposto com `index.html` diretamente na raiz, sem uma pasta extra envolvendo tudo.
- Compatibilidade dos saves: chaves de armazenamento existentes preservadas.
- Código do motor usa como base a correção técnica anterior (v9.16).

**Não foram adicionados mapas ou ginásios novos nesta reembalagem.** O simulador offline e os mapas adaptados mantêm as limitações previamente documentadas. Faça backup do seu save antes de publicar uma atualização.
