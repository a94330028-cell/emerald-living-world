# 🌿 EMERALD LIVING WORLD V9 — SHARED WORLD BETA

__**NOVIDADES**__
- 🧭 Caminho a pé para encontrar um bot, sem atravessar barreiras e com aviso quando falta um evento.
- ⚔️ Duelo com o time persistente do bot; HP e resultados sincronizados no servidor.
- 👥 Dois visitantes não podem enfrentar simultaneamente o mesmo bot.
- 🏥 Melhoria da navegação em Centros Pokémon e Poké Marts compartilhados.
- 🤖 Bot que perde repetidamente para o rival na Rota 110 passa a treinar seu parceiro.
- 💾 Salvamento do HP da equipe após duelos e recuperação de duelos abandonados.
- 🎮 Reconhecimento local do cabeçalho da ROM Quetzal, com fórmula de checksum corrigida.

__**AINDA PENDENTE**__
- 🗺️ Mapas e NPCs completos de Hoenn, animações extraídas da ROM, campanha após Wattson.
- ⚔️ Batalhas online Gen III completas e IA competitiva real nos duelos.
- 🌐 Contas verificadas, PvP completo e moderação para um servidor público.

-# Os arquivos do Quetzal não estão no pacote. É uma atualização beta verificável, não o MMO completo.
