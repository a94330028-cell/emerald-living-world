# Emerald Living V2 — correção de IA parada em portas

**Causa identificada:** o movimento exigia que a célula da própria porta fosse piso caminhável. Em Pokémon Emerald, o `map.json` registra warps mesmo quando a célula do limiar é um bloco com colisão. As IAs chegavam à porta e ficavam estacionadas porque nenhum caminho até a célula da porta era aceito.

- Novos alvos de portas: chegar à célula livre adjacente, percorrendo toda a rota calculada sobre `map.bin`; só então acionar o warp original.
- Não é permitido acionar uma porta a distância nem cruzar paredes comuns.
- A direção visual do treinador é atualizada ao se aproximar da porta.
- O loop não inventa conexões se um mapa oficial está indisponível; mostra a razão de bloqueio.
- Créditos, versão pública V2, Pokédex, ginásios e as outras funcionalidades do site permanecem intactos.

**Limitações:** outras regras especiais da ROM (puzzles, Surf, mergulho, obstáculos que dependem de eventos) ainda não estão totalmente implementadas; nem todos os mapas oficiais puderam ser testados online nesta execução.
