# Versão 2 — modos, desempenho e rotas

- **Antes de começar:** tela com modos Aventura + IAs, Simulação das IAs e Campanha do jogador; quantidade configurável de 5 a 100 bots.
- **Salvamento anterior:** opção de retomar sem reiniciar as IAs; criar novo mundo reinicia apenas a simulação. Exporte seus saves por segurança.
- **Desempenho:** atualizações do mapa limitadas a 12–25 FPS conforme a quantidade de bots; processamento por lotes equitativos em modo round-robin; limite de 2 passos lógicos por frame; intervalo mínimo de 45 segundos entre autosaves. Com 80–100 IAs, cada IA avança com menor frequência para evitar congelamento do Android.
- **Encontros:** eventos comuns de Pokémon selvagem são permitidos apenas no tile de grama alta/longa/grama com cinzas do mapa oficial; encontros especiais de cavernas somente nos interiores adequados. O personagem precisa ter avançado fisicamente um bloco. Sem aparecimento genérico sobre ruas/cidades.
- **Rotas:** percurso de cada bot pode incluir desvio curto, individual e validado pelas colisões, antes de alcançar o destino oficial. Personalidades exploradoras tendem a trajetos diferentes; sem ultrapassar a ordem das missões.
- **Limitação:** sprites dos Pokémon ainda são exibidos nas batalhas/cartões, não como criaturas caminhando pelo mapa; os encontros seguem o motor de batalha. Modo "Jogador" pausa as IAs, não cria movimentação manual em mapas.
- **Validação:** testes automatizados e revisão visual devem confirmar o comportamento no seu dispositivo. Sem promessa de zero bugs.
