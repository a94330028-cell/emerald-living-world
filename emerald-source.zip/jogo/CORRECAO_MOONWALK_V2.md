# Emerald Living V2 — ajuste do moonwalk

- Encontrada a causa visual: as linhas do Brendan no atlas local estavam invertidas. A linha rotulada esquerda desenhava o rosto olhando à direita, e vice-versa.
- Corrigido apenas o atlas do Brendan (a May já tinha as duas linhas na ordem certa).
- A animação agora lê o mesmo instante de início do passo gravado pelo motor de navegação, reduzindo recuos causados por atraso entre lógica e desenho.
- Adicionada a página `teste-caminhada.html` para conferir as quatro direções no Android independentemente dos mapas.
- Os mapas, saves, batalha, PC, Pokédex, créditos e nome público V2 não foram alterados.

Limites: isso corrige o erro do sprite olhando para o lado oposto do deslocamento. A IA ainda pode fazer curvas ou ficar presa se as rotas ou eventos especiais estiverem incorretos. Não houve teste de campanha completa no Cloudflare.
