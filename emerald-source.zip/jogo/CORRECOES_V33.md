# V33 — telhados, oclusão e colisão

- A renderização dos mapas oficiais passa a separar as 3 categorias de layers do pokeemerald: metatiles `Normal` e `Split` têm suas imagens superiores por cima dos sprites; `Covered` continua atrás. Assim o personagem pode passar **por trás** da cumeeira do telhado sem aparecer sobre ela.
- `map.bin` continua sendo a referência principal de colisão/elevation. A segunda fileira do telhado das casas comuns do tileset General (`0x10` a `0x12`) recebe bloqueio defensivo, mesmo se o mapa tiver flag 0. A fileira superior (`0x08` a `0x0A`) permanece transitável, como no Emerald original.
- As rotas de IA e cada passo usam a mesma função `walkable`/`canStep`, para não atravessarem telhados sólidos.
- As colisões de ledges direcionais, sprites menores, progressão de missões e as demais correções da V32 foram mantidas.
- Os testes automatizados são sintéticos; dados reais de todos os mapas e navegação publicada no Cloudflare **não** foram testados integralmente.
