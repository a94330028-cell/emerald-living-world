# Integração de mapas originais — v31

Os dados são lidos diretamente do repositório público [pret/pokeemerald](https://github.com/pret/pokeemerald), somente quando necessários, sem incorporar os gráficos originais no ZIP.

## Como a simulação usa os mapas

1. `js/official-runtime.js` encontra um mapa a partir da etapa do treinador (por exemplo `Route 101` → `Route101`) e consulta `data/maps/<Nome>/map.json`.
2. `data/layouts/layouts.json` indica o tamanho e arquivo binário (`map.bin`), cujos bits 10–11 representam flags de colisão e bits 12–15 representam elevação.
3. Os metatiles vêm de `data/tilesets/primary|secondary/<nome>/metatile_attributes.bin`, evitando água profunda, saltos e outros terrenos que exigem ações especiais.
4. Uma busca em largura encontra os caminhos caminháveis entre a posição da IA e o destino. Cada passo é novamente validado para não atravessar paredes.
5. `warp_events` e `connections` permitem entrar em interiores e cruzar mapas adjacentes. A ligação precisa existir no arquivo oficial e o ponto de saída precisa ser caminhável.
6. `js/world.js` mostra na tela principal o tileset oficial reconstruído com `tiles.png`, `metatiles.bin` e `palettes/*.pal`. Exibe as IAs em coordenadas compatíveis com o tamanho real do mapa. A chave **🚧 Colisões** ajuda a inspecionar obstáculos.
7. `mapas-oficiais.html` continua disponível como visualizador e ferramenta de inspeção.

## Limitações

- O simulador tem regras e missões próprias. Não interpreta o código C nem os scripts e condições de cutscenes do jogo original.
- Algumas viagens mais distantes não estão conectadas bloco a bloco; são trocas de capítulo com surgimento em uma posição passável.
- Tilesets e mapas são baixados no navegador; a velocidade depende do GitHub, e não há modo offline completo.
- A campanha humana oferece batalhas e montagem do time. O marcador humano da simulação indica a etapa atual, não uma simulação manual de caminhada.
- Os testes automatizados foram feitos com arquivos simulados; mapas reais e colisões condicionais exigem validação durante o uso. Nenhuma promessa de zero erros.

## Links de referência

- https://github.com/pret/pokeemerald/tree/master/data/maps
- https://github.com/pret/pokeemerald/tree/master/data/layouts
- https://github.com/pret/pokeemerald/tree/master/data/tilesets
- https://github.com/pret/pokeemerald/tree/master/graphics/object_events/pics
- https://github.com/pret/pokeemerald/blob/master/include/constants/metatile_behaviors.h
