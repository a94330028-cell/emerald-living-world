# V32 — progresso, sprites e bordas de salto

- Sprites de Brendan e May usam os spritesheets PNG + palettes do repositório pret/pokeemerald carregados sob demanda. Sem redesenhar bonecos. Como os gráficos remotos não são incluídos no ZIP, é necessário acesso ao GitHub, e será usado um marcador pequeno se a rede falhar.
- O tamanho visual dos sprites respeita o zoom: 16x32 pixels por quadro de origem no overworld, renderizados com fator do mapa. Na visão geral reduzem junto com o cenário.
- Colisão direcional (comportamentos de ledges 0x38–0x3f): o pathfinding e a execução impedem atravessar a borda pelo sentido contrário. São permitidos saltos no sentido indicado.
- Progressão dos capítulos: o temporizador de navegação permite destravar os eventos narrativos se uma sala não comportar a quantidade de passos necessária; isso não autoriza atravessar colisões nem substituir os scripts completos do jogo original.
- Testes automatizados usam mapas simulados. Os sprites oficiais são obtidos remotamente pelo navegador; o pacote não foi testado com todas as rotas reais de Hoenn.
