# Controle do Mundo — Emerald Living World V2

Acesse **⚙️ Mundo**, botão vermelho fixo acima da barra inferior, a qualquer momento. Há também um atalho em **Configurações**.

- **Aplicar sem reiniciar:** altera o modo do jogo, aumenta/diminui a quantidade de treinadores e salva as escolhas do bot. Preserva o progresso dos treinadores que continuarem no mundo.
- **Recomeçar mundo:** após confirmação, reinicia as jornadas e insígnias das IAs, incluindo seu bot, com o modo e quantidade definidos no painel. A campanha manual separada permanece.
- **Bots:** o total inclui o treinador do usuário; diminuir a quantidade remove os últimos bots (sem preservar seus dados), portanto exporte seu save antes caso queira recuperar esses bots.
- **Inicial:** selecionar outro inicial durante uma jornada em andamento não substitui o Pokémon inicial já escolhido. O novo inicial passa a valer ao recomeçar o mundo.

Os ajustes ficam salvos localmente no navegador. Em celular, comece com 5–20 treinadores para ter menor carga no aparelho.
