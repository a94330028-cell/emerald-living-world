/* Emerald Living World v2 — navegação sobre map.bin do pret/pokeemerald.
 * Sem dados da ROM embutidos: carrega mapas/tilesets oficiais sob demanda.
 * As flags de colisão do mapa bloqueiam a navegação das IAs; scripts, surf e
 * obstáculos condicionais continuam fora do escopo do simulador de fãs.
 */
(()=>{'use strict';
const ROOT='https://raw.githubusercontent.com/pret/pokeemerald/master/';
const cache=new Map(), arts=new Map(), files=new Map(), sentryCache=new Map(), sentryBlockers=new Map(), aliases={
 'Littleroot':'LittlerootTown','Littleroot Town':'LittlerootTown','Caminhão':'LittlerootTown_BrendansHouse_1F',
 'Casa':'LittlerootTown_BrendansHouse_1F','Quarto':'LittlerootTown_BrendansHouse_2F',
 'Casa do rival':'LittlerootTown_MaysHouse_1F','Quarto do rival':'LittlerootTown_MaysHouse_2F',
 'Laboratório':'LittlerootTown_ProfessorBirchsLab','Oldale':'OldaleTown',
 'Petalburg Woods':'PetalburgWoods','Granite Cave':'GraniteCave_B1F',
 'Rusturf Tunnel':'RusturfTunnel','Fiery Path':'FieryPath','Jagged Pass':'JaggedPass',
 'Meteor Falls':'MeteorFalls_1F_1R','Victory Road':'VictoryRoad_1F',
 'Mt. Pyre':'MtPyre_1F','New Mauville':'NewMauville_Inside',
 'Shoal Cave':'ShoalCave_LowTideEntranceRoom','Safari Zone':'SafariZone_Northwest',
 'Battle Frontier':'BattleFrontier_OutsideEast',
 'Liga Pokémon':'EverGrandeCity_PokemonLeague_1F','Mt. Chimney':'MtChimney',
 'Seafloor Cavern':'SeafloorCavern_Entrance',
 'Route 101':'Route101','Route 102':'Route102','Route 103':'Route103','Route 104':'Route104',
 'Rustboro Gym':'RustboroCity_Gym','Dewford Gym':'DewfordTown_Gym',
 'Mauville Gym':'MauvilleCity_Gym','Lavaridge Gym':'LavaridgeTown_Gym_1F',
 'Petalburg Gym':'PetalburgCity_Gym','Fortree Gym':'FortreeCity_Gym',
 'Mossdeep Gym':'MossdeepCity_Gym','Sootopolis Gym':'SootopolisCity_Gym_1F',
 'Ginásio de Rustboro':'RustboroCity_Gym','Ginásio de Dewford':'DewfordTown_Gym',
 'Ginásio de Mauville':'MauvilleCity_Gym','Ginásio de Lavaridge':'LavaridgeTown_Gym_1F',
 'Ginásio de Petalburg':'PetalburgCity_Gym','Ginásio de Fortree':'FortreeCity_Gym',
 'Ginásio de Mossdeep':'MossdeepCity_Gym','Ginásio de Sootopolis':'SootopolisCity_Gym_1F',
 'Rustboro School':'RustboroCity_PokemonSchool','Oceanic Museum':'SlateportCity_OceanicMuseum_1F',
 'Weather Institute':'Route119_WeatherInstitute_1F',
 'Magma Hideout':'MagmaHideout_1F','Aqua Hideout':'AquaHideout_1F',
 'Sky Pillar':'SkyPillar_Entrance','Terra Cave':'TerraCave_Entrance','Marine Cave':'MarineCave_Entrance','Desert Ruins':'DesertRuins','Island Cave':'IslandCave','Ancient Tomb':'AncientTomb',
 'Rota 101':'Route101','Rota 102':'Route102','Rota 103':'Route103','Rota 104':'Route104',
 'Dewford Town':'DewfordTown','Slateport City':'SlateportCity',
 'Rustboro City':'RustboroCity','Mauville City':'MauvilleCity',
 'Lavaridge Town':'LavaridgeTown','Petalburg City':'PetalburgCity',
 'Fortree City':'FortreeCity','Mossdeep City':'MossdeepCity',
 'Sootopolis City':'SootopolisCity','Ever Grande City':'EverGrandeCity'
};
const mapToConst=n=>'MAP_'+n.replace(/([a-z])([A-Z])/g,'$1_$2').replace(/([A-Z])([A-Z][a-z])/g,'$1_$2').toUpperCase();
const known=new Map();let catalogueStatus='loading';
// Corredor inicial documentado no jogo: as ligações só são usadas quando
// a porta/conexão correspondente está realmente registrada no map.json.
const A='LittlerootTown',B='LittlerootTown_BrendansHouse_1F',C='LittlerootTown_BrendansHouse_2F',
 D='LittlerootTown_MaysHouse_1F',E='LittlerootTown_MaysHouse_2F',F='LittlerootTown_ProfessorBirchsLab';
const EARLY_LINKS=[
 [A,B],[B,C],[A,D],[D,E],[A,F],[A,'Route101'],['Route101','OldaleTown'],
 ['OldaleTown','Route102'],['OldaleTown','Route103'],['Route102','PetalburgCity'],
 ['PetalburgCity','Route104'],['Route104','PetalburgWoods'],['Route104','RustboroCity'],
 ['RustboroCity','Route116'],['Route116','RusturfTunnel'],
 ['Route104','Route104_MrBrineysHouse'],
 ['OldaleTown','OldaleTown_PokemonCenter_1F'],
 ['PetalburgCity','PetalburgCity_PokemonCenter_1F'],
 ['RustboroCity','RustboroCity_PokemonCenter_1F'],
 ['MauvilleCity','MauvilleCity_PokemonCenter_1F'],
 ['LittlerootTown','LittlerootTown_ProfessorBirchsLab'],
 ['RustboroCity','RustboroCity_Gym'],['DewfordTown','DewfordTown_Gym'],
 ['MauvilleCity','MauvilleCity_Gym'],['LavaridgeTown','LavaridgeTown_Gym_1F'],
 ['LavaridgeTown_Gym_1F','LavaridgeTown_Gym_B1F'],
 ['PetalburgCity','PetalburgCity_Gym'],['FortreeCity','FortreeCity_Gym'],
 ['MossdeepCity','MossdeepCity_Gym'],['SootopolisCity','SootopolisCity_Gym_1F'],
 ['SootopolisCity_Gym_1F','SootopolisCity_Gym_B1F'],
 ['RustboroCity','RustboroCity_PokemonSchool'],
 ['SlateportCity','SlateportCity_OceanicMuseum_1F'],
 ['Route119','Route119_WeatherInstitute_1F'],
 // Caminhos registrados só são percorridos se o arquivo oficial tiver uma conexão ou warp real.
 ['Route104','Route105'],['Route105','Route106'],['Route106','DewfordTown'],
 ['DewfordTown','Route107'],['Route107','Route108'],['Route108','Route109'],
 ['Route109','SlateportCity'],['SlateportCity','Route110'],['Route110','MauvilleCity'],
 ['MauvilleCity','Route111'],['Route111','Route112'],['Route112','FieryPath'],
 ['FieryPath','Route113'],['Route113','FallarborTown'],['FallarborTown','Route114'],
 ['Route114','MeteorFalls_1F_1R'],['Route112','MtChimney'],
 ['MtChimney','JaggedPass'],['JaggedPass','LavaridgeTown'],
 ['Route112','LavaridgeTown'],['MauvilleCity','Route117'],['Route117','VerdanturfTown'],
 ['VerdanturfTown','RusturfTunnel'],['MauvilleCity','Route118'],
 ['Route118','Route119'],['Route119','FortreeCity'],['FortreeCity','Route120'],
 ['Route120','Route121'],['Route121','LilycoveCity'],
 ['LilycoveCity','Route124'],['Route124','MossdeepCity'],
 ['MossdeepCity','Route125'],['MossdeepCity','Route127'],
 ['Route127','Route126'],['Route126','SootopolisCity'],
 ['Route127','Route128'],['Route128','EverGrandeCity'],
 ['EverGrandeCity','VictoryRoad_1F'],
 ['LittlerootTown','Route101'],
 // Conexões e interiores necessários para os capítulos posteriores. A ligação
 // no grafo é apenas um planejamento: a transição usa uma saída oficial ou
 // um transporte adaptado, nunca muda o mapa sem chegar a uma passagem.
 ['Route106','GraniteCave_1F'],
 ['Route112','Route112_CableCarStation'],
 ['Route112_CableCarStation','MtChimney_CableCarStation'],
 ['MtChimney_CableCarStation','MtChimney'],
 ['JaggedPass','MagmaHideout_1F'],
 ['Route121','Route122'],['Route122','MtPyre_1F'],
 ['LilycoveCity','AquaHideout_1F'],
 ['Route128','SeafloorCavern_Entrance'],
 ['Route128','Route129'],['Route129','Route130'],['Route130','Route131'],
 ['Route131','SkyPillar_Entrance'],
 ['EverGrandeCity','EverGrandeCity_PokemonLeague_1F'],
 // Travessias de Mr. Briney: acesso marítimo após a missão da Devon.
 ['Route104','DewfordTown'],['DewfordTown','Route109']
 ];
const FERRY_LINKS=new Set(['Route104>DewfordTown','DewfordTown>Route104',
 'DewfordTown>Route109','Route109>DewfordTown']);
function ferryGoal(t,m,hop,from){
 if((t.stage||0)<20)return null;
 const candidates=[];
 if(m.name==='Route104'){
  for(const w of m.meta.warp_events||[])if(mapName(w.dest_map)==='Route104_MrBrineysHouse'){
   candidates.push({x:Number(w.x),y:Number(w.y)+1});
  }
 }
 // Dewford and Route 109 do not have a normal warp to the boat; in this
 // simulation the ferry picks the nearest reachable shore, not a random tile.
 if(m.name==='DewfordTown'||m.name==='Route109'){
  for(let y=1;y<m.height-1;y++)for(let x=1;x<m.width-1;x++){
   if(!walkable(m,x,y))continue;
   if([[0,1],[0,-1],[-1,0],[1,0]].some(([dx,dy])=>{
    const b=infoAt(m,x+dx,y+dy);return b&&SEA.has(b.behavior);
   }))candidates.push({x,y});
  }
 }
 const mode=travelMode(t,m);
 const choices=[];
 for(const at of candidates){
  const goal=nearest(m,at,mode),path=goal?findPath(m,from,goal,mode):[];
  if(goal&&(path.length||goal.x===from.x&&goal.y===from.y))choices.push({goal,path,kind:'ferry',destination:hop});
 }
 choices.sort((a,b)=>a.path.length-b.path.length);
 return choices[0]||null;
}
const ADJ=new Map();
function connect(a,b){if(!a||!b||a===b)return;for(const [u,v] of [[a,b],[b,a]]){
 if(!ADJ.has(u))ADJ.set(u,[]);if(!ADJ.get(u).includes(v))ADJ.get(u).push(v);
}}
for(const [a,b] of EARLY_LINKS)connect(a,b);

function nextHop(from,to){if(from===to)return null;
 const queue=[from],parent=new Map([[from,null]]);
 for(let i=0;i<queue.length&&i<200;i++){
  const current=queue[i];if(current===to)break;
  for(const n of ADJ.get(current)||[]){if(!parent.has(n)){parent.set(n,current);queue.push(n)}}
 }
 if(!parent.has(to))return null;
 let node=to;while(parent.get(node)!==from){node=parent.get(node);if(!node)return null}return node;
}
function resolve(location){
 let s=String(location||'').trim();if(!s)return 'LittlerootTown';
 if(aliases[s])return aliases[s];
 const center=/^Centro Pokémon\s*[•-]\s*(.*)$/.exec(s);
 if(center)return resolve(center[1])+'_PokemonCenter_1F';
 if(/^Route\s*\d+$/i.test(s))return 'Route'+s.match(/\d+/)[0];
 if(/^Rota\s*\d+$/i.test(s))return 'Route'+s.match(/\d+/)[0];
 if(/^(?:.*)\sTown$|^(?:.*)\sCity$/.test(s))return s.replace(/\s/g,'');
 if(known.has(s))return s;
 return s.replace(/[^\w]/g,'');
}
const GYM_LABELS={
 RustboroCity_Gym:'Ginásio de Rustboro',DewfordTown_Gym:'Ginásio de Dewford',
 MauvilleCity_Gym:'Ginásio de Mauville',LavaridgeTown_Gym_1F:'Ginásio de Lavaridge — térreo',
 LavaridgeTown_Gym_B1F:'Ginásio de Lavaridge — subsolo',PetalburgCity_Gym:'Ginásio de Petalburg',
 FortreeCity_Gym:'Ginásio de Fortree',MossdeepCity_Gym:'Ginásio de Mossdeep',
 SootopolisCity_Gym_1F:'Ginásio de Sootopolis — térreo',SootopolisCity_Gym_B1F:'Ginásio de Sootopolis — subsolo'
};
const SPECIAL_LABELS={
 LittlerootTown:'Littleroot Town',LittlerootTown_BrendansHouse_1F:'Casa de Brendan — térreo',
 LittlerootTown_BrendansHouse_2F:'Casa de Brendan — quarto',
 LittlerootTown_MaysHouse_1F:'Casa de May — térreo',LittlerootTown_MaysHouse_2F:'Casa de May — quarto',
 LittlerootTown_ProfessorBirchsLab:'Laboratório do Professor Birch',
 RustboroCity_PokemonSchool:'Escola Pokémon de Rustboro',
 SlateportCity_OceanicMuseum_1F:'Museu Oceânico de Slateport — térreo',
 Route119_WeatherInstitute_1F:'Instituto Meteorológico — térreo',
 EverGrandeCity_PokemonLeague_1F:'Liga Pokémon — entrada'
};
function label(name){
 const canonical=resolve(name);if(GYM_LABELS[canonical])return GYM_LABELS[canonical];
 if(SPECIAL_LABELS[canonical])return SPECIAL_LABELS[canonical];
 if(/^Route\d+$/.test(canonical))return 'Rota '+canonical.slice(5);
 const center=/^(.+)_PokemonCenter_(\d+)F$/.exec(canonical);
 if(center)return 'Centro Pokémon de '+label(center[1])+' — '+center[2]+'º andar';
 if(/^(.*?)(Town|City)$/.test(canonical))return canonical.replace(/(Town|City)$/,' $1').replace(/([a-z])([A-Z])/g,'$1 $2');
 return canonical.replaceAll('_',' — ').replace(/([a-z])([A-Z])/g,'$1 $2');
}
function safePath(path){if(!/^[A-Za-z0-9_./-]+$/.test(path)||path.includes('..'))throw Error('Caminho inválido') ;return path}
// Cache persistente local: uma rota oficial visitada volta a abrir mesmo
// depois de recarregar a pagina, sem nova descarga dos mesmos dados.
// Se CacheStorage nao estiver disponivel, utiliza somente o cache da sessao.
const persistentFiles=typeof caches!=='undefined'?caches.open('emerald-official-assets-v26').catch(()=>null):Promise.resolve(null);
function fetchFile(path,as='json'){
 const clean=safePath(path),key=as+':'+clean;
 if(files.has(key))return files.get(key);
 const req=(async()=>{
  const url=ROOT+clean;
  const store=await persistentFiles;
  let response=null;
  if(store)try{response=await store.match(url)}catch(_){}
  if(!response){
   const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),6500);
   try{
    response=await fetch(url,{signal:ctrl.signal,mode:'cors'});
    if(!response.ok)throw Error(`Arquivo ${path} indisponível (${response.status})`);
    if(store)store.put(url,response.clone()).catch(()=>{});
   }finally{clearTimeout(timer)}
  }
  const result=await (as==='json'?response.json():as==='text'?response.text():response.arrayBuffer());
  if(files.size>150){for(const k of files.keys()){
   if(k==='json:data/layouts/layouts.json'||k==='json:data/maps/map_groups.json')continue;
   files.delete(k);if(files.size<=125)break;
  }}
  return result;
 })();files.set(key,req);req.catch(()=>files.delete(key));return req;
}
async function loadCatalog(){try{const groups=await fetchFile('data/maps/map_groups.json');
 for(const group of groups.group_order||[])for(const n of groups[group]||[])known.set(mapToConst(n),n);
 catalogueStatus='ready';return known;
 }catch(e){catalogueStatus='offline';return known}}
const catalogPromise=loadCatalog();
function mapName(value){if(!value)return null;if(known.has(value))return known.get(value);
 if(value.startsWith('MAP_')){for(const key of Object.keys(aliases)){const nm=aliases[key];if(mapToConst(nm)===value)return nm;}
  // Antes de o catálogo carregar, converte MAP_ROUTE101, MAP_OLDALE_TOWN etc.
  if(/^MAP_ROUTE\d+$/.test(value))return 'Route'+value.slice(9);
  const lookup=[...ADJ.keys(),...ADJ.values()].flat();return lookup.find(n=>mapToConst(n)===value)||null;
 }
 return resolve(value)}
// Navigation is isolated so collision logic is testable without the UI.
const navigation=window.EmeraldNavigation;
if(!navigation)throw Error('Módulo de navegação ausente: game/navigation/core.js');
const {infoAt,walkable,canStep,nearest,findPath,SEA}=navigation;
function travelMode(t,m){
 if(m?.meta?.map_type==='MAP_TYPE_UNDERWATER')return 'dive';
 return (t?.badges||0)>=5?'surf':'walk';
}
// Malha de recuperação para quando a hospedagem de mapas oficiais estiver
// indisponível. Não finge ser a ROM: o painel identifica claramente o modo
// alternativo. Cada entrada continua exigindo percorrer um caminho válido.
// Offline scenery follows the same collision cells as pathfinding, so a painted
// house/tree cannot secretly be walked through. These are ORIGINAL adapted
// drawings, not redistributed Emerald graphics.
function recoveryPlan(name){
 const indoor=/Gym|House|Center|Mart|Museum|Lab|League|Hideout|Institute|Station|Cave|Tunnel|Tower|Pillar|Falls|Room|_1F|_B1F|_2F/.test(name);
 const route=/^Route\d+|Woods|Path|Pass/.test(name);
 const cave=/Cave|Tunnel|Falls|Pillar|Hideout/.test(name);
 const center=/Center|Mart|Lab|Museum|League|House|Gym|Institute|Station/.test(name);
 const width=30,height=22;
 const buildings=!indoor&&!route?[{x:4,y:4,w:7,h:5},{x:19,y:4,w:7,h:5},{x:4,y:13,w:7,h:4},{x:19,y:13,w:7,h:4}]:[];
 const forest=route?[
  {x:4,y:4,w:5,h:4},{x:20,y:4,w:5,h:4},{x:4,y:14,w:5,h:4},{x:20,y:14,w:5,h:4}
 ]:[];
 const furniture=indoor?[
  {x:4,y:5,w:5,h:3},{x:21,y:5,w:5,h:3},
  {x:4,y:14,w:5,h:3},{x:21,y:14,w:5,h:3}
 ]:[];
 return {indoor,route,cave,center,width,height,buildings,forest,furniture};
}
function recoverySolid(plan,x,y){
 if(x===0||y===0||x===plan.width-1||y===plan.height-1)return true;
 const inside=r=>x>=r.x&&x<r.x+r.w&&y>=r.y&&y<r.y+r.h;
 return [...plan.buildings,...plan.forest,...plan.furniture].some(inside);
}
function fallbackMap(name){
 const plan=recoveryPlan(name),{width,height}=plan,blocks=new ArrayBuffer(width*height*2),data=new DataView(blocks);
 for(let y=0;y<height;y++)for(let x=0;x<width;x++){
  data.setUint16((y*width+x)*2,(recoverySolid(plan,x,y)?0x400:0)|1,true);
 }
 const neighbors=[...new Set(ADJ.get(name)||[])].sort();
 const positions=[];
 // Warps stay on navigable cells and always have a direct route to the hub.
 for(let x=2;x<width-2;x+=2){positions.push({x,y:1});positions.push({x,y:height-2});}
 for(let y=3;y<height-3;y+=2){positions.push({x:1,y});positions.push({x:width-2,y});}
 const warp_events=neighbors.map((other,i)=>{
  const pt=positions[i%positions.length],back=[...new Set(ADJ.get(other)||[])].sort().indexOf(name);
  return {...pt,elevation:0,dest_warp_id:Math.max(0,back),dest_map:mapToConst(other)};
 });
 const layout={width,height,primary_tileset:'gTileset_Recovery',secondary_tileset:'gTileset_Recovery'};
 return {name,width,height,layout,blocks:data,primaryAttrs:new DataView(new ArrayBuffer(32)),secondaryAttrs:new DataView(new ArrayBuffer(32)),fallback:true,
  recoveryPlan:plan,
  meta:{name,map_type:plan.indoor?'MAP_TYPE_INDOOR':plan.route?'MAP_TYPE_ROUTE':'MAP_TYPE_TOWN',connections:[],warp_events,object_events:[]}};
}
function drawRecovery(m){
 const canvas=document.createElement('canvas'),w=m.width,h=m.height,S=16;
 canvas.width=w*S;canvas.height=h*S;
 const c=canvas.getContext('2d',{alpha:false});c.imageSmoothingEnabled=false;
 const plan=m.recoveryPlan||recoveryPlan(m.name),indoors=plan.indoor;
 function rect(x,y,rw,rh,color){c.fillStyle=color;c.fillRect(Math.round(x),Math.round(y),Math.round(rw),Math.round(rh))}
 function tile(x,y,color){rect(x*S,y*S,S,S,color)}
 function hash(x,y,k=0){let n=Math.imul(x+7+k,374761393)^Math.imul(y+17,668265263);n=Math.imul(n^(n>>>13),1274126177);return (n^(n>>>16))>>>0}
 // Organic grass, dirt paths and interior wooden/stone floors; no checkerboard.
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){
  const px=x*S,py=y*S,n=hash(x,y),cross=(x>=12&&x<=17)||(y>=9&&y<=12);
  const material=indoors?(plan.cave?['#727c72','#788478','#7b8379']:['#c6b69a','#c4b298','#c8b99d']):
    cross?['#d4c9a2','#d0c49c','#cfc3a0']:['#80b67b','#78ad75','#83b57d'];
  rect(px,py,S,S,material[n%material.length]);
  if(indoors){
   rect(px+1,py+1,14,1,plan.cave?'#9fa89b':'#d6c3a5');
   if(n%5===0)rect(px+5,py+8,3,1,plan.cave?'#606b65':'#ac9a82');
  }else if(!cross){
   const highlight=['#9acc91','#679e68','#a4c995'];
   rect(px+(n%12)+1,py+((n>>>8)%12)+1,2,2,highlight[(n>>>17)%highlight.length]);
   if(n%17===0){rect(px+4,py+8,2,4,'#c6e79c');rect(px+9,py+5,2,5,'#b1dc91')}
  }else if(n%7===0){rect(px+7,py+6,3,2,'#beb18b')}
 }
 // Two natural path intersections with a central paved square, not empty turf.
 if(!indoors){
  for(let yy=9;yy<=12;yy++){rect(12*S,yy*S,6*S,1,'#e7d7aa')}
  for(let xx=12;xx<=17;xx++){rect(xx*S,9*S,1,4*S,'#e7d7aa')}
 }
 function flower(x,y){const px=x*S+4,py=y*S+4;rect(px+3,py+5,2,5,'#326d46');for(const [dx,dy] of [[2,0],[5,0],[0,3],[7,3],[3,6]])rect(px+dx,py+dy,3,3,'#fff0d3');rect(px+3,py+2,3,3,'#f5a3a2')}
 function tree(x,y){const px=x*S,py=y*S;rect(px+6,py+9,5,7,'#745539');rect(px+3,py+4,12,10,'#266c4e');rect(px+1,py+5,14,7,'#2f835c');rect(px+3,py+1,11,7,'#56a76b');rect(px+5,py+1,5,3,'#9bc886');rect(px+1,py+8,4,3,'#76b777')}
 function house(r,idx){
  const x=r.x*S,y=r.y*S,W=r.w*S,H=r.h*S;
  rect(x+5,y+14,W-10,H-14,'#d3b794');rect(x+5,y+14,W-10,3,'#9a876b');
  rect(x+7,y+18,W-14,H-22,'#dfc9a7');
  rect(x-3,y+4,W+6,20,'#705b72');rect(x-4,y+1,W+8,15,idx%2?'#b26b6a':'#8c8197');
  for(let tx=0;tx<W+3;tx+=13){rect(x+tx,y+2,9,2,'#e0b5a3');rect(x+tx+4,y+9,9,2,'#d8a89d')}
  rect(x-5,y+15,W+10,4,'#655b63');rect(x+6,y+20,18,15,'#5b8397');rect(x+8,y+22,13,10,'#9dd0cb');
  rect(x+W-24,y+20,18,15,'#5b8397');rect(x+W-22,y+22,13,10,'#9dd0cb');
  rect(x+Math.floor(W/2)-8,y+H-25,16,25,'#745448');rect(x+Math.floor(W/2)-5,y+H-21,10,21,'#b59a6c');rect(x+Math.floor(W/2)+2,y+H-13,2,2,'#eedcb2');
  rect(x,y+H-3,W,3,'#746859');
 }
 function furniture(r,i){const x=r.x*S,y=r.y*S,W=r.w*S,H=r.h*S;
  rect(x,y+3,W,H-3,plan.cave?'#4e5e58':'#71584b');rect(x+3,y+3,W-6,3,plan.cave?'#849387':'#c9ac76');
  for(let z=0;z<3;z++)rect(x+7+z*20,y+9,10,8,i%2?'#8a9f92':'#c2a878');
 }
 // Structure footprints are exactly the ones used by recoverySolid().
 for(const [i,r] of plan.buildings.entries())house(r,i);
 for(const r of plan.forest)for(let yy=r.y;yy<r.y+r.h;yy++)for(let xx=r.x;xx<r.x+r.w;xx++){
  if((xx+yy)%2===0)tree(xx,yy);else{tile(xx,yy,'#3f8559');rect(xx*S+2,yy*S+2,12,7,'#61a36b')}
 }
 for(const [i,r] of plan.furniture.entries())furniture(r,i);
 if(!indoors){
  // Perimeter trees leave the validated exit cells and their approach clear.
  const portalKeys=new Set((m.meta.warp_events||[]).flatMap(p=>[p.x+','+p.y,(p.x+1)+','+p.y,(p.x-1)+','+p.y,p.x+','+(p.y+1),p.x+','+(p.y-1)]));
  for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){
   if(recoverySolid(plan,x,y)||x>=11&&x<=18||y>=8&&y<=13||portalKeys.has(x+','+y))continue;
   const n=hash(x,y,37);if(n%15===0)flower(x,y);
  }
 }
 // Walls are always recognizable; portal markers are visible and traversable.
 for(let x=0;x<w;x++){tile(x,0,indoors?'#4a534c':'#2c7954');tile(x,h-1,indoors?'#4a534c':'#2b6948')}
 for(let y=0;y<h;y++){tile(0,y,indoors?'#4a534c':'#2c7954');tile(w-1,y,indoors?'#4a534c':'#2b6948')}
 for(const warp of m.meta.warp_events||[]){
  const x=warp.x*S+3,y=warp.y*S+3;
  rect(x-1,y-1,12,12,'#224c55');rect(x,y,10,10,'#89d5d0');rect(x+3,y+2,4,6,'#e5fff0');
 }
 if(indoors){rect(12*S,1*S,6*S,3,'#b08c69');rect(12*S,1*S+4,6*S,2,'#e5c292')}
 return {image:canvas,base:canvas,foreground:null,adapted:true};
}
function getNav(name){return cache.get(name)?.value||null}
async function ensureNav(name){name=resolve(name);if(!name)return null;
 const old=cache.get(name);if(old)return old.promise;
 const entry={promise:null,value:null,error:null};
 entry.promise=(async()=>{
  try{
   const [meta,layouts]=await Promise.all([fetchFile(`data/maps/${name}/map.json`),fetchFile('data/layouts/layouts.json')]);
   const layout=(layouts.layouts||[]).find(l=>l.id===meta.layout);
   if(!layout)throw Error('Layout desconhecido '+meta.layout);
   const [buff,primaryAttrs,secondaryAttrs]=await Promise.all([
    fetchFile(layout.blockdata_filepath,'binary'),
    fetchFile(`data/tilesets/primary/${tilesetSlug(layout.primary_tileset)}/metatile_attributes.bin`,'binary'),
    fetchFile(`data/tilesets/secondary/${tilesetSlug(layout.secondary_tileset)}/metatile_attributes.bin`,'binary')
   ]);
   if(buff.byteLength!==layout.width*layout.height*2)throw Error('Grade binária inválida em '+name);
   const m={name,meta,layout,width:layout.width,height:layout.height,blocks:new DataView(buff),primaryAttrs:new DataView(primaryAttrs),secondaryAttrs:new DataView(secondaryAttrs)};
   // A fence / door / plot actor may sit on a ground tile marked walkable.
   // NPC positions are obstacles to both the pathfinder and physical steps.
   m.solidObjects=new Set((meta.object_events||[]).filter(o=>Number.isInteger(Number(o.x))&&Number.isInteger(Number(o.y))).map(o=>Number(o.x)+':'+Number(o.y)));
   entry.value=m;
   for(const link of m.meta.connections||[])connect(name,mapName(link.map));
   for(const link of m.meta.warp_events||[])connect(name,mapName(link.dest_map));
   if(cache.size>55){const active=new Set((window.emeraldTrainers||[]).map(t=>resolve(t.officialMap||t.location)));for(const [key,val] of cache){if(cache.size<=45)break;if(!active.has(key)&&key!==name&&val.value)cache.delete(key)}}
   return m;
  }catch(e){
   // Sem internet ou arquivo inexistente: preservar a progressão usando uma
   // malha local claramente sinalizada como adaptada.
   entry.warning=e;
   entry.value=fallbackMap(name);
   return entry.value;
  }
 })();cache.set(name,entry);entry.promise.catch(()=>{});return entry.promise;
}
function prefetch(name){const n=resolve(name),v=cache.get(n);if(v?.error&&Date.now()-(v.errorTime||0)>25000)cache.delete(n);if(!cache.has(n))ensureNav(n).catch(()=>{});return cache.get(n)}
function navStatus(name){const n=resolve(name),v=cache.get(n);return !v?'unrequested':v.error?'error':v.value?'ready':'loading'}
function pickCandidate(m,origin,seed,level=0,mode='walk'){
 // Escolha determinística por treinador, com pontos distribuídos no terreno real.
 const rng=(Math.imul((seed+1)>>>0,1664525)+1013904223)>>>0;
 const candidates=[];const stride=Math.max(1,Math.floor(Math.sqrt(m.width*m.height)/11));
 for(let y=1;y<m.height-1;y+=stride)for(let x=1;x<m.width-1;x+=stride){if(!walkable(m,x,y,mode))continue;
  if(Math.abs(x-origin.x)+Math.abs(y-origin.y)<Math.max(3,Math.min(m.width,m.height)/6))continue;
  candidates.push({x,y});
 }
 for(let count=0;count<Math.min(30,candidates.length);count++){
  const target=candidates[((rng+Math.imul(count+level+1,2654435761))>>>0)%candidates.length];
  const path=findPath(m,origin,target,mode);if(path.length)return {goal:target,path,kind:'patrol'};
 }
 return null;
}
function findEdge(m,target){for(const conn of m.meta.connections||[]){if(mapName(conn.map)===target)return conn}return null}
// Only let a connection use the orthogonal border strip shared by both maps.
// Never repair a broken connection by landing in a distant region.
function edgeLanding(dest,edge,previous,mode='walk'){
 const dir=edge.direction,offset=Number(edge.offset)||0;
 let x=previous.x,y=previous.y;
 if(dir==='up'){x-=offset;y=dest.height-1}
 else if(dir==='down'){x-=offset;y=0}
 else if(dir==='left'){x=dest.width-1;y-=offset}
 else if(dir==='right'){x=0;y-=offset}
 else return null;
 if(x<0||y<0||x>=dest.width||y>=dest.height)return null;
 const inward=dir==='up'?[0,-1]:dir==='down'?[0,1]:dir==='left'?[-1,0]:[1,0];
 for(let step=0;step<=2;step++){
  const nx=x+inward[0]*step,ny=y+inward[1]*step;
  if(walkable(dest,nx,ny,mode))return {x:nx,y:ny};
 }
 return null;
}
function edgeGoal(m,edge,from,mode='walk'){
 const dir=edge.direction;
 if(!['up','down','left','right'].includes(dir))return null;
 const targetName=mapName(edge.map),targetMap=cache.get(targetName)?.value;
 const offset=Number(edge.offset)||0;
 const candidates=[];
 for(let i=0;i<(dir==='up'||dir==='down'?m.width:m.height);i++){
  // A conexão só é válida na faixa comum às duas bordas. Antes da
  // carga do destino, a saída é revalidada por destinationOf().
  if(targetMap){const coordinate=i-offset;
   if(coordinate<0||coordinate>=(dir==='up'||dir==='down'?targetMap.width:targetMap.height))continue;
  }
  const x=dir==='left'?0:dir==='right'?m.width-1:i;
  const y=dir==='up'?0:dir==='down'?m.height-1:i;
  if(walkable(m,x,y,mode)&&(!targetMap||edgeLanding(targetMap,edge,{x,y},mode)))candidates.push({x,y});
 }
 candidates.sort((a,b)=>(Math.abs(from.x-a.x)+Math.abs(from.y-a.y))-(Math.abs(from.x-b.x)+Math.abs(from.y-b.y)));
 for(const targetPos of candidates){const path=findPath(m,from,targetPos,mode);
  if(path.length||targetPos.x===from.x&&targetPos.y===from.y)
   return {goal:targetPos,path,kind:'edge',destination:targetName,edge};
 }
 return null;
}
 // Portas podem possuir um metatile de colisão, mesmo sendo warps válidos.
 // O treinador deve alcançar uma casa ADJACENTE à porta pelo chão caminhável.
 // Só nesse ponto é permitida a transição pelo evento de warp do map.json.
 function warpGoal(m,warp,from,mode='walk'){
  const target={x:Number(warp.x),y:Number(warp.y)};
  const destination=mapName(warp.dest_map);
  if(!destination||!Number.isInteger(target.x)||!Number.isInteger(target.y))return null;
  const direct=walkable(m,target.x,target.y,mode);
  if(direct){
   const path=findPath(m,from,target,mode);
   if(path.length||(target.x===from.x&&target.y===from.y))
    return {goal:target,path,kind:'warp',destination,warp,door:target,approach:false};
  }
  // Contornar a porta exige caminhar até seu limiar. Nunca atravessar um bloco
  // sólido comum que não esteja explicitamente listado em warp_events.
  // Portas externas são alcançadas de baixo; saídas de interiores, por cima.
  const outdoor=m.meta.map_type!=='MAP_TYPE_INDOOR';
  const offsets=outdoor?[[0,1],[-1,0],[1,0],[0,-1]]:[[0,-1],[-1,0],[1,0],[0,1]];
  const approaches=[];
  for(const [dx,dy] of offsets){
   const pos={x:target.x+dx,y:target.y+dy};
   if(!walkable(m,pos.x,pos.y,mode))continue;
   const path=findPath(m,from,pos,mode);
   if(path.length||(pos.x===from.x&&pos.y===from.y))approaches.push({pos,path});
  }
  if(!approaches.length)return null;
  // Preserve a direção natural de acesso à porta e prefira uma rota curta.
  approaches.sort((a,b)=>a.path.length-b.path.length);
  const preferred=approaches.find(p=>outdoor?p.pos.x===target.x&&p.pos.y===target.y+1:
                             p.pos.x===target.x&&p.pos.y===target.y-1);
  const chosen=preferred||approaches[0];
  return {goal:chosen.pos,path:chosen.path,kind:'warp',destination,warp,door:target,approach:true};
 }
function routeVariety(t,m,from,result){
 if(!result?.path?.length||result.path.length<10)return result;
 if(m.meta.map_type==='MAP_TYPE_INDOOR'||m.width*m.height<450)return result;
 const personality=String(t.personality||'');
 const trait=Math.max(0,Math.min(1,Number(t.traits?.explore)||0));
 // Aventureiros, pesquisadores e colecionadores preferem desvios curtos;
 // competitivos e cautelosos priorizam o caminho mais rápido.
 const explore=trait>0.75||/Aventureiro|Explorador|Pesquisador|Colecionador/.test(personality);
 // Prefer a stable, direct route for regular trainers. Artificial scenic
 // zigzags made avatars turn in circles without meaningful exploration.
 if(!explore)return result;
 const seed=(Math.imul(t.id+11,2654435761) ^ Math.imul(t.stage+29,1597334677) ^ Math.imul(m.name.length+17,1000003))>>>0;
 const amplitude=explore?6:3;
 const anchor=result.path[Math.max(1,Math.min(result.path.length-2,Math.floor(result.path.length*(.3+(seed%20)/100))))];
 const dx=(seed&1?1:-1)*(2+seed%amplitude),dy=(seed&2?1:-1)*(2+((seed>>>5)%amplitude));
 const mode=travelMode(t,m);
 const detour=nearest(m,{x:anchor.x+dx,y:anchor.y+dy},mode);
 if(!detour)return result;
 const leg1=findPath(m,from,detour,mode),leg2=findPath(m,detour,result.goal,mode);
 if(!leg1.length||!leg2.length)return result;
 // Preserve narrative order: no long random tours, and no warp until the real exit.
 if(leg1.length+leg2.length>result.path.length+Math.max(7,Math.floor(result.path.length*.3)))return result;
 const Facing=window.EmeraldMovementFacing;
 const combined=[...leg1,...leg2];
 const cleaned=Facing?.removeLoops(from,combined)||null;
 if(!cleaned||!cleaned.length||cleaned.length>result.path.length+Math.max(3,Math.floor(result.path.length*.16)))return result;
 // Reject needless multiple rotations around the same two tiles.
 if(Facing.turns(from,cleaned)>Facing.turns(from,result.path)+2)return result;
 return {...result,path:cleaned,individualRoute:true};
}
// Route 104 is split into physical north/south sections. Shortest map-name paths
// do not necessarily connect the two sections. Plan by reachable exits first.
function graphDistanceBfs(from,to){
 if(from===to)return 0;const queue=[{map:from,d:0}],seen=new Set([from]);
 for(let i=0;i<queue.length&&i<180;i++)for(const next of ADJ.get(queue[i].map)||[]){
  if(next===to)return queue[i].d+1;
  if(!seen.has(next)){seen.add(next);queue.push({map:next,d:queue[i].d+1})}
 }return Infinity;
}
function portalOptions(t,m,pos,destination){
 const opts=[],mode=travelMode(t,m);
 if(FERRY_LINKS.has(m.name+'>'+destination)){
  const ferry=ferryGoal(t,m,destination,pos);
  if(ferry)opts.push(ferry);
 }
 for(const edge of m.meta.connections||[]){
  if(mapName(edge.map)!==destination)continue;
  const result=edgeGoal(m,edge,pos,mode);
  if(result)opts.push(result);
 }
 for(const [idx,warp] of (m.meta.warp_events||[]).entries()){
  if(mapName(warp.dest_map)!==destination)continue;
  const result=warpGoal(m,warp,pos,mode);
  if(result)opts.push({...result,warpIndex:idx});
 }
 return opts;
}
function choosePortal(t,m,pos,destination){
 const opts=portalOptions(t,m,pos,destination);
 if(!opts.length)return null;
 if(m.name==='PetalburgWoods'&&destination==='Route104'){
  // The forest has two exits to the SAME route. Never return through the
  // entrance if the other reachable exit leads toward the story objective.
  const goal=t.officialTarget||'';
  const towardsNorth=goal==='RustboroCity'||goal==='Route116'||goal==='RustboroCity_Gym'||/Rustboro/.test(goal);
  const towardsSouth=goal==='DewfordTown'||goal==='Route109'||goal==='PetalburgCity'||goal==='Route105'||goal==='Route106';
  const route=cache.get('Route104')?.value;
  const yAtDestination=o=>{
   const n=Number(o.warp?.dest_warp_id);
   const entry=Number.isInteger(n)?route?.meta?.warp_events?.[n]:null;
   return Number.isFinite(Number(entry?.y))?Number(entry.y):Number(o.warp?.y)||0;
  };
  opts.sort((a,b)=>{
   if(towardsNorth||towardsSouth){const dy=yAtDestination(a)-yAtDestination(b);if(dy)return towardsNorth?dy:-dy;}
   const entered=t.officialInboundWarpIndex===null||t.officialInboundWarpIndex===undefined?null:Number(t.officialInboundWarpIndex);
   const aBack=Number.isInteger(entered)&&a.warpIndex===entered?1:0;
   const bBack=Number.isInteger(entered)&&b.warpIndex===entered?1:0;
   return aBack-bBack||(a.path?.length||0)-(b.path?.length||0);
  });
 }else opts.sort((a,b)=>(a.path?.length||0)-(b.path?.length||0));
 return opts[0];
}
function alternativeTransit(t,m,pos,wanted){
 // If the closest connection is blocked, choose another REACHABLE exit, not
 // a teleport or an invented straight line. A woods detour is essential on
 // Route 104 to reach the north half or Mr Briney's boat in the south.
 const destinations=new Set();
 for(const edge of m.meta.connections||[])destinations.add(mapName(edge.map));
 for(const warp of m.meta.warp_events||[])destinations.add(mapName(warp.dest_map));
 for(const n of ADJ.get(m.name)||[])if(FERRY_LINKS.has(m.name+'>'+n))destinations.add(n);
 const chosen=[];
 for(const destination of destinations){
  if(!destination||destination===wanted||destination===m.name)continue;
  const distance=graphDistanceBfs(destination,t.officialTarget);
  if(!Number.isFinite(distance))continue;
  // Only a constrained detour. For Route104 the forest is an alternative
  // connection even though it is one map farther from Rustboro/Dewford.
  if(distance>graphDistanceBfs(m.name,t.officialTarget)+2)continue;
  const result=choosePortal(t,m,pos,destination);
  if(!result)continue;
  const last=t.officialLastMap===destination?1:0;
  const visits=t.officialTransitCounts?.[m.name+'>'+destination]||0;
  if(visits>=3)continue; // Don't endlessly loop through the same doorway.
  const woods=m.name==='Route104'&&destination==='PetalburgWoods'?-30:0;
  chosen.push({result,score:distance*12+(result.path?.length||0)*.08+last*8+visits*15+woods});
 }
 chosen.sort((a,b)=>a.score-b.score);
 return chosen[0]?.result||null;
}
function replan(t){
 if(!t)return false;
 t.walkPath=[];t.officialGoal=null;t.officialPortal=null;t.storyAnchor=null;t.storyDwellAt=0;
 t.walkNextAt=0;t.officialRouteRetryAt=0;t.officialError=null;t.walkStuckSince=Date.now();
 t.officialRetryCount=(t.officialRetryCount||0)+1;
 t.walkObjective='Recalculando rota sem mudar a posição';return true;
}
// Build route candidates from the map graph instead of retrying the same
// topological "shortest" hop forever. An actual path to the exit is required.
function orderedHops(t,m){
 const desired=t.officialTarget,dist=graphDistanceBfs(m.name,desired);
 const neighbors=[...new Set(ADJ.get(m.name)||[])].filter(n=>n&&n!==m.name);
 return neighbors.map(hop=>{
  const remaining=graphDistanceBfs(hop,desired);
  const used=t.officialTransitCounts?.[m.name+'>'+hop]||0;
  const back=hop===t.officialLastMap?1:0;
  return {hop,remaining,used,back,score:remaining*20+used*40+back*12};
 }).filter(h=>Number.isFinite(h.remaining)&&h.used<4&&
  (h.remaining<dist||(m.name==='Route104'&&h.hop==='PetalburgWoods')) )
 .sort((a,b)=>a.score-b.score);
}
function safeExitAnchors(m,hop,mode){
 const candidates=[],seen=new Set();
 const add=(x,y)=>{
  if(!walkable(m,x,y,mode))return;
  const key=x+','+y;if(seen.has(key))return;seen.add(key);
  if(![[0,1],[0,-1],[1,0],[-1,0]].some(([dx,dy])=>canStep(m,{x,y},{x:x+dx,y:y+dy},mode)))return;
  candidates.push({x,y});
 };
 for(const w of m.meta.warp_events||[]){
  if(mapName(w.dest_map)!==hop)continue;
  const x=Number(w.x),y=Number(w.y);
  for(const [dx,dy] of [[0,1],[0,-1],[1,0],[-1,0],[0,0]])add(x+dx,y+dy);
 }
 for(const edge of m.meta.connections||[]){
  if(mapName(edge.map)!==hop)continue;
  const vertical=edge.direction==='left'||edge.direction==='right';
  const size=vertical?m.height:m.width;
  for(let i=0;i<size;i+=Math.max(1,Math.floor(size/24))){
   const x=edge.direction==='left'?0:edge.direction==='right'?m.width-1:i;
   const y=edge.direction==='up'?0:edge.direction==='down'?m.height-1:i;
   add(x,y);
  }
 }
 // Coasts for scripted ferry transport (only on routes with an actual ferry).
 if(FERRY_LINKS.has(m.name+'>'+hop)){
  if(m.name==='Route104'){
   for(const w of m.meta.warp_events||[])if(mapName(w.dest_map)==='Route104_MrBrineysHouse')add(+w.x,+w.y+1);
  }else for(let y=1;y<m.height-1;y++)for(let x=1;x<m.width-1;x++){
   if(!walkable(m,x,y,mode))continue;
   if([[0,1],[0,-1],[1,0],[-1,0]].some(([dx,dy])=>SEA.has(infoAt(m,x+dx,y+dy)?.behavior)))add(x,y);
  }
 }
 return candidates;
}
// A broken or stale save may leave an avatar in a physically disconnected
// pocket. Recover only when no exit from that component is possible; never
// use this as a shortcut for an inaccessible story puzzle or normal replan.
function recoverIsolatedOutdoorSpawn(t,m,pos){
 // Disabled in V9.16: never relocate a trainer to fix a blocked route.
 // Recovery is allowed ONLY after every Pokémon is knocked out, at a Center.
 t.officialError='Posição isolada: sem caminho seguro; posição preservada';
 return false;
}
function selectGoal(t,m){
 const pos={x:t.walkX,y:t.walkY},seed=(t.id*393919+(t.walkCount||0)*1103515245+(t.stage||0)*131)>>>0;
 // Prefer physically reachable exits, ordered by campaign distance and
 // penalized on backtracking/loops. Recalculation must not repeat a dead hop.
 if(t.officialTarget&&t.officialTarget!==m.name){
  const hops=orderedHops(t,m);
  if(!hops.length){t.officialError='Sem ligação válida entre '+m.name+' e '+t.officialTarget;return null}
  for(const item of hops){
   const candidate=choosePortal(t,m,pos,item.hop);
   if(candidate){
    t.officialError=null;t.officialNoRouteRetries=0;
    return routeVariety(t,m,pos,candidate);
   }
  }
  t.officialNoRouteRetries=(t.officialNoRouteRetries||0)+1;
  if(t.officialNoRouteRetries>=3)recoverIsolatedOutdoorSpawn(t,m,pos);
  t.officialError='Nenhuma saída alcançável em '+m.name+' para '+t.officialTarget;
  return null;
 }
 t.officialError=null;t.officialNoRouteRetries=0;
 return pickCandidate(m,pos,seed,seed%5,travelMode(t,m));
}
function arrivalAt(m,entry,mode='walk',options={}){
 if(!entry)return null; // Never silently teleport to the center of an unknown map.
 const x=Number(entry.x),y=Number(entry.y);
 if(!Number.isInteger(x)||!Number.isInteger(y)||x<0||y<0||x>=m.width||y>=m.height)return null;
 const indoor=m.meta.map_type==='MAP_TYPE_INDOOR';
 const order=options.edge?[[0,0],[0,1],[0,-1],[1,0],[-1,0]]:
    indoor?[[0,-1],[0,0],[-1,0],[1,0],[0,1]]:[[0,1],[0,0],[-1,0],[1,0],[0,-1]];
 for(const [dx,dy] of order)if(walkable(m,x+dx,y+dy,mode))return {x:x+dx,y:y+dy};
 // Only nearby doorway tiles may be used; a closed room must NOT cause
 // the trainer to respawn on the far side of an inaccessible building.
 return nearest(m,{x,y},mode,2);
}
function reciprocalWarpId(value){
 if((typeof value!=='string'&&typeof value!=='number')||!/^\d+$/.test(String(value)))return null;
 const n=Number(value);return Number.isSafeInteger(n)?n:null;
}
async function destinationOf(portal,from,previous,mode='walk'){
 const dest=portal.destination;if(!dest||dest===from.name)return null;
 const m=await ensureNav(dest);if(!m)return null;
 let at=null;
 if(portal.kind==='ferry'){
  // Adapted ferry: choose an actual shoreline walkway, not the middle of a wall.
  const waterNeighbor=(x,y)=>[[1,0],[-1,0],[0,1],[0,-1]].some(([dx,dy])=>SEA.has(infoAt(m,x+dx,y+dy)?.behavior));
  const coast=[];for(let y=1;y<m.height-1;y++)for(let x=1;x<m.width-1;x++){
   if(walkable(m,x,y,mode)&&waterNeighbor(x,y))coast.push({x,y});
  }
  coast.sort((a,b)=>Math.abs(a.x-m.width/2)+Math.abs(a.y-m.height*.65)-Math.abs(b.x-m.width/2)-Math.abs(b.y-m.height*.65));
  at=coast[0]|| (m.fallback?arrivalAt(m,{x:Math.floor(m.width/2),y:Math.floor(m.height*.65)},mode):null);
 }else if(portal.kind==='warp'){
  const n=reciprocalWarpId(portal.warp?.dest_warp_id);
  const reciprocal=n===null?null:m.meta.warp_events?.[n];
  if(!reciprocal)return null;
  if(mapName(reciprocal.dest_map)!==from.name&&!m.fallback)return null;
  at=arrivalAt(m,reciprocal,mode);
 }else if(portal.kind==='edge'){
  at=edgeLanding(m,portal.edge,previous,mode);
 }
 return at?{map:m,at}:null;
}
// Tempo mínimo entre passos no mapa. A velocidade da simulação pode ser 40x,
// mas o avatar nunca muda várias células antes de concluir uma passada visível.
function tileStepMs(){
 const speed=Number(window.emeraldOptions?.speed||0);
 if(!speed)return 0; // permite testes determinísticos do motor sem relógio real
 return speed>=40?140:speed>=10?165:speed>=3?205:270;
}
function stepTrainer(t,{intro=false}={}){
  // Only a real cell transition can trigger a grass encounter.
  t.walkJustStepped=false;
  const hub=resolve(t.location);
 if(!hub)return false;
 // Trocas de estágio mudam a META, não a posição física do treinador.
 if(t.storyNavStage!==t.stage||t.storyMapGoal!==hub){
  t.storyNavStage=t.stage;t.storyMapGoal=hub;
  t.storyDwell=0;t.storyArrived=false;t.introReady=false;
  t.storyAnchor=null;t.storyDwellAt=0;
  t.officialGoal=null;t.officialPortal=null;t.walkPath=[];t.officialRouteRetryAt=0;t.officialNoRouteRetries=0;
 }
 if(!t.officialMap){t.officialMap=hub;t.officialSpawn=true;t.walkMap='official:'+hub}
 t.officialTarget=hub;
 if(t.officialPending){t.walkMoving=false;t.walkObjective='Atravessando a passagem oficial…';return true}
 // Blackout is the ONLY permitted position relocation. Resolve the Center
 // before touching the previous map, otherwise a defeated bot could wait
 // forever inside a Route104 map while its team has zero HP.
 if(t.healing?.wiped===true){
  const center=resolve(t.location),centerState=prefetch(center);
  if(!/PokemonCenter_1F$/.test(center)||!centerState?.value){
   t.walkMoving=false;t.walkObjective='Aguardando Centro Pokémon para derrota total';return true;
  }
  const centerMap=centerState.value,door=(centerMap.meta.warp_events||[])[0];
  const landing=door?nearest(centerMap,{x:+door.x,y:+door.y-1},'walk',3):null;
  if(!landing){t.officialError='Centro Pokémon sem entrada segura';t.walkMoving=false;return true;}
  t.officialMap=center;t.walkMap='official:'+center;
  t.walkX=landing.x;t.walkY=landing.y;t.walkPrevX=landing.x;t.walkPrevY=landing.y;
  t.officialSpawn=false;t.healing.wiped=false;t.healing.blackoutArrived=true;
  t.walkPath=[];t.officialPortal=null;t.officialGoal=null;t.officialPending=null;
  t.walkNextAt=0;t.walkStepStartedAt=0;t.officialError=null;
  t.storyArrived=false;t.storyAnchor=null;
  t.walkObjective='Retornou ao Centro Pokémon após a derrota total';
 }
 const current=t.officialMap;
 const state=prefetch(current);
 if(!state?.value){t.walkMoving=false;t.walkObjective=state?.error?'Erro ao carregar '+current:'Carregando colisões de '+current+'…';return true}
 const m=state.value,mode=travelMode(t,m);
 const invalidPosition=!Number.isInteger(t.walkX)||!Number.isInteger(t.walkY)||!walkable(m,t.walkX,t.walkY,mode);
 if(!t.officialSpawn&&invalidPosition){
  // Preserve corrupted/isolated saves for inspection. No hidden relocation.
  t.officialError='Posição bloqueada no save. Nenhum teletransporte permitido.';
  t.walkMoving=false;t.walkPath=[];t.officialPortal=null;return true;
 }
 if(t.officialSpawn){
  const base={x:Math.floor(m.width/2),y:Math.floor(m.height/2)};
  const radius=Math.max(2,Math.floor(Math.min(m.width,m.height)/3));
  const offset=((t.id*17)%Math.max(1,2*radius+1))-radius;
  const initial=nearest(m,{x:base.x+offset,y:base.y+((t.id*7)%5)-2},mode);
  if(!initial){t.walkMoving=false;t.walkObjective='Sem área caminhável no mapa';return true}
  t.walkX=initial.x;t.walkY=initial.y;
  // Spawn/carregamento de mapa NÃO deve virar o avatar para a câmera.
  t.walkFacingDir=Number.isInteger(t.walkFacingDir)?t.walkFacingDir:(Number.isInteger(t.walkDir)?t.walkDir:2);
  t.walkDir=t.walkFacingDir;t.walkStage=t.stage;
  t.officialSpawn=false;t.officialGoal=null;t.walkPath=[];t.officialPortal=null;
  t.walkStepStartedAt=0;
  t.walkStepSeq=(t.walkStepSeq||0)+1;
 }
 if(t.battle){t.walkMoving=false;return true}
 // Mantém a velocidade lógica do mundo, mas aplica cada passo físico em tempo real.
 const minimumStep=tileStepMs(),now=Date.now();
 const sameSpot=t.walkLastCheckX===t.walkX&&t.walkLastCheckY===t.walkY&&t.officialMap===t.walkLastCheckMap;
 t.walkStuckSince=sameSpot?(t.walkStuckSince||now):now;
 t.walkLastCheckX=t.walkX;t.walkLastCheckY=t.walkY;t.walkLastCheckMap=t.officialMap;
 const portalBusy=!!t.officialPending||!!t.battle;
 // Do not reset a legitimate pause every four seconds: with 100 bots,
 // individual trainers receive fewer updates. Replan only after a real stall.
 const botCount=window.emeraldTrainers?.length||20;
 const stallLimit=Math.max(14000,Math.ceil(botCount/7)*1800);
 if(!portalBusy&&now-(t.walkStuckSince||now)>stallLimit&&(!t.storyArrived||t.walkPath?.length||t.officialPortal||t.officialGoal)){
  replan(t);t.walkObjective='Tentando outra passagem do mapa';
 }
 if(minimumStep&&Number(t.walkNextAt)>now){
  t.walkMoving=!!t.walkPath?.length;
  return true;
 }
 // Ao chegar ao mapa correto, a IA caminha até um local de interação.
 // Só depois de parar diante do evento é que a missão poderá avançar.
 if(current===hub){
  const here={x:t.walkX,y:t.walkY};
  if(!t.storyAnchor){
   const possible=[];
   const add=(pt,weight)=>{
    const target=nearest(m,pt,mode);if(!target)return;
    const path=findPath(m,here,target,mode);
    if(!path.length&&(target.x!==here.x||target.y!==here.y))return;
    const len=path.length;
    // Escolha pontos de interação mais próximos e atingíveis.
    possible.push({target,path,score:weight+Math.min(12,len)});
   };
   // À frente dos objetos, sem ocupar a célula do NPC.
   const objs=m.meta.object_events||[];
   for(let k=0;k<objs.length;k++){
    const obj=objs[(k+t.id)%objs.length];
    if(!Number.isInteger(+obj.x)||!Number.isInteger(+obj.y))continue;
    for(const [dx,dy] of [[0,1],[0,-1],[1,0],[-1,0]]){
     if(walkable(m,+obj.x+dx,+obj.y+dy,mode))add({x:+obj.x+dx,y:+obj.y+dy},7);
    }
   }
   const mid={x:Math.floor(m.width/2),y:Math.floor(m.height/2)};
   for(const [dx,dy] of [[0,0],[2,0],[-2,0],[0,2],[0,-2],[3,3],[-3,-3]])
    add({x:mid.x+dx+(t.id%3)-1,y:mid.y+dy},2);
   // Preferir o objetivo alcançável MAIS PRÓXIMO, sem passeios circulares.
   // Desempate por objetivo e id; o destino não muda a cada frame.
   possible.sort((a,b)=>a.path.length-b.path.length||a.score-b.score||a.target.y-b.target.y||a.target.x-b.target.x);
   const chosen=possible[Math.min(t.id%3,Math.max(0,possible.length-1))];
   t.storyAnchor=chosen?.target||here;
   t.walkPath=chosen?.path||[];
   t.storyDwellAt=0;t.storyArrived=false;
   t.officialPortal=null;
  }
  if(t.walkX===t.storyAnchor.x&&t.walkY===t.storyAnchor.y&&!t.walkPath?.length){
   t.walkMoving=false;t.walkObjective=t.storyArrived?'Evento concluído':'Interagindo com o evento';
   if(!t.storyDwellAt)t.storyDwellAt=now;
   if(now-t.storyDwellAt>=750+(t.id%9)*115){t.storyArrived=true;t.introReady=true}
   return true;
  }
  t.storyDwellAt=0;t.storyArrived=false;t.introReady=false;
  if(!t.walkPath?.length){t.walkPath=findPath(m,here,t.storyAnchor,mode);}
  t.walkObjective='Indo ao evento da história';
  if(!t.walkPath?.length){
   // Recalcular em vez de ficar girando quando uma âncora mudou de acessibilidade.
   t.storyAnchor=null;t.walkMoving=false;t.walkObjective='Recalculando ponto da missão';return true;
  }
 }else{
  t.storyDwellAt=0;t.storyArrived=false;t.introReady=false;
  t.storyAnchor=null;
 }
 if(!t.walkPath?.length&&!t.officialPortal){
  if(current!==hub&&t.officialRouteRetryAt>now){t.walkMoving=false;return true}
  const next=selectGoal(t,m);
  if(next){t.officialRouteRetryAt=0;t.officialGoal=next.goal;t.walkPath=next.path;t.officialPortal=next.kind==='patrol'?null:next;
   t.walkObjective=next.kind==='ferry'?'Caminhando até o barco de Mr. Briney':next.kind==='warp'?'Caminhando até uma porta':next.kind==='edge'?'Seguindo pela conexão oficial':
   t.storyArrived?'Explorando '+current:'Percorrendo o cenário antes da missão';
  }else{t.officialRouteRetryAt=t.officialRescueKey===m.name+'|'+t.officialTarget+'|'+t.stage&&t.officialNoRouteRetries===0?0:now+2100;t.walkMoving=false;t.walkObjective=t.officialError||t.walkObjective||'Sem saída caminhável; tentando outra passagem';}
 }
 if(!t.walkPath?.length){
   if(t.officialPortal){
    const portal=t.officialPortal;t.officialPortal=null;
    // É proibido executar um warp antes de percorrer o caminho calculado.
    const atDoor=!portal.approach&&t.walkX===portal.door?.x&&t.walkY===portal.door?.y;
    const besideDoor=portal.approach&&Math.abs(t.walkX-portal.door?.x)+Math.abs(t.walkY-portal.door?.y)===1;
    if(portal.kind==='warp'&&!atDoor&&!besideDoor){
     t.walkObjective='Recalculando acesso à porta';t.officialGoal=null;return true;
    }
    if(portal.destination&&portal.destination!==m.name){
     if(portal.kind==='warp'&&portal.approach){
      t.walkDir=portal.door.x>t.walkX?1:portal.door.x<t.walkX?3:portal.door.y>t.walkY?2:0;
      t.walkFacingDir=t.walkDir;
      t.walkObjective='Entrando pela porta oficial';
     }
     t.officialPending=portal;
     if(portal.kind==='ferry')t.walkObjective='⛵ Atravessando o mar com Mr. Briney…';
     destinationOf(portal,m,{x:t.walkX,y:t.walkY},mode).then(async dest=>{
     if(portal.kind==='ferry')await new Promise(resolve=>setTimeout(resolve,1600));
     if(!dest){t.officialError='Saída inacessível: '+portal.destination;t.officialRouteRetryAt=Date.now()+2400;t.officialRetryCount=(t.officialRetryCount||0)+1;return}
     t.officialLastMap=m.name;
     t.officialInboundWarpIndex=portal.kind==='warp'?Number(portal.warp?.dest_warp_id):null;
     t.officialTransitCounts??={};
     const transitKey=m.name+'>'+dest.map.name;
     t.officialTransitCounts[transitKey]=(t.officialTransitCounts[transitKey]||0)+1;
     if(Object.keys(t.officialTransitCounts).length>40)t.officialTransitCounts={};
     t.officialMap=dest.map.name;t.walkMap='official:'+dest.map.name;
     t.walkX=dest.at.x;t.walkY=dest.at.y;t.walkPrevX=dest.at.x;t.walkPrevY=dest.at.y;
     t.walkStepStartedAt=0;
     t.walkNextAt=Date.now()+tileStepMs();t.officialSteps=0;
     t.walkPath=[];t.officialGoal=null;t.officialSpawn=false;t.officialRouteRetryAt=0;
     t.storyDwell=0;t.storyArrived=false;t.introReady=false;
     t.storyAnchor=null;t.storyDwellAt=0;
    }).catch(err=>{t.officialError=String(err?.message||err)}).finally(()=>{t.officialPending=null});
   }
  }
  t.walkMoving=false;return true;
 }
 const next=t.walkPath.shift(),dx=next.x-t.walkX,dy=next.y-t.walkY;
 if(!canStep(m,{x:t.walkX,y:t.walkY},next,mode)){
  t.walkPath=[];t.officialGoal=null;t.officialPortal=null;t.walkMoving=false;
  t.walkObjective='Colisão detectada; recalculando rota';return true;
 }
 t.walkPrevX=t.walkX;t.walkPrevY=t.walkY;
 t.walkDir=dx>0?1:dx<0?3:dy>0?2:0;
 // O lado para o qual olha permanece fixo até o próximo passo REAL.
 t.walkFacingDir=t.walkDir;
 t.walkStepMs=minimumStep||200;
 t.walkNextAt=now+minimumStep;
 t.walkX=next.x;t.walkY=next.y;
 t.walkStepStartedAt=now;
 t.walkStepSeq=(t.walkStepSeq||0)+1;
 t.walkCount=(t.walkCount||0)+1;t.walkStepsOnMap=(t.walkStepsOnMap||0)+1;
 t.officialSteps=(t.officialSteps||0)+1;t.walkMoving=true;t.walkJustStepped=true;
 const vision=trainerVisionTarget(m,{x:t.walkX,y:t.walkY},now,t.defeatedOfficialTrainers);
 if(vision&&window.emeraldOfficialTrainerEncounter){
  const defeated=t.defeatedOfficialTrainers||(t.defeatedOfficialTrainers={});
  if(!defeated[vision.key]&&(!t.officialTrainerRetryUntil||t.officialTrainerRetryUntil<=now)){
   const started=window.emeraldOfficialTrainerEncounter(t,vision,m.name);
   if(started){t.walkMoving=false;t.walkPath=[];t.officialGoal=null;t.officialPortal=null;t.walkObjective='Treinador avistou o bot!';}
  }
 }
 return true;
}
// Renderização dos gráficos oficiais do tileset (mesma codificação dos mapas do jogo).
async function decodePng(buffer){const data=new Uint8Array(buffer),view=new DataView(buffer);
 if(data.length<33||[137,80,78,71,13,10,26,10].some((n,i)=>data[i]!==n))throw Error('PNG inválido');
 let pos=8,width=0,height=0,depth=0,color=0,interlace=0;const parts=[];
 while(pos+12<=data.length){const len=view.getUint32(pos),tag=String.fromCharCode(...data.slice(pos+4,pos+8));pos+=8;
  if(pos+len+4>data.length)throw Error('PNG truncado');
  if(tag==='IHDR'){width=view.getUint32(pos);height=view.getUint32(pos+4);depth=data[pos+8];color=data[pos+9];interlace=data[pos+12]}
  else if(tag==='IDAT')parts.push(data.slice(pos,pos+len));
  pos+=len+4;if(tag==='IEND')break;
 }
 if(!width||!height||width*height>12000000||color!==3||interlace||![1,2,4,8].includes(depth))throw Error('Formato do tileset PNG não suportado');
 const compressed=new Uint8Array(parts.reduce((n,p)=>n+p.length,0));let i=0;for(const p of parts){compressed.set(p,i);i+=p.length}
 if(typeof DecompressionStream==='undefined')throw Error('Navegador sem suporte a descompressão');
 const raw=new Uint8Array(await new Response(new Blob([compressed]).stream().pipeThrough(new DecompressionStream('deflate'))).arrayBuffer());
 const rowLen=Math.ceil(width*depth/8),bytesPerPixel=1,output=new Uint8Array(width*height);let cursor=0,prev=new Uint8Array(rowLen);
 for(let y=0;y<height;y++){
  const filter=raw[cursor++];if(filter>4)throw Error('Filtro PNG inválido');
  const line=new Uint8Array(rowLen);
  for(let x=0;x<rowLen;x++){
   const a=x>=bytesPerPixel?line[x-bytesPerPixel]:0,b=prev[x],c=x>=bytesPerPixel?prev[x-bytesPerPixel]:0;
   let predict=0;if(filter===1)predict=a;else if(filter===2)predict=b;else if(filter===3)predict=Math.floor((a+b)/2);
   else if(filter===4){const p=a+b-c,da=Math.abs(p-a),db=Math.abs(p-b),dc=Math.abs(p-c);predict=da<=db&&da<=dc?a:db<=dc?b:c}
   line[x]=(raw[cursor++]+predict)&255;
  }
  for(let x=0;x<width;x++){
   const shift=8-depth*(x%(8/depth)+1),byte=line[Math.floor(x*depth/8)];output[y*width+x]=(byte>>shift)&((1<<depth)-1)
  }
  prev=line;
 }
 return {index:output,width,height};
}
function tilesetSlug(t){return t.replace(/^gTileset_/,'').replace(/([a-z])([A-Z])/g,'$1_$2').replace(/([A-Z])([A-Z][a-z])/g,'$1_$2').toLowerCase()}
const tileSets=new Map();
function getTiles(level,id){const name=tilesetSlug(id),key=level+':'+name;if(tileSets.has(key))return tileSets.get(key);
 const path=`data/tilesets/${level}/${name}/`;
 const req=Promise.all([fetchFile(path+'tiles.png','binary'),fetchFile(path+'metatiles.bin','binary'),fetchFile(path+'metatile_attributes.bin','binary')]).then(async ([png,meta,attrs])=>({level,name,image:await decodePng(png),metatiles:new DataView(meta),attributes:new DataView(attrs)}));
 tileSets.set(key,req);req.catch(()=>tileSets.delete(key));return req;
}
function pal(txt){const lines=txt.trim().split(/\r?\n/);if(lines.shift()!=='JASC-PAL')throw Error('Paleta inválida');lines.shift();const total=Number(lines.shift());return lines.slice(0,total).map(s=>s.trim().split(/\s+/).slice(0,3).map(Number))}
async function drawArt(m){const [primary,secondary]=await Promise.all([getTiles('primary',m.layout.primary_tileset),getTiles('secondary',m.layout.secondary_tileset)]);
 const palettes=await Promise.all(Array.from({length:13},(_,i)=>{const t=i<6?primary:secondary;return fetchFile(`data/tilesets/${t.level}/${t.name}/palettes/${String(i).padStart(2,'0')}.pal`,'text').then(pal)}));
 const bitmap=document.createElement('canvas');bitmap.width=m.width*16;bitmap.height=m.height*16;
 const context=bitmap.getContext('2d',{alpha:false});context.imageSmoothingEnabled=false;
 // Este canvas é transparente e será desenhado DEPOIS dos personagens.
 // No GBA, layer Normal e Split usam BG1 sobre os sprites (telhados/árvores).
 const foreground=document.createElement('canvas');foreground.width=bitmap.width;foreground.height=bitmap.height;
 const fgContext=foreground.getContext('2d');fgContext.imageSmoothingEnabled=false;
 const tileCache=new Map();
 const paint=(entry,x,y,target)=>{const tileId=entry&1023,flipX=!!(entry&1024),flipY=!!(entry&2048),palId=(entry>>>12)&15;
  const group=tileId>=512?secondary:primary,id=tileId-(tileId>=512?512:0),key=group.level+':'+group.name+':'+id+':'+palId;
  let small=tileCache.get(key);
  if(!small){const {index,width,height}=group.image,cols=width/8,sx=(id%cols)*8,sy=Math.floor(id/cols)*8;if(!Number.isInteger(cols)||sy+8>height)return;
   small=document.createElement('canvas');small.width=small.height=8;
   const c=small.getContext('2d'),px=c.createImageData(8,8),colors=palettes[palId]||palettes[0];
   for(let j=0;j<8;j++)for(let k=0;k<8;k++){
    const colorId=index[(sy+j)*width+sx+k]&15,rgbs=colors[colorId]||[0,0,0],at=(j*8+k)*4;
    px.data[at]=rgbs[0];px.data[at+1]=rgbs[1];px.data[at+2]=rgbs[2];px.data[at+3]=colorId?255:0;
   }
   c.putImageData(px,0,0);tileCache.set(key,small);
  }
  if(flipX||flipY){target.save();target.translate(x+(flipX?8:0),y+(flipY?8:0));target.scale(flipX?-1:1,flipY?-1:1);target.drawImage(small,0,0);target.restore()}
  else target.drawImage(small,x,y);
 };
 for(let y=0;y<m.height;y++)for(let x=0;x<m.width;x++){
  const info=infoAt(m,x,y),grp=info.id>=512?secondary:primary,id=info.id>=512?info.id-512:info.id,offset=id*16;
  if(offset+16>grp.metatiles.byteLength)continue;
  const overlay=info.layerType===0||info.layerType===2;
  for(let layer=0;layer<2;layer++)for(let z=0;z<4;z++){
   const target=layer===1&&overlay?fgContext:context;
   paint(grp.metatiles.getUint16(offset+(layer*4+z)*2,true),x*16+(z&1)*8,y*16+(z>>1)*8,target);
  }
 }
 // O canvas público permanece como a imagem completa para visualizadores.
 // A simulação desenha base, personagens e a camada de frente nesta ordem.
 const combined=document.createElement('canvas');combined.width=bitmap.width;combined.height=bitmap.height;
 const full=combined.getContext('2d');full.imageSmoothingEnabled=false;full.drawImage(bitmap,0,0);full.drawImage(foreground,0,0);
 return {image:combined,base:bitmap,foreground};
}
// Renderizador por setores: nao cria uma tela de milhares de pixels para
// todas as rotas. Em Android, reter 56 setores de 16x16 tiles (~29 MiB nas
// duas camadas RGBA) e compor apenas o retangulo visivel da camera.
const CHUNK_TILES=16,CHUNK_LIMIT=56;
const chunkCache=new Map(),chunkJobs=[],paletteCache=new Map(),swatchCache=new Map();
let chunkDrawing=false,chunkFinished=0,chunkErrors=0;
function paletteSet(m){
 const key=m.layout.primary_tileset+':'+m.layout.secondary_tileset;
 if(paletteCache.has(key))return paletteCache.get(key);
 const task=Promise.all([getTiles('primary',m.layout.primary_tileset),getTiles('secondary',m.layout.secondary_tileset)]).then(async([primary,secondary])=>({
  primary,secondary,colors:await Promise.all(Array.from({length:13},(_,i)=>{
   const t=i<6?primary:secondary;
   return fetchFile(`data/tilesets/${t.level}/${t.name}/palettes/${String(i).padStart(2,'0')}.pal`,'text').then(pal);
  }))
 }));
 paletteCache.set(key,task);task.catch(()=>paletteCache.delete(key));return task;
}
function swatch(group,index,palette,colors){
 const key=group.level+':'+group.name+':'+index+':'+palette;
 if(swatchCache.has(key))return swatchCache.get(key);
 const cols=group.image.width/8,sx=index%cols*8,sy=Math.floor(index/cols)*8;
 if(!Number.isInteger(cols)||sy+8>group.image.height)return null;
 const tile=document.createElement('canvas');tile.width=tile.height=8;
 const ctx=tile.getContext('2d'),pix=ctx.createImageData(8,8),table=colors[palette]||colors[0];
 for(let y=0;y<8;y++)for(let x=0;x<8;x++){
  const v=group.image.index[(sy+y)*group.image.width+sx+x]&15,
   rgb=table[v]||[0,0,0],at=(y*8+x)*4;
  pix.data[at]=rgb[0];pix.data[at+1]=rgb[1];pix.data[at+2]=rgb[2];pix.data[at+3]=v?255:0;
 }
 ctx.putImageData(pix,0,0);swatchCache.set(key,tile);
 if(swatchCache.size>2200)swatchCache.delete(swatchCache.keys().next().value);
 return tile;
}
async function paintChunk(m,cx,cy){
 const {primary,secondary,colors}=await paletteSet(m),x0=cx*CHUNK_TILES,y0=cy*CHUNK_TILES;
 const w=Math.min(CHUNK_TILES,m.width-x0),h=Math.min(CHUNK_TILES,m.height-y0);
 if(w<=0||h<=0)throw Error('Chunk fora do mapa');
 const base=document.createElement('canvas'),foreground=document.createElement('canvas');
 for(const canvas of [base,foreground]){canvas.width=w*16;canvas.height=h*16;}
 const bg=base.getContext('2d',{alpha:false}),fg=foreground.getContext('2d');
 bg.imageSmoothingEnabled=false;fg.imageSmoothingEnabled=false;
 function paint(entry,px,py,target){
  const num=entry&1023,flipX=!!(entry&1024),flipY=!!(entry&2048),palette=(entry>>>12)&15;
  const group=num>=512?secondary:primary,index=num-(num>=512?512:0);
  const tile=swatch(group,index,palette,colors);if(!tile)return;
  if(flipX||flipY){target.save();target.translate(px+(flipX?8:0),py+(flipY?8:0));
   target.scale(flipX?-1:1,flipY?-1:1);target.drawImage(tile,0,0);target.restore();}
  else target.drawImage(tile,px,py);
 }
 for(let y=y0;y<y0+h;y++)for(let x=x0;x<x0+w;x++){
  const info=infoAt(m,x,y),grp=info.id>=512?secondary:primary;
  const id=info.id>=512?info.id-512:info.id,offset=id*16;
  if(offset+16>grp.metatiles.byteLength)continue;
  const cover=info.layerType===0||info.layerType===2;
  for(let layer=0;layer<2;layer++)for(let z=0;z<4;z++){
   paint(grp.metatiles.getUint16(offset+(layer*4+z)*2,true),
    (x-x0)*16+(z&1)*8,(y-y0)*16+(z>>1)*8,layer===1&&cover?fg:bg);
  }
 }
 return {base,foreground,width:w*16,height:h*16};
}
function ensureChunk(name,cx,cy){
 name=resolve(name);cx=Math.floor(cx);cy=Math.floor(cy);
 const key=name+':'+cx+':'+cy;
 if(chunkCache.has(key)){
  const entry=chunkCache.get(key);chunkCache.delete(key);chunkCache.set(key,entry);return entry;
 }
 const entry={value:null,error:null,promise:null};chunkCache.set(key,entry);
 let resolveTask;
 entry.promise=new Promise(ok=>{resolveTask=ok});
 chunkJobs.push({name,cx,cy,entry,done:resolveTask});
 pumpChunkJobs();
 while(chunkCache.size>CHUNK_LIMIT){
  const oldest=chunkCache.keys().next().value;
  // O emprego de um mapa distante nao invalida a promessa dos setores pendentes.
  chunkCache.delete(oldest);
 }
 return entry;
}
function pumpChunkJobs(){
 if(chunkDrawing||!chunkJobs.length)return;
 chunkDrawing=true;
 const job=chunkJobs.shift();
 setTimeout(async()=>{
  try{
   const m=await ensureNav(job.name);
   if(m.fallback){
    const original=drawRecovery(m),src=original.base;
    const sx=job.cx*CHUNK_TILES*16,sy=job.cy*CHUNK_TILES*16;
    const w=Math.min(CHUNK_TILES*16,src.width-sx),h=Math.min(CHUNK_TILES*16,src.height-sy);
    if(w<=0||h<=0)throw Error('Chunk adaptado fora do mapa');
    const base=document.createElement('canvas');base.width=w;base.height=h;
    base.getContext('2d').drawImage(src,sx,sy,w,h,0,0,w,h);
    job.entry.value={base,foreground:null,width:w,height:h,adapted:true};
   }else job.entry.value=await paintChunk(m,job.cx,job.cy);
   chunkFinished++;
  }catch(e){job.entry.error=e;chunkErrors++;}
  finally{job.done(job.entry.value);chunkDrawing=false;pumpChunkJobs()}
 },0);
}
function chunkStats(){return {cached:chunkCache.size,queued:chunkJobs.length,drawn:chunkFinished,
 failures:chunkErrors,maximum:CHUNK_LIMIT,chunkTiles:CHUNK_TILES}}

// Sprites reais do overworld no repositorio do Emerald. As imagens nao sao
// empacotadas; o navegador carrega sob demanda, com a paleta indexada correta.
const trainerSprites=new Map();
function getTrainerSprite(kind='brendan'){
 const name=kind==='may'?'may':'brendan';
 if(trainerSprites.has(name))return trainerSprites.get(name);
 const entry={value:null,error:null,promise:null};trainerSprites.set(name,entry);
 entry.promise=Promise.all([
  fetchFile(`graphics/object_events/pics/people/${name}/walking.png`,'binary'),
  fetchFile(`graphics/object_events/palettes/${name}.pal`,'text')
 ]).then(async([raw,palette])=>{
  const png=await decodePng(raw),colors=pal(palette);
  const canvas=document.createElement('canvas');canvas.width=png.width;canvas.height=png.height;
  const c=canvas.getContext('2d');const im=c.createImageData(png.width,png.height);
  for(let i=0;i<png.index.length;i++){
   const id=png.index[i],rgba=colors[id]||[0,0,0];
   im.data[i*4]=rgba[0];im.data[i*4+1]=rgba[1];im.data[i*4+2]=rgba[2];
   im.data[i*4+3]=id===0?0:255;
  }
  c.putImageData(im,0,0);entry.value=canvas;return canvas;
 }).catch(e=>{entry.error=e;throw e});entry.promise.catch(()=>{});
 return entry;
}
function ensureArt(name){name=resolve(name);let previous=arts.get(name);if(previous?.error&&Date.now()-(previous.errorTime||0)>25000){arts.delete(name);previous=null}if(previous)return previous;
 const entry={value:null,error:null,promise:null};
 entry.promise=ensureNav(name).then(async m=>{
  if(m.fallback)return drawRecovery(m);
  try{return await drawArt(m)}catch(e){m.artFallback=true;return drawRecovery(m)}
 }).then(layers=>{entry.value=layers.image;entry.layers=layers;return layers.image}).catch(e=>{entry.error=e;entry.errorTime=Date.now();throw e});
 entry.promise.catch(()=>{});arts.set(name,entry);
 // Mantém poucos canvases no celular. O catálogo binário continua com cache.
 if(arts.size>4)for(const [key,val] of arts){if(key!==name&&val.value){arts.delete(key);if(arts.size<=4)break}}
 return entry;
}
function art(name){return arts.get(resolve(name))?.value||null}
function artLayers(name){return arts.get(resolve(name))?.layers||null}

// Treinadores do mapa: somente object_events realmente marcados como treinadores.
// Os campos trainer_type / trainer_sight... pertencem ao formato pokeemerald.
function metaNum(v,fallback=0){const n=Number(v);return Number.isFinite(n)?n:fallback}
function metaText(v){return String(v??'').trim()}
const FACE_NAMES={UP:0,RIGHT:1,DOWN:2,LEFT:3};
function movementProfile(obj){
 const motion=metaText(obj.movement_type).replace(/^MOVEMENT_TYPE_/,'');
 const dirs=motion.split('_').filter(k=>Object.prototype.hasOwnProperty.call(FACE_NAMES,k)).map(k=>FACE_NAMES[k]);
 let allowed=dirs.length?dirs:[0,1,2,3];
 // LOOK_AROUND, WANDER e FACE_DOWN_UP_AND_RIGHT giram. FACE_DOWN fica parado.
 // WANDER means NPC movement in the ROM; this renderer does not yet simulate
 // its footsteps, so inventing a timed 360-degree turn looks like spinning.
 // Only an explicit multi-facing idle instruction may turn in place.
 const turner=dirs.length>1&&/FACE_|LOOK_AROUND/.test(motion);
 return {motion,dirs:allowed,rotating:turner,dir:allowed[0]??2};
}
function sentryName(obj,index){
 const script=metaText(obj.script);
 const suffix=script.match(/_EventScript_([A-Za-z0-9]+)$/)?.[1];
 const gfx=metaText(obj.graphics_id).replace(/^OBJ_EVENT_GFX_/,'').replace(/_/g,' ').toLowerCase().replace(/\b\w/g,c=>c.toUpperCase());
 if(suffix&&!/^(Trainer|Trainer1|Trainer2|Event)$/i.test(suffix))return `${gfx||'Treinador'} ${suffix.replace(/([a-z])([A-Z])/g,'$1 $2')}`;
 return gfx||`Treinador ${index+1}`;
}
function isOfficialTrainer(obj){
 const type=metaText(obj.trainer_type);
 return !!type&&type!=='TRAINER_TYPE_NONE'&&type!=='0'&&type!=='NONE';
}
function trainerSentries(mapLike){
 const m=mapLike?.meta?mapLike:cache.get(resolve(mapLike))?.value;
 if(!m)return [];
 if(sentryCache.has(m.name))return sentryCache.get(m.name);
 const sentries=[];
 for(const [i,obj] of (m.meta.object_events||[]).entries()){
  if(!isOfficialTrainer(obj)||obj.flag&&obj.flag!=='0')continue;
  const x=metaNum(obj.x,NaN),y=metaNum(obj.y,NaN);
  if(!Number.isInteger(x)||!Number.isInteger(y))continue;
  const profile=movementProfile(obj);
  const radius=Math.max(0,Math.min(8,metaNum(obj.trainer_sight_or_berry_tree_id,0)));
  const seed=(Math.imul(x+1,131)^Math.imul(y+1,67)^Math.imul(i+1,17))>>>0;
  sentries.push({id:i,key:`${m.name}:${i}:${x}:${y}`,x,y,
   dir:profile.dir,dirs:profile.dirs,rotating:profile.rotating,fixed:!profile.rotating,
   sight:radius,seed,label:sentryName(obj,i),graphicsId:metaText(obj.graphics_id),kind:'trainer'});
  if(sentries.length>=50)break;
 }
 sentryCache.set(m.name,sentries);
 sentryBlockers.set(m.name,new Set((m.meta.object_events||[]).filter(o=>!o.flag||o.flag==='0').map(o=>`${Number(o.x)},${Number(o.y)}`)));
 return sentries;
}
function sentryFacing(s,now=Date.now()){
 if(!s)return 2;
 const available=s.dirs?.length?s.dirs:[s.dir??2];
 if(!s.rotating)return available[0];
 return available[(Math.floor(now/8000)+(s.seed||0))%available.length];
}
function trainerVisionTarget(mapLike,at,now=Date.now(),defeated={}){
 const m=mapLike?.meta?mapLike:cache.get(resolve(mapLike))?.value;
 if(!m||!at)return null;
 const sentries=trainerSentries(m),objects=sentryBlockers.get(m.name)||new Set();
 for(const s of sentries){
  if(defeated?.[s.key]||s.sight<1)continue;
  const dir=sentryFacing(s,now),vec=[[0,-1],[1,0],[0,1],[-1,0]][dir]||[0,1];
  for(let dist=1;dist<=s.sight;dist++){
   const x=s.x+vec[0]*dist,y=s.y+vec[1]*dist;
   if(!walkable(m,x,y))break;
   // Outros personagens impedem a visão através de obstáculos móveis.
   if(objects.has(`${x},${y}`))break;
   if(at.x===x&&at.y===y)return {...s,dir};
  }
 }
 return null;
}
window.emeraldOfficialWorld={ROOT,resolve,label,mapName,known,cache,ensureNav,prefetch,navStatus,infoAt,walkable,canStep,nearest,findPath,travelMode,stepTrainer,nextHop,choosePortal,alternativeTransit,selectGoal,replan,routeVariety,warpGoal,edgeGoal,arrivalAt,destinationOf,ensureArt,art,artLayers,ensureChunk,chunkStats,getTrainerSprite,decodePng,trainerSentries,sentryFacing,trainerVisionTarget,loadCatalog:()=>catalogPromise,diagnoseMap:(name)=>{const m=cache.get(resolve(name))?.value;return m?{name:m.name,width:m.width,height:m.height,source:m.fallback?'adapted':'official',warps:(m.meta.warp_events||[]).length,connections:(m.meta.connections||[]).length}:null},navStats:()=>({ready:[...cache.values()].filter(x=>x.value).length,loading:[...cache.values()].filter(x=>!x.value&&!x.error).length,failed:[...cache.values()].filter(x=>x.error).length,catalogueStatus})};
})();
