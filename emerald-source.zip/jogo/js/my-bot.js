(()=>{'use strict';
const root=document.getElementById('myBotPanel');if(!root)return;
const $=id=>document.getElementById(id);
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pref=()=>window.emeraldGetBotPrefs?.()||{name:'Meu Treinador',starter:'Mudkip',goal:'story',style:'balanced'};
const starters=window.EmeraldStarters?.ALL||['Treecko','Torchic','Mudkip'];
let lastSignature='';
const monArt=species=>window.EmeraldPokemonArt.tag(species);
root.innerHTML=`
<section class="personalHero">
 <div class="personalHeroTitle"><span class="personalEyebrow">SUA HISTÓRIA EM HOENN</span><h2>Minha Jornada <span>🌿</span></h2><p>Seu treinador explora o mundo. Você toma as decisões importantes.</p></div>
 <button type="button" id="botFollow" class="personalSubtle">🗺️ Ver no mapa</button>
</section>
<div class="personalSpeedControl"><label for="botSpeed">⚡ Velocidade da simulação</label><select id="botSpeed" aria-label="Escolher velocidade do meu bot">${(window.EmeraldSimSpeed?.PRESETS||[1,2,3,5]).map(n=>`<option value="${n}">${n}× · ${n*40}× anterior</option>`).join('')}</select><small>Novo 1× = antigo 40× na velocidade solicitada. O celular limita o processamento quando necessário.</small></div>
<section class="personalPartyCard" aria-label="Equipe do seu bot"><div class="personalSectionHeading"><h3>Meu time Pokémon</h3><span id="botPartyCount">0/6</span></div><div id="botRoster" class="personalParty"></div></section>
<section class="personalWorldCard" id="personalWorldCard" aria-label="Mundo original de Hoenn, com mapa animado">
 <div class="personalSectionHeading"><h3>🌿 Explorando Hoenn</h3><button id="botWorldZoom" type="button" class="personalSubtle" aria-pressed="false">🗺️ Ampliar</button></div>
 <div id="myBotMapMount" class="sharedWorldMount" aria-label="O mesmo mapa oficial animado da versão 9.6"></div>
 <p class="personalMapNote">Mapa animado da jornada. Casas, árvores, grama, caminhos e camadas preservadas da V9.6. A IA continua seguindo as colisões do mapa.</p>
</section>
<section class="personalChoiceCard playerCommandCard" id="botJourneyDecision" aria-label="Decisões da sua jornada">
 <div class="personalEyebrow">VOCÊ CONTROLA SEU PERSONAGEM</div>
 <h3>🧭 Qual vai ser seu próximo passo?</h3>
 <p id="botJourneyPrompt">Escolha a próxima ação. Seu treinador não continua a história sem sua decisão.</p>
 <div class="playerCommandButtons" role="group" aria-label="Escolher próxima ação do treinador">
  <button type="button" data-journey-action="story" class="personalPrimary">📜 Seguir história</button>
  <button type="button" data-journey-action="train">💪 Treinar time</button>
  <button type="button" data-journey-action="capture">🔴 Procurar Pokémon</button>
  <button type="button" data-journey-action="explore">🗺️ Explorar</button>
  <button type="button" data-journey-action="battle">⚔️ Desafiar treinador</button>
 </div>
 <p id="botJourneyMessage" class="playerCommandStatus" role="status" aria-live="polite"></p>
</section>
<section class="personalTopSix" id="botTopSixCard" aria-label="Treinadores em destaque">
 <div class="personalSectionHeading"><h3>🏆 Destaques dos treinadores</h3><span>Times e jornada</span></div>
 <div class="personalTopSixList" id="botTopSixList"><p class="personalEmpty">Aguardando Pokémon...</p></div>
</section>
<section class="personalJourneyCard" aria-label="Progresso do meu treinador">
 <div class="personalCardTop"><strong id="botDisplayName">Meu Treinador</strong><span id="botStatus">Preparando jornada</span></div>
 <p id="botPosition" class="personalMuted">Littleroot</p>
 <div class="personalStats"><div><small>Insígnias</small><b id="botBadges">0/8</b></div><div><small>Vitórias</small><b id="botWins">0</b></div><div><small>História</small><b id="botStage">1</b></div></div>
 <p class="personalObjective" id="botObjective">Escolha seu Pokémon inicial para começar.</p>
 <p id="botWarning" class="personalWarning" hidden></p>
</section>
<section id="botRivalDecision" class="personalChoiceCard" hidden aria-label="Decisão antes da batalha do rival">
 <div class="personalEyebrow">UMA ESCOLHA IMPORTANTE</div><h3 id="botRivalTitle">Seu rival espera!</h3>
 <p>Você pode desafiar agora ou treinar mais três vezes para preparar seu time. O resultado depende da batalha.</p>
 <div class="personalChoiceActions"><button type="button" data-rival-choice="train" class="personalSecondary">💪 Treinar primeiro</button><button type="button" data-rival-choice="fight" class="personalPrimary">⚔️ Enfrentar agora</button></div>
</section>
<section id="botTrainingStatus" class="personalChoiceCard" hidden aria-live="polite"><h3>💪 Preparando sua equipe</h3><p id="botTrainingText">Treinamento em andamento...</p></section>
<section id="botBattleCard" class="personalBattleCard" hidden aria-label="Batalha do meu treinador">
 <div class="personalBattleHeading"><span class="personalEyebrow">BATALHA EM ANDAMENTO</span><label class="personalAutoToggle"><input type="checkbox" id="botAutoMoves"> Golpes automáticos</label></div>
 <h3 id="botBattleHeading">Encontro Pokémon</h3>
 <div class="personalBattleField"><div id="botOpponent" class="personalCombatant"></div><span class="personalVersus">VS</span><div id="botMyPokemon" class="personalCombatant"></div></div>
 <h4 id="botTurnTitle">Escolha sua ação</h4><div id="botMoveChoices" class="personalMoves"></div><p id="botActionMessage" role="status" aria-live="polite"></p>
 <details class="personalBattleLog"><summary>📜 Ver histórico da batalha</summary><div id="botBattleLines"></div></details>
</section>

<details class="personalSettings"><summary>⚙️ Ajustar meu treinador</summary>
 <div class="personalFields"><label>Nome<input type="text" id="botName" maxlength="24"></label>
 <label>Inicial<select id="botStarter">${starters.map(name=>`<option value="${esc(name)}">${esc(name)} · Geração ${window.EmeraldStarters?.GENERATION[name]||3}</option>`).join('')}</select></label>
 <label>Prioridade<select id="botGoal"><option value="story">Seguir história</option><option value="train">Treinar equipe</option><option value="capture">Capturar Pokémon</option><option value="battle">Desafiar treinadores</option><option value="explore">Explorar rotas</option></select></label>
 <label>Estratégia<select id="botStyle"><option value="balanced">Equilibrada</option><option value="aggressive">Ofensiva</option><option value="defensive">Defensiva</option><option value="catcher">Foco em captura</option></select></label></div>
 <div class="personalSettingsActions"><button id="botApply" type="button" class="personalPrimary">Salvar preferências</button><button id="botSetupOpen" type="button" class="personalSecondary">Modo de jogo e saves</button></div><p id="botNote" role="status"></p>
</details>
<details class="personalDiary"><summary>📖 Diário das decisões</summary><div id="botMemo"></div></details>`;
// Dashboard compacto: mapa → time → decisões → Top 6. Sem duplicar canvas ou saves.
const order=['.personalHero','#personalWorldCard','.personalPartyCard','#botJourneyDecision','#botRivalDecision','#botBattleCard','#botTrainingStatus','#botTopSixCard','.personalJourneyCard','.personalSpeedControl','.personalSettings','.personalDiary'];
const panels=order.map(sel=>root.querySelector(sel)).filter(Boolean);
if(panels.length===order.length)root.replaceChildren(...panels);
let lastTopSix='';
function renderTopSix(){
 if(root.closest('.pageView')?.hidden)return;
 const target=$('botTopSixList');if(!target)return;
 const data=window.EmeraldTrainerRankings?.ranks(window.emeraldTrainers||[],window.emeraldStrength,3);
 if(!data)return;
 const signature=data.strength.map(x=>x.t.id+':'+x.score).join('|')+'|'+data.story.map(x=>x.t.id+':'+x.stage+':'+x.round+':'+!!x.t.champion).join('|');
 if(signature===lastTopSix)return;lastTopSix=signature;
 const build=(title,rows,kind)=>`<div class="elwHomeRankGroup"><h4>${title}</h4>${rows.map((x,i)=>`<div class="elwHomeRankLine"><b>${i+1}º</b><strong>${esc(x.t.name||'Treinador')}</strong><span>${kind==='power'?`${x.score.toLocaleString('pt-BR')} pts`:esc(x.chapter)}</span></div>`).join('')||'<p class="personalEmpty">Aguardando treinadores.</p>'}</div>`;
 target.innerHTML=build('⚡ Times mais fortes',data.strength,'power')+build('🧭 História mais avançada',data.story,'story')+'<button type="button" class="elwHomeFullRank" data-shortcut="ranking">Ver ranking completo</button>';
 target.querySelector('[data-shortcut="ranking"]')?.addEventListener('click',()=>window.emeraldShowPage?.('ranking'));
}
function render(){if(root.closest('.pageView')?.hidden)return;const bot=window.emeraldMyBot?.();if(!bot)return;
 const isSolo=window.emeraldOptions?.gameMode==='player';
 renderTopSix();
 if($('botSpeed')&&$('botSpeed')!==document.activeElement){const v=String(window.emeraldOptions?.speed||3);if($('botSpeed').value!==v)$('botSpeed').value=v;}
 const opponent=bot.battle?.enemy?.[bot.battle.enemyIndex];
 const own=bot.battle?(bot.team[bot.battle.ownIndex]?.hp>0?bot.team[bot.battle.ownIndex]:bot.team.find(x=>x.hp>0)):null;
 const decision=bot.userRivalChoice;
 const signature=[bot.stage,bot.location,bot.badges,bot.wins,bot.battle?.round,bot.battle?.kind,opponent?.hp,own?.hp,bot.queuedBattleAction?.name,bot.queuedBattleAction?.kind,bot.manualBattleEnabled,decision?.choice,decision?.trainingLeft,bot.team.map(m=>m.species+':'+m.level+':'+m.hp).join(','),bot.name,isSolo,bot.playerJourneyCommand,bot.playerCommandFeedback].join('|');
 if(signature===lastSignature)return;lastSignature=signature;
 $('botDisplayName').textContent=bot.name+(bot.starter?' · '+bot.starter:'');
 $('botStatus').textContent=bot.battle?'⚔️ Batalhando':decision?.choice==='pending'&&isSolo?'✦ Sua decisão':bot.healing?'🏥 Recuperando':'🌿 Explorando';
 $('botPosition').textContent='📍 '+(window.emeraldOfficialWorld?.label(bot.officialMap||bot.location)||bot.location);
 $('botBadges').textContent=(bot.badges||0)+'/8';$('botWins').textContent=bot.wins||0;$('botStage').textContent=(bot.stage||0)+1;
 $('botObjective').textContent='🎯 '+(bot.walkObjective||'Seguindo a história');
 $('botWarning').hidden=!bot.officialError;if(bot.officialError)$('botWarning').textContent='⚠️ '+bot.officialError;
 const inRivalDecision=isSolo&&!bot.battle&&decision?.choice==='pending';
 const decisionCard=$('botJourneyDecision');
 decisionCard.hidden=!isSolo||!!bot.battle||!!bot.healing||inRivalDecision;
 const currentCommand=bot.playerJourneyCommand;
 const prompt=$('botJourneyPrompt');
 if(prompt)prompt.textContent=currentCommand?'Executando sua escolha: '+({story:'continuar história',train:'treinar equipe',capture:'procurar Pokémon',battle:'desafiar treinador',explore:'explorar o mapa'})[currentCommand]+'.': 'Seu treinador espera por você. Escolha o que fazer agora; nada da campanha avança sozinho.';
 const msg=$('botJourneyMessage');if(msg)msg.textContent=bot.playerCommandFeedback||(!window.emeraldPaused?'Sua escolha vale para a próxima ação.':'Jogo pausado: retome a simulação para executar sua escolha.');
 for(const button of decisionCard.querySelectorAll('[data-journey-action]')){
  const action=button.dataset.journeyAction;
  button.disabled=!!currentCommand||(action!=='story'&&!bot.team.length)||(action==='capture'&&!(bot.bag?.Pokeball>0))||(action==='battle'&&(bot.stage<16||(bot.routeFights?.[bot.stage]||0)>=(window.emeraldOptions?.routeTrainers||2)));
 }
 const pending=isSolo&&!bot.battle&&decision?.choice==='pending';
 $('botRivalDecision').hidden=!pending;if(pending)$('botRivalTitle').textContent=decision.label+' espera por você!';
 $('botTrainingStatus').hidden=!(isSolo&&!bot.battle&&decision?.choice==='train');
 if(decision?.choice==='train')$('botTrainingText').textContent=`${decision.trainingLeft} treinamento(s) restantes. O bot só enfrentará o rival quando você autorizar.`;
 $('botBattleCard').hidden=!bot.battle;
 if(bot.battle){const b=bot.battle,manual=isSolo&&bot.manualBattleEnabled!==false;
  $('botAutoMoves').checked=!manual;$('botBattleHeading').textContent=(b.label||{rival:'Rival',gym:'Líder de ginásio',wild:'Pokémon selvagem',story:'Desafio da campanha'}[b.kind]||'Encontro')+' · Turno '+(b.round+1);
  function card(mon,title){if(!mon)return '<p>Carregando Pokémon...</p>';const percent=Math.max(0,Math.min(100,Math.round(100*mon.hp/Math.max(1,mon.maxHp))));return `${monArt(mon.species)}<b>${esc(mon.species)} · Nv.${mon.level}</b><small>${title} · HP ${mon.hp}/${mon.maxHp}</small><div class="personalHp"><span style="width:${percent}%"></span></div>`}
  $('botOpponent').innerHTML=card(opponent,'Adversário');$('botMyPokemon').innerHTML=card(own,'Seu Pokémon');
  $('botTurnTitle').textContent=manual?'Escolha o próximo golpe':'Sua IA está escolhendo os golpes';
  const disabled=!!bot.queuedBattleAction||!manual;
  let buttons=(own?.moves||[]).map(m=>`<button type="button" class="personalMove" data-action="attack" data-value="${esc(m)}" ${disabled||((own?.pp?.[m]??20)<=0)?'disabled':''}>⚔️ ${esc(m)} <small>${own?.pp?.[m]??20} PP</small></button>`);
  if(['wild','trainingWild','postgameWild'].includes(b.kind)&&bot.bag.Pokeball)buttons.push(`<button class="personalMove" data-action="capture" ${disabled?'disabled':''}>🔴 Pokébola · ${bot.bag.Pokeball}</button>`);
  if(bot.bag.Potion>0&&own?.hp<own?.maxHp)buttons.push(`<button class="personalMove" data-action="potion" ${disabled?'disabled':''}>🧴 Potion · ${bot.bag.Potion}</button>`);
  for(let i=0;i<bot.team.length;i++){const mon=bot.team[i];if(mon.hp>0&&i!==b.ownIndex)buttons.push(`<button class="personalMove" data-action="switch" data-value="${i}" ${disabled?'disabled':''}>🔁 ${esc(mon.species)} · Nv.${mon.level}</button>`)}
  $('botMoveChoices').innerHTML=buttons.join('');
  $('botActionMessage').textContent=bot.queuedBattleAction?'Ação escolhida. Executando o turno...':manual?'Escolha um movimento para avançar o combate.':'O combate acontece automaticamente.';
  $('botBattleLines').innerHTML=(b.history||[]).slice(0,10).map(x=>'<p>'+esc(x)+'</p>').join('')||'<p>O confronto está começando.</p>';
 }
 $('botPartyCount').textContent=bot.team.length+'/6';$('botRoster').innerHTML=bot.team.length?bot.team.map(mon=>{
  const pct=Math.max(0,Math.min(100,Math.round(100*mon.hp/Math.max(1,mon.maxHp))));return `<div class="personalPokemon">${monArt(mon.species)}<div><b>${esc(mon.species)} <small>Nv. ${mon.level}</small></b><div class="personalHp"><span style="width:${pct}%"></span></div><small>HP ${mon.hp}/${mon.maxHp} · ⚡ ${window.emeraldPower?.(mon)||0}</small><div class="personalKnownMoves" aria-label="Golpes conhecidos">${(mon.moves||[]).slice(0,4).map(move=>`<span>${esc(move)}</span>`).join('')||'<span>Ainda sem golpes registrados</span>'}</div>${window.EmeraldMonDetails?.html(mon)||''}</div></div>`;
 }).join(''):'<div class="personalEmpty">Seu primeiro parceiro aparece após o encontro com o Professor Birch.</div>';
 $('botMemo').innerHTML=(bot.mem||[]).slice(0,8).map(x=>'<p>'+esc(x)+'</p>').join('')||'<p>As decisões importantes serão registradas aqui.</p>';
 const preferences=pref();for(const [id,key] of [['botName','name'],['botStarter','starter'],['botGoal','goal'],['botStyle','style']]){const e=$(id);if(e&&e!==document.activeElement)e.value=preferences[key]}
}
$('botSpeed').onchange=e=>{window.emeraldSetOption?.('speed',Number(e.target.value));lastSignature='';render()};
$('botFollow').onclick=()=>{const bot=window.emeraldMyBot?.();if(!bot)return;window.emeraldSelectTrainer?.(bot.id);const focus=$('liveFocus');if(focus)focus.value='selected';$('personalWorldCard')?.scrollIntoView({behavior:'smooth',block:'start'});window.emeraldLiveDraw?.()};
$('botWorldZoom').onclick=()=>{const card=$('personalWorldCard'),large=card.classList.toggle('expanded');$('botWorldZoom').textContent=large?'🔍 Reduzir':'🗺️ Ampliar';$('botWorldZoom').setAttribute('aria-pressed',String(large));window.emeraldLiveDraw?.()};
$('botSetupOpen').onclick=()=>window.emeraldOpenWorldControl?.();
$('botApply').onclick=()=>{const b=window.emeraldMyBot?.(),old=b?.starter;const preferences=window.emeraldSetMyBotSettings?.({name:$('botName').value,starter:$('botStarter').value,goal:$('botGoal').value,style:$('botStyle').value});$('botNote').textContent=old&&preferences?.starter!==old?'Preferências salvas. O inicial que você já recebeu não muda.':'Suas preferências foram salvas.';lastSignature='';render()};
root.addEventListener('click',e=>{
 const journey=e.target.closest('[data-journey-action]');
 if(journey){const result=window.emeraldChooseJourneyAction?.(journey.dataset.journeyAction);
  $('botJourneyMessage').textContent=result?.ok?'Decisão registrada. Seu treinador vai executar esta ação.':result?.error||'Ação indisponível.';
  lastSignature='';render();return;
 }
 const rival=e.target.closest('[data-rival-choice]');if(rival){const result=window.emeraldChooseRivalPath?.(rival.dataset.rivalChoice);if(!result?.ok)$('botNote').textContent=result?.error||'Decisão indisponível';lastSignature='';render();return}
 const action=e.target.closest('#botMoveChoices [data-action]');if(action){const result=window.emeraldMyBotBattleAction?.(action.dataset.action,action.dataset.value);$('botActionMessage').textContent=result?.ok?'Ação escolhida. Executando o turno...':result?.error||'Ação indisponível';lastSignature='';render()}
});
$('botAutoMoves').onchange=e=>{window.emeraldMyBotBattleMode?.(!e.target.checked);lastSignature='';render()};
window.emeraldRefreshMyBot=()=>{lastSignature='';render()};
render();setInterval(render,450);setInterval(renderTopSix,2000);
})();
