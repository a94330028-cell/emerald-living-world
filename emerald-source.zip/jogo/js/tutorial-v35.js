/* Emerald Living World 3.5 — tutorial de primeiros passos. UI-only; saves intact. */
(()=>{'use strict';
const $=id=>document.getElementById(id);
const dialog=$('guideDialog'); if(!dialog)return;
const doneKey='elw_onboarding_v35_completed';
const steps=[
 {icon:'🌿',heading:'Bem-vindo ao Emerald Living World',name:'Conheça a aventura',description:'Aqui você pode cuidar do seu próprio treinador ou acompanhar um mundo vivo de treinadores controlados por IA.',items:[
  ['🧢 Meu treinador','Você escolhe os próximos passos do seu personagem e os golpes durante as batalhas manuais.'],
  ['👁️ Assistir às IAs','Observe outros treinadores progredindo, capturando Pokémon e disputando ginásios.'],
  ['💾 Progresso','O jogo salva no navegador. Continue uma jornada existente para manter seus Pokémon e insígnias.']],tip:'Você não precisa criar uma conta para experimentar o modo local.',target:'landing'},
 {icon:'🔴',heading:'Escolha seu inicial e comece',name:'Primeiros passos',description:'Na tela inicial, selecione seu primeiro Pokémon e depois escolha como prefere explorar Hoenn.',items:[
  ['1. Escolha seu inicial','Selecione o Pokémon que deseja levar na sua jornada.'],
  ['2. Selecione o modo','Toque em “Meu treinador” para jogar com decisões manuais ou “Assistir às IAs” para observar.'],
  ['3. Continue sem perder nada','Use “Continuar Jornada” se já começou; “Nova Jornada” pode reiniciar a simulação.']],tip:'Antes de reiniciar seu mundo, exporte uma cópia do save em Recuperação.',target:'landing'},
 {icon:'🗺️',heading:'Explore o mapa de Hoenn',name:'Mapa e câmera',description:'O mapa mostra onde os treinadores estão e o que acontece durante a aventura.',items:[
  ['👁️ Seguir','Use “Seguir” para acompanhar o treinador selecionado com a câmera.'],
  ['🌳 Terreno e caminhos','Rotas, cidades, interiores, obstáculos e água têm regras diferentes de acesso.'],
  ['⏯️ Controlar o ritmo','Pause, avance um evento ou ajuste a velocidade. A velocidade pode ser limitada no celular.']],tip:'Exploração e movimentação em algumas áreas ainda são experimentais.',target:'jogo'},
 {icon:'🧭',heading:'Você decide o destino do treinador',name:'Suas decisões',description:'No modo “Meu treinador”, o painel “Qual vai ser seu próximo passo?” permite escolher a próxima atividade.',items:[
  ['📜 Seguir história','Avance nos acontecimentos principais da campanha e nos desafios de Hoenn.'],
  ['💪 Treinar ou 🔴 procurar Pokémon','Fortaleça a equipe ou busque encontros para capturar novos parceiros.'],
  ['🗺️ Explorar ou ⚔️ desafiar','Visite novos lugares ou escolha um desafio quando ele estiver disponível.']],tip:'Durante uma batalha manual, escolha ataques, trocas ou itens disponíveis. Algumas opções exigem condições ou recursos.',target:'jogo'},
 {icon:'🎒',heading:'Cuide do seu time Pokémon',name:'Equipe e batalhas',description:'Um treinador pode manter até seis Pokémon na equipe. Um time equilibrado faz diferença nos confrontos.',items:[
  ['📕 Pokédex','Confira espécies, tipos, atributos e informações dos seus Pokémon.'],
  ['❤️ HP, níveis e golpes','Acompanhe a vida e os ataques. Níveis e estratégia afetam o desempenho.'],
  ['📦 Reservas no PC','Use as opções de equipe e PC para consultar Pokémon fora dos seis espaços ativos.']],tip:'Ter um Pokémon com nível maior nem sempre garante a vitória: golpes e tipos também importam.',target:'pokedex'},
 {icon:'🏆',heading:'Entenda os dois rankings',name:'Classificações',description:'A aba Rank compara treinadores da simulação atual, não apenas Pokémon individuais.',items:[
  ['⚡ Times mais fortes','Classificação pela força calculada da equipe ativa de cada treinador.'],
  ['🧭 História mais avançada','Mostra quem chegou mais longe na campanha de Hoenn, incluindo Liga e campeões.'],
  ['🔄 Acompanhe a evolução','As posições podem mudar conforme as jornadas e equipes avançam.']],tip:'O Top Mundial é um recurso separado e depende da configuração do serviço online.',target:'ranking'},
 {icon:'📖',heading:'Pronto para começar!',name:'Saves e ajuda',description:'Agora você sabe onde encontrar as principais ferramentas da sua jornada.',items:[
  ['💾 Faça backups','Abra Recuperação e exporte seu save antes de trocar de aparelho ou reiniciar a simulação.'],
  ['🌙 Personalize o jogo','Altere tema escuro, qualidade gráfica e outras opções nas configurações.'],
  ['💬 Comunidade e suporte','Use o Discord oficial ou o chat, quando o serviço estiver habilitado e sua conta estiver conectada.']],tip:'Você pode abrir este tutorial novamente pelo botão “📖 Como jogar”, a qualquer momento.',target:'recuperacao'}
];
let index=0;
const banner=$('elwLearnBanner');
function storageGet(){try{return localStorage.getItem(doneKey)==='1'}catch{return false}}
function storageSet(){try{localStorage.setItem(doneKey,'1')}catch{}}
function updateBanner(){if(banner)banner.hidden=storageGet()}
function complete(){storageSet();updateBanner();dialog.close()}
function open(){index=0;if(!dialog.open)dialog.showModal();render()}
function close(){complete()}
function itemRow(title,description){const box=document.createElement('div');box.className='elw-tutorial-item';const a=document.createElement('strong');a.textContent=title;const b=document.createElement('p');b.textContent=description;box.append(a,b);return box}
function render(){const s=steps[index];
 $('elwTutorialIcon').textContent=s.icon;
 $('guideTitle').textContent=s.heading;
 $('guideDescription').textContent=s.description;
 $('elwTutorialStepLabel').textContent=`PASSO ${index+1} DE ${steps.length}`;
 $('elwTutorialStepName').textContent=s.name;
 $('elwTutorialProgress').setAttribute('aria-valuenow',String(index+1));
 $('elwTutorialProgressFill').style.width=((index+1)/steps.length*100)+'%';
 const items=$('elwTutorialItems');items.replaceChildren(...s.items.map(item=>itemRow(...item)));
 $('elwTutorialTip').textContent='💡 '+s.tip;
 $('elwTutorialBack').disabled=index===0;
 $('elwTutorialNext').textContent=index===steps.length-1?'✓ Concluir tutorial':'Próximo →';
 $('elwTutorialSkip').textContent=index===steps.length-1?'Fechar':'Pular tutorial';
 const goto=$('elwTutorialGo');
 const onLanding=document.body.classList.contains('landing-active');
 goto.hidden=s.target!=='landing'&&onLanding;
 goto.textContent=s.target==='landing'?'Voltar à tela inicial ↗':{
   jogo:'Abrir o Jogo ↗',pokedex:'Abrir a Pokédex ↗',ranking:'Abrir o Rank ↗',recuperacao:'Abrir Recuperação ↗'
 }[s.target];
 const body=dialog.querySelector('.elw-tutorial-body');body.scrollTop=0;
 if(dialog.open)$('guideTitle').focus({preventScroll:true});
}
$('elwTutorialNext').addEventListener('click',()=>{if(index===steps.length-1)complete();else{index++;render()}});
$('elwTutorialBack').addEventListener('click',()=>{if(index>0){index--;render()}});
$('elwTutorialSkip').addEventListener('click',close);
$('closeGuide').onclick=close;
$('openGuide').onclick=open;
document.querySelectorAll('[data-guide-open]').forEach(el=>el.addEventListener('click',open));
// The header help button is hidden on mobile: expose the same tutorial in the pages drawer.
const drawer=document.getElementById('navDrawer');
const drawerSheet=drawer?.querySelector('.drawerSheet');
if(drawerSheet){
 const help=document.createElement('button');help.type='button';help.className='elw-drawer-guide';
 help.textContent='📖 Como jogar · Guia para iniciantes';
 const first=drawerSheet.querySelector('.secondaryGroup');
 if(first)first.before(help);else drawerSheet.append(help);
 help.addEventListener('click',()=>{drawer.hidden=true;document.body.classList.remove('drawerOpen');open()});
}

$('elwTutorialGo').addEventListener('click',()=>{
 const target=steps[index].target;
 if(target==='landing')window.emeraldShowEntry?.();
 else window.emeraldShowPage?.(target);
 complete();
});
dialog.addEventListener('close',()=>{if(!storageGet())storageSet();updateBanner()});
dialog.addEventListener('keydown',e=>{
 if(e.target.closest('button,input,textarea,select'))return;
 if(e.key==='ArrowRight'&&index<steps.length-1){e.preventDefault();index++;render()}
 if(e.key==='ArrowLeft'&&index>0){e.preventDefault();index--;render()}
});
updateBanner();render();
window.EmeraldTutorial={open,steps:steps.length};
})();
