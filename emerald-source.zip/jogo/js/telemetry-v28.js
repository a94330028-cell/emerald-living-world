/* Estatísticas consentidas. Nenhuma requisição é enviada antes do opt-in. */
(()=>{'use strict';
const cfg=window.EMERALD_CLOUD_CONFIG||{};
const base=String(cfg.supabaseUrl||'').replace(/\/+$/,'');
const key=String(cfg.supabaseAnonKey||'');
const ready=/^https:\/\/[^/]+\.supabase\.co$/.test(base)&&key.length>15;
const CONSENT='elw_metrics_consent_v1',VISITOR='elw_metrics_visitor_v1',SESSION='elw_metrics_session_v1';
const uuid=()=>typeof crypto!=='undefined'?crypto.randomUUID?.()||null:null;
const valid=v=>/^[0-9a-f]{8}-[0-9a-f-]{27,}$/i.test(v||'');
const allowed=new Set(['session_play','campaign_start','starter_choose','pokemon_capture','gym_win','gym_loss','elite_four_win','campaign_complete','save']);
let active=false,sent=0;
function storage(kind='local'){try{return kind==='session'?sessionStorage:localStorage}catch{return null}}
function read(k,kind='local'){try{return storage(kind)?.getItem(k)||null}catch{return null}}
function write(k,v,kind='local'){try{storage(kind)?.setItem(k,v)}catch{}}
function path(){return location.pathname+(location.hash||'').slice(0,44)}
function enabled(){return read(CONSENT)==='yes'&&ready}
function identity(){let visitorId=read(VISITOR),sessionId=read(SESSION,'session');
 if(!valid(visitorId)){visitorId=uuid();if(visitorId)write(VISITOR,visitorId)}
 if(!valid(sessionId)){sessionId=uuid();if(sessionId)write(SESSION,sessionId,'session')}
 return {visitorId,sessionId};
}
function token(){try{const session=JSON.parse(read('elw_cloud_session_v1')||'null');if(session?.access_token&&Number(session.expires_at)*1000>Date.now()+60000)return session.access_token}catch{}return key}
function send(kind,more={},keepalive=false){
 if(!enabled())return false;const ids=identity();if(!ids.visitorId||!ids.sessionId)return false;
 const payload=JSON.stringify({kind,...ids,page:path(),...more});
 fetch(base+'/functions/v1/telemetry',{method:'POST',keepalive,headers:{'Content-Type':'application/json','apikey':key,'Authorization':'Bearer '+token()},body:payload,cache:'no-store'}).catch(()=>{});
 sent++;return true;
}
function start(){if(active||!enabled())return;active=true;send('open')}
function event(type,detail=''){
 if(!allowed.has(type)||!enabled())return false;
 if(type==='save'&&Date.now()-(event.lastSave||0)<120000)return false;
 if(type==='save')event.lastSave=Date.now();
 start();return send('event',{eventType:type,detail:String(detail||'').slice(0,42)});
}
function stop(){if(active&&enabled())send('close',{},true);active=false}
function status(){const label=document.getElementById('elwMetricsStatus'),yes=document.getElementById('elwMetricsYes'),no=document.getElementById('elwMetricsNo');
 if(label)label.textContent=read(CONSENT)==='yes'?ready?'Coleta opcional ativada neste dispositivo.':'Consentimento salvo; Supabase ainda não configurado.':read(CONSENT)==='no'?'Coleta desativada.':'Nenhuma estatística pessoal é enviada sem sua autorização.';
 if(yes)yes.disabled=read(CONSENT)==='yes';if(no)no.disabled=read(CONSENT)==='no';
}
document.addEventListener('click',e=>{
 if(e.target.closest('#elwMetricsYes')){write(CONSENT,'yes');start();status()}
 if(e.target.closest('#elwMetricsNo')){stop();write(CONSENT,'no');try{storage()?.removeItem(VISITOR);storage('session')?.removeItem(SESSION)}catch{}status()}
});
window.addEventListener('hashchange',()=>{if(active)send('heartbeat')});
// Erros genéricos; nunca transmitir mensagens de exceção com dados privados.
window.addEventListener('error',()=>{if(active)send('error',{message:'Falha JavaScript no jogo'})});
window.addEventListener('unhandledrejection',()=>{if(active)send('error',{message:'Operacao JavaScript rejeitada'})});
window.addEventListener('pagehide',stop);
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')start()});
setInterval(()=>{if(!document.hidden&&active)send('heartbeat')},60000);
window.ELWTelemetry={event,enabled,start,debug:()=>({ready,consent:read(CONSENT)||'unset',active,sent})};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>{status();start()});else{status();start()}
})();
