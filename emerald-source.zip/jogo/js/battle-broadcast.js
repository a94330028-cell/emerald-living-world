/* Batalhas das IAs ao vivo e combates recém-encerrados. A tela é espectadora:
   comandos de combate continuam reservados ao modo Jogador. */
(()=>{'use strict';
const root=document.getElementById('liveBattleCinema');if(!root)return;
let watch=null,open=true,last='',pinned=false;
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const percent=m=>Math.max(0,Math.min(100,Math.round((m?.hp||0)/Math.max(1,m?.maxHp||1)*100)));
const picture=(m,position)=>m?`<div class="arenaPokemon ${position}"><div class="arenaMonArt"><img loading="lazy" src="assets/pokemon_fit/${encodeURIComponent(m.species.toLowerCase())}.png" alt="${escape(m.species)}" onerror="if(!this.dataset.fallback){this.dataset.fallback=1;this.src='assets/pokemon_fit/${encodeURIComponent(m.species.toLowerCase())}.gif'}else if(!this.dataset.official){this.dataset.official=1;this.src='https://raw.githubusercontent.com/pret/pokeemerald/master/graphics/pokemon/${encodeURIComponent(m.species.toLowerCase())}/front.png'}else{this.onerror=null;this.style.display='none'}"></div><div class="arenaStats"><b>${escape(m.species)}</b><small>Nv. ${m.level||'?'} · ${m.hp??0}/${m.maxHp||1} HP</small><div class="arenaHp" aria-label="${percent(m)} por cento de HP"><span style="width:${percent(m)}%;background:${percent(m)<25?'#ff8686':percent(m)<55?'#f4cb71':'#78e9aa'}"></span></div></div></div>`:'<div class="arenaWaiting">Aguardando Pokémon...</div>';
const battleKind={wild:'Selvagem',gym:'Ginásio',gymTrainer:'Treinador do ginásio',routeTrainer:'Treinador da rota',rival:'Rival',rescue:'Resgate',elite:'Liga Pokémon',ai:'Duelo entre IAs'};
function snapshot(t){const b=t.battle;return {id:t.id,name:t.name,kind:b.kind,round:b.round,place:t.officialMap||t.location,
 own:t.team?.[b.ownIndex],foe:b.enemy?.[b.enemyIndex],lines:b.history||[],won:null};}
function render(){if(document.hidden)return;
 const trainers=window.emeraldTrainers||[];
 const live=trainers.filter(t=>t.battle&&t.team?.length).map(snapshot);
 const archive=window.emeraldBattleArchive||[];
 const candidates=[...live,...archive.slice(0,6)];
 if(!candidates.length){root.innerHTML=`<div class="arenaHeading"><span>⚔️ ARENA DE HOENN</span><strong>Transmissão das batalhas</strong></div><p class="arenaEmpty">Os bots ainda não começaram uma batalha. Quando uma luta iniciar, ela aparecerá aqui; os duelos encerrados ficam no histórico recente.</p>`;last='none';return}
 if(!pinned&&live.length){const active=live[0];watch=active.id+':live'}
 if(watch==null||!candidates.some(b=>(b.id+':'+(b.tick??'live'))===watch)){pinned=false;
  const b=live[0]||archive[0];watch=b.id+':'+(b.tick??'live');
 }
 const current=candidates.find(b=>(b.id+':'+(b.tick??'live'))===watch)||candidates[0];
 const signature=JSON.stringify([open,watch,candidates.map(x=>[x.id,x.tick??'live',x.round,x.own?.hp,x.foe?.hp]),current.lines?.slice(0,4)]);
 if(signature===last)return;last=signature;
 const name=window.emeraldOfficialWorld?.label?.(current.place)||current.place;
 root.innerHTML=`<div class="arenaHeading"><div><span>⚔️ ARENA DE HOENN</span><strong>Batalhas ao vivo <small>${live.length} acontecendo</small></strong></div><button type="button" class="arenaToggle" data-arena-toggle="1" aria-expanded="${open}">${open?'Ocultar':'Assistir'} ${open?'⌃':'⌄'}</button></div>
 ${open?`<div class="arenaBroadcast"><div class="arenaChips">${candidates.slice(0,8).map(b=>`<button type="button" data-battle-watch="${escape(b.id+':'+(b.tick??'live'))}" class="${watch===b.id+':'+(b.tick??'live')?'active':''}">${b.tick===undefined?'●':'◌'} ${escape(b.name)} <small>${escape(battleKind[b.kind]||'Duelo')}</small></button>`).join('')}</div>
 <div class="arenaSpotlight"><div class="arenaTopBar"><b>${escape(current.name)}</b><span>${current.won===null?'● AO VIVO':current.won?'✓ Vitória':'✕ Derrota'} • Turno ${current.round||0}</span></div><small class="arenaPlace">${escape(name||'Hoenn')} · ${escape(battleKind[current.kind]||'Batalha')}</small>
 <div class="arenaStage">${picture(current.foe,'enemy')}<span class="arenaVs">VS</span>${picture(current.own,'own')}</div>
 <div class="arenaMoves"><strong>📣 Últimos acontecimentos</strong>${current.lines?.length?current.lines.slice(0,5).map((s,i)=>`<p class="${i===0?'latest':''}">${escape(s)}</p>`).join(''):'<p>O primeiro turno está começando.</p>'}</div>
 ${current.won===null?`<button type="button" class="arenaFollow" data-arena-focus="${current.id}">👁️ Seguir ${escape(current.name)} no mapa</button>`:''}</div></div>`:''}`;
}
root.addEventListener('click',e=>{
 const toggle=e.target.closest('[data-arena-toggle]');if(toggle){open=!open;last='';render();return}
 const button=e.target.closest('[data-battle-watch]');if(button){watch=button.dataset.battleWatch;pinned=true;last='';render();return}
 const focus=e.target.closest('[data-arena-focus]');if(focus){window.emeraldSelectTrainer?.(Number(focus.dataset.arenaFocus));document.getElementById('liveWorld')?.scrollIntoView?.({behavior:'smooth',block:'center'});}
});
setInterval(render,850);render();
})();