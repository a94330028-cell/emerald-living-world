/* Emerald Living V2 — Roteiro de Hoenn com 8 capítulos.
   Baseado no guia fornecido pelo autor do projeto. Simulação adaptada, não ROM.
   Cada missão tem um identificador estável e pode ser exibida no mapa oficial. */
(()=>{'use strict';
const phases=[
 {title:'O começo em Hoenn',subtitle:'Littleroot → Rustboro • 1ª insígnia',icon:'🌱'},
 {title:'A entrega da Devon',subtitle:'Rustboro → Dewford • 2ª insígnia',icon:'🌊'},
 {title:'À sombra da Cycling Road',subtitle:'Slateport → Mauville • 3ª insígnia',icon:'⚡'},
 {title:'O vulcão desperta',subtitle:'Mt. Chimney → Lavaridge • 4ª insígnia',icon:'🌋'},
 {title:'Família e céu aberto',subtitle:'Petalburg → Fortree • 5ª e 6ª insígnias',icon:'🪽'},
 {title:'Orbes e esconderijos',subtitle:'Mt. Pyre → Mossdeep • 7ª insígnia',icon:'🌙'},
 {title:'A crise dos lendários',subtitle:'O fundo do mar → Sootopolis • 8ª insígnia',icon:'🐉'},
 {title:'Rumo ao título',subtitle:'Victory Road → Liga Pokémon',icon:'🏆'}
];
const steps=[];let ch=-1;
function phase(){ch++}
function add(kind,place,title,extra={}){steps.push({id:'c'+(ch+1)+'-'+String(steps.length+1).padStart(3,'0'),chapter:ch+1,kind,place,title,...extra});}
const story=(place,title,extra={})=>add('story',place,title,extra);
const battle=(place,name,roster,extra={})=>add('trainer',place,`Batalha: ${name}`,{name,roster,...extra});
const wild=(place,title,pool,level)=>add('wild',place,title,{pool,level});
const gym=(place,name,roster,badge,map)=>add('gym',place,`Líder ${name}`,{name,roster,badge,map});
const league=(name,roster)=>add('league','Liga Pokémon',`Elite e campeão: ${name}`,{name,roster,map:'EverGrandeCity_PokemonLeague_1F'});
phase();
story('Littleroot Town','Chegada: caminhão, casa e relógio',{map:'LittlerootTown_BrendansHouse_1F'});
story('Littleroot Town','Conhecer o quarto do rival e investigar a Pokébola',{map:'LittlerootTown_MaysHouse_2F'});
wild('Route 101','Ajudar o Professor Birch',['Zigzagoon'],2);
story('Littleroot Town','Retornar ao laboratório',{map:'LittlerootTown_ProfessorBirchsLab'});
story('Oldale Town','Conhecer o Centro Pokémon e o mercado',{map:'OldaleTown_PokemonCenter_1F'});
battle('Route 103','May / Brendan',[['Wingull',5],['RIVAL_STARTER',6]],{rival:true});
story('Littleroot Town','Receber Pokédex e Pokébolas no laboratório',{map:'LittlerootTown_ProfessorBirchsLab',reward:{Pokeball:5}});
story('Littleroot Town','Despedir-se e seguir para Oldale');
battle('Route 102','Youngster Calvin',[['Zigzagoon',4],['Poochyena',4]]);
battle('Route 102','Bug Catcher Rick',[['Wurmple',3],['Wurmple',3],['Silcoon',4]]);
battle('Route 102','Youngster Allen',[['Zigzagoon',3],['Taillow',5]]);
battle('Route 102','Lass Tiana',[['Zigzagoon',4],['Zigzagoon',4]]);
story('Petalburg City','Falar com Norman e ajudar Wally',{map:'PetalburgCity_Gym'});
story('Route 104','Chegar à entrada de Petalburg Woods');
battle('Petalburg Woods','Bug Catcher Lyle',[['Wurmple',3],['Silcoon',3],['Cascoon',3]]);
battle('Petalburg Woods','Bug Catcher James',[['Nincada',6]]);
battle('Petalburg Woods','Team Aqua Grunt',[['Poochyena',9]]);
story('Route 104','Atravessar a ponte e seguir ao norte');
battle('Rustboro City','School Kid Josh',[['Geodude',10],['Geodude',10]],{map:'RustboroCity_Gym'});
battle('Rustboro City','School Kid Tommy',[['Geodude',11]],{map:'RustboroCity_Gym'});
battle('Rustboro City','Hiker Marc',[['Geodude',8],['Geodude',8],['Geodude',8]],{map:'RustboroCity_Gym'});
gym('Rustboro City','Roxanne',[['Geodude',12],['Geodude',12],['Nosepass',15]],'Pedra','RustboroCity_Gym');
phase();
battle('Route 116','Youngster Joey',[['Zigzagoon',11]]);
battle('Route 116','Hiker Clark',[['Geodude',11],['Onix',11]]);
battle('Route 116','Youngster Jose',[['Zigzagoon',10],['Taillow',10]]);
battle('Route 116','Lass Karen',[['Whismur',11]]);
battle('Route 116','Bug Catcher Jerry',[['Nincada',10],['Nincada',10]]);
battle('Route 116','School Kid Johnson',[['Abra',10],['Machop',12]]);
battle('Route 116','Hiker Dudley',[['Geodude',10],['Geodude',10],['Geodude',10]]);
battle('Rusturf Tunnel','Team Aqua Grunt',[['Poochyena',11]]);
story('Rustboro City','Recuperar os bens da Devon e receber o PokéNav');
story('Route 104','Conversar com Mr. Briney e navegar até Dewford',{map:'Route104_MrBrineysHouse'});
battle('Dewford Town','Black Belt Takao',[['Machop',14]],{map:'DewfordTown_Gym'});
battle('Dewford Town','Battle Girl Laura',[['Meditite',14]],{map:'DewfordTown_Gym'});
battle('Dewford Town','Black Belt Mitsuru',[['Machop',13],['Machop',13]],{map:'DewfordTown_Gym'});
battle('Dewford Town','Battle Girl Jocelyn',[['Meditite',13],['Meditite',13]],{map:'DewfordTown_Gym'});
gym('Dewford Town','Brawly',[['Machop',16],['Meditite',16],['Makuhita',19]],'Punho','DewfordTown_Gym');
story('Granite Cave','Receber Flash e entregar a carta a Steven',{map:'GraniteCave_1F'});
story('Route 109','Embarcar rumo à praia de Slateport');
phase();
story('Slateport City','Localizar o Museu Oceânico',{map:'SlateportCity_OceanicMuseum_1F'});
battle('Slateport City','Team Aqua Grunt',[['Carvanha',15],['Zubat',15]],{map:'SlateportCity_OceanicMuseum_1F'});
story('Slateport City','Entregar a encomenda ao Capitão Stern');
battle('Route 110','Pokéfan Isabel',[['Pikachu',15]]);
battle('Route 110','Collector Edwin',[['Electrike',14],['Voltorb',14]]);
battle('Route 110','Collector Kaleb',[['Plusle',14],['Minun',14]]);
battle('Route 110','Lass Haley',[['Oddish',13],['Zigzagoon',13],['Poochyena',13]]);
battle('Route 110','Psychic Edward',[['Abra',12],['Ralts',12]]);
battle('Route 110','Psychic Jaclyn',[['Natu',13]]);
battle('Route 110','May / Brendan',[['Slugma',18],['RIVAL_MIDDLE',18],['RIVAL_EVOLVED',20]],{rival:true});
story('Mauville City','Encontrar Wally perto do ginásio');
battle('Mauville City','Wally',[['Ralts',16]]);
story('Mauville City','Obter Rock Smash e chegar ao ginásio',{map:'MauvilleCity_Gym'});
battle('Mauville City','Guitarist Kirk',[['Voltorb',18],['Voltorb',18],['Voltorb',18]],{map:'MauvilleCity_Gym'});
battle('Mauville City','Youngster Ben',[['Electrike',19]],{map:'MauvilleCity_Gym'});
battle('Mauville City','School Kid Shawn',[['Electrike',17],['Voltorb',17],['Magnemite',17]],{map:'MauvilleCity_Gym'});
battle('Mauville City','Guitarist Vivian',[['Electrike',18],['Voltorb',18]],{map:'MauvilleCity_Gym'});
gym('Mauville City','Wattson',[['Magnemite',22],['Voltorb',20],['Magneton',23],['Electrike',20]],'Dínamo','MauvilleCity_Gym');
phase();
story('Route 117','Visitar Verdanturf Town e liberar Rusturf Tunnel');
story('Route 111','Seguir ao norte passando pelas montanhas');
battle('Route 111','Hiker Brice',[['Geodude',18],['Machop',18]]);
battle('Route 112','Hiker Trent',[['Numel',17],['Machop',17]]);
story('Fiery Path','Cruzar o túnel vulcânico');
battle('Route 113','Youngster Lawrence',[['Zigzagoon',18],['Aron',19]]);
battle('Route 113','Ninja Boy Lung',[['Nincada',19],['Zubat',19]]);
story('Fallarbor Town','Investigar o desaparecimento do Professor Cozmo');
story('Route 114','Seguir para Meteor Falls');
battle('Route 114','Hiker Wayne',[['Geodude',18],['Machop',19]]);
story('Meteor Falls','Descobrir os planos da Team Magma',{map:'MeteorFalls_1F_1R'});
story('Route 112','Subir ao Mt. Chimney pelo Cable Car',{map:'Route112_CableCarStation'});
battle('Mt. Chimney','Team Magma Grunt',[['Numel',23],['Poochyena',23]]);
battle('Mt. Chimney','Maxie',[['Mightyena',24],['Golbat',24],['Camerupt',25]]);
story('Jagged Pass','Descer o vulcão até Lavaridge');
battle('Lavaridge Town','Kindler Jace',[['Numel',23],['Slugma',23]],{map:'LavaridgeTown_Gym_1F'});
battle('Lavaridge Town','Kindler Andy',[['Slugma',24]],{map:'LavaridgeTown_Gym_1F'});
gym('Lavaridge Town','Flannery',[['Slugma',26],['Slugma',26],['Camerupt',28],['Magcargo',28]],'Calor','LavaridgeTown_Gym_1F');
story('Lavaridge Town','Receber Go-Goggles de May / Brendan');
phase();
story('Petalburg City','Retornar para desafiar seu pai');
battle('Petalburg City','Cooltrainer Randall',[['Linoone',27]],{map:'PetalburgCity_Gym'});
battle('Petalburg City','Cooltrainer Mary',[['Zangoose',27]],{map:'PetalburgCity_Gym'});
battle('Petalburg City','Cooltrainer Alex',[['Vigoroth',27]],{map:'PetalburgCity_Gym'});
gym('Petalburg City','Norman',[['Spinda',27],['Vigoroth',27],['Linoone',29],['Slaking',31]],'Balanço','PetalburgCity_Gym');
story('Petalburg City','Receber Surf com a família de Wally');
story('Route 118','Cruzar o rio usando Surf');
story('Route 119','Seguir pela chuva até o Instituto Meteorológico');
battle('Route 119','Team Aqua Grunt',[['Poochyena',27],['Zubat',27]],{map:'Route119_WeatherInstitute_1F'});
story('Route 119','Salvar o Instituto Meteorológico e receber Castform',{map:'Route119_WeatherInstitute_1F',rewardMon:['Castform',25]});
battle('Route 119','May / Brendan',[['Slugma',29],['RIVAL_MIDDLE',29],['RIVAL_EVOLVED',31]],{rival:true});
story('Fortree City','Seguir a Route 120 atrás do Devon Scope');
story('Route 120','Encontrar Steven e revelar o Kecleon invisível');
battle('Fortree City','Bird Keeper Jared',[['Swellow',29],['Pelipper',30]],{map:'FortreeCity_Gym'});
battle('Fortree City','Bird Keeper Edward',[['Skarmory',31]],{map:'FortreeCity_Gym'});
gym('Fortree City','Winona',[['Swellow',33],['Pelipper',33],['Skarmory',32],['Altaria',35],['Tropius',33]],'Pena','FortreeCity_Gym');
phase();
story('Route 121','Avançar para Lilycove pelas rotas do leste');
story('Mt. Pyre','Testemunhar o roubo do orbe sagrado',{map:'MtPyre_1F'});
battle('Mt. Pyre','Team Magma Grunt',[['Mightyena',32],['Golbat',32]]);
story('Slateport City','Assistir à entrevista de Stern e ao roubo do submarino');
story('Jagged Pass','Investigar a entrada do esconderijo Magma');
battle('Magma Hideout','Maxie',[['Mightyena',34],['Golbat',34],['Camerupt',36]],{map:'MagmaHideout_1F'});
story('Lilycove City','Encontrar o esconderijo da Team Aqua');
battle('Aqua Hideout','Team Aqua Admin',[['Golbat',35],['Sharpedo',36]],{map:'AquaHideout_1F'});
story('Route 124','Navegar para Mossdeep City');
battle('Mossdeep City','Psychic Preston',[['Kadabra',35],['Solrock',35]],{map:'MossdeepCity_Gym'});
battle('Mossdeep City','Psychic Maura',[['Lunatone',36]],{map:'MossdeepCity_Gym'});
gym('Mossdeep City','Tate & Liza',[['Solrock',42],['Lunatone',42]],'Mente','MossdeepCity_Gym');
phase();
story('Mossdeep City','Defender o Centro Espacial com Steven');
battle('Mossdeep City','Team Magma Grunt',[['Mightyena',37],['Golbat',37]]);
story('Mossdeep City','Receber Dive na casa de Steven');
story('Route 128','Encontrar a entrada submarina da Seafloor Cavern');
battle('Seafloor Cavern','Archie',[['Mightyena',38],['Golbat',38],['Sharpedo',41]],{map:'SeafloorCavern_Entrance'});
story('Sootopolis City','Presenciar a crise de Groudon e Kyogre');
story('Sky Pillar','Despertar Rayquaza no topo',{map:'SkyPillar_Entrance'});
story('Sootopolis City','Assistir à intervenção de Rayquaza e receber Waterfall');
battle('Sootopolis City','Cooltrainer Crissy',[['Golduck',39],['Luvdisc',39]],{map:'SootopolisCity_Gym_1F'});
battle('Sootopolis City','Cooltrainer Easton',[['Azumarill',40]],{map:'SootopolisCity_Gym_1F'});
gym('Sootopolis City','Juan',[['Luvdisc',41],['Whiscash',41],['Sealeo',43],['Crawdaunt',43],['Kingdra',46]],'Chuva','SootopolisCity_Gym_1F');
phase();
story('Ever Grande City','Subir a cachoeira e chegar a Victory Road');
battle('Victory Road','Cooltrainer Albert',[['Golbat',43],['Mawile',43]],{map:'VictoryRoad_1F'});
battle('Victory Road','Cooltrainer Edgar',[['Machoke',43],['Lairon',43]],{map:'VictoryRoad_1F'});
story('Victory Road','Atravessar a caverna com os HMs necessários',{map:'VictoryRoad_1F'});
battle('Victory Road','Wally',[['Altaria',44],['Delcatty',43],['Magneton',41],['Roselia',43],['Gardevoir',45]],{map:'VictoryRoad_1F'});
story('Liga Pokémon','Preparar a equipe para a Elite dos Quatro');
league('Sidney',[['Mightyena',46],['Shiftry',48],['Cacturne',46],['Sharpedo',48],['Absol',49]]);
league('Phoebe',[['Dusclops',48],['Banette',49],['Sableye',50],['Banette',49],['Dusclops',51]]);
league('Glacia',[['Glalie',50],['Sealeo',50],['Sealeo',52],['Glalie',52],['Walrein',53]]);
league('Drake',[['Shelgon',52],['Altaria',53],['Kingdra',53],['Flygon',53],['Salamence',55]]);
league('Wallace',[['Wailord',57],['Tentacruel',55],['Ludicolo',56],['Gyarados',56],['Whiscash',56],['Milotic',58]]);
window.EMERALD_CAMPAIGN_PHASES=phases;
window.EMERALD_CAMPAIGN_STEPS=steps;
window.EMERALD_CAMPAIGN_OLD_STOPS=[
 'c1-001','c1-003','c1-005','c1-006','c1-009','c1-013','c1-014','c1-022',
 'c2-009','c2-015','c3-001','c3-017','c4-001','c4-015','c5-001','c5-005',
 'c5-007','c5-014','c6-001','c6-009','c7-001','c7-011','c8-001','c8-005','c8-006'];
})();