
(()=>{'use strict';
const $=s=>document.querySelector(s), rnd=n=>Math.floor(Math.random()*n),pick=a=>a[rnd(a.length)],clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const SPEC={
Treecko:['Grass',40,45,35,70,65,55,'Grovyle',16],Grovyle:['Grass',50,65,45,95,85,65,'Sceptile',36],Sceptile:['Grass',70,85,65,120,105,85],
Torchic:['Fire',45,60,40,45,70,50,'Combusken',16],Combusken:['Fire',60,85,60,55,85,60,'Blaziken',36],Blaziken:['Fire',80,120,70,80,110,70],
Mudkip:['Water',50,70,50,40,50,50,'Marshtomp',16],Marshtomp:['Water',70,85,70,50,60,70,'Swampert',36],Swampert:['Water',100,110,90,60,85,90],
Poochyena:['Dark',35,55,35,35,35,30,'Mightyena',18],Mightyena:['Dark',70,90,70,70,70,60],
Zigzagoon:['Normal',38,30,41,60,30,41,'Linoone',20],Linoone:['Normal',78,70,61,100,50,61],
Wurmple:['Bug',45,45,35,20,20,30,'Silcoon',7],Silcoon:['Bug',50,35,55,15,25,25,'Beautifly',10],Beautifly:['Bug',60,70,50,65,100,50],
Lotad:['Water',40,30,30,30,40,50,'Lombre',14],Lombre:['Water',60,50,50,50,60,70],
Seedot:['Grass',40,40,50,30,30,30,'Nuzleaf',14],Nuzleaf:['Grass',70,70,40,60,60,40],
Taillow:['Normal',40,55,30,85,30,30,'Swellow',22],Swellow:['Normal',60,85,60,125,75,50],
Ralts:['Psychic',28,25,25,40,45,35,'Kirlia',20],Kirlia:['Psychic',38,35,35,50,65,55,'Gardevoir',30],Gardevoir:['Psychic',68,65,65,80,125,115],
Shroomish:['Grass',60,40,60,35,40,60,'Breloom',23],Breloom:['Grass',60,130,80,70,60,60],
Wingull:['Water',40,30,30,85,55,30,'Pelipper',25],Pelipper:['Water',60,50,100,65,85,70],
Geodude:['Rock',40,80,100,20,30,30,'Graveler',25],Graveler:['Rock',55,95,115,35,45,45],
Electrike:['Electric',40,45,40,65,65,40,'Manectric',26],Manectric:['Electric',70,75,60,105,105,60],
Makuhita:['Fighting',72,60,30,25,20,30,'Hariyama',24],Hariyama:['Fighting',144,120,60,50,40,60],
Aron:['Steel',50,70,100,30,40,40,'Lairon',32],Lairon:['Steel',60,90,140,40,50,50],
Numel:['Fire',60,60,40,35,65,45,'Camerupt',33],Camerupt:['Fire',70,100,70,40,105,75],
Skitty:['Normal',50,45,45,50,35,35],Spinda:['Normal',60,60,60,60,60,60],
Slakoth:['Normal',60,60,60,30,35,35,'Vigoroth',18],Vigoroth:['Normal',80,80,80,90,55,55],
Magikarp:['Water',20,10,55,80,15,20,'Gyarados',20],Gyarados:['Water',95,125,79,81,60,100],
Roselia:['Grass',50,60,45,65,100,80],Nincada:['Bug',31,45,90,40,30,30,'Ninjask',20],Ninjask:['Bug',61,90,45,160,50,50]
};
Object.assign(SPEC,{Nosepass:["Rock",30,45,135,30,45,90],Sableye:["Dark",50,75,75,50,65,65],Shuppet:['Ghost',44,75,35,45,63,33,'Banette',37],Banette:['Ghost',64,115,65,65,83,63],Duskull:['Ghost',20,40,90,25,30,90,'Dusclops',37],Dusclops:['Ghost',40,70,130,25,60,130],Rayquaza:['Dragon',105,150,90,95,150,90],Kyogre:['Water',100,100,90,90,150,140],Groudon:['Ground',100,150,140,90,100,90],Latias:['Dragon',80,80,90,110,110,130],Latios:['Dragon',80,90,80,110,130,110],Tropius:["Grass",99,68,83,51,72,87],Kecleon:["Normal",60,90,70,40,60,120],Volbeat:["Bug",65,73,55,85,47,75],Illumise:["Bug",65,47,55,85,73,75],
Surskit:["Bug", 40, 30, 32, 65, 50, 52, "Masquerain", 22],Masquerain:["Bug", 70, 60, 62, 60, 80, 82],Whismur:["Normal", 64, 51, 23, 28, 51, 23, "Loudred", 20],Loudred:["Normal", 84, 71, 43, 48, 71, 43, "Exploud", 40],Exploud:["Normal", 104, 91, 63, 68, 91, 73],Meditite:["Fighting", 30, 40, 55, 60, 40, 55, "Medicham", 37],Medicham:["Fighting", 60, 60, 75, 80, 60, 75],Trapinch:["Ground", 45, 100, 45, 10, 45, 45, "Vibrava", 35],Vibrava:["Ground", 50, 70, 50, 70, 50, 50, "Flygon", 45],Flygon:["Ground", 80, 100, 80, 100, 80, 80],Swablu:["Normal", 45, 40, 60, 50, 40, 75, "Altaria", 35],Altaria:["Dragon", 75, 70, 90, 80, 70, 105],Barboach:["Water", 50, 48, 43, 60, 46, 41, "Whiscash", 30],Whiscash:["Water", 110, 78, 73, 60, 76, 71],Corphish:["Water", 43, 80, 65, 35, 50, 35, "Crawdaunt", 30],Crawdaunt:["Water", 63, 120, 85, 55, 90, 55],Absol:["Dark", 65, 130, 60, 75, 75, 60],Torkoal:["Fire", 70, 85, 140, 20, 85, 70],Spoink:["Psychic", 60, 25, 35, 60, 70, 80, "Grumpig", 32],Grumpig:["Psychic", 80, 45, 65, 80, 90, 110],Snorunt:["Ice", 50, 50, 50, 50, 50, 50, "Glalie", 42],Glalie:["Ice", 80, 80, 80, 80, 80, 80],Spheal:["Water", 70, 40, 50, 25, 55, 50, "Sealeo", 32],Sealeo:["Water", 90, 60, 70, 45, 75, 70, "Walrein", 44],Walrein:["Water", 110, 80, 90, 65, 95, 90]});

Object.assign(SPEC,{
 Machop:['Fighting',70,80,50,35,35,35,'Machoke',28],Machoke:['Fighting',80,100,70,45,50,60],
 Voltorb:['Electric',40,30,50,100,55,55,'Electrode',30],Electrode:['Electric',60,50,70,140,80,80],
 Magnemite:['Electric',25,35,70,45,95,55,'Magneton',30],Magneton:['Electric',50,60,95,70,120,70],
 Slugma:['Fire',40,40,40,20,70,40,'Magcargo',38],Magcargo:['Fire',60,50,120,30,90,80],
 Vigoroth:['Normal',80,80,80,90,55,55,'Slaking',36],Slaking:['Normal',150,160,100,100,95,65],
 Xatu:['Psychic',65,75,70,95,95,70],Claydol:['Psychic',60,70,105,75,70,120],
 Lunatone:['Rock',70,55,65,70,95,85],Solrock:['Rock',70,95,85,70,55,65],
 Luvdisc:['Water',43,30,55,97,40,65],Kingdra:['Water',75,95,95,85,95,95],
 Shiftry:['Grass',90,100,60,80,90,60],Cacturne:['Grass',70,115,60,55,115,60],
 Wailord:['Water',170,90,45,60,90,45],Ludicolo:['Water',80,70,70,70,90,100],
 Tentacruel:['Water',80,70,65,100,80,120],Milotic:['Water',95,60,79,81,100,125],
 Skarmory:['Steel',65,80,140,70,40,70],Shelgon:['Dragon',65,95,100,50,60,50,'Salamence',50],Salamence:['Dragon',95,135,80,100,110,80],
 Banette:['Ghost',64,115,65,65,83,63],Dusclops:['Ghost',40,70,130,25,60,130],
 Claydol:['Psychic',60,70,105,75,70,120],Glalie:['Ice',80,80,80,80,80,80],
 Meditite:['Fighting',30,40,55,60,40,55,'Medicham',37],Medicham:['Fighting',60,60,75,80,60,75],
 Swablu:['Normal',45,40,60,50,40,75,'Altaria',35],Tropius:['Grass',99,68,83,51,72,87]
});

// Species encountered on optional paths that were missing from the old simplified catalogue.
Object.assign(SPEC,{Wailmer:['Water',130,70,35,60,70,35,'Wailord',40],Wailord:['Water',170,90,45,60,90,45],Relicanth:['Water',100,90,130,55,45,65],Zubat:['Poison',40,45,35,55,30,40,'Golbat',22],Golbat:['Poison',75,80,70,90,65,75],Voltorb:['Electric',40,30,50,100,55,55,'Electrode',30],Electrode:['Electric',60,50,70,140,80,80],Magnemite:['Electric',25,35,70,45,95,55,'Magneton',30],Solrock:['Rock',70,95,85,70,55,65],Shuppet:['Ghost',44,75,35,45,63,33,'Banette',37],Pikachu:['Electric',35,55,30,90,50,40],Oddish:['Grass',45,50,55,30,75,65],Doduo:['Normal',35,85,45,75,35,35,'Dodrio',31],Girafarig:['Normal',70,80,65,85,90,65],Natu:['Psychic',40,50,45,70,70,45,'Xatu',25],Cacnea:['Grass',50,85,40,35,85,40,'Cacturne',32],Sandshrew:['Ground',50,75,85,40,20,30,'Sandslash',22],Machop:['Fighting',70,80,50,35,35,35,'Machoke',28],Vulpix:['Fire',38,41,40,65,50,65],Plusle:['Electric',60,50,40,95,85,75],Minun:['Electric',60,40,50,95,75,85],Chinchou:['Water',75,38,38,67,56,56,'Lanturn',27],Tentacool:['Water',40,40,35,70,50,100,'Tentacruel',30],Snorunt:['Ice',50,50,50,50,50,50,'Glalie',42]});
Object.assign(SPEC,{
 Onix:['Rock',35,45,160,70,30,45],Cascoon:['Bug',50,35,55,15,25,25],
 Abra:['Psychic',25,20,15,90,105,55,'Kadabra',16],Kadabra:['Psychic',40,35,30,105,120,70],
 Carvanha:['Water',45,90,20,65,65,20,'Sharpedo',30],Sharpedo:['Water',70,120,40,95,95,40],
 Castform:['Normal',70,70,70,70,70,70],Zangoose:['Normal',73,115,60,90,60,60],
 Golduck:['Water',80,82,78,85,95,80],Azumarill:['Water',100,50,80,50,60,80],
 Mawile:['Steel',50,85,85,50,55,55],Delcatty:['Normal',70,65,65,90,55,55]
});
// Evoluções adicionais da Geração III, incluindo troca e pedras.
Object.assign(SPEC,{
 Machamp:['Fighting',90,130,80,55,65,85],Golem:['Rock',80,110,130,45,55,65],
 Alakazam:['Psychic',55,50,45,120,135,85],Crobat:['Poison',85,90,80,130,70,80],
 Raichu:['Electric',60,90,55,100,90,80],Ninetales:['Fire',73,76,75,100,81,100],
 Gloom:['Grass',60,65,70,40,85,75,'Vileplume',0],Vileplume:['Grass',75,80,85,50,100,90],
 Metang:['Steel',60,75,100,50,55,80,'Metagross',45],Metagross:['Steel',80,135,130,70,95,90],
 Beldum:['Steel',40,55,80,30,35,60,'Metang',20],
 Seadra:['Water',55,65,95,85,95,45,'Kingdra',0],Horsea:['Water',30,40,70,60,70,25,'Seadra',32],
 Feebas:['Water',20,15,20,80,10,55,'Milotic',0],
 Eevee:['Normal',55,55,50,55,45,65]
});
SPEC.Machoke[7]='Machamp';SPEC.Machoke[8]=0;
SPEC.Graveler[7]='Golem';SPEC.Graveler[8]=0;
SPEC.Kadabra[7]='Alakazam';SPEC.Kadabra[8]=0;
SPEC.Golbat[7]='Crobat';SPEC.Golbat[8]=0;
SPEC.Lombre[7]='Ludicolo';SPEC.Lombre[8]=0;
SPEC.Nuzleaf[7]='Shiftry';SPEC.Nuzleaf[8]=0;
SPEC.Skitty[7]='Delcatty';SPEC.Skitty[8]=0;
SPEC.Vulpix[7]='Ninetales';SPEC.Vulpix[8]=0;
SPEC.Pikachu[7]='Raichu';SPEC.Pikachu[8]=0;
SPEC.Oddish[7]='Gloom';SPEC.Oddish[8]=21;
Object.assign(SPEC,{
 Gulpin:['Poison',70,43,53,40,43,53,'Swalot',26],Swalot:['Poison',100,73,83,55,73,83],
 Rhyhorn:['Ground',80,85,95,25,30,30,'Rhydon',42],Rhydon:['Ground',105,130,120,40,45,45],
 Wigglytuff:['Normal',140,70,45,45,75,50],Wobbuffet:['Psychic',190,33,58,33,33,58],
 Goldeen:['Water',45,67,60,63,35,50,'Seaking',33],Seaking:['Water',80,92,65,68,65,80],
 Muk:['Poison',105,105,75,50,65,100]
});
// Espécies usadas pela campanha, por arenas e pela Frontier sem dados completos na V3.
// As estatísticas-base desta tabela são as da terceira geração.
Object.assign(SPEC,{
 Baltoy:['Ground',40,40,55,55,40,70,'Claydol',36],
 Aggron:['Steel',70,110,180,50,60,60],
 Marill:['Water',70,20,50,40,20,50,'Azumarill',18],
 Azurill:['Normal',50,20,40,20,20,40,'Marill',0],
 Duskull:['Ghost',20,40,90,25,30,90,'Dusclops',37],
 Clamperl:['Water',35,64,85,32,74,55],
 Bagon:['Dragon',45,75,60,50,40,30,'Shelgon',30],
 Lileep:['Rock',66,41,77,23,61,87,'Cradily',40],
 Cradily:['Rock',86,81,97,43,81,107],
 Anorith:['Rock',45,95,50,75,40,50,'Armaldo',40],
 Armaldo:['Rock',75,125,100,45,70,80],
 Shroomish:['Grass',60,40,60,35,40,60,'Breloom',23],
 Nincada:['Bug',31,45,90,40,30,30,'Ninjask',20],
 Shedinja:['Bug',1,90,45,40,30,30],
 Gulpin:['Poison',70,43,53,40,43,53,'Swalot',26],
 Swalot:['Poison',100,73,83,55,73,83],
 Feebas:['Water',20,15,20,80,10,55,'Milotic',0],
 Kingdra:['Water',75,95,95,85,95,95],
 Regirock:['Rock',80,100,200,50,50,100],
 Regice:['Ice',80,50,100,50,100,200],
 Registeel:['Steel',80,75,150,50,75,150],
 Dodrio:['Normal',60,110,70,100,60,60],Sandslash:['Ground',75,100,110,65,45,55],
 Lanturn:['Water',125,58,58,67,76,76]
});
SPEC.Aggron[7]=undefined;
SPEC.Lairon[7]='Aggron'; SPEC.Lairon[8]=42;
// Corrige base stats que estavam trocados/alterados, sem mexer nos times salvos.
SPEC.Lotad.splice(0,7,'Water',40,30,30,30,40,50);
SPEC.Nuzleaf.splice(0,7,'Grass',70,70,40,60,60,40);
SPEC.Kingdra.splice(0,7,'Water',75,95,95,85,95,95);
// A forma escolhida do Wurmple é persistida em cada mon, não aleatória a cada level-up.

SPEC.Cascoon[7]='Dustox';SPEC.Cascoon[8]=10;SPEC.Silcoon[7]='Beautifly';SPEC.Silcoon[8]=10;SPEC.Dustox=['Bug',60,50,70,65,50,90];
// V9.3: the same 1,528 records available in the Quetzal Pokédex are now
// registered in the OFFLINE AI simulation (1,025 National species + forms).
// Battle stats preserve the engine's legacy [type,HP,ATK,DEF,SPE,SPA,SPD] layout.
const NATIONAL_ROWS=window.EmeraldNationalCatalog||[];
const NATIONAL_POOL=window.EmeraldNationalPools;
const NATIONAL_ENTRIES=NATIONAL_ROWS.map(row=>NATIONAL_POOL.adapt(row));
const NATIONAL_BY_NAME=new Map(NATIONAL_ENTRIES.map(row=>[row.key,row]));
for(const row of NATIONAL_ENTRIES){
 const old=SPEC[row.key];
 SPEC[row.key]=[row.types[0],row.base[0],row.base[1],row.base[2],row.base[5],row.base[3],row.base[4],old?.[7],old?.[8]];
}

// Evolutions below are known level-based starter lines; all other unknown
// Quetzal-specific evolution methods remain unimplemented, not guessed.
for(const [from,level,to] of [
 ['Bulbasaur',16,'Ivysaur'],['Ivysaur',32,'Venusaur'],['Charmander',16,'Charmeleon'],['Charmeleon',36,'Charizard'],
 ['Squirtle',16,'Wartortle'],['Wartortle',36,'Blastoise'],['Caterpie',7,'Metapod'],['Metapod',10,'Butterfree'],
 ['Weedle',7,'Kakuna'],['Kakuna',10,'Beedrill'],['Pidgey',18,'Pidgeotto'],['Pidgeotto',36,'Pidgeot'],
 ['Chikorita',16,'Bayleef'],['Bayleef',32,'Meganium'],['Cyndaquil',14,'Quilava'],['Quilava',36,'Typhlosion'],
 ['Totodile',18,'Croconaw'],['Croconaw',30,'Feraligatr'],['Turtwig',18,'Grotle'],['Grotle',32,'Torterra'],
 ['Chimchar',14,'Monferno'],['Monferno',36,'Infernape'],['Piplup',16,'Prinplup'],['Prinplup',36,'Empoleon'],
 ['Snivy',17,'Servine'],['Servine',36,'Serperior'],['Tepig',17,'Pignite'],['Pignite',36,'Emboar'],
 ['Oshawott',17,'Dewott'],['Dewott',36,'Samurott'],['Chespin',16,'Quilladin'],['Quilladin',36,'Chesnaught'],
 ['Fennekin',16,'Braixen'],['Braixen',36,'Delphox'],['Froakie',16,'Frogadier'],['Frogadier',36,'Greninja'],
 ['Rowlet',17,'Dartrix'],['Dartrix',34,'Decidueye'],['Litten',17,'Torracat'],['Torracat',34,'Incineroar'],
 ['Popplio',17,'Brionne'],['Brionne',34,'Primarina'],['Grookey',16,'Thwackey'],['Thwackey',35,'Rillaboom'],
 ['Scorbunny',16,'Raboot'],['Raboot',35,'Cinderace'],['Sobble',16,'Drizzile'],['Drizzile',35,'Inteleon'],
 ['Sprigatito',16,'Floragato'],['Floragato',36,'Meowscarada'],['Fuecoco',16,'Crocalor'],['Crocalor',36,'Skeledirge'],
 ['Quaxly',16,'Quaxwell'],['Quaxwell',36,'Quaquaval'],
]){if(SPEC[from]&&SPEC[to]&&!SPEC[from][7]){SPEC[from][7]=to;SPEC[from][8]=level;}}
const EVO_STONES={Lombre:'WaterStone',Nuzleaf:'LeafStone',Skitty:'MoonStone',Vulpix:'FireStone',Pikachu:'ThunderStone',Gloom:'LeafStone'};
const EVO_TRADE=new Set(['Machoke','Graveler','Kadabra','Seadra']);
const MOVES={Struggle:['Normal',50,100],
Tackle:['Normal',40,100],Scratch:['Normal',40,100],Pound:['Normal',40,100],QuickAttack:['Normal',40,100],Absorb:['Grass',20,100],BulletSeed:['Grass',45,90],LeafBlade:['Grass',90,100],
Ember:['Fire',40,100],FlameWheel:['Fire',60,100],Flamethrower:['Fire',90,100],WaterGun:['Water',40,100],MudShot:['Ground',55,95],Surf:['Water',90,100],
Gust:['Flying',40,100],WingAttack:['Flying',60,100],Bite:['Dark',60,100],Confusion:['Psychic',50,100],Psybeam:['Psychic',65,100],
RockThrow:['Rock',50,90],Spark:['Electric',65,100],Thunderbolt:['Electric',90,100],KarateChop:['Fighting',50,100],Headbutt:['Normal',70,100],IronTail:['Steel',80,75],BugBite:['Bug',60,100]
};
Object.assign(MOVES,{
 Growl:['Normal',0,100],Leer:['Normal',0,100],TailWhip:['Normal',0,100],
 ThunderWave:['Electric',0,100],Toxic:['Poison',0,85],SwordsDance:['Normal',0,100],
 CalmMind:['Psychic',0,100],BulkUp:['Fighting',0,100],Recover:['Normal',0,100],
 Protect:['Normal',0,100],Agility:['Psychic',0,100],SandAttack:['Ground',0,100],
 Peck:['Flying',35,100],MegaDrain:['Grass',40,100],GigaDrain:['Grass',60,100],
 MudSlap:['Ground',20,100],Slam:['Normal',80,75],TakeDown:['Normal',90,85],
 Slash:['Normal',70,100],RazorLeaf:['Grass',55,95],WaterPulse:['Water',60,100],
 Bubble:['Water',20,100],RockTomb:['Rock',50,80],Overheat:['Fire',140,90],
 Facade:['Normal',70,100],AerialAce:['Flying',60,100],
 IcePunch:['Ice',75,100],FirePunch:['Fire',75,100],ThunderPunch:['Electric',75,100]
});
// Na Geração III, poder e categoria ainda dependem da edição e do tipo.
Object.assign(MOVES,{
 LeafBlade:['Grass',70,100],Flamethrower:['Fire',95,100],Thunderbolt:['Electric',95,100],
 Surf:['Water',95,100],HydroPump:['Water',120,80],BulletSeed:['Grass',10,100],
 QuickAttack:['Normal',40,100],AerialAce:['Flying',60,100],
 DoubleKick:['Fighting',30,100],
 DoubleTeam:['Normal',0,100],Hypnosis:['Psychic',0,60],SleepPowder:['Grass',0,75],
 WillOWisp:['Fire',0,75],LeechSeed:['Grass',0,90],Rest:['Psychic',0,100],
 DragonDance:['Dragon',0,100],AncientPower:['Rock',60,100],
 BrickBreak:['Fighting',75,100],Strength:['Normal',80,100],
 ConfuseRay:['Ghost',0,100],BodySlam:['Normal',85,100],
 Thunder:['Electric',120,70],Swift:['Normal',60,100],
 Waterfall:['Water',80,100],IceBeam:['Ice',95,100],
 SolarBeam:['Grass',120,100],FeintAttack:['Dark',60,100]
});

const MOVE_PP={DoubleTeam:15,Hypnosis:20,SleepPowder:15,WillOWisp:15,LeechSeed:10,Rest:10,DragonDance:20,AncientPower:5,BrickBreak:15,Strength:15,ConfuseRay:10,BodySlam:15,Thunder:10,Swift:20,Waterfall:15,FeintAttack:20,DoubleKick:30,BulletSeed:30,LeafBlade:15,Growl:40,Leer:30,TailWhip:30,ThunderWave:20,Toxic:10,SwordsDance:30,CalmMind:20,BulkUp:20,Recover:20,Protect:10,Agility:30,SandAttack:15,
 Flamethrower:15,Thunderbolt:15,Surf:15,HydroPump:5,Earthquake:10,IceBeam:10,Overheat:5,GigaDrain:5,QuickAttack:30};
const movePP=name=>MOVE_PP[name]||20;
const SPECIES_LEVEL_MOVES={
 Treecko:[[1,'Pound'],[6,'Absorb'],[11,'QuickAttack'],[21,'MegaDrain'],[26,'Slam'],[36,'GigaDrain']],
 Grovyle:[[1,'Pound'],[6,'Absorb'],[11,'QuickAttack'],[17,'LeafBlade'],[29,'GigaDrain']],
 Sceptile:[[1,'Pound'],[6,'Absorb'],[11,'QuickAttack'],[16,'LeafBlade'],[36,'GigaDrain']],
 Torchic:[[1,'Scratch'],[7,'Growl'],[10,'Ember'],[16,'Peck'],[28,'QuickAttack'],[34,'Slash'],[43,'Flamethrower']],
 Combusken:[[1,'Scratch'],[10,'Ember'],[16,'Peck'],[16,'DoubleKick'],[28,'BulkUp'],[43,'Flamethrower']],
 Blaziken:[[1,'Scratch'],[10,'Ember'],[16,'Peck'],[16,'DoubleKick'],[28,'BulkUp'],[43,'Flamethrower']],
 Mudkip:[[1,'Tackle'],[6,'MudSlap'],[10,'WaterGun'],[28,'TakeDown'],[37,'Protect'],[42,'HydroPump']],
 Marshtomp:[[1,'Tackle'],[6,'MudSlap'],[10,'WaterGun'],[16,'MudShot'],[37,'Protect'],[42,'HydroPump']],
 Swampert:[[1,'Tackle'],[6,'MudSlap'],[10,'WaterGun'],[16,'MudShot'],[37,'Protect'],[42,'HydroPump']],
 Ralts:[[1,'Growl'],[6,'Confusion'],[21,'CalmMind'],[26,'Psychic']],
 Kirlia:[[1,'Growl'],[6,'Confusion'],[21,'CalmMind'],[26,'Psychic']],
 Gardevoir:[[1,'Growl'],[6,'Confusion'],[21,'CalmMind'],[26,'Psychic']],
 Geodude:[[1,'Tackle'],[11,'RockThrow'],[16,'RockTomb'],[36,'Earthquake']],
 Aron:[[1,'Tackle'],[10,'MudSlap'],[16,'Headbutt'],[34,'IronTail']],
 Taillow:[[1,'Peck'],[8,'QuickAttack'],[13,'WingAttack'],[34,'AerialAce']],
 Magikarp:[[1,'Tackle']],Gyarados:[[1,'Bite'],[20,'DragonBreath'],[30,'HydroPump']],
 Slakoth:[[1,'Scratch'],[7,'Growl'],[25,'Slash']],Vigoroth:[[1,'Scratch'],[7,'Growl'],[25,'Slash']],Slaking:[[1,'Scratch'],[7,'Growl'],[25,'Slash']]
};
MOVES.DoubleKick=['Fighting',30,100];
const LEARN={Grass:['Tackle','Absorb','BulletSeed','LeafBlade'],Fire:['Scratch','Ember','FlameWheel','Flamethrower'],Water:['Tackle','WaterGun','MudShot','Surf'],Normal:['Tackle','QuickAttack','Headbutt'],Dark:['Tackle','Bite','QuickAttack'],Flying:['Tackle','Gust','WingAttack'],Psychic:['Pound','Confusion','Psybeam'],Bug:['Tackle','BugBite'],Rock:['Tackle','RockThrow'],Electric:['Tackle','Spark','Thunderbolt'],Fighting:['Tackle','KarateChop'],Steel:['Tackle','IronTail'],Dragon:['Tackle','Headbutt'],Ghost:['Tackle','Bite','Confusion']};
Object.assign(MOVES,{DragonBreath:['Dragon',60,100],ShadowBall:['Ghost',80,100],PowderSnow:['Ice',40,100],IceBeam:['Ice',95,100],Sludge:['Poison',65,100],SludgeBomb:['Poison',90,100],Dig:['Ground',60,100]});
MOVES.FairyWind=['Fairy',40,100]; LEARN.Fairy=['Tackle','FairyWind','Swift'];
Object.assign(LEARN,{Dragon:['Tackle','DragonBreath','Headbutt'],Ghost:['Tackle','ShadowBall','Bite'],Ice:['Tackle','PowderSnow','IceBeam'],Poison:['Tackle','Sludge','SludgeBomb'],Ground:['Tackle','MudShot','Dig']});
const LEGEND_PROFILES={
 Rayquaza:{title:'Soberano dos céus',hp:1.6,atk:1.5,def:1.3,spAtk:1.5,spDef:1.3,speed:1.15,minLevel:65,ability:'Air Lock',detail:'Ataque misto devastador. Dissipa o clima ao entrar; Gelo causa dano ×4.',moves:[[1,'DragonBreath'],[1,'WingAttack'],[35,'Crunch'],[45,'DragonClaw'],[55,'Earthquake']]},
 Kyogre:{title:'Senhor dos oceanos',hp:1.6,atk:1.25,def:1.3,spAtk:1.55,spDef:1.45,speed:1.1,minLevel:60,ability:'Drizzle',detail:'Ataque e defesa especiais colossais. A chuva fortalece Água; vulnerável a Elétrico e Grama.',moves:[[1,'WaterGun'],[20,'IceBeam'],[35,'Surf'],[45,'Thunderbolt'],[55,'HydroPump']]},
 Groudon:{title:'Titã dos continentes',hp:1.6,atk:1.55,def:1.5,spAtk:1.25,spDef:1.3,speed:1.1,minLevel:60,ability:'Drought',detail:'Ataque e defesa físicos colossais. O sol enfraquece Água; imune a Elétrico.',moves:[[1,'MudShot'],[20,'RockSlide'],[35,'Flamethrower'],[45,'Earthquake'],[55,'SolarBeam']]},
 Latias:{title:'Guardiã do horizonte',hp:1.5,atk:1.2,def:1.35,spAtk:1.35,spDef:1.55,speed:1.25,minLevel:50,ability:'Levitate',detail:'Veloz e resistente a ataques especiais. Levitate concede imunidade a Terra.',moves:[[1,'DragonBreath'],[20,'Psybeam'],[35,'Surf'],[45,'Psychic'],[50,'DragonClaw']]},
 Latios:{title:'Lança do horizonte',hp:1.5,atk:1.25,def:1.3,spAtk:1.55,spDef:1.35,speed:1.25,minLevel:50,ability:'Levitate',detail:'Velocidade e ataque especial elevados. Levitate concede imunidade a Terra.',moves:[[1,'DragonBreath'],[20,'Psybeam'],[35,'Thunderbolt'],[45,'Psychic'],[50,'DragonClaw']]}
};
Object.assign(MOVES,{DragonClaw:['Dragon',80,100],Psychic:['Psychic',90,100],Earthquake:['Ground',100,100],RockSlide:['Rock',75,90],Crunch:['Dark',80,100],HydroPump:['Water',120,80],SolarBeam:['Grass',120,100]});
Object.assign(SPECIES_LEVEL_MOVES,{
 Shroomish:[[1,'Absorb'],[7,'StunSpore'],[10,'LeechSeed'],[16,'MegaDrain'],[22,'Headbutt']],
 Breloom:[[1,'Absorb'],[7,'StunSpore'],[16,'MegaDrain'],[23,'MachPunch'],[28,'Headbutt']],
 Gyarados:[[1,'Thrash'],[20,'Bite'],[25,'DragonRage'],[40,'HydroPump']],
 Altaria:[[1,'Peck'],[18,'Sing'],[35,'DragonBreath'],[40,'DragonDance']],
 Kingdra:[[1,'WaterGun'],[29,'Twister'],[40,'HydroPump']],
 Milotic:[[1,'WaterGun'],[15,'WaterPulse'],[30,'Recover'],[40,'Surf']],
 Skarmory:[[1,'Peck'],[16,'Swift'],[26,'SteelWing'],[32,'AirCutter']],
 Regirock:[[1,'RockThrow'],[21,'AncientPower'],[41,'Superpower']],
 Regice:[[1,'PowderSnow'],[21,'AncientPower'],[41,'IceBeam']],
 Registeel:[[1,'MetalClaw'],[21,'AncientPower'],[41,'IronDefense']]
});
Object.assign(MOVES,{
 StunSpore:['Grass',0,75],MachPunch:['Fighting',40,100],Thrash:['Normal',90,100],
 DragonRage:['Dragon',0,100],Sing:['Normal',0,55],Twister:['Dragon',40,100],
 SteelWing:['Steel',70,90],AirCutter:['Flying',55,95],Superpower:['Fighting',120,100],
 MetalClaw:['Steel',50,95],IronDefense:['Steel',0,100]
});

const LATE_MOVES={Ground:'Earthquake',Psychic:'Psychic',Rock:'RockSlide',Dark:'Crunch',Dragon:'DragonClaw'};
function learnedMoves(species,level){
 if(LEGEND_PROFILES[species])return LEGEND_PROFILES[species].moves.filter(([lv,name])=>level>=lv&&MOVES[name]).map(([,name])=>name).slice(-4);
 const speciesList=SPECIES_LEVEL_MOVES[species];
 if(speciesList){const learned=[...new Set(speciesList.filter(([lv,name])=>lv<=level&&MOVES[name]).map(([,name])=>name))];return learned.slice(-4)}
 const types=monTypes({species}),primary=LEARN[types[0]]||LEARN.Normal,secondary=LEARN[types[1]];
 const pool=[primary[0],primary[1],...(secondary?[secondary[1]]:[]),...primary.slice(2),...(secondary?secondary.slice(2):[])].filter(n=>MOVES[n]);
 if(level>=36)for(const tp of types)if(LATE_MOVES[tp])pool.push(LATE_MOVES[tp]);
 const unique=[...new Set(pool)];return level>=28?unique.slice(-4):unique.slice(0,level>=13?3:2)
}
const ADV={Fire:{Grass:2,Bug:2,Water:.5,Fire:.5,Rock:.5},Water:{Fire:2,Rock:2,Ground:2,Water:.5,Grass:.5},Grass:{Water:2,Ground:2,Rock:2,Fire:.5,Grass:.5,Bug:.5,Flying:.5},Electric:{Water:2,Flying:2,Grass:.5,Electric:.5,Ground:0},Ground:{Fire:2,Electric:2,Rock:2,Steel:2,Grass:.5,Flying:0},Flying:{Grass:2,Bug:2,Fighting:2,Electric:.5,Rock:.5},Fighting:{Normal:2,Rock:2,Steel:2,Flying:.5,Psychic:.5,Bug:.5},Psychic:{Fighting:2,Poison:2,Psychic:.5,Dark:0},Rock:{Fire:2,Flying:2,Bug:2,Fighting:.5,Ground:.5,Steel:.5},Bug:{Grass:2,Psychic:2,Dark:2,Fire:.5,Fighting:.5,Flying:.5},Dark:{Psychic:2,Dark:.5,Fighting:.5},Steel:{Rock:2,Steel:.5,Fire:.5,Water:.5},Normal:{Rock:.5,Steel:.5}};

// Tabela de efetividades da Geração III (sem Fairy), incluindo imunidades.
Object.assign(ADV,{
 Normal:{Rock:.5,Ghost:0,Steel:.5},
 Fire:{Fire:.5,Water:.5,Grass:2,Ice:2,Bug:2,Rock:.5,Dragon:.5,Steel:2},
 Water:{Fire:2,Water:.5,Grass:.5,Ground:2,Rock:2,Dragon:.5},
 Electric:{Water:2,Electric:.5,Grass:.5,Ground:0,Flying:2,Dragon:.5},
 Grass:{Fire:.5,Water:2,Grass:.5,Poison:.5,Ground:2,Flying:.5,Bug:.5,Rock:2,Dragon:.5,Steel:.5},
 Ice:{Fire:.5,Water:.5,Grass:2,Ice:.5,Ground:2,Flying:2,Dragon:2,Steel:.5},
 Fighting:{Normal:2,Ice:2,Poison:.5,Flying:.5,Psychic:.5,Bug:.5,Rock:2,Ghost:0,Dark:2,Steel:2},
 Poison:{Grass:2,Poison:.5,Ground:.5,Rock:.5,Ghost:.5,Steel:0},
 Ground:{Fire:2,Electric:2,Grass:.5,Poison:2,Flying:0,Bug:.5,Rock:2,Steel:2},
 Flying:{Electric:.5,Grass:2,Fighting:2,Bug:2,Rock:.5,Steel:.5},
 Psychic:{Fighting:2,Poison:2,Psychic:.5,Dark:0,Steel:.5},
 Bug:{Fire:.5,Grass:2,Fighting:.5,Poison:.5,Flying:.5,Psychic:2,Ghost:.5,Dark:2,Steel:.5},
 Rock:{Fire:2,Ice:2,Fighting:.5,Ground:.5,Flying:2,Bug:2,Steel:.5},
 Ghost:{Normal:0,Psychic:2,Ghost:2,Dark:.5,Steel:.5},
 Dragon:{Dragon:2,Steel:.5},
 Dark:{Fighting:.5,Psychic:2,Ghost:2,Dark:.5,Steel:.5},
 Steel:{Fire:.5,Water:.5,Electric:.5,Ice:2,Rock:2,Steel:.5}
});
// Modern typing extension for species originating after Gen III.
ADV.Fairy={Fighting:2,Dragon:2,Dark:2,Fire:.5,Poison:.5,Steel:.5};
for(const [attack,mul] of Object.entries({Fighting:.5,Bug:.5,Dark:.5,Dragon:0}))ADV[attack].Fairy=mul;
ADV.Poison.Fairy=2;ADV.Steel.Fairy=2;
const STAGES=[
['Caminhão','Sair do caminhão'],['Casa','Conhecer a casa'],['Quarto','Pegar Potion no PC'],['Quarto','Ajustar o relógio'],['Casa','Conversar com a mãe'],['Casa do rival','Subir ao quarto do rival'],['Quarto do rival','Investigar a Pokébola'],['Littleroot','Ir para o norte'],['Route 101','Salvar o Professor Birch'],['Laboratório','Receber o Pokémon inicial'],['Route 101','Explorar a rota'],['Oldale Town','Visitar o Centro Pokémon'],['Route 103','Encontrar o rival'],['Route 103','Batalhar com o rival'],['Laboratório','Receber Pokédex e Pokébolas'],['Littleroot','Receber Running Shoes'],['Route 102','Iniciar a aventura em Hoenn'],['Petalburg City','Encontrar Norman'],['Petalburg Woods','Explorar a floresta'],['Rustboro City','Desafiar Roxanne'],['Dewford Town','Desafiar Brawly'],['Mauville City','Desafiar Wattson'],['Lavaridge Town','Desafiar Flannery'],['Petalburg City','Desafiar Norman'],['Fortree City','Desafiar Winona'],['Mossdeep City','Desafiar Tate e Liza'],['Sootopolis City','Desafiar Juan'],['Ever Grande City','Desafiar a Elite Four']
];
const GYMS={
 19:['Roxanne','Rock',[['Geodude',12],['Geodude',12],['Nosepass',15]],18],
 20:['Brawly','Fighting',[['Machop',16],['Meditite',16],['Makuhita',19]],24],
 21:['Wattson','Electric',[['Voltorb',20],['Electrike',20],['Magneton',22],['Manectric',24]],29],
 22:['Flannery','Fire',[['Numel',24],['Slugma',24],['Camerupt',26],['Torkoal',29]],34],
 23:['Norman','Normal',[['Spinda',27],['Vigoroth',27],['Linoone',29],['Slaking',31]],39],
 24:['Winona','Flying',[['Swablu',29],['Tropius',29],['Pelipper',30],['Skarmory',31],['Altaria',33]],44],
 25:['Tate e Liza','Psychic',[['Claydol',41],['Xatu',41],['Lunatone',42],['Solrock',42]],49],
 26:['Juan','Water',[['Luvdisc',41],['Whiscash',41],['Sealeo',43],['Crawdaunt',43],['Kingdra',46]],54]
};
const PERSONALITIES=[['Estrategista',.85,.2,.75,.6],['Aventureiro',.45,.95,.35,.6],['Competitivo',.8,.45,.95,.35],['Colecionador',.45,.9,.45,.9],['Cauteloso',.8,.35,.2,.8],['Impulsivo',.25,.7,.95,.2],['Pesquisador',.75,.85,.4,.75],['Persistente',.65,.55,.8,.6],['Treinador',.8,.55,.7,.65],['Sortudo',.45,.8,.65,.55]];
const NAMES=['Brendan','May','Kai','Luna','Theo','Nina','Leo','Mika','Ash','Rina','Noah','Yuki','Davi','Maya','Ravi','Ayla','Ren','Iris','Ken','Sora','Roxanne','Brawly','Wattson','Flannery','Norman','Winona','Tate','Liza','Juan','Wallace','Steven','Wally','Phoebe','Glacia','Drake','Sidney','Archie','Maxie','Courtney','Shelly','Tabitha','Matt','Birch','Lass','Ace','Ranger','Ninja','Swimmer','Collector','Breeder','Hiker','Bug Catcher','Psychic','Camper','Pokefan','Fisher','Sailor','Rich Boy'];
const EXTRA_NAMES=['Aiko','Akira','Amara','Anya','Aria','Asher','Aurora','Bela','Bianca','Caio','Cecilia','Clara','Dante','Elena','Elias','Emi','Enzo','Erika','Felix','Flora','Gael','Hana','Haruki','Helena','Hiro','Isabel','Jade','Jasper','Juno','Kaito','Kaori','Lara','Levi','Lia','Luca','Lucia','Maia','Milo','Mina','Mirela','Nara','Nico','Olivia','Otto','Pietra','Rael','Rafael','Reina','Riku','Rosa','Sakura','Samira','Sara','Selena','Shin','Sofia','Takeshi','Talia','Taro','Tessa','Uma','Valentina','Vera','Vitor','Yara','Yasmin','Yuna','Zara','Zoe','Aster','Bento','Ciro','Dahlia','Eden','Faye','Gabi','Hector','Inari','Joaquim','Keiko','Lorenzo','Mabel','Natsuki','Orion','Pablo','Quinn','Rafaela','Sienna','Tobias','Ulisses','Violeta','Willow','Xavier','Yumi','Zelda','Alina','Brisa','Cora','Dorian','Estela','Fiona','Giulia','Hikari','Ivo','Jasmine','Kiara','Luiza','Marina','Naomi','Oliver','Priscila','Raissa','Satoshi','Tina','Uriel','Vânia','Wesley','Ximena','Yoshi','Zuri'];
const UNIQUE_NAMES=[...new Set([...NAMES.filter(n=>!['Lass','Ace','Ranger','Ninja','Swimmer','Collector','Breeder','Hiker','Bug Catcher','Psychic','Camper','Pokefan','Fisher','Sailor','Rich Boy'].includes(n)),...EXTRA_NAMES])];
const STAT_KEYS=['maxHp','atk','def','speed','spAtk','spDef'];
const NATURES={Hardy:[],Lonely:['atk','def'],Brave:['atk','speed'],Adamant:['atk','spAtk'],Naughty:['atk','spDef'],
 Bold:['def','atk'],Docile:[],Relaxed:['def','speed'],Impish:['def','spAtk'],Lax:['def','spDef'],
 Timid:['speed','atk'],Hasty:['speed','def'],Serious:[],Jolly:['speed','spAtk'],Naive:['speed','spDef'],
 Modest:['spAtk','atk'],Mild:['spAtk','def'],Quiet:['spAtk','speed'],Bashful:[],Rash:['spAtk','spDef'],
 Calm:['spDef','atk'],Gentle:['spDef','def'],Sassy:['spDef','speed'],Careful:['spDef','spAtk'],Quirky:[]};
const NATURE_LIST=Object.keys(NATURES);
const randomIvs=()=>Object.fromEntries(STAT_KEYS.map(k=>[k,rnd(32)]));
const blankEvs=()=>Object.fromEntries(STAT_KEYS.map(k=>[k,0]));
const expNeeded=lv=>lv>=100?Infinity:((lv+1)**3-lv**3);
function levelCapFor(t){return t?.champion?100:[15,19,24,29,31,33,42,46,58][clamp(Math.floor(Number(t?.badges)||0),0,8)]}
function levelStats(species,level,ivs={},evs={},nature='Hardy'){
 const s=SPEC[species]||SPEC.Zigzagoon;
 const lv=clamp(Math.floor(Number(level)||1),1,100),stats={};
 const natureKeys=NATURES[nature]||[];
 STAT_KEYS.forEach((key,i)=>{
   const base=s[i+1],iv=clamp(Math.floor(Number(ivs[key])||0),0,31),ev=clamp(Math.floor(Number(evs[key])||0),0,255);
   const raw=Math.floor(((2*base+iv+Math.floor(ev/4))*lv)/100);
   const natureModifier=natureKeys[0]===key?1.1:natureKeys[1]===key?.9:1;
   stats[key]=i===0?raw+lv+10:Math.floor((raw+5)*natureModifier);
 });
 if(species==='Shedinja')stats.maxHp=1;
 return stats;
}
function normalizeMon(m,owner=null,legacy=false){
 if(!m||!m.species)return;
 if(!m.ivs||typeof m.ivs!=='object')m.ivs=Object.fromEntries(STAT_KEYS.map(k=>[k,15]));
 if(!m.evs||typeof m.evs!=='object')m.evs=blankEvs();
 if(!NATURES[m.nature])m.nature='Hardy';
 m.friendship=clamp(Math.floor(Number(m.friendship)||70),0,255);
 if(m.species==='Wurmple'&&!['Silcoon','Cascoon'].includes(m.wurmpleBranch))m.wurmpleBranch='Silcoon';
 m.level=clamp(Math.floor(Number(m.level)||1),1,owner?levelCapFor(owner):100);
 const prevMax=Math.max(1,Number(m.maxHp)||1),prevHp=Math.max(0,Number(m.hp)||0);
 const stats=levelStats(m.species,m.level,m.ivs,m.evs,m.nature);
 Object.assign(m,stats);
 m.hp=prevHp?Math.min(m.maxHp,Math.max(1,Math.round(m.maxHp*prevHp/prevMax))):0;
 if(m.status==='toxic')m.toxicTurns=clamp(Math.floor(Number(m.toxicTurns)||0),0,15);
 m.type=SPEC[m.species]?.[0]||m.type||'Normal';
 m.moves=(Array.isArray(m.moves)?m.moves:learnedMoves(m.species,m.level)).filter(x=>MOVES[x]).slice(-4);
 if(!m.moves.length)m.moves=learnedMoves(m.species,m.level);
 m.pp??={};for(const move of m.moves)m.pp[move]=clamp(Math.floor(Number.isFinite(Number(m.pp[move]))&&m.pp[move]!==undefined?Number(m.pp[move]):movePP(move)),0,movePP(move));
 if(legacy)m.exp=Math.round(clamp((Number(m.exp)||0)/Math.max(1,m.level*12),0,.999)*expNeeded(m.level));
 m.exp=(owner&&m.level>=levelCapFor(owner))?0:clamp(Math.floor(Number(m.exp)||0),0,Number.isFinite(expNeeded(m.level))?expNeeded(m.level)-1:0);
}
function createMon(species,lv,shiny=false){
 const s=SPEC[species]||SPEC.Zigzagoon,ivs=randomIvs(),evs=blankEvs(),nature=pick(NATURE_LIST);
 const level=clamp(Math.floor(lv),1,100),stats=levelStats(species,level,ivs,evs,nature);
 const moves=learnedMoves(species,level);return{uid:'p'+Math.random().toString(36).slice(2),species,type:s[0],level,exp:0,ivs,evs,nature,friendship:70,wurmpleBranch:species==='Wurmple'?(rnd(2)?'Silcoon':'Cascoon'):null,...stats,hp:stats.maxHp,shiny,status:null,moves,pp:Object.fromEntries(moves.map(n=>[n,movePP(n)]))};
}
function teachMove(t,m,name){
 if(!MOVES[name]||m.moves.includes(name))return false;
 if(m.moves.length===4){
   const value=n=>MOVES[n][1]?moveStrength(m,n):(['Recover','CalmMind','BulkUp','SwordsDance','ThunderWave'].includes(n)?38:10);
   const weakest=[...m.moves].sort((a,b)=>value(a)-value(b))[0];
   if(value(name)<value(weakest)*.85)return false;
   m.moves.splice(m.moves.indexOf(weakest),1);delete m.pp[weakest];
 }
 m.moves.push(name);m.pp[name]=movePP(name);if(t)emit(t,'level',`${m.species} aprendeu ${name}!`);return true;
}
function maybeEvolve(t,m){
 if(!settings.evolution)return false;
 const evo=SPEC[m.species];if(!evo?.[7])return false;
 let can=false;
 if(evo[8]>0)can=m.level>=evo[8];
 else if(EVO_STONES[m.species]){const stone=EVO_STONES[m.species];can=!!t.bag[stone]&&m.level>=20;if(can)t.bag[stone]--}
 else if(EVO_TRADE.has(m.species))can=t.badges>=5&&m.level>=36; // regra de troca alternativa claramente definida
 else if(m.species==='Golbat')can=m.friendship>=220; // geração III: amizade alta
 else if(m.species==='Feebas')can=m.beauty>=170&&m.level>=20; // evolução por beleza
 if(!can)return false;
 const old=m.species,previousMax=m.maxHp;
 const evolution=(old==='Wurmple'&&m.wurmpleBranch)||evo[7];
 m.species=evolution;m.type=SPEC[m.species][0];
 if(!t.dex.includes(m.species))t.dex.push(m.species);
 Object.assign(m,levelStats(m.species,m.level,m.ivs,m.evs,m.nature));
 if(m.hp>0)m.hp=Math.min(m.maxHp,m.hp+m.maxHp-previousMax);
 const learned=learnedMoves(m.species,m.level);for(const name of learned)teachMove(t,m,name);
 emit(t,'rare',`✨ ${old} evoluiu para ${m.species}!`,true);
 if(old==='Nincada'&&m.level>=20&&t.bag.Pokeball>0&&t.team.length<6){
  const shed=createMon('Shedinja',m.level,m.shiny);shed.ivs={...m.ivs};shed.evs={...m.evs};shed.nature=m.nature;
  Object.assign(shed,levelStats('Shedinja',shed.level,shed.ivs,shed.evs,shed.nature));shed.hp=1;
  t.team.push(shed);t.bag.Pokeball--;t.dex.push('Shedinja');emit(t,'rare',`✨ Shedinja surgiu após a evolução de Nincada!`,true);
 }
 t.needsRebalance=true;return true;
}
function awardEffort(m,enemies){
 const evs=m.evs||blankEvs();m.evs=evs;
 for(const defeated of enemies){const sp=SPEC[defeated.species];if(!sp)continue;
  let idx=1;for(let i=2;i<7;i++)if(sp[i]>sp[idx])idx=i;
  const stat=STAT_KEYS[idx-1],total=STAT_KEYS.reduce((v,k)=>v+(evs[k]||0),0);
  if(total<510)evs[stat]=Math.min(255,(evs[stat]||0)+1,510-total);
 }
 const old=m.maxHp;Object.assign(m,levelStats(m.species,m.level,m.ivs,m.evs,m.nature));if(m.hp>0)m.hp=Math.min(m.maxHp,m.hp+(m.maxHp-old));
}
function newTrainer(i){let p=PERSONALITIES[i%PERSONALITIES.length];return{id:i,name:UNIQUE_NAMES[i]||`Treinador ${i+1}`,personality:p[0],traits:{strategy:p[1],explore:p[2],aggression:p[3],care:p[4]},stage:0,location:'Caminhão',team:[],bag:{Potion:1,Pokeball:0},money:3000,wins:0,losses:0,badges:0,dex:[],mem:[],rivals:{},friends:{},strategyMemory:{},battle:null,cooldown:rnd(7),starter:null,steps:0,events:[],champion:false,finishTick:null,personalBest:null,pc:[],captures:0,teamChanges:0,routeCaught:{},teamLog:[],quests:{},campaignSequence:2,gymGuards:{},leagueRound:0,routeFights:{},healing:null,healingCount:0,grindWins:0,grindSessions:0,grindTarget:0,centersVisited:[],lastHealTick:-100,tournamentWins:0,walkX:8+rnd(5),walkY:7+rnd(4),walkDir:1,walkCount:0,walkMap:'',walkTarget:null,detoursDone:{},detour:null,routeLog:[],teamReason:'Jornada iniciada',trainingProject:null,trainingLoan:null,loanDoneStages:{},frontier:{wins:{},losses:{},symbols:{},last:null},postgameSteps:0,isUserBot:false,botStarter:null,botStyle:'balanced',botGoal:'story',botName:null,playerJourneyCommand:null,playerExploreSteps:0}};
const SIM_SPEED=window.EmeraldSimSpeed;
const DEFAULTS={speed:1,speedScaleVersion:2,autosave:100,renderMs:750,shinies:true,shinyOdds:4096,legendaries:true,legendaryOdds:2500,worldEvents:true,friendships:true,rivalries:true,capture:true,captureAggression:70,teamOptimization:true,pcStorage:true,teamSize:6,partyRebalance:8,expMultiplier:1,damageMultiplier:1,smartMoves:true,smartSwitch:true,potions:true,critical:true,status:true,evolution:true,starter:'adaptive',camera:'auto',weather:true,seasonGoal:10,uiDensity:'normal',animations:true,aiRisk:50,training:60,gymTrainers:2,routeTrainers:2,battlePace:3,leagueLevel:58,leagueHeal:false,requireGuards:true,tournamentEnabled:true,tournamentInterval:600,tournamentMinStage:16,tournamentTeamSize:3,trainerEncounters:true,grinding:true,grindIntensity:100,centerThreshold:62,centerVisits:true,partyReadiness:6,shareTraining:true,grindWildBattles:true,customRuleText:'',frontierEnabled:true,postgameTraining:true,tournamentMatchTurns:90,tournamentReplay:true,teamPolicy:'intelligent',explorationFreedom:68,routeProfile:'personality',squadStability:12,futureInvestment:true,encounterOdds:16,enableTileEncounters:true,showHabitat:true,protectedCities:true,collectionGoal:false,nationalEncounters:true,nationalForms:false,enemyLevelBonus:0,levelCap:true,weatherMode:'dynamic',gameMode:'mixed'};
let settings={...DEFAULTS},speedNeedsMigration=false;try{const v=JSON.parse(localStorage.getItem('emerald_v21_options')||localStorage.getItem('emerald_v20_options')||localStorage.getItem('emerald_v19_options')||localStorage.getItem('emerald_v10_options')||'{}');speedNeedsMigration=v.speedScaleVersion!==2;for(const k of Object.keys(DEFAULTS))if(k in v&&(!('emerald_v21_options' in localStorage)||k!=='leagueLevel'&&k!=='leagueHeal'))settings[k]=v[k]}catch(e){}
if(speedNeedsMigration){settings.speed=SIM_SPEED.fromLegacy(settings.speed);settings.speedScaleVersion=2;}
settings.levelCap=true;settings.leagueLevel=58;settings.damageMultiplier=1;
function storeOptions(){settings.levelCap=true;settings.leagueLevel=58;settings.damageMultiplier=1;try{localStorage.setItem('emerald_v21_options',JSON.stringify(settings))}catch(e){}}
window.emeraldOptions=settings;window.emeraldDefaults=DEFAULTS;
let savedDataRestored=false;
let hall=[],season=1,rareEvents=0,records=[];let nextBotIndex=0,lastAutosaveAt=0;let trainers=Array.from({length:20},(_,i)=>newTrainer(i)),feed=[],pairScores={},selected=0,featured=0,camera='auto',paused=true,speed=SIM_SPEED.normalize(settings.speed,true),filter='all',clock=0,turns=0;
settings.speed=speed;
function syncSpeedUi(){const select=$('#speed');if(select&&select.tagName==='SELECT')select.value=String(speed||1);const solo=document.getElementById('botSpeed');if(solo&&solo!==document.activeElement)solo.value=String(speed||1);}
const GYM_TYPES=['Rock','Fighting','Electric','Fire','Normal','Flying','Psychic','Water'];

function nextGymType(t){return t.badges>=8?['Dark','Ghost','Ice','Dragon','Water'][Math.min(4,t.leagueRound||0)]:GYM_TYPES[Math.min(t.badges,7)]}
// A terceira geração separa físico/especial PELO TIPO, não pelo movimento.
const GEN3_PHYSICAL=new Set(['Normal','Fighting','Flying','Poison','Ground','Rock','Bug','Ghost','Steel']);
const MON_SECONDARY={Lotad:'Grass',Lombre:'Grass',Ludicolo:'Grass',Nuzleaf:'Dark',Shiftry:'Dark',Taillow:'Flying',Swellow:'Flying',Swablu:'Flying',Altaria:'Flying',Beautifly:'Flying',Gyarados:'Flying',Marshtomp:'Ground',Swampert:'Ground',Wingull:'Flying',Pelipper:'Flying',Combusken:'Fighting',Blaziken:'Fighting',Breloom:'Fighting',Geodude:'Ground',Graveler:'Ground',Aron:'Rock',Lairon:'Rock',Numel:'Ground',Camerupt:'Ground',Roselia:'Poison',Nincada:'Ground',Ninjask:'Flying',Surskit:'Water',Masquerain:'Flying',Sableye:'Ghost',Rayquaza:'Flying',Latias:'Psychic',Latios:'Psychic',Tropius:'Flying',Meditite:'Psychic',Medicham:'Psychic',Vibrava:'Dragon',Flygon:'Dragon',Barboach:'Ground',Whiscash:'Ground',Crawdaunt:'Dark',Spheal:'Ice',Sealeo:'Ice',Walrein:'Ice',Magnemite:'Steel',Magneton:'Steel',Magcargo:'Rock',Xatu:'Flying',Claydol:'Ground',Lunatone:'Psychic',Solrock:'Psychic',Kingdra:'Dragon',Cacturne:'Dark',Tentacool:'Poison',Tentacruel:'Poison',Skarmory:'Flying',Salamence:'Flying',Relicanth:'Rock',Zubat:'Flying',Golbat:'Flying',Oddish:'Poison',Doduo:'Flying',Girafarig:'Psychic',Natu:'Flying',Chinchou:'Electric',Baltoy:'Psychic',Aggron:'Rock',Bagon:undefined,Clamperl:undefined,Shedinja:'Ghost',Gloom:'Poison',Vileplume:'Poison',Metang:'Psychic',Metagross:'Psychic',Beldum:'Psychic',Cradily:'Grass',Armaldo:'Bug',Lileep:'Grass',Anorith:'Bug',Duskull:undefined,Marill:undefined,Azurill:undefined,Regirock:undefined,Regice:undefined,Registeel:undefined};
for(const row of NATIONAL_ENTRIES){if(row.types[1])MON_SECONDARY[row.key]=row.types[1];}
const ABILITY_HINT={Treecko:'Overgrow',Grovyle:'Overgrow',Sceptile:'Overgrow',Torchic:'Blaze',Combusken:'Blaze',Blaziken:'Blaze',Mudkip:'Torrent',Marshtomp:'Torrent',Swampert:'Torrent',Gyarados:'Intimidate',Mightyena:'Intimidate',Swellow:'Guts',Shroomish:'Effect Spore',Breloom:'Effect Spore',Ralts:'Synchronize',Kirlia:'Synchronize',Gardevoir:'Synchronize',Aron:'Sturdy',Lairon:'Sturdy',Aggron:'Sturdy',Electrike:'Static',Manectric:'Static',Slakoth:'Truant',Vigoroth:'Vital Spirit',Slaking:'Truant',Altaria:'Natural Cure',Tentacool:'Clear Body',Tentacruel:'Clear Body',Pelipper:'Keen Eye',Wingull:'Keen Eye',Torkoal:'White Smoke',Flygon:'Levitate',Vibrava:'Levitate',Claydol:'Levitate',Baltoy:'Levitate',Lunatone:'Levitate',Solrock:'Levitate',Tropius:'Chlorophyll',Spheal:'Thick Fat',Walrein:'Thick Fat',Snorunt:'Inner Focus',Zubat:'Inner Focus',Golbat:'Inner Focus',Absol:'Pressure',Skarmory:'Keen Eye',Sableye:'Keen Eye',Swablu:'Natural Cure',Milotic:'Marvel Scale',Wailmer:'Water Veil',Wailord:'Water Veil',Trapinch:'Hyper Cutter',Metagross:'Clear Body',Salamence:'Intimidate'};
function abilityScore(m){const a=ability(m)||'—';const bonus={Intimidate:90,Levitate:88,Natural_Cure:83,'Natural Cure':83,Thick_Fat:82,'Thick Fat':82,Pressure:78,Clear_Body:77,'Clear Body':77,Sturdy:74,Static:73,Overgrow:69,Blaze:69,Torrent:69,Truant:24,Chlorophyll:64};return bonus[a]??59}
const ROLE_ICONS={'Atacante físico':'⚔️','Atacante especial':'✨','Misto':'🔁','Muralha':'🛡️','Veloz':'💨','Suporte':'🌱'};
const ROLE_ATTRIBUTES={};
const ROLE_SUPPORT=new Set(['Shroomish','Breloom','Roselia','Gardevoir','Altaria','Ludicolo','Tropius','Sableye','Dusclops','Wobbuffet','Nosepass','Delcatty','Grumpig']);
const TOURNAMENT_TYPES=['Normal','Fire','Water','Electric','Grass','Ice','Fighting','Poison','Ground','Flying','Psychic','Bug','Rock','Ghost','Dragon','Dark','Steel'];
function monTypes(m){return [...new Set([SPEC[m.species]?.[0]||m.type||'Normal',MON_SECONDARY[m.species]].filter(Boolean))]}
function multiEffect(moveType,m){return monTypes(m).reduce((v,type)=>v*effective(moveType,type),1)}
function speciesValue(m){const s=SPEC[m.species]||SPEC.Zigzagoon;return Math.min(100,Math.round((s.slice(1,7).reduce((a,b)=>a+(Number(b)||0),0)-170)/5.3))}
function stageOfSpecies(species){let current=species,steps=0,seen=new Set();while(SPEC[current]?.[7]&&!seen.has(current)&&steps<3){seen.add(current);current=SPEC[current][7];steps++}return {final:current,steps}}
function futureValue(m){const evo=stageOfSpecies(m.species),s=SPEC[evo.final]||SPEC[m.species],total=(s||[]).slice(1,7).reduce((n,v)=>n+(Number(v)||0),0);const threshold=SPEC[m.species]?.[8]||50;const soon=(threshold-(m.level||1));return Math.min(100,Math.max(0,Math.round((total-180)/5+(evo.steps?Math.max(0,35-soon):0))))}
function roleOf(m){const s=SPEC[m.species]||SPEC.Zigzagoon;const atk=Number(s[2])||1,def=Number(s[3])||1,speed=Number(s[4])||1,spA=Number(s[5])||1,spD=Number(s[6])||1,hp=Number(s[1])||1;
 if(ROLE_SUPPORT.has(m.species)&&Math.max(atk,spA)<96)return 'Suporte';
 if(speed>=100&&Math.max(atk,spA)>=65)return 'Veloz';
 if((hp+def+spD)/3>Math.max(atk,spA)*1.17)return 'Muralha';
 if(Math.abs(atk-spA)<13&&Math.max(atk,spA)>68)return 'Misto';
 return atk>=spA?'Atacante físico':'Atacante especial';}
function moveStrength(m,name){const v=MOVES[name];if(!v)return 0;const [type,power,accuracy]=v;if(!power)return 0;const physical=GEN3_PHYSICAL.has(type);const attack=physical?(m.atk||50):(m.spAtk||50);const defenseBaseline=60+Number(m.level||1);const stab=monTypes(m).includes(type)?1.5:1;return (power*accuracy/100)*stab*(0.66+Math.min(2,attack/Math.max(30,defenseBaseline))*.35)}
function moveQuality(m){const values=(m.moves||[]).map(n=>moveStrength(m,n)).sort((a,b)=>b-a);const best=values[0]||0;const mix=new Set((m.moves||[]).map(n=>MOVES[n]?.[0]).filter(Boolean)).size;return Math.min(100,Math.round(best*.76+(values[1]||0)*.18+Math.max(0,mix-1)*9))}
function coverageOf(m,t){const categories=new Set((m.moves||[]).map(n=>MOVES[n]?.[0]).filter(Boolean));if(!categories.size)categories.add(m.type);const gym=nextGymType(t);let best=Math.max(...[...categories].map(tp=>effective(tp,gym)));const broad=TOURNAMENT_TYPES.reduce((n,tp)=>n+([...categories].some(attack=>effective(attack,tp)>1)?1:0),0);return Math.min(100,Math.round((broad/TOURNAMENT_TYPES.length)*80+Math.min(2,best)*14))}
function roleScore(m){const s=SPEC[m.species]||SPEC.Zigzagoon;const role=roleOf(m);if(role==='Suporte')return 88;if(role==='Veloz')return Math.min(100,55+s[4]*.26);if(role==='Muralha')return Math.min(100,40+(s[1]+s[3]+s[6])*.16);return Math.min(100,45+Math.max(s[2],s[5])*.33)}
// Displayed Pokémon power is based on the six *current Gen III stats*, not
// a mixture of species base stats, move names and a cosmetic level bonus.
// The HP stat always rises with level, so a Pokémon of the same species,
// IVs, EVs and Nature grows in the ranking whenever it levels up.
function combatPower(m){
 if(!m)return 0;
 const stats=levelStats(m.species,m.level,m.ivs||{},m.evs||{},m.nature||'Hardy');
 return STAT_KEYS.reduce((sum,key)=>sum+Math.max(0,Number(stats[key])||0),0);
}
function individualValue(m,t){const ability=(roleScore(m)*.65+abilityScore(m)*.35),future=futureValue(m),species=speciesValue(m),coverage=coverageOf(m,t),moves=moveQuality(m);const stage=Number(m.level)||1,goal=Math.max(15,PROGRESSION_LEVELS[t.stage]||15),readiness=Math.max(0,Math.min(1,stage/goal));
 // Individual scoring: 25% species, 20% coverage, 20% moves, 10% role, 10% potential.
 // Remaining 15% is team compatibility, applied in scoreTeamComposition.
 return (LEGEND_PROFILES[m.species]?1.35:1)*(.25*species+.20*coverage+.20*moves+.10*ability+.10*future)*(0.45+0.55*readiness)/.85;
}
function scoreTeamComposition(squad,t){if(!squad.length)return 0;let base=squad.reduce((n,m)=>n+individualValue(m,t),0),roleCount={},types={},attacks=new Set(),weakness={},physical=0,special=0,commonWeakness=0;
 for(const m of squad){const role=roleOf(m);roleCount[role]=(roleCount[role]||0)+1;for(const tp of monTypes(m))types[tp]=(types[tp]||0)+1;const best=(m.moves||[]).map(n=>MOVES[n]?.[0]).filter(Boolean);for(const tp of best)attacks.add(tp);if(['Atacante físico'].includes(role))physical++;if(['Atacante especial'].includes(role))special++;for(const tp of TOURNAMENT_TYPES){const v=multiEffect(tp,m);if(v>1)weakness[tp]=(weakness[tp]||0)+1}}
 let redundant=Object.values(types).reduce((n,x)=>n+Math.max(0,x-2)*5,0);let roleDiversity=Object.keys(roleCount).length*9;let typeDiversity=Object.keys(types).length*3;let moveDiversity=attacks.size*2.8;commonWeakness=Object.values(weakness).reduce((n,x)=>n+(x>=3?(x-2)*(x-2)*7:0),0);
 const target=nextGymType(t),answers=squad.filter(m=>[...(m.moves||[])].some(n=>effective(MOVES[n]?.[0],target)>1)).length;
 const upcoming=target?(Math.min(3,answers)*7):0;
 return base+(.15*Math.max(0,Math.min(100,squad.length*6+roleDiversity+typeDiversity+moveDiversity+upcoming-commonWeakness-redundant)))*squad.length-strongOverlapPenalty(squad)-commonWeakness*.65;
}
function strongOverlapPenalty(squad){const species={};let extra=0;for(const m of squad){species[m.species]=(species[m.species]||0)+1;if(species[m.species]>1)extra+=18}return extra}
function monScore(m,t){return individualValue(m,t)*1.9+combatPower(m)*.1}
function strengthOfTeam(t){return Math.round(scoreTeamComposition(t.team||[],t)*10)}
function bestOwnedMon(t){return [...(t.team||[]),...(t.pc||[])].sort((a,b)=>combatPower(b)-combatPower(a))[0]||null}
function allOwned(t){return [...(t.team||[]),...(t.pc||[])].filter(m=>m&&m.species)}
function computeIdealTeam(t,items,cap){
 const raw=items.map((m,i)=>({m,i,value:individualValue(m,t),role:roleOf(m),types:monTypes(m),moves:[...new Set((m.moves||[]).map(n=>MOVES[n]?.[0]).filter(Boolean))],weak:TOURNAMENT_TYPES.filter(tp=>multiEffect(tp,m)>1)}));
 const ranked=raw.sort((a,b)=>b.value-a.value||a.i-b.i).slice(0,Math.max(15,cap+8));
 let beam=[{members:[],indices:[],score:0}],width=10;
 for(let slot=0;slot<Math.min(cap,ranked.length);slot++){
  const expanded=[];
  for(const state of beam){const roles=new Set(state.members.map(x=>x.role)),types=new Set(state.members.flatMap(x=>x.types)),attacks=new Set(state.members.flatMap(x=>x.moves));
   for(let id=0;id<ranked.length;id++){
    if(state.indices.includes(id))continue;const c=ranked[id];
    const freshType=c.types.filter(tp=>!types.has(tp)).length,freshAttack=c.moves.filter(tp=>!attacks.has(tp)).length;
    const sharedWeak=c.weak.reduce((sum,tp)=>sum+state.members.filter(x=>x.weak.includes(tp)).length,0);
    const duplicates=state.members.filter(x=>x.m.species===c.m.species).length;
    const nextGym=nextGymType(t);const matchup=c.moves.some(tp=>effective(tp,nextGym)>1);
    let bonus=freshType*3+freshAttack*1.5+(!roles.has(c.role)?8:0)+(matchup?6:0)-sharedWeak*1.5-duplicates*16;
    if(settings.teamPolicy==='balanced')bonus+=freshType*3;
    if(settings.teamPolicy==='counter'&&matchup)bonus+=9;
    if(settings.teamPolicy==='strongest')bonus+=combatPower(c.m)*.028;
    if(t.personality==='Colecionador'&&!duplicates)bonus+=3;
    if(t.personality==='Estrategista'&&(c.role==='Muralha'||c.role==='Suporte'))bonus+=2;
    if(t.team.includes(c.m))bonus+=2.5;
    expanded.push({members:[...state.members,c],indices:[...state.indices,id],score:state.score+c.value+bonus});
   }
  }
  expanded.sort((a,b)=>b.score-a.score);const seen=new Set();beam=[];
  for(const row of expanded){const key=[...row.indices].sort((a,b)=>a-b).join(',');if(seen.has(key))continue;seen.add(key);beam.push(row);if(beam.length===width)break}
 }
 // The finalist is evaluated with the full six-member compatibility model.
 const finalists=beam.map(state=>({team:state.members.map(x=>x.m),score:scoreTeamComposition(state.members.map(x=>x.m),t)}));
 finalists.sort((a,b)=>b.score-a.score);
 return finalists[0]?.team||ranked.slice(0,cap).map(x=>x.m);
}
function rebalanceTeam(t,reason='rota'){
 if(!settings.teamOptimization||t.battle||t.trainingLoan)return;
 t.pc??=[];const cap=Math.max(1,Math.min(6,Number(settings.teamSize)||6));
 const items=[...new Set(allOwned(t))];if(!items.length)return;
 const signature=`${t.stage}:${t.badges}|${items.map(m=>m.species+':'+m.level+':'+(m.moves||[]).join('.')).join('|')}`;
 if(!t.needsRebalance&&t.lastTeamSignature===signature)return;
 t.lastTeamSignature=signature;
 const ideal=computeIdealTeam(t,items,cap),old=t.team.slice(),membersChanged=old.length!==ideal.length||old.some(m=>!ideal.includes(m));
 const currentScore=scoreTeamComposition(old,t),idealScore=scoreTeamComposition(ideal,t);
 const threshold=Math.max(0,Number(settings.squadStability)||0);
 const shouldReplace=membersChanged&&(old.length<Math.min(cap,items.length)||idealScore>currentScore+threshold);
 // Keep the six selected slots in order. Pure reordering isn't a 'team change'.
 const next=shouldReplace?[...old.filter(m=>ideal.includes(m)),...ideal.filter(m=>!old.includes(m))]:old.slice();
 if(next.length>cap)next.length=cap;
 const picked=new Set(next),rest=items.filter(m=>!picked.has(m));t.team=next;t.pc=rest;
 const spare=rest.filter(m=>futureValue(m)>=70&&m.level<Math.max(15,...next.map(x=>x.level))-6).sort((a,b)=>futureValue(b)-futureValue(a))[0];
 const project=spare&&settings.futureInvestment?{species:spare.species,level:spare.level,target:Math.max(20,Math.min(60,Math.round(next.reduce((n,m)=>n+m.level,0)/Math.max(1,next.length))-3))}:null;
 t.trainingProject=project;t.teamReason=shouldReplace?`Equipe adaptada para ${nextGymType(t)}; cobertura, funções e resistência`: 'Equipe mantida: trocas sem vantagem significativa foram evitadas';
 if(shouldReplace){t.teamChanges=(t.teamChanges||0)+1;let gained=next.filter(m=>!old.includes(m)).map(m=>m.species),lost=old.filter(m=>!next.includes(m)).map(m=>m.species);let detail=gained.length?`${gained.join(', ')} entraram; ${lost.join(', ')||'vagas livres'} foram para o PC.`:'Completou as vagas livres.';
   const msg=`🧠 ${t.name} reorganizou a equipe: ${detail}`;t.teamLog??=[];t.teamLog.unshift(msg);t.teamLog=t.teamLog.slice(0,16);emit(t,'story',msg);remember(t,`Time estratégico: ${next.map(m=>m.species).join(', ')}.`)}
 t.needsRebalance=false;
}
function acquireMon(t,m){if(!legendaryAvailable(m.species,t))return false;t.pc??=[];t.captures=(t.captures||0)+1;if(t.isUserBot)window.ELWTelemetry?.event("pokemon_capture",m.species);t.routeCaught??={};t.routeCaught[t.location]=(t.routeCaught[t.location]||0)+1;
 if(!t.dex.includes(m.species))t.dex.push(m.species);
 const cap=Math.min(6,Math.max(1,Number(settings.teamSize)||6));
 if(t.team.length<cap)t.team.push(m);
 else if(settings.pcStorage!==false)t.pc.push(m);
 else{const pool=[...t.team,m];const ideal=computeIdealTeam(t,pool,cap);if(ideal.includes(m)){const dropped=t.team.find(x=>!ideal.includes(x));t.team=t.team.filter(x=>x!==dropped);t.team.push(m)}else remember(t,`Libertou ${m.species}: não acrescentava algo à equipe.`)}
 t.needsRebalance=true;if(settings.teamOptimization)rebalanceTeam(t,'captura');
}
function shouldCapture(t,foe){if(!settings.capture||!t.bag.Pokeball)return false;if(LEGEND_PROFILES[foe.species])return legendaryAvailable(foe.species,t);
 if(settings.collectionGoal&&!t.dex.includes(foe.species))return true;
 const seen=t.dex.includes(foe.species),items=allOwned(t),cap=Math.min(6,Number(settings.teamSize)||6);if(items.length<cap)return Math.random()<settings.captureAggression/100;
 const promising=futureValue(foe)>75,important=individualValue(foe,t)>Math.min(...t.team.map(m=>individualValue(m,t)))+5;
 const uncovered=!(t.team||[]).some(m=>monTypes(m).some(tp=>monTypes(foe).includes(tp)));
 return (!seen||foe.shiny||promising||important||uncovered)&&Math.random()<settings.captureAggression/100;
}
function teamAnalysis(t){const mons=t.team||[],roles=[...new Set(mons.map(roleOf))];const project=t.trainingProject;const types=[...new Set(mons.flatMap(monTypes))];return {roles,types,project,loan:t.trainingLoan,abilities:[...new Set(mons.map(m=>ability(m)).filter(Boolean))],score:strengthOfTeam(t),reason:t.teamReason||'',next:nextGymType(t),routes:(t.routeLog||[]).slice(0,3)}}
function remember(t,msg){t.mem.unshift(msg);if(t.mem.length>12)t.mem.pop()}
function emit(t,kind,msg,important=false){let ev={time:++clock,id:t.id,kind,msg,important};feed.unshift(ev);if(feed.length>450)feed.pop();t.events.unshift(ev);if(t.events.length>90)t.events.pop();if(important&&camera==='auto')featured=t.id;return ev}
function advance(t,txt){t.stage++;if(t.pc?.length)rebalanceTeam(t,'próxima rota');t.location=CAMPAIGN[t.stage]?.[0]?.[0]||STAGES[Math.min(t.stage,STAGES.length-1)][0];t.storyArrived=false;t.introReady=false;t.storyDwell=0;emit(t,'story',txt||STAGES[Math.min(t.stage,STAGES.length-1)][1]);t.cooldown=2+rnd(5)}
const PROGRESSION_LEVELS={16:9,17:12,18:15,19:18,20:24,21:29,22:34,23:39,24:44,25:49,26:54,27:60};
const CENTER_CLOSEST={'Caminhão':'Littleroot','Route 101':'Oldale Town','Route 102':'Oldale Town','Route 103':'Oldale Town',
 'Petalburg Woods':'Petalburg City','Route 104':'Rustboro City','Rusturf Tunnel':'Rustboro City','Granite Cave':'Dewford Town',
 'Oceanic Museum':'Slateport City','Route 110':'Slateport City','Route 111':'Mauville City','Meteor Falls':'Fallarbor Town',
 'Mt. Chimney':'Lavaridge Town','Jagged Pass':'Lavaridge Town','Route 118':'Mauville City',
 'Route 119':'Fortree City','Route 120':'Fortree City','Weather Institute':'Fortree City',
 'Magma Hideout':'Lavaridge Town','Aqua Hideout':'Lilycove City','Mt. Pyre':'Lilycove City',
 'Route 124':'Mossdeep City','Route 126':'Mossdeep City','Route 128':'Ever Grande City',
 'Seafloor Cavern':'Sootopolis City','Sky Pillar':'Pacifidlog Town','Victory Road':'Ever Grande City',
 'Liga Pokémon':'Ever Grande City','Ever Grande City':'Ever Grande City'};
function nearestCenter(t){const loc=t.location||'';if(CENTER_CLOSEST[loc])return CENTER_CLOSEST[loc];for(const c of CITY_PATH){if(loc.includes(c)||loc.includes(c.replace(' City','').replace(' Town','')))return c}const idx={0:'Oldale Town',1:'Oldale Town',2:'Oldale Town',3:'Oldale Town',4:'Oldale Town',5:'Oldale Town',6:'Oldale Town',7:'Oldale Town',8:'Oldale Town',9:'Oldale Town',10:'Oldale Town',11:'Oldale Town',12:'Oldale Town',13:'Oldale Town',14:'Oldale Town',15:'Oldale Town',16:'Petalburg City',17:'Rustboro City',18:'Slateport City',19:'Rustboro City',20:'Dewford Town',21:'Mauville City',22:'Lavaridge Town',23:'Petalburg City',24:'Fortree City',25:'Mossdeep City',26:'Sootopolis City',27:'Ever Grande City'};return idx[t.stage]||'Oldale Town'}
function heal(t){for(const m of [...t.team,...(t.pc||[])]){m.hp=m.maxHp;m.status=null;m.pp??={};for(const move of m.moves||[])m.pp[move]=movePP(move)}t.healingCount=(t.healingCount||0)+1;t.lastHealTick=turns;emit(t,'heal',`💗 ${t.name} recuperou HP, PP e status de todos os Pokémon no Centro Pokémon de ${t.healing?.city||nearestCenter(t)}.`)}
function wipedTeam(t){return !!(t.team?.length)&&t.team.every(m=>!m||Number(m.hp)<=0)}
function healingNeeded(t,important=false){if(!t.team?.length||t.battle||t.healing)return false;const mons=t.team,avg=mons.reduce((a,m)=>a+m.hp/Math.max(1,m.maxHp),0)/mons.length;
 const fainted=mons.some(m=>m.hp<=0);const status=mons.some(m=>!!m.status);const noPP=mons.some(m=>(m.moves||[]).length&&m.moves.every(x=>Number.isFinite(m.pp?.[x])&&m.pp[x]<=0));
 return fainted||status&&avg<.92||noPP||avg<settings.centerThreshold/100||(important&&avg<.92)}
function requestCenterVisit(t,reason='recuperar a equipe'){
 if(t.healing||t.battle||!t.team?.length)return false;
 // Even if visits are disabled, a full team wipe must remain recoverable.
 const wipe=wipedTeam(t);
 // Partial HP/PP recovery is a real journey: no free cure or relocation.
 // Only a full party wipe authorizes a respawn at the Pokémon Center.
 const city=nearestCenter(t);t.healing={from:t.location,city,phase:'arrival',reason,wiped:wipe,blackoutArrived:false};
 t.location=`Centro Pokémon • ${city}`;t.cooldown=3;
 emit(t,'story',wipe?`🆘 ${t.name} perdeu toda a equipe e será levado ao Centro Pokémon de ${city}.`:
   `🏥 ${t.name} caminha de ${t.healing.from} até o Centro Pokémon de ${city} para ${reason}.`);
 return true
}
function centerVisitStep(t){
 if(!t.healing)return false;
 const api=window.emeraldOfficialWorld;
 const arrived=!api||(t.officialMap===api.resolve(t.location)&&t.storyArrived);
 if(!arrived)return true; // Não curar nem voltar antes de chegar fisicamente.
 if(t.cooldown>0){t.cooldown--;return true}
 if(t.healing.phase==='arrival'){
  heal(t);t.healing.phase='return';t.cooldown=3;return true;
 }
 if(t.healing.phase==='return'){
  const dest=t.healing.from;
  t.location=dest;t.healing.phase='returning';t.storyArrived=false;t.introReady=false;
  t.walkPath=[];t.cooldown=2;
  emit(t,'story',`🚶 ${t.name} saiu do Centro Pokémon e segue de volta a ${api?.label?.(dest)||dest}.`);
  return true;
 }
 if(t.healing.phase==='returning'){
  const dest=t.healing.from;t.healing=null;t.cooldown=2;
  emit(t,'story',`✅ ${t.name} chegou a ${api?.label?.(dest)||dest} após recuperar a equipe.`);
  return true;
 }
 return true;
}
function partyTrainingMembers(t){return t.team.filter(m=>m&&m.species).sort((a,b)=>a.level-b.level)}
function readiness(t,target){const party=partyTrainingMembers(t);if(!party.length)return {ready:false,min:0,avg:0,required:1};
 const required=Math.min(party.length,Math.max(1,Math.min(6,Number(settings.partyReadiness)||4)));const top=party.slice(-required);
 return {ready:top.every(m=>m.level>=target)&&!(t.stage>=27&&settings.capture&&party.length<Number(settings.teamSize)&&settings.partyReadiness>=Number(settings.teamSize)),min:Math.min(...top.map(m=>m.level)),avg:Math.round(top.reduce((n,m)=>n+m.level,0)/top.length),required}
}
function getTrainingTarget(t){if(t.champion||settings.grinding===false)return 0;const base=PROGRESSION_LEVELS[t.stage]||0;return base?Math.min(levelCapFor(t),base+(t.personality==='Competitivo'?2:0)):0}
const TRAINING_ZONES={16:'Route 102',17:'Route 102',18:'Petalburg Woods',19:'Route 104',20:'Granite Cave',21:'Route 110',22:'Route 112',23:'Route 111',24:'Route 119',25:'Route 120',26:'Route 126',27:'Victory Road'};
function startTrainingTrip(t){
 if(t.grindTrip)return;const zone=TRAINING_ZONES[t.stage]||'Route 102';const current=getScene(t.location);
 if(t.location===zone||current.kind==='forest'||current.kind==='cave'||current.kind==='route'||current.kind==='ocean'||current.kind==='desert'){return}
 t.grindTrip={origin:t.location,zone};t.location=zone;t.walkMap='';t.cooldown=5;
 emit(t,'story',`🥾 ${t.name} foi de ${t.grindTrip.origin} até ${zone} para treinar e procurar Pokémon selvagens.`);
}
function finishTrainingTrip(t){if(!t.grindTrip)return false;const origin=t.grindTrip.origin;const zone=t.grindTrip.zone;t.grindTrip=null;t.location=origin;t.walkMap='';t.cooldown=5;emit(t,'story',`✅ ${t.name} voltou de ${zone} para ${origin} com a equipe preparada.`);return true}
// Percursos opcionais de Hoenn. A sequência principal dos oito ginásios continua correta;
// cada treinador escolhe passeios secundários conforme sua personalidade e capturas.
const DETOUR_ROUTES={
16:[['Route 102','capturar parceiros antes do primeiro ginásio','capture'],['Petalburg Woods','explorar a mata e procurar Shroomish','explore'],['Route 104','ganhar experiência contra treinadores','train']],
17:[['Rusturf Tunnel','procurar Pokémon de caverna','capture'],['Route 104','revisitar os treinadores da ponte','train'],['Granite Cave','procurar raridades na caverna','explore']],
18:[['Route 110','enfrentar treinadores e colher itens','train'],['Granite Cave','explorar as galerias opcionais','explore'],['Route 103','procurar novos parceiros antes de Mauville','capture']],
19:[['Petalburg Woods','treinar na floresta antes do desafio de pedra','train'],['Route 104','procurar opções de água e planta','capture'],['Rusturf Tunnel','revisitar os túneis','explore']],
20:[['Granite Cave','treinar para o ginásio de luta','train'],['Route 106','pesquisar Pokémon na costa de Dewford','capture'],['Route 107','explorar a costa com Mr. Briney','explore']],
21:[['Route 110','treinar nos arredores de Mauville','train'],['Route 117','procurar parceiros para a equipe','capture'],['Verdanturf Town','conhecer a área do Day Care','explore']],
22:[['Fiery Path','procurar Pokémon resistentes ao fogo','capture'],['Route 113','visitar a rota de cinzas','explore'],['Jagged Pass','treinar no relevo vulcânico','train']],
23:[['Route 111','explorar o deserto com os Go-Goggles','explore'],['Rusturf Tunnel','usar o atalho para Petalburg','train'],['Mirage Tower','procurar um fóssil raro','capture']],
24:[['New Mauville','explorar a instalação elétrica','explore'],['Route 119','capturar parceiros na grama alta','capture'],['Route 120','treinar para Winona','train']],
25:[['Safari Zone','procurar novas espécies','capture'],['Mt. Pyre','treinar e investigar os arredores','train'],['Route 121','explorar um caminho alternativo','explore']],
26:[['Shoal Cave','explorar as cavernas costeiras','explore'],['Route 124','procurar aliados aquáticos','capture'],['Route 126','treinar no oceano de Hoenn','train']],
27:[['Victory Road','ganhar experiência antes da Liga','train'],['Route 128','explorar os arredores de Ever Grande','explore'],['Meteor Falls','preparar a equipe para a Liga','capture']]
};
function routePreference(t,kind){const p=t.personality;
 if(kind==='capture')return p==='Colecionador'||p==='Pesquisador'?2.5:p==='Aventureiro'?1.45:1;
 if(kind==='train')return p==='Competitivo'||p==='Persistente'||p==='Treinador'?2.6:p==='Estrategista'?2.1:1;
 return p==='Aventureiro'||p==='Sortudo'?3:p==='Cauteloso'?.5:1;
}
function chooseDetour(t,list){let total=0;const weights=list.map(([place,goal,kind],i)=>{const trait=kind==='train'?t.traits.aggression:kind==='capture'?t.traits.explore:t.traits.explore;
   const w=(.5+trait)*routePreference(t,kind)*(settings.routeProfile==='explorer'&&kind==='explore'?2.2:1)*(settings.routeProfile==='speedrun'&&kind==='train'?2.2:1);
   total+=w;return w});let draw=Math.random()*total;for(let i=0;i<list.length;i++){draw-=weights[i];if(draw<=0)return list[i]}return list[list.length-1]}
function sideRouteStep(t){const stage=t.stage;if(stage<16||stage>27||!settings.explorationFreedom)return false;
 t.detoursDone??={};t.routeLog??=[];
 if(t.detour){if(t.battle||t.healing)return true;
   if(t.detour.stage!==stage){t.detour=null;return false}
   t.detour.steps--;
   if(t.detour.steps>0){if(t.detour.steps%7===0&&wildHabitat(t)&&Math.random()<.22){wild(t)}return true}
   const ended=t.detour;t.location=ended.origin;t.walkMap='';t.walkPath=[];t.detour=null;t.cooldown=3;
   emit(t,'story',`🧭 ${t.name} concluiu a visita a ${ended.place} e retomou o objetivo principal.`);
   return true;
 }
 if(t.detoursDone[stage])return false;
 t.detoursDone[stage]=true;
 const chance=Math.min(.96,(Number(settings.explorationFreedom)||0)/100*(.45+t.traits.explore*.85))*(settings.routeProfile==='speedrun'?.45:1);
 if(Math.random()>chance)return false;
 let options=DETOUR_ROUTES[stage]||[];if(!options.length)return false;
 const [place,goal,kind]=chooseDetour(t,options),origin=t.location;
 t.detour={origin,place,goal,kind,stage,steps:10+Math.floor(t.traits.explore*12)+rnd(8)};
 t.location=place;t.walkMap='';t.walkPath=[];t.cooldown=1;
 t.routeLog.unshift(`${place} · ${goal}`);t.routeLog=t.routeLog.slice(0,9);
 emit(t,'story',`🗺️ ${t.name} escolheu visitar ${place} para ${goal}.`,false);
 return true;
}
// Treino de um Pokémon de reserva de verdade: troca temporária com um titular,
// sobe níveis na grama/caverna e devolve o titular ao PC/equipe ao final.
function ensureMonUid(m){if(!m.uid)m.uid='p'+Math.random().toString(36).slice(2);return m.uid}
function beginProspectTraining(t,target){if(!settings.futureInvestment||t.stage<21||t.stage>=27||t.trainingLoan||t.loanDoneStages?.[t.stage]||t.team.length<6||!t.pc?.length||t.grindSessions<4)return false;
 let candidate=t.pc.filter(m=>futureValue(m)>=65&&m.level<target-7).sort((a,b)=>futureValue(b)-futureValue(a)||b.level-a.level)[0];
 if(!candidate||Math.random()>Math.min(.86,.34+t.traits.strategy*.44))return false;
 const index=t.team.map((m,i)=>({i,v:individualValue(m,t)})).sort((a,b)=>a.v-b.v)[0].i;
 const old=t.team[index],at=t.pc.indexOf(candidate);ensureMonUid(old);ensureMonUid(candidate);
 t.pc[at]=old;t.team[index]=candidate;t.trainingLoan={uid:candidate.uid,original:old.uid,stage:t.stage,target,until:t.grindSessions+8};
 t.loanDoneStages??={};t.loanDoneStages[t.stage]=true;
 emit(t,'level',`🌱 ${t.name} chamou ${candidate.species} do PC para treinar com os titulares antes do próximo ginásio.`);
 t.needsRebalance=true;return true;
}
function finishProspectTraining(t){const loan=t.trainingLoan;if(!loan)return false;
 const candidate=t.team.find(m=>m.uid===loan.uid),original=t.pc.find(m=>m.uid===loan.original);
 if(candidate&&original){t.team[t.team.indexOf(candidate)]=original;t.pc[t.pc.indexOf(original)]=candidate}
 t.trainingLoan=null;t.needsRebalance=true;
 const name=candidate?.species||'reserva';emit(t,'level',`✅ ${t.name} concluiu o treino de ${name} e voltou a avaliar os seis melhores parceiros.`);
 rebalanceTeam(t,'final do treino de reserva');return true;
}
function grindOneStep(t,target){target=Math.min(target,levelCapFor(t));if(!t.team.length||t.battle||t.healing)return;
 startTrainingTrip(t);if(t.cooldown>0)return;
 if(t.trainingLoan&&(t.grindSessions>=t.trainingLoan.until||t.team.some(m=>m.uid===t.trainingLoan.uid&&m.level>=target-1))){finishProspectTraining(t)}
 else if(!t.trainingLoan){beginProspectTraining(t,target)}
 const party=partyTrainingMembers(t);const needed=party.filter(m=>m.level<target);
 t.grindTarget=target;t.grindSessions=(t.grindSessions||0)+1;
 if(t.stage>=27&&settings.capture&&settings.partyReadiness>=Number(settings.teamSize)&&t.team.length<Number(settings.teamSize)){
  if(t.pc?.length){rebalanceTeam(t,'preparação para a Liga');if(t.team.length>=Number(settings.teamSize))return}
  if(t.bag.Pokeball<5){t.bag.Pokeball+=5;t.money=Math.max(0,t.money-600)}
  const species=pick(REGIONAL_WILD['Victory Road']||['Golbat','Aron','Lairon','Hariyama']);startBattle(t,{species,level:38+rnd(8)},'wild');
  emit(t,'level',`🎒 ${t.name} procura o ${t.team.length+1}º Pokémon para completar a equipe antes da Liga.`);return
 }
 if(!needed.length)return;
 if(t.grindSessions%5===1||t.grindSessions%9===0){if(t.bag.Pokeball<4&&t.money>=600){t.money-=600;t.bag.Pokeball+=5;emit(t,'story',`🛍️ ${t.name} comprou mais Pokébolas para treinar e capturar nas rotas.`)}}
 // Battles grant organic EXP and can damage the team. The training drills below
 // deliberately focus on its lowest-level Pokémon rather than overlevelling the lead.
 if(settings.grindWildBattles&&t.grindSessions%4===0){
  const lv=Math.min(45,Math.max(3,Math.round(Math.min(target-2,Math.max(...party.map(m=>m.level))-2))));
  const species=pick(REGIONAL_WILD[t.location]||WILD);if(wildHabitat(t)){startBattle(t,{species,level:lv},'wild')}else{expGain(t,needed[0],Math.max(40,Math.round(expNeeded(needed[0].level)*.4)))}
  emit(t,'level',`🌿 Grinding de ${t.name}: treino selvagem em ${t.location} para alcançar Nv. ${target}.`);return
 }
 const mon=needed[0];const basic=expNeeded(mon.level);const gain=Math.max(35,Math.round(basic*(.58+Math.random()*.26)*Math.max(.2,settings.grindIntensity/100)));
 expGain(t,mon,gain);
 if(settings.shareTraining&&needed.length>1){const other=needed[1];expGain(t,other,Math.round(gain*.43))}
 if(t.grindSessions%6===0){emit(t,'level',`💪 ${t.name} está treinando ${mon.species}: Nv. ${mon.level}/${target} para ${t.badges===8?'a Liga':`o próximo ginásio`}.`)}
 t.cooldown=1+rnd(2);
}
// As equipes devem ter parceiros reais antes dos ginásios. Sem esta rotina,
// vários treinadores chegavam a Wattson ainda com somente o inicial e morriam centenas de vezes.
const PARTY_TARGETS={16:2,17:2,18:2,19:3,20:3,21:4,22:4,23:5,24:5,25:6,26:6,27:6};
function ensurePartyStep(t){
 if(!settings.capture||t.battle||t.healing||t.champion||t.stage<16||t.stage>27)return false;
 const target=Math.min(Number(settings.teamSize)||6,(PARTY_TARGETS[t.stage]||2)+((t.losses||0)>=5?1:0));
 if(allOwned(t).length>=target){t.teamSearchAttempts=0;return false}
 if((t.teamSearchAttempts||0)>30){
  // Nunca bloqueia a campanha permanentemente se uma equipe de seis não puder ser completada.
  // O treinador tentará novamente depois de outras missões ou treinamentos.
  t.teamSearchAttempts=0;t.teamSearchPauseUntil=t.steps+32;return false;
 }
 if(t.steps<(t.teamSearchPauseUntil||0))return false;
 t.teamSearchAttempts=(t.teamSearchAttempts||0)+1;
 if(t.bag.Pokeball<3){
  if(t.money>=600){t.money-=600;t.bag.Pokeball+=5;emit(t,'story',`🛍️ ${t.name} comprou Pokébolas para completar a equipe.`)}
  else if(t.bag.Pokeball<=0){t.money+=150;t.cooldown=1;return true}
 }
 const zone=TRAINING_ZONES[t.stage]||'Route 102';
 if(t.location!==zone){if(!t.partyHuntOrigin)t.partyHuntOrigin=t.location;t.location=zone;t.storyArrived=false;t.walkMap='';t.cooldown=2;return true}
 if(!t.storyArrived){return true}
 const pool=(REGIONAL_WILD[zone]||WILD).filter(species=>SPEC[species]&&!LEGEND_PROFILES[species]&&!allOwned(t).some(m=>m.species===species));
 if(!pool.length){t.teamSearchAttempts=31;return false}
 const targetType=nextGymType(t);
 const candidates=pool.map(species=>{
  const mon=createMon(species,Math.max(5,Math.min(levelCapFor(t),6+Math.floor(t.stage*.55))));
  const offensive=Math.max(...(mon.moves||[]).map(move=>effective(MOVES[move]?.[0],targetType)));
  const survive=multiEffect(targetType,mon);const overlap=t.team.some(m=>monTypes(m).some(type=>monTypes(mon).includes(type)));
  return {species,score:offensive*6-survive*3-(overlap?4:0)+Math.random()*5};
 }).sort((a,b)=>b.score-a.score);
 const species=candidates[0].species;
 const highest=t.team.length?Math.max(...t.team.map(m=>m.level)):8;
 const level=Math.max(3,Math.min(levelCapFor(t)-1,Math.max(5,highest-2)));
 if(startBattle(t,{species,level},'trainingWild')){
  t.battle.teamRecruit=true;
  emit(t,'story',`🌿 ${t.name} procurou ${species} selvagem na área de ${zone} para reforçar o time.`,false);
  return true;
 }
 return false;
}
function finishPartyTrip(t){
 if(!t.partyHuntOrigin)return false;
 const origin=t.partyHuntOrigin;t.partyHuntOrigin=null;
 if(t.location!==origin){t.location=origin;t.walkMap='';t.storyArrived=false;t.cooldown=2;return true}
 return false;
}
function expGain(t,m,amount){
 if(!m||!t)return;
 const cap=levelCapFor(t);if(m.level>=cap){m.exp=0;return}
 m.exp+=Math.max(0,Math.floor(Number(amount||0)*settings.expMultiplier));
 while(m.level<cap&&m.level<100&&m.exp>=expNeeded(m.level)){
  const before={...m},oldMax=m.maxHp,oldHp=m.hp,needed=expNeeded(m.level);
  m.exp-=needed;m.level++;m.friendship=clamp((m.friendship||70)+3,0,255);Object.assign(m,levelStats(m.species,m.level,m.ivs,m.evs,m.nature));
  m.hp=oldHp>0?Math.min(m.maxHp,oldHp+m.maxHp-oldMax):0;
  for(const name of learnedMoves(m.species,m.level))teachMove(t,m,name);
  const gains=[['maxHp','HP'],['atk','Ataque'],['def','Defesa'],['spAtk','At. Esp.'],['spDef','Def. Esp.'],['speed','Velocidade']]
   .filter(([key])=>m[key]>before[key]).map(([key,label])=>`${label} +${m[key]-before[key]}`).join(' • ');
  emit(t,'level',`${m.species} subiu para Nv. ${m.level}! ${gains}`);
  maybeEvolve(t,m);t.needsRebalance=true;
 }
 // XP excedente nunca acumula no teto para saltar vários níveis após uma insígnia.
 if(m.level>=cap||m.level>=100)m.exp=0;
}
const WEATHER_NAMES={clear:'Céu limpo',sun:'Sol forte',rain:'Chuva',sand:'Tempestade de areia',snow:'Neve'};
let worldWeather='clear';
Object.assign(ABILITY_HINT,{Lotad:'Swift Swim',Lombre:'Rain Dish',Ludicolo:'Swift Swim',Seedot:'Chlorophyll',Nuzleaf:'Chlorophyll',Shiftry:'Chlorophyll',Cacnea:'Sand Veil',Cacturne:'Sand Veil',Kyogre:'Drizzle',Groudon:'Drought'});
function ability(m){return LEGEND_PROFILES[m.species]?.ability||m.ability||ABILITY_HINT[m.species]||''}
function weatherBoost(type,w){return w==='sun'?(type==='Fire'?1.5:type==='Water'?.5:1):w==='rain'?(type==='Water'?1.5:type==='Fire'?.5:1):1}
function battleSpeed(m,w){return m.speed*stageRatio(clamp(m.statStages?.speed||0,-6,6))*(m.status==='paralysis'?.25:1)*((w==='sun'&&ability(m)==='Chlorophyll'||w==='rain'&&ability(m)==='Swift Swim'||w==='sand'&&ability(m)==='Sand Rush'||w==='snow'&&ability(m)==='Slush Rush')?2:1)}
function enterBattle(m,b){if(!m||m.hp<=0)return;if(ability(m)==='Air Lock'){b.weather='clear';b.weatherTurns=0;b.history.unshift(`${m.species}: Air Lock dissipou o clima da batalha.`);return}const w={Drizzle:'rain',Drought:'sun','Sand Stream':'sand','Snow Warning':'snow'}[ability(m)];if(w){b.weather=w;b.weatherTurns=-1;b.history.unshift(`${m.species}: ${ability(m)} ativou ${WEATHER_NAMES[w]} por 5 turnos.`)}}
/** V3.9: Gen-III-style residual sequence for the original offline AI simulation.
 * Weather first; per-Pokemon recovery/Leech Seed before poison/burn.
 * Does not claim full cartridge event-script parity.
 */
function resolveBattleResidual(own,foe,field){
 const participants=[own,foe].filter(m=>m&&m.hp>0);
 const lose=(m,dmg,why)=>{if(m.hp<=0)return;const actual=Math.min(m.hp,dmg);m.hp-=actual;
  if(actual)field.history.unshift(`${m.species}: −${actual} HP (${why}).`);};
 const heal=(m,amount,why)=>{if(m.hp<=0||m.hp>=m.maxHp)return;
  const gain=Math.min(m.maxHp-m.hp,amount);m.hp+=gain;
  if(gain)field.history.unshift(`${m.species}: +${gain} HP (${why}).`);};
 // The whole field's damaging weather is processed before held-item healing.
 for(const m of participants){
  if(field.weather==='sand'&&!monTypes(m).some(t=>['Rock','Ground','Steel'].includes(t))&&!['Sand Veil','Sand Rush'].includes(ability(m)))
   lose(m,Math.max(1,Math.floor(m.maxHp/16)),'Sandstorm');
  if(field.weather==='snow'&&!monTypes(m).includes('Ice'))
   lose(m,Math.max(1,Math.floor(m.maxHp/16)),'Hail');
 }
 for(const m of participants.sort((a,b)=>battleSpeed(b,field.weather)-battleSpeed(a,field.weather))){
  if(m.hp<=0)continue;
  if(ability(m)==='Shed Skin'&&m.status&&Math.random()<1/3){m.status=null;m.toxicTurns=0;field.history.unshift(`${m.species} se curou com Shed Skin.`);}
  if(field.weather==='rain'&&ability(m)==='Rain Dish')heal(m,Math.max(1,Math.floor(m.maxHp/16)),'Rain Dish');
  if(m.heldItem==='Leftovers')heal(m,Math.max(1,Math.floor(m.maxHp/16)),'Leftovers');
  if(m.leechSeed&&m.hp>0){const other=m===own?foe:own;
   const drained=Math.min(m.hp,Math.max(1,Math.floor(m.maxHp/8)));lose(m,drained,'Leech Seed');
   if(other?.hp>0)heal(other,drained,'Leech Seed');
  }
  if(m.hp>0&&['poison','burn','toxic'].includes(m.status)){
   if(m.status==='toxic')m.toxicTurns=clamp((m.toxicTurns||0)+1,1,15);
   const dmg=Math.max(1,Math.floor(m.maxHp*(m.status==='toxic'?m.toxicTurns/16:1/8)));
   lose(m,dmg,m.status);
  }
  if(m.hp>0&&field.weather==='sun'&&ability(m)==='Solar Power')lose(m,Math.max(1,Math.floor(m.maxHp/8)),'Solar Power');
 }
 tickWeather(field);
}
function suppressWeather(b,own,foe){if([own,foe].some(m=>m?.hp>0&&ability(m)==='Air Lock')){b.weather='clear';b.weatherTurns=0}}
function tickWeather(b){if(b.weatherTurns>0&&--b.weatherTurns===0){b.weather='clear';b.history.unshift('O clima da batalha terminou.')}}
function stageRatio(stage){return stage>=0?(2+stage)/2:2/(2-stage)}
function accuracyRatio(stage){return stage>=0?(3+stage)/3:3/(3-stage)}
function effectiveAccuracy(a,b,move,w){
 if(['Swift','AerialAce'].includes(move.name))return 100;
 const diff=clamp((a.statStages?.accuracy||0)-(b.statStages?.evasion||0),-6,6);
 return clamp(move.accuracy*accuracyRatio(diff)*(w==='sand'&&ability(b)==='Sand Veil'?.8:1),0,100);
}

function damageStats(a,b,type,w,critical=false){
 const physical=GEN3_PHYSICAL.has(type),attackKey=physical?'atk':'spAtk',defKey=physical?'def':'spDef';
 let aStage=clamp(a.statStages?.[attackKey]||0,-6,6),dStage=clamp(b.statStages?.[defKey]||0,-6,6);if(critical){aStage=Math.max(0,aStage);dStage=Math.min(0,dStage)}
 let atk=a[attackKey]*stageRatio(aStage),def=b[defKey]*stageRatio(dStage);
 if(w==='sun'&&ability(a)==='Solar Power'&&!physical)atk*=1.5;
 // Overgrow/Blaze/Torrent change move power, handled by the damage modifier instead of double-buffing raw Attack.
 if(ability(b)==='Thick Fat'&&['Fire','Ice'].includes(type))atk*=.5;
 if(ability(b)==='Marvel Scale'&&b.status&&physical)def*=1.5;
 if(a.status==='burn'&&physical&&ability(a)!=='Guts')atk*=.5;
 if(a.status&&ability(a)==='Guts'&&physical)atk*=1.5;
 if(physical&&a.heldItem==='Choice Band')atk*=1.5;
 return {atk:Math.max(1,Math.floor(atk)),def:Math.max(1,Math.floor(def))};
}
function moveScore(a,b,name,w){
 const move=MOVES[name]||MOVES.Struggle;
 if(move[1]===0){
  const improving=['CalmMind','BulkUp','SwordsDance','Agility','DragonDance','IronDefense','DoubleTeam'].includes(name),heal=name==='Recover';
  if(heal)return a.hp>0&&a.hp/a.maxHp<.55?Math.round((1-a.hp/a.maxHp)*65):0;
  if(name==='Rest')return a.hp>0&&a.hp/a.maxHp<.4?40:0;
  if(['Hypnosis','SleepPowder','Sing'].includes(name))return b.status?0:40*move[2]/100;
  if(name==='WillOWisp')return b.status||monTypes(b).includes('Fire')?0:28;
  if(name==='LeechSeed')return b.leechSeed||monTypes(b).includes('Grass')?0:25;
  if(name==='ThunderWave')return b.status||monTypes(b).includes('Ground')?0:Math.max(15,b.speed>a.speed?35:20);
  if(name==='StunSpore')return b.status?0:25;
  if(name==='Toxic')return b.status||monTypes(b).some(t=>['Poison','Steel'].includes(t))?0:28;
  if(improving)return (a.statStages?.[name==='CalmMind'?'spAtk':name==='Agility'?'speed':'atk']||0)>=4?0:Math.round(Math.max(0,30-(a.statStages?.atk||0)*4));
  if(name==='Protect')return 4;
  return 0;
 }
 let mult=name==='Struggle'?1:multiEffect(move[0],b);
 if(move[0]==='Ground'&&ability(b)==='Levitate')mult=0;
 if(!mult)return 0;
 const {atk,def}=damageStats(a,b,move[0],w);
 return (Math.floor(Math.floor((Math.floor(2*a.level/5)+2)*move[1]*atk/def)/50)+2)*mult*(monTypes(a).includes(move[0])&&name!=='Struggle'?1.5:1)*weatherBoost(move[0],w)*move[2]/100*.925;
}
function captureChance(foe){const hp=foe.hp/foe.maxHp;if(LEGEND_PROFILES[foe.species])return clamp(.015+(1-hp)*.065+(foe.status?.025:0),.015,.105);return clamp(.4+(1-hp)*.6,.15,.94)}
function battleDecision(t,b,own,foe){const w=b.weather||'clear',competitive=['Competitivo','Estrategista'].includes(t.personality),collector=t.personality==='Colecionador',explorer=['Explorador','Aventureiro'].includes(t.personality);let name=chooseMove(own,foe,t.traits,t,w);let preserving=false;if(['wild','postgameWild'].includes(b.kind)&&LEGEND_PROFILES[foe.species]&&settings.capture&&t.bag.Pokeball>0){const safe=own.moves.filter(n=>(own.pp?.[n]??20)>0&&moveScore(own,foe,n,w)>0&&moveScore(own,foe,n,w)<foe.hp*.8).sort((a,c)=>moveScore(own,foe,c,w)-moveScore(own,foe,a,w));if(safe.length){name=safe[0];preserving=true}}const choices=[{kind:'attack',name,score:40+moveScore(own,foe,name,w),reason:preserving?`${name} enfraquece o lendário com menor risco de nocaute antes da captura.`:`${name}: dano estimado ${Math.round(moveScore(own,foe,name,w))}, considerando tipos, habilidades e ${WEATHER_NAMES[w]}.`}];const ratio=own.hp/own.maxHp;
if(settings.potions&&t.bag.Potion>0&&ratio<.6)choices.push({kind:'potion',score:(competitive?125:80)*(1-ratio),reason:`Preservar ${own.species}: HP em ${Math.round(ratio*100)}%.`});
if((b.kind==='wild'||b.kind==='trainingWild'||b.kind==='postgameWild')&&(b.teamRecruit||shouldCapture(t,foe))&&(LEGEND_PROFILES[foe.species]?foe.hp/foe.maxHp<=.3:(foe.hp/foe.maxHp<.95||!t.dex.includes(foe.species))))choices.push({kind:'capture',score:LEGEND_PROFILES[foe.species]?2000:b.teamRecruit?210:collector&&!t.dex.includes(foe.species)?1000:80,reason:LEGEND_PROFILES[foe.species]?`Lendário enfraquecido: ${Math.round(captureChance(foe)*100)}% de chance por Pokébola.`:!t.dex.includes(foe.species)?`${foe.species} ainda não está na coleção.`:'O alvo está enfraquecido para captura.'});
if(settings.smartSwitch&&!b.switchedLast)for(let i=0;i<t.team.length;i++){const m=t.team[i];if(i===b.ownIndex||m.hp<=0)continue;const incoming=Math.max(...foe.moves.map(n=>moveScore(foe,m,n,w))),current=Math.max(...foe.moves.map(n=>moveScore(foe,own,n,w)));const outgoing=Math.max(...m.moves.map(n=>moveScore(m,foe,n,w)));const score=30+outgoing-incoming+(competitive&&incoming<current?35:0)+(ratio<(collector?.15:.3)?35:0)+(explorer&&m.level<own.level?15:0);choices.push({kind:'switch',index:i,score,reason:`${m.species}: cobertura ofensiva e resistência ao adversário${explorer?' com prioridade para treinar os mais novos':''}.`})}
if(t.isUserBot){const style=t.botStyle||'balanced';for(const opt of choices){
 if(style==='aggressive'&&opt.kind==='attack')opt.score+=45;
 if(style==='defensive'&&['potion','switch'].includes(opt.kind))opt.score+=48;
 if(style==='catcher'&&opt.kind==='capture')opt.score+=90;
 }}
 choices.sort((a,b)=>b.score-a.score);b.decision={profile:t.personality,round:b.round,selected:choices[0],alternatives:choices.slice(1,4)};return choices[0]}
function alive(team){return team.findIndex(m=>m.hp>0)}
function effective(a,b){return (ADV[a]&&ADV[a][b])??1}
function chooseMove(att,def,traits,trainer=null,w='clear'){
const usable=att.moves.filter(name=>!att.pp||att.pp[name]===undefined||att.pp[name]>0);if(!usable.length)return 'Struggle';const scores=usable.map(name=>{let m=MOVES[name],mult=multiEffect(m[0],def),memory=trainer?.strategyMemory?.[def.type]?.[name]||0;return{name,score:moveScore(att,def,name,w)+clamp(memory,-4,4)*3}});
scores.sort((a,b)=>b.score-a.score);return ['Competitivo','Estrategista'].includes(trainer?.personality)||Math.random()<(traits.strategy||.5)*.9?scores[0].name:pick(scores.slice(0,Math.min(3,scores.length))).name}
const STATUS_ACTIONS={
 DoubleTeam:['self','evasion',1],DragonDance:['self','atk',1,'speed',1],IronDefense:['self','def',2],
 Growl:['foe','atk',-1],Leer:['foe','def',-1],TailWhip:['foe','def',-1],
 SwordsDance:['self','atk',2],CalmMind:['self','spAtk',1,'spDef',1],BulkUp:['self','atk',1,'def',1],Agility:['self','speed',2],SandAttack:['foe','accuracy',-1]
};
function attack(a,b,name,w='clear'){
 a.pp??={};if(name!=='Struggle'){if(!Number.isFinite(a.pp[name]))a.pp[name]=movePP(name);if(a.pp[name]<=0)name='Struggle';else a.pp[name]--;}
 if(a.status==='paralysis'&&rnd(4)===0)return{name,damage:0,txt:`${a.species} ficou paralisado e não agiu.`};
 if(a.status==='sleep'){
  a.sleepTurns=Math.max(0,(a.sleepTurns||2)-1);
  if(a.sleepTurns>0)return{name,damage:0,txt:`${a.species} está dormindo.`};
  a.status=null;
 }
 if(a.status==='freeze'){
  if(Math.random()<.2)a.status=null;
  else return{name,damage:0,txt:`${a.species} está congelado.`};
 }
 const move=MOVES[name]||MOVES.Struggle,type=move[0],power=move[1];
 const accuracy=effectiveAccuracy(a,b,{name,accuracy:move[2]},w);
 if(rnd(100)>=accuracy)return{name,damage:0,txt:`${a.species} errou ${name}!`};
 if(power===0){
  if(name==='Rest'){a.hp=a.maxHp;a.status='sleep';a.sleepTurns=2;return{name,damage:0,txt:`${a.species} recuperou a vida com Rest e dormiu.`}}
  if(name==='DragonRage'){const dmg=multiEffect('Dragon',b)===0?0:Math.min(40,b.hp);b.hp-=dmg;return{name,damage:dmg,txt:`${a.species} usou Dragon Rage: ${dmg} de dano.`}}
  if(name==='Recover'){const heal=Math.min(a.maxHp-a.hp,Math.floor(a.maxHp/2));a.hp+=heal;return{name,damage:0,txt:`${a.species} recuperou ${heal} HP com Recover.`}}
  if(name==='Protect'){a.protectedThisTurn=true;return{name,damage:0,txt:`${a.species} se protegeu.`}}
  if(b.protectedThisTurn)return{name,damage:0,txt:`${b.species} bloqueou ${name} com Protect!`};
  if(['ThunderWave','Toxic','Hypnosis','SleepPowder','StunSpore','WillOWisp','Sing','LeechSeed'].includes(name)){
   const types=monTypes(b);
   if(name==='LeechSeed'){
    if(types.includes('Grass')||b.leechSeed)return{name,damage:0,txt:`Leech Seed não teve efeito em ${b.species}.`};
    b.leechSeed=true;return{name,damage:0,txt:`${a.species} semeou ${b.species} com Leech Seed.`};
   }
   const immune=(name==='ThunderWave'&&types.includes('Ground'))
    ||(name==='Toxic'&&types.some(x=>['Poison','Steel'].includes(x)))
    ||(name==='WillOWisp'&&types.includes('Fire'));
   if(immune||b.status)return{name,damage:0,txt:`${name} não teve efeito sobre ${b.species}.`};
   b.status=name==='Toxic'?'toxic':name==='WillOWisp'?'burn':['Hypnosis','SleepPowder','Sing'].includes(name)?'sleep':'paralysis';
   if(b.status==='toxic')b.toxicTurns=0;
   if(b.status==='sleep')b.sleepTurns=2+rnd(3);
   return{name,damage:0,txt:`${b.species} recebeu ${b.status}!`};
  }
  const change=STATUS_ACTIONS[name];if(change){const target=change[0]==='self'?a:b;target.statStages??={};let output=[];
   for(let i=1;i<change.length;i+=2){const stat=change[i],delta=change[i+1];target.statStages[stat]=clamp((target.statStages[stat]||0)+delta,-6,6);output.push(`${stat} ${delta>0?'+':''}${delta}`)}
   return{name,damage:0,txt:`${a.species} usou ${name}: ${output.join(' • ')}.`};
  }
  return{name,damage:0,txt:`${a.species} usou ${name}.`};
 }
 if(b.protectedThisTurn)return{name,damage:0,txt:`${b.species} bloqueou ${name} com Protect!`};
 const mult=name==='Struggle'?1:type==='Ground'&&ability(b)==='Levitate'?0:multiEffect(type,b);
 const critical=settings.critical&&Math.random()<1/16;const {atk,def}=damageStats(a,b,type,w,critical);
 // Geração III: arredondar etapas, crítico ×2, STAB, tipos e variação 85..100%.
 const base=Math.floor(Math.floor(((Math.floor(2*a.level/5)+2)*power*atk)/Math.max(1,def))/50)+2;
 const abilityBonus=a.hp>0&&a.hp/a.maxHp<=1/3&&({Overgrow:'Grass',Blaze:'Fire',Torrent:'Water'}[ability(a)]===type)?1.5:1;
 const modifier=weatherBoost(type,w)*abilityBonus*(critical?2:1)*(monTypes(a).includes(type)&&name!=='Struggle'?1.5:1)*mult*(85+rnd(16))/100;
 const hits=name==='DoubleKick'?2:name==='BulletSeed'?([2,2,2,3,3,4,5][rnd(7)]):1;
 const singleDamage=mult===0?0:Math.max(1,Math.floor(base*modifier));
 const dmg=Math.min(b.hp,singleDamage*hits);b.hp=Math.max(0,b.hp-dmg);
 if(name==='Struggle')a.hp=Math.max(0,a.hp-Math.max(1,Math.floor(dmg/4)));
 return{name,damage:dmg,txt:`${a.species} usou ${name}: ${dmg} de dano${hits>1?` (${hits} acertos)`:''}${critical?' (crítico!)':''}${mult>1?' (super efetivo!)':mult<1?' (pouco efetivo)':''}.`}
}
function startBattle(t,enemy,kind,other=null){if(!t.team.length)return false;t.queuedBattleAction=null;if(kind==='wild'&&!wildHabitat(t))return false;if(['wild','postgameWild'].includes(kind)&&(Array.isArray(enemy)?enemy:[enemy]).some(e=>!legendaryAvailable(e.species)))return false;const foes=(Array.isArray(enemy)?enemy:[enemy]).map(e=>createMon(e.species,(kind==='wild'&&LEGEND_PROFILES[e.species]?Math.max(e.level,LEGEND_PROFILES[e.species].minLevel):e.level)+(kind==='ai'?Number(settings.enemyLevelBonus)||0:0),e.shiny));for(const mon of [...t.team,...foes]){mon.statStages={};mon.protectedThisTurn=false}t.battle={kind,enemy:foes,enemyIndex:0,ownIndex:alive(t.team),other,round:0,history:[],started:clock,weather:settings.weather?worldWeather:'clear',weatherTurns:5};[t.team[t.battle.ownIndex],foes[0]].filter(Boolean).sort((a,b)=>battleSpeed(b,t.battle.weather)-battleSpeed(a,t.battle.weather)).forEach(m=>enterBattle(m,t.battle));suppressWeather(t.battle,t.team[t.battle.ownIndex],foes[0]);if(kind==='wild'&&LEGEND_PROFILES[foes[0].species]){rareEvents++;emit(t,'rare',`${LEGEND_PROFILES[foes[0].species].title}: ${foes[0].species} Nv. ${foes[0].level}! ${LEGEND_PROFILES[foes[0].species].detail}`,true)}emit(t,'battle',`⚔️ ${t.name} iniciou batalha contra ${kind==='wild'?'Pokémon selvagem':kind==='ai'?'outro treinador':kind==='gym'?'líder de ginásio':'rival'}!`,kind!=='wild');return true}
function resolveBattle(t,win){const b=t.battle;if(!b)return;
 // Guardar os combates concluídos para assistir à narração mesmo em 40×.
 window.emeraldBattleArchive??=[];
 window.emeraldBattleArchive.unshift({id:t.id,name:t.name,kind:b.kind,round:b.round,
  place:t.officialMap||t.location,won:!!win,
  own:t.team[b.ownIndex]?{...t.team[b.ownIndex]}:null,
  foe:b.enemy[b.enemyIndex]?{...b.enemy[b.enemyIndex]}:b.enemy.at(-1)?{...b.enemy.at(-1)}:null,
  lines:(b.history||[]).slice(0,16),tick:turns});
 window.emeraldBattleArchive.length=Math.min(40,window.emeraldBattleArchive.length);
 // Encontros com treinadores de object_events: a vitória persiste no save.
 if(b.sentryKey){
  if(win){t.defeatedOfficialTrainers??={};t.defeatedOfficialTrainers[b.sentryKey]=true;}
  else t.officialTrainerRetryUntil=Date.now()+15000;
 }
 for(const mon of [...t.team,...b.enemy]){mon.statStages={};mon.protectedThisTurn=false}
 if(b.postgameKey){
  t.postgameQuest??={done:{},attempts:{}};
  if(win)t.postgameQuest.done[b.postgameKey]='vencido';
  else t.postgameQuest.attempts[b.postgameKey]=(t.postgameQuest.attempts[b.postgameKey]||0)+1;
 }
   if(t.isUserBot){
   if(b.userTrainingKey&&win&&t.userRivalChoice?.key===b.userTrainingKey&&t.userRivalChoice.choice==='train'){
    const d=t.userRivalChoice;d.trainingLeft=Math.max(0,d.trainingLeft-1);
    if(d.trainingLeft===0){d.choice='pending';emit(t,'story',`✅ Treinamento concluído. Você pode enfrentar ${d.label} ou treinar de novo.`,true)}
   }
   if(b.userRivalKey&&t.userRivalChoice?.key===b.userRivalKey){
    if(win)t.userRivalChoice=null;
    else{t.userRivalChoice.choice='pending';emit(t,'story','Você perdeu. Escolha tentar novamente ou treinar mais.',true)}
   }
  }
  t.queuedBattleAction=null;
  t.battle=null;if(win){t.wins++;t.money+=b.kind==='wild'?0:b.kind==='gym'?1800:b.kind==='elite'?Math.max(1,...b.enemy.map(m=>m.level))*(t.leagueRound===4?200:100):b.kind==='postgame'?7500:300;if(b.kind==='rescue'){advance(t,'Professor Birch foi salvo do Zigzagoon!')}else if(b.kind==='gym'){t.badges++;if(t.isUserBot)window.ELWTelemetry?.event('gym_win',String(t.badges));emit(t,'rare',`🏅 ${t.name} conquistou a insígnia ${t.badges}/8!`,true);advance(t)}else if(b.kind==='story'){if(b.storyKey){t.storyBattleProgress??={};t.storyBattleProgress[b.storyKey]=(t.storyBattleProgress[b.storyKey]||0)+1;}emit(t,'battle',`📖 ${t.name} venceu ${b.label||'um adversário da campanha'}!`,true)}else if(b.kind==='gymTrainer'){t.gymGuards??={};t.gymGuards[t.stage]=(t.gymGuards[t.stage]||0)+1;emit(t,'battle',`${t.name} venceu um treinador do ginásio!`)}else if(b.kind==='routeTrainer'){t.routeFights??={};t.routeFights[t.stage]=(t.routeFights[t.stage]||0)+1;emit(t,'battle',`${t.name} venceu um treinador da rota!`)}else if(b.kind==='elite'){t.leagueRound=(t.leagueRound||0)+1;if(t.isUserBot)window.ELWTelemetry?.event('elite_four_win',String(t.leagueRound));emit(t,'rare',`🏆 ${t.name} venceu ${LEAGUE[t.leagueRound-1]?.[0]}!`,true)}else if(b.kind==='rival'){emit(t,'battle',`🏆 ${t.name} venceu o rival!`,true);advance(t)}else if(b.kind==='ai'){let other=trainers[b.other];if(other){let key=[t.id,other.id].sort((a,b)=>a-b).join('-');pairScores[key]??={a:0,b:0};pairScores[key][t.id<other.id?'a':'b']++;t.rivals[other.id]=(t.rivals[other.id]||0)+1;remember(t,`Venceu ${other.name} numa batalha em ${t.location}.`);other.rivals[t.id]=(other.rivals[t.id]||0)+1;remember(other,`Perdeu para ${t.name}; ajustar estratégia.`);emit(t,'battle',`🏆 ${t.name} venceu ${other.name} em um encontro entre IAs!`,true)}}else emit(t,'battle',`${t.name} venceu o encontro selvagem.`);for(let m of t.team.filter(m=>m.hp>0)){awardEffort(m,b.enemy);const total=b.enemy.reduce((sum,e)=>{const base=SPEC[e.species]||SPEC.Zigzagoon;return sum+Math.max(35,Math.round(base.slice(1,7).reduce((a,b)=>a+b,0)/4.5))*e.level/7},0);expGain(t,m,Math.max(1,Math.floor(total/t.team.length)))}}else{t.losses++;if(t.isUserBot&&b.kind==='gym')window.ELWTelemetry?.event('gym_loss',String(t.stage));remember(t,'Perdeu uma batalha; precisa preparar a equipe e recuperar HP.');emit(t,'battle',`💥 ${t.name} foi derrotado e voltou para se recuperar.`,true);t.cooldown=3;if(b.kind==='elite'){t.leagueRound=0;t.leaguePrepared=false}requestCenterVisit(t,'recuperar-se da derrota');if(b.kind==='ai'){let other=trainers[b.other];if(other){other.wins++;let key=[t.id,other.id].sort((a,b)=>a-b).join('-');pairScores[key]??={a:0,b:0};pairScores[key][t.id<other.id?'b':'a']++;emit(other,'battle',`🏆 ${other.name} venceu ${t.name}!`,true)}}}}
 // Personal journey decisions are saved on the trainer, not the page.
 function personalRivalGate(t,key,label){
  if(!t.isUserBot||settings.gameMode!=='player')return false;
  if(!t.userRivalChoice||t.userRivalChoice.key!==key){
   t.userRivalChoice={key,label,choice:'pending',trainingLeft:0};
   emit(t,'story',`🎯 Decida: enfrentar ${label} agora ou treinar antes?`,true);window.emeraldRefreshMyBot?.();
  }
  const d=t.userRivalChoice;
  if(d.choice==='pending')return true;
  if(d.choice==='train'){
   if(d.trainingLeft<=0){d.choice='pending';emit(t,'story',`✅ Treino concluído. Você decide quando desafiar ${label}.`,true);return true}
   // Training sessions at rival routes are actual wild encounters using this
   // region's curated species, even if the trainer stands on a safe path tile.
   const routeTraining=['Route 103','Route 110','Route 119'].includes(t.location);
   if(routeTraining){
    const encounters=REGIONAL_WILD[t.location]||['Poochyena','Zigzagoon','Wingull'];
    const species=pick(encounters.filter(name=>SPEC[name]))||'Zigzagoon';
    const level=Math.max(3,Math.min(45,Math.round((t.team.find(m=>m.hp>0)?.level||5)*.75)));
    startBattle(t,{species,level},'trainingWild');
    if(t.battle){t.battle.userTrainingKey=key;emit(t,'battle',`💪 Treinamento: ${t.name} enfrentou ${species} na ${t.location}.`);return true}
   }
   if(wildHabitat(t)&&wild(t)){
    if(t.battle)t.battle.userTrainingKey=key;
    return true;
   }
   // Cities without wild terrain retain the existing simplified practice mode.
   train(t);d.trainingLeft--;if(d.trainingLeft<=0)d.choice='pending';return true;
  }
  return false;
 }
 function personalBattleAction(t,own,foe){
  const data=t.queuedBattleAction;
  if(!data)return null;
  t.queuedBattleAction=null;
  if(data.kind==='attack'&&own.moves.includes(data.name)&&(own.pp?.[data.name]??20)>0)
   return {kind:'attack',name:data.name,reason:`Você escolheu ${data.name}.`};
  if(data.kind==='switch'&&Number.isInteger(data.index)&&data.index!==t.battle.ownIndex&&t.team[data.index]?.hp>0)
   return {kind:'switch',index:data.index,reason:`Você decidiu trocar para ${t.team[data.index].species}.`};
  if(data.kind==='potion'&&t.bag.Potion>0&&own.hp<own.maxHp)
   return {kind:'potion',reason:'Você decidiu usar uma Potion.'};
  if(data.kind==='capture'&&['wild','trainingWild','postgameWild'].includes(t.battle.kind)&&t.bag.Pokeball>0)
   return {kind:'capture',reason:'Você decidiu lançar uma Pokébola.'};
  return null;
 }
function battleTurn(t){const b=t.battle;if(!b)return;let own=t.team[b.ownIndex],foe=b.enemy[b.enemyIndex];if(!own||own.hp<=0){b.ownIndex=alive(t.team);if(b.ownIndex<0){resolveBattle(t,false);return}own=t.team[b.ownIndex];enterBattle(own,b);b.history.unshift(`🔁 Entrou ${own.species}.`)}
if(!foe||foe.hp<=0){b.enemyIndex=b.enemy.findIndex(m=>m.hp>0);if(b.enemyIndex<0){resolveBattle(t,true);return}foe=b.enemy[b.enemyIndex]}
 const manual=t.isUserBot&&settings.gameMode==='player'&&t.manualBattleEnabled!==false;
 const action=manual?personalBattleAction(t,own,foe):battleDecision(t,b,own,foe);
 if(!action)return; // The player's turn is never chosen automatically in manual mode.
 b.round++;if(b.round>350){resolveBattle(t,alive(t.team)>=0&&alive(b.enemy)<0);return}b.weather??=settings.weather?worldWeather:'clear';suppressWeather(b,own,foe);for(const mon of [own,foe])mon.protectedThisTurn=false;
 b.history.unshift((manual?'Você: ':'IA '+t.personality+': ')+action.reason);b.switchedLast=action.kind==='switch';
let ownAttacks=false;
if(action.kind==='potion'){t.bag.Potion--;const amount=Math.min(20,own.maxHp-own.hp);own.hp+=amount;b.history.unshift(`${t.name} usou Potion: +${amount} HP.`)}
else if(action.kind==='capture'){t.bag.Pokeball--;if(Math.random()<captureChance(foe)){const caught={...foe,moves:[...foe.moves],pp:{...foe.pp}};caught.hp=Math.max(1,Math.floor(caught.maxHp*.6));acquireMon(t,caught);
 if(b.postgameKey){t.postgameQuest??={done:{},attempts:{}};t.postgameQuest.done[b.postgameKey]='capturado';}
 emit(t,'capture',`${t.name} capturou ${caught.species}!`);t.battle=null;return}b.history.unshift(`A Pokébola falhou! Chance da tentativa: ${Math.round(captureChance(foe)*100)}%.`)}
else if(action.kind==='switch'){b.ownIndex=action.index;own=t.team[action.index];own.statStages={};enterBattle(own,b);b.history.unshift(`${t.name} trocou para ${own.species}.`)}else ownAttacks=true;
suppressWeather(b,own,foe);const enemyMove=chooseMove(foe,own,{strategy:.65},null,b.weather);
const playerHit=()=>{const result=attack(own,foe,action.name,b.weather);b.history.unshift(result.txt);t.strategyMemory??={};t.strategyMemory[foe.type]??={};t.strategyMemory[foe.type][action.name]=(t.strategyMemory[foe.type][action.name]||0)+(result.damage>0?1:-1)};
const enemyHit=()=>b.history.unshift('Adversário: '+attack(foe,own,enemyMove,b.weather).txt);
const priority=n=>({HelpingHand:5,MagicCoat:4,Snatch:4,Protect:3,Detect:3,Endure:3,FollowMe:3,QuickAttack:1,ExtremeSpeed:1,FakeOut:1,MachPunch:1,VitalThrow:-1,FocusPunch:-3,Revenge:-4,Counter:-5,MirrorCoat:-5,Roar:-6,Whirlwind:-6})[n]??0;const first=ownAttacks&&(priority(action.name)>priority(enemyMove)||priority(action.name)===priority(enemyMove)&&(battleSpeed(own,b.weather)>battleSpeed(foe,b.weather)||battleSpeed(own,b.weather)===battleSpeed(foe,b.weather)&&Math.random()<.5));
if(first){playerHit();if(foe.hp>0)enemyHit()}else{enemyHit();if(ownAttacks&&own.hp>0)playerHit()}
resolveBattleResidual(own,foe,b);
if(alive(t.team)<0){resolveBattle(t,false);return}if(alive(b.enemy)<0){resolveBattle(t,true);return}
if(foe.hp<=0){b.enemyIndex=alive(b.enemy);b.enemy[b.enemyIndex].statStages={};enterBattle(b.enemy[b.enemyIndex],b)}
b.history=b.history.slice(0,12)}

function starterChoice(t){const starters=window.EmeraldStarters?.ALL||['Treecko','Torchic','Mudkip'];
 const selectedByBot=t.isUserBot&&starters.includes(t.botStarter)?t.botStarter:null;
 const preset=starters.includes(settings.starter)?settings.starter:null;
 // All 27 are available to autonomous bots; with 20 bots, their starters differ.
 const name=selectedByBot||preset||(settings.starter==='random'?pick(starters):starters[(t.id||0)%starters.length]);
 t.starter=name;if(t.isUserBot)window.ELWTelemetry?.event("starter_choose",name);t.team.push(createMon(name,5));t.dex.push(name);remember(t,`Escolheu ${name} para salvar Birch.`);
 emit(t,'rare',`🌿 ${t.name} escolheu ${name} para enfrentar Zigzagoon!`,true);startBattle(t,{species:'Zigzagoon',level:2},'rescue')}
const CAMPAIGN={
 // As etapas 16-27 correspondem aos capítulos do motor de IAs (não à ROM inteira).
 // Caminhos/portas são percorridos pelo official-runtime antes da missão concluir.
 16:[['Route 102','Batalhar com os treinadores da Rota 102']],
 17:[['Petalburg City','Conversar com Norman e ajudar Wally'],['PetalburgCity_Gym','Visitar o ginásio de Petalburg']],
 18:[['Route 104','Avançar rumo à floresta'],['Petalburg Woods','Defender o pesquisador da Devon'],['Route 104','Chegar ao norte da Rota 104'],['Rustboro City','Entrar em Rustboro']],
 19:[['RustboroCity_Gym','Visitar o ginásio antes de Roxanne']],
 20:[['Route 116','Alcançar o túnel de Rusturf'],['Rusturf Tunnel','Recuperar a mercadoria da Devon'],['Rustboro City','Falar com o presidente da Devon'],['Route 104','Encontrar Mr. Briney e seguir de barco'],['Dewford Town','Chegar a Dewford'],['Granite Cave','Entregar a carta para Steven'],['DewfordTown_Gym','Desafiar Brawly']],
 21:[['Route 109','Desembarcar em Slateport'],['Slateport City','Entregar mercadorias a Stern'],['SlateportCity_OceanicMuseum_1F','Enfrentar a Team Aqua no museu'],['Route 110','Batalhar com a rival no caminho de Mauville'],['Mauville City','Enfrentar Wally e obter Rock Smash'],['MauvilleCity_Gym','Desafiar Wattson']],
 22:[['Route 117','Visitar Verdanturf'],['Route 111','Subir pelo caminho da montanha'],['Route 112','Acessar Fiery Path'],['Fiery Path','Atravessar a passagem'],['Route 113','Cruzar a rota de cinzas'],['Fallarbor Town','Investigar o desaparecimento do professor'],['Route 114','Seguir para Meteor Falls'],['Meteor Falls','Investigar a Team Magma'],['Route 112','Retornar para o teleférico'],['Mt. Chimney','Vencer Maxie'],['Jagged Pass','Descer o vulcão'],['LavaridgeTown_Gym_1F','Enfrentar Flannery']],
 23:[['Petalburg City','Voltar à cidade de Norman'],['PetalburgCity_Gym','Enfrentar o quinto ginásio']],
 24:[['Route 118','Usar Surf para avançar a leste'],['Route 119','Avançar sob chuva'],['Route119_WeatherInstitute_1F','Salvar o Instituto Meteorológico'],['Route 119','Enfrentar o rival e obter Fly'],['Fortree City','Investigar a árvore bloqueada'],['Route 120','Receber o Devon Scope'],['FortreeCity_Gym','Enfrentar Winona']],
 25:[['Route 121','Seguir para Mt. Pyre'],['Lilycove City','Último desafio contra May ou Brendan'],['Mt. Pyre','Ver o roubo do orbe'],['Slateport City','Presenciar o roubo do submarino'],['Jagged Pass','Retornar ao esconderijo Magma'],['MagmaHideout_1F','Vencer Maxie na base'],['Lilycove City','Encontrar o esconderijo Aqua'],['AquaHideout_1F','Superar os Aqua'],['Route 124','Navegar até Mossdeep'],['MossdeepCity_Gym','Enfrentar Tate e Liza']],
 26:[['Mossdeep City','Salvar o Centro Espacial e obter Dive'],['Route 128','Procurar a entrada submarina'],['Seafloor Cavern','Vencer Archie'],['Sootopolis City','Assistir à crise dos lendários'],['SkyPillar_Entrance','Acordar Rayquaza'],['SootopolisCity_Gym_1F','Enfrentar Juan']],
 27:[['Route 128','Seguir em direção a Ever Grande'],['Ever Grande City','Chegar à cachoeira'],['Victory Road','Passar pelo desafio de Victory Road'],['Victory Road','Enfrentar Wally'],['EverGrandeCity_PokemonLeague_1F','Chegar à Elite dos Quatro']]
};

// Encontros fixos do Emerald. Chaves: "etapa:índice da missão".
// Chefes e rival usam times e níveis da história, não a dificuldade dos bots.
function rivalRoster(t,which){
 const st=t.starter||'Treecko';
 const squads={
  route110:{Treecko:[['Wingull',18],['Lombre',18],['Combusken',20]],Torchic:[['Wingull',18],['Slugma',18],['Marshtomp',20]],Mudkip:[['Pelipper',18],['Slugma',18],['Grovyle',20]]},
  route119:{Treecko:[['Pelipper',29],['Lombre',29],['Combusken',31]],Torchic:[['Lombre',29],['Slugma',29],['Marshtomp',31]],Mudkip:[['Pelipper',29],['Slugma',29],['Grovyle',31]]},
  lilycove:{Treecko:[['Tropius',31],['Pelipper',32],['Ludicolo',32],['Combusken',34]],Torchic:[['Tropius',31],['Ludicolo',32],['Slugma',32],['Marshtomp',34]],Mudkip:[['Tropius',31],['Slugma',32],['Pelipper',32],['Grovyle',34]]}
 };return squads[which]?.[st]||squads[which]?.Treecko||[];
}
const STORY_ENCOUNTERS={
 '18:1':[['Recruta Aqua — Petalburg Woods',[['Poochyena',9]]]],
 '20:1':[['Recruta Aqua — Rusturf Tunnel',[['Poochyena',11]]]],
 '21:2':[['Recruta Aqua — museu',[['Carvanha',15]]],['Recruta Aqua — museu',[['Zubat',14],['Carvanha',14]]]],
 '21:3':[['May/Brendan — Route 110','route110']],
 '21:4':[['Wally — Mauville',[['Ralts',16]]]],
 '22:9':[['Tabitha — Mt. Chimney',[['Numel',18],['Poochyena',20],['Numel',22],['Zubat',22]]],['Maxie — Mt. Chimney',[['Mightyena',24],['Zubat',24],['Camerupt',25]]]],
 '24:2':[['Shelly — Weather Institute',[['Carvanha',28],['Mightyena',28]]]],
 '24:3':[['May/Brendan — Route 119','route119']],
 '25:1':[['May/Brendan — Lilycove','lilycove']],
 '25:5':[['Tabitha — Magma Hideout',[['Numel',26],['Mightyena',28],['Zubat',30],['Camerupt',33]]],['Maxie — Magma Hideout',[['Mightyena',37],['Crobat',38],['Camerupt',39]]]],
 '25:7':[['Matt — Aqua Hideout',[['Mightyena',34],['Golbat',34]]]],
 '26:0':[['Tabitha — Mossdeep Space Center',[['Camerupt',36],['Mightyena',38],['Golbat',40]]],['Maxie — Mossdeep Space Center',[['Mightyena',42],['Crobat',43],['Camerupt',44]]]],
 '26:2':[['Shelly — Seafloor Cavern',[['Sharpedo',37],['Mightyena',37]]],['Archie — Seafloor Cavern',[['Mightyena',41],['Crobat',41],['Sharpedo',43]]]],
 '27:3':[['Wally — Victory Road',[['Magneton',41],['Delcatty',43],['Altaria',44],['Roselia',44],['Gardevoir',45]]]]
};
function questStep(t){
 const quests=CAMPAIGN[t.stage];if(!quests)return false;
 t.quests??={};const idx=t.quests[t.stage]||0;if(idx>=quests.length)return false;
 const [place,description]=quests[idx],api=window.emeraldOfficialWorld;
 const target=api?.resolve(place)||place;
 if((api?.resolve(t.officialMap)||t.officialMap)!==target){
  // Mudar objetivo não é completar a missão ou mover o sprite.
  if((api?.resolve(t.location)||t.location)!==target){
   t.location=place;t.storyArrived=false;t.introReady=false;t.storyDwell=0;
   t.walkObjective='Indo até '+(api?.label?.(place)||place);
  }
  return true;
 }
 if(!t.storyArrived)return true;
 t.location=place;
 const storyKey=`${t.stage}:${idx}`,storyFights=STORY_ENCOUNTERS[storyKey]||[];
 t.storyBattleProgress??={};const fought=t.storyBattleProgress[storyKey]||0;
 if(fought<storyFights.length){
     const potentialRival=storyFights[fought][0];
   const rivalEvent=/May\/Brendan|Rival|Wally/i.test(potentialRival);
   if(rivalEvent&&personalRivalGate(t,`story-${storyKey}-${fought}`,potentialRival))return true;
   if(healingNeeded(t,true)){requestCenterVisit(t,'se preparar para '+storyFights[fought][0]);return true}
  const [label,squad]=storyFights[fought],roster=typeof squad==='string'?rivalRoster(t,squad):squad;
  startBattle(t,roster.map(([species,level])=>({species,level})),'story');
     if(t.battle){t.battle.storyKey=storyKey;t.battle.storyIndex=fought;t.battle.label=label;
    if(rivalEvent&&t.isUserBot)t.battle.userRivalKey=`story-${storyKey}-${fought}`;
   emit(t,'battle',`📖 ${t.name} enfrenta ${label} na campanha!`,true)}
  return true;
 }
 t.quests[t.stage]=idx+1;
 emit(t,'story',`📜 ${t.name} chegou a ${api?.label?.(place)||place}: ${description}.`,idx===quests.length-1);
 remember(t,description);t.cooldown=3+rnd(4);
 if(storyKey==='24:2'&&!(t.dex||[]).includes('Castform')){
  const gift=createMon('Castform',25);t.dex.push('Castform');acquireMon(t,gift);
  emit(t,'rare',`🌦️ Pesquisadores entregaram Castform Nv. 25 para ${t.name}!`,true);
 }
 if(t.pc?.length)rebalanceTeam(t,'missão de Hoenn');return true;
}
const LEAGUE=[
 ['Sidney','Dark',[['Mightyena',46],['Absol',49],['Shiftry',48],['Cacturne',46],['Crawdaunt',48]],46],
 ['Phoebe','Ghost',[['Dusclops',48],['Banette',49],['Sableye',50],['Banette',49],['Dusclops',51]],48],
 ['Glacia','Ice',[['Glalie',50],['Sealeo',50],['Sealeo',52],['Glalie',52],['Walrein',53]],50],
 ['Drake','Dragon',[['Shelgon',52],['Flygon',53],['Altaria',54],['Salamence',55],['Kingdra',53]],52],
 ['Wallace','Water',[['Wailord',57],['Ludicolo',56],['Tentacruel',55],['Whiscash',56],['Gyarados',56],['Milotic',58]],55]
];
const CITY_PATH=['Littleroot Town','Oldale Town','Petalburg City','Rustboro City','Dewford Town','Slateport City','Mauville City','Verdanturf Town','Fallarbor Town','Lavaridge Town','Fortree City','Lilycove City','Mossdeep City','Sootopolis City','Ever Grande City'];
function gymGuardFight(t,s,lv){t.gymGuards??={};const n=t.gymGuards[s]||0;if(n>=settings.gymTrainers)return false;
 const options={19:['Geodude','Nosepass'],20:['Machop','Meditite','Makuhita'],21:['Voltorb','Electrike','Magnemite'],22:['Numel','Slugma','Torkoal'],23:['Zigzagoon','Spinda','Vigoroth'],24:['Swablu','Pelipper','Tropius'],25:['Baltoy','Lunatone','Solrock'],26:['Luvdisc','Barboach','Corphish']};
 const [leader,type,roster]=GYMS[s];const map={19:'RustboroCity_Gym',20:'DewfordTown_Gym',21:'MauvilleCity_Gym',22:'LavaridgeTown_Gym_1F',23:'PetalburgCity_Gym',24:'FortreeCity_Gym',25:'MossdeepCity_Gym',26:'SootopolisCity_Gym_1F'}[s];
 const npc=GYM_NPC_ROSTERS[map]?.[n];
 if(npc){startBattle(t,npc[1].map(([species,level])=>({species,level})),'gymTrainer');emit(t,'battle',`🏟️ ${t.name} enfrenta ${npc[0]} no ginásio de ${leader}!`,true)}
 else{const foe=pick(options[s]||['Zigzagoon']),top=roster[roster.length-1][1];startBattle(t,[{species:foe,level:Math.max(6,top-5+n)}],'gymTrainer');emit(t,'battle',`🏟️ ${t.name} enfrenta treinador ${n+1}/${settings.gymTrainers} do ginásio de ${leader}!`,true)}return true}
const NAMED_ROUTE_TRAINERS={
 16:[['Youngster Calvin',[['Poochyena',5]]],['Bug Catcher Rick',[['Wurmple',4],['Wurmple',4]]],['Youngster Allen',[['Zigzagoon',4],['Taillow',3]]],['Lass Tiana',[['Zigzagoon',4],['Shroomish',4]]]],
 18:[['Youngster Billy',[['Zigzagoon',5],['Seedot',7]]],['Fisherman Darian',[['Magikarp',9]]],['Lady Cindy',[['Zigzagoon',7]]],['Bug Catcher Lyle',[['Wurmple',3],['Wurmple',3],['Wurmple',3],['Wurmple',3]]],['Bug Catcher James',[['Nincada',6],['Nincada',6]]],['Rich Boy Winston',[['Zigzagoon',7]]],['Lass Haley',[['Lotad',6],['Shroomish',6]]]],
 20:[['Team Aqua Grunt',[['Poochyena',11]]]],
 21:[['Pokéfan Isabel',[['Plusle',14],['Minun',14]]],['Pokéfan Kaleb',[['Minun',14],['Plusle',14]]],['Youngster Timmy',[['Aron',15],['Electrike',13]]],['Collector Edwin',[['Lombre',14],['Nuzleaf',14]]],['Guitarist Joseph',[['Electrike',14],['Voltorb',14]]],['Psychic Edward',[['Abra',15]]],['Triathlete Alyssa',[['Magnemite',15]]]],
 22:[['Hiker Eric',[['Geodude',20],['Baltoy',20]]],['Team Magma Grunt',[['Poochyena',22],['Numel',22]]],['Picnicker Diana',[['Shroomish',19],['Oddish',19],['Swablu',19]]],['Picnicker Autumn',[['Shroomish',21]]],['Triathlete Julio',[['Magnemite',21]]],['Camper Ethan',[['Zigzagoon',20],['Taillow',20]]]],
 24:[['Team Aqua Grunt',[['Poochyena',27],['Zubat',27]]]],
 25:[['PokéManiac Mark',[['Rhyhorn',31]]],['Hex Maniac Leah',[['Spoink',31]]],['Black Belt Zander',[['Hariyama',31]]],['Team Magma Grunt',[['Mightyena',32],['Golbat',32]]]],
 26:[['Team Aqua Grunt',[['Mightyena',38],['Golbat',38]]]],
 27:[['Cooltrainer Albert',[['Magneton',43],['Muk',43]]],['Cooltrainer Hope',[['Roselia',45]]],['Cooltrainer Shannon',[['Claydol',45]]],['Cooltrainer Samuel',[['Swellow',42],['Mawile',42],['Kadabra',42]]]]
};
// Padrões dos treinadores de ginásio da versão Emerald.
const GYM_NPC_ROSTERS={
 RustboroCity_Gym:[['Youngster Josh',[['Geodude',10]]],['Youngster Tommy',[['Geodude',8],['Geodude',8]]],['Hiker Marc',[['Geodude',8],['Geodude',8]]]],
 DewfordTown_Gym:[['Battle Girl Laura',[['Meditite',13]]],['Battle Girl Lilith',[['Meditite',13]]],['Sailor Brenden',[['Machop',13]]],['Black Belt Takao',[['Machop',13]]],['Black Belt Cristian',[['Makuhita',13]]],['Battle Girl Jocelyn',[['Meditite',13]]]],
 MauvilleCity_Gym:[['Battle Girl Vivian',[['Meditite',17],['Meditite',17]]],['Guitarist Kirk',[['Electrike',17],['Voltorb',17]]],['Youngster Ben',[['Zigzagoon',17],['Gulpin',17]]],['Bug Maniac Angelo',[['Illumise',17],['Volbeat',17]]],['Guitarist Shawn',[['Voltorb',17],['Magnemite',17]]]],
 LavaridgeTown_Gym_1F:[['Kindler Jeff',[['Slugma',22],['Slugma',22]]],['Kindler Jace',[['Slugma',23]]],['Hiker Eli',[['Numel',23]]],['Kindler Cole',[['Numel',23]]],['Cooltrainer Gerald',[['Kecleon',23]]],['Kindler Axle',[['Numel',23]]],['Kindler Keegan',[['Slugma',23]]],['Battle Girl Danielle',[['Meditite',23]]]],
 PetalburgCity_Gym:[['Cooltrainer Randall',[['Swellow',26]]],['Cooltrainer Mary',[['Delcatty',26]]],['Cooltrainer Parker',[['Spinda',26]]],['Cooltrainer Alexia',[['Wigglytuff',26]]],['Cooltrainer George',[['Slakoth',26]]],['Cooltrainer Jody',[['Zangoose',26]]],['Cooltrainer Berke',[['Vigoroth',26]]]],
 FortreeCity_Gym:[['Bird Keeper Humberto',[['Skarmory',30]]],['Bird Keeper Jared',[['Doduo',27],['Skarmory',27],['Tropius',27]]],['Picnicker Ashley',[['Swablu',27],['Swablu',27],['Swablu',27]]],['Bird Keeper Flint',[['Swellow',29],['Xatu',29]]],['Bird Keeper Edwardo',[['Doduo',29],['Pelipper',29]]],['Camper Darius',[['Tropius',30]]]],
 MossdeepCity_Gym:[['Psychic Preston',[['Kirlia',36]]],['Psychic Maura',[['Kadabra',36]]],['Psychic Samantha',[['Xatu',36]]],['Psychic Blake',[['Girafarig',36]]],['Psychic Macey',[['Natu',36]]],['Gentleman Clifford',[['Girafarig',36]]],['Hex Maniac Kathleen',[['Kadabra',36]]],['Psychic Nicholas',[['Wobbuffet',36]]]],
 SootopolisCity_Gym_1F:[['Beauty Connie',[['Goldeen',40]]],['Lass Andrea',[['Luvdisc',40]]],['Lady Daphne',[['Luvdisc',39],['Luvdisc',39]]],['Pokéfan Annika',[['Feebas',39],['Feebas',39]]],['Beauty Tiffany',[['Carvanha',39],['Sharpedo',39]]],['Lass Crissy',[['Goldeen',39],['Wailmer',39]]]]
};
function routeTrainerFight(t){t.routeFights??={};const n=t.routeFights[t.stage]||0;if(n>=settings.routeTrainers)return false;
 const named=NAMED_ROUTE_TRAINERS[t.stage]?.[n];
 if(named){startBattle(t,named[1].map(([species,level])=>({species,level})),'routeTrainer');emit(t,'battle',`🥊 ${t.name} enfrenta ${named[0]} em ${t.location}.`,true);return true}
 let lv=Math.max(5,Math.min(45,(PROGRESSION_LEVELS[t.stage]||10)-5));let pool=REGIONAL_WILD[t.location]||WILD;startBattle(t,[{species:pick(pool),level:lv},{species:pick(pool),level:lv+1}],'routeTrainer');emit(t,'battle',`🚶 ${t.name} encontrou um treinador na rota (${n+1}/${settings.routeTrainers})!`,true);return true}
// Na Liga não há Centro Pokémon entre as salas. Itens comprados antes da
// entrada e consumidos entre lutas mantêm a mesma regra que o GBA.
function stockLeagueItems(t){
 t.bag??={};t.bag.HyperPotion??=0;t.bag.Revive??=0;t.money=Math.max(0,Number(t.money)||0);
 // Priorizar reviver integrantes: a equipe é a principal defesa da IA.
 while(t.bag.Revive<12&&t.money>=1500){t.money-=1500;t.bag.Revive++}
 while(t.bag.HyperPotion<20&&t.money>=1200){t.money-=1200;t.bag.HyperPotion++}
}
function restoreLeagueParty(t){
 t.bag??={};let revived=0,restored=0;
 // Revive recupera 50% do HP; Hyper Potion recupera até 200 HP.
 for(const m of t.team){if(m.hp<=0&&(t.bag.Revive||0)>0){t.bag.Revive--;m.hp=Math.max(1,Math.floor(m.maxHp/2));revived++}}
 for(const m of t.team){if(m.hp>0&&m.hp<m.maxHp&&(t.bag.HyperPotion||0)>0){t.bag.HyperPotion--;m.hp=Math.min(m.maxHp,m.hp+200);restored++}}
 if(revived+restored)emit(t,'battle',`🧰 ${t.name} usou ${revived} Revive e ${restored} Hyper Potion entre as salas da Liga.`);
 return revived+restored;
}
function prepareStoneEvolutions(t){
 t.bag??={};for(const m of t.team){
  const stone=EVO_STONES[m.species];if(!stone||m.level<20)continue;
  if((t.bag[stone]||0)<1&&t.money>=2500){t.money-=2500;t.bag[stone]=(t.bag[stone]||0)+1;}
  if(t.bag[stone]>0)maybeEvolve(t,m);
 }
}
function leagueStep(t){if(t.badges<8||t.battle||t.healing)return;t.leagueRound??=0;
 if(t.leagueRound>=LEAGUE.length){if(!t.champion){t.champion=true;if(t.isUserBot)window.ELWTelemetry?.event('campaign_complete');t.finishTick=turns;t.personalBest=turns;const result={season,name:t.name,id:t.id,ticks:turns,team:t.team.map(m=>m.species),wins:t.wins,badges:t.badges};hall.push({...result,when:clock});records.push(result);records.sort((a,b)=>a.ticks-b.ticks);records=records.slice(0,100);emit(t,'rare',`👑 ${t.name} venceu a Elite Four e Wallace!`,true)}return}
 if(t.leagueRound===0){const need=Math.min(58,Math.max(1,Number(settings.leagueLevel)||58));const ready=readiness(t,need);if(!ready.ready){grindOneStep(t,need);return}if(!t.leaguePrepared){if(healingNeeded(t,true)){requestCenterVisit(t,'se preparar para a Elite Four');return}prepareStoneEvolutions(t);stockLeagueItems(t);t.leaguePrepared=true;emit(t,'story',`🎫 ${t.name} entrou na Liga com seus Pokémon prontos (meta: Nv. ${need}), levando itens comprados.`)}}
 else{restoreLeagueParty(t);if(settings.leagueHeal&&healingNeeded(t,true)){requestCenterVisit(t,'recuperação especial entre membros da Liga');return}}
 const [name,type,roster]=LEAGUE[t.leagueRound];if(alive(t.team)<0){t.leagueRound=0;t.leaguePrepared=false;requestCenterVisit(t,'recuperar-se após derrota na Liga');return}
 startBattle(t,roster.map(([species,level])=>({species,level})),'elite');emit(t,'battle',`🏆 ${t.name} enfrenta ${name} (${t.leagueRound+1}/5), sem Centro Pokémon entre as batalhas!`,true)
}
// Confrontos de campeonato com golpes/HP/turnos reais da simulacao.
// Equipes sao clonadas; um torneio nao altera a jornada ou os recursos da IA.
function tournamentDuel(a,b,opts={}){
 const teamCap=Math.max(1,Math.min(6,Number(opts.size||settings.tournamentTeamSize)||3));
 const clone=t=>t.team.filter(m=>m&&m.species).slice(0,teamCap).map(m=>{
   const fresh=createMon(m.species,Math.max(1,Number(m.level)||5),!!m.shiny);
   fresh.moves=(m.moves||fresh.moves).filter(n=>MOVES[n]);if(!fresh.moves.length)fresh.moves=['Tackle'];
   fresh.ivs={...m.ivs};fresh.evs={...m.evs};fresh.nature=m.nature;Object.assign(fresh,levelStats(m.species,fresh.level,fresh.ivs,fresh.evs,fresh.nature));fresh.maxHp=Math.max(1,Number(m.maxHp)||fresh.maxHp);fresh.hp=fresh.maxHp;
   fresh.pp=Object.fromEntries(fresh.moves.map(n=>[n,movePP(n)]));return fresh;
 });
 const A=clone(a),B=clone(b),maxTurns=Math.max(12,Math.min(220,Number(opts.limit||settings.tournamentMatchTurns)||90));
 let ia=0,ib=0,turn=0,log=[];const field={weather:settings.weather?worldWeather:'clear',weatherTurns:5,history:log};let prevX=null,prevY=null;
 const front=(team,i)=>{while(i<team.length&&team[i].hp<=0)i++;return i};
 const act=(att,def,t)=>{const move=opts.randomMoves?pick(att.moves):chooseMove(att,def,t.traits,t,field.weather);const hit=attack(att,def,move,field.weather);if(log.length<34||turn>maxTurns-5)log.push(hit.txt);return hit};
 for(;turn<maxTurns;turn++){
  ia=front(A,ia);ib=front(B,ib);if(ia>=A.length||ib>=B.length)break;
  const x=A[ia],y=B[ib];if(x!==prevX||y!==prevY){[...(x!==prevX?[x]:[]),...(y!==prevY?[y]:[])].sort((a,b)=>battleSpeed(b,field.weather)-battleSpeed(a,field.weather)).forEach(m=>enterBattle(m,field));prevX=x;prevY=y}const xFirst=battleSpeed(x,field.weather)>battleSpeed(y,field.weather)||battleSpeed(x,field.weather)===battleSpeed(y,field.weather)&&Math.random()<.5;
  if(xFirst){act(x,y,a);if(y.hp>0)act(y,x,b)}else{act(y,x,b);if(x.hp>0)act(x,y,a)}
  resolveBattleResidual(x,y,field);
  if(opts.arena&&turn===2)break;
 }
 const hpScore=team=>team.reduce((sum,m)=>sum+(m.hp>0?20:0)+100*Math.max(0,m.hp)/Math.max(1,m.maxHp),0);
 let as=hpScore(A),bs=hpScore(B);
 if(as===bs)as+=Math.random()-.5;
 const winner=as>bs?a:b;
 return {winner:winner.id,loser:winner.id===a.id?b.id:a.id,turns:turn+1,scoreA:Math.round(as),scoreB:Math.round(bs),log:log.slice(-24)};
}
let tournaments=[];
function runTournament(){
 if(!settings.tournamentEnabled)return;
 const eligible=trainers.filter(t=>t.stage>=settings.tournamentMinStage&&t.team?.some(m=>m.hp>0));
 if(eligible.length<2)return;
 const pool=[...eligible].sort(()=>Math.random()-.5).slice(0,Math.min(16,eligible.length));
 let bracket=pool.map(t=>t.id),rounds=[],matches=[];
 while(bracket.length>1){const next=[];for(let i=0;i<bracket.length;i+=2){
  const a=trainers[bracket[i]],b=trainers[bracket[i+1]];
  if(!b){next.push(a.id);continue}
  const r=tournamentDuel(a,b,{size:settings.tournamentTeamSize});const winner=trainers[r.winner];
  rounds.push(`${a.name} × ${b.name} → ${winner.name} (${r.turns} turnos)`);
  matches.push({a:a.name,b:b.name,winner:winner.name,...r});next.push(winner.id)
 }bracket=next}
 const champion=trainers[bracket[0]];champion.tournamentWins=(champion.tournamentWins||0)+1;
 const record={season,turns,winner:champion.name,rounds,matches,entrants:pool.length};
 tournaments.unshift(record);tournaments=tournaments.slice(0,30);
 emit(champion,'rare',`🏆 ${champion.name} venceu um torneio com ${pool.length} treinadores em batalhas por turnos!`,true)
}
// Encontros de pós-jogo adicionais do Emerald. O simulador continua adaptado:
// as cavernas e ilhas de evento são tratadas como objetivos de exploração, não como puzzles completos.
const POSTGAME_CHALLENGES=[
 {key:'latioslatias',place:'Route 118',species:t=>t.postgameColor==='vermelha'?'Latias':'Latios',level:40,min:58},
 {key:'rayquaza',place:'Sky Pillar',species:'Rayquaza',level:70,min:68},
 {key:'groudon',place:'Terra Cave',species:'Groudon',level:70,min:68},
 {key:'kyogre',place:'Marine Cave',species:'Kyogre',level:70,min:68},
 {key:'regirock',place:'Desert Ruins',species:'Regirock',level:40,min:58},
 {key:'regice',place:'Island Cave',species:'Regice',level:40,min:58},
 {key:'registeel',place:'Ancient Tomb',species:'Registeel',level:40,min:58},
 {key:'steven',place:'Meteor Falls',min:76,roster:[['Claydol',75],['Aggron',76],['Cradily',76],['Armaldo',76],['Skarmory',77],['Metagross',78]]}
];
function postgameQuestStep(t){
 if(!t.champion||t.battle||t.healing)return false;
 t.postgameQuest??={done:{},attempts:{}};
 if(!t.postgameColor)t.postgameColor=t.id%2?'vermelha':'azul';
 const q=t.postgameQuest;
 const challenge=POSTGAME_CHALLENGES.find(item=>!q.done[item.key]);
 if(!challenge)return false;
 const species=typeof challenge.species==='function'?challenge.species(t):challenge.species;
 if(species&&!legendaryAvailable(species,t)){
  // O fato de outro bot ter iniciado o encontro não significa captura.
  // Só marcar indisponível quando o lendário já tiver dono no mundo compartilhado.
  const owned=trainers.some(other=>other!==t&&allOwned(other).some(m=>m.species===species));
  if(owned)q.done[challenge.key]='capturado por outro treinador';
  else t.cooldown=4;
  return true;
 }
 if((q.attempts[challenge.key]||0)>=4){q.done[challenge.key]='derrotado';return true}
 // A jornada do Campeão também precisa de recuperação após a Elite Four.
 // Recuperar HP/PP num Centro antes de procurar um lendário ou Steven.
 if(healingNeeded(t,true)){requestCenterVisit(t,'se preparar para os desafios do pós-jogo');return true}
 const party=t.team.filter(m=>m&&m.hp>0);
 if(party.length<2||party.slice().sort((a,b)=>b.level-a.level)[0].level<challenge.min){
  train(t);return true;
 }
 if(species&&t.bag.Pokeball<10){if(t.money>=1200){t.money-=1200;t.bag.Pokeball+=10;}else{t.money+=250;t.cooldown=1;return true}}
 if(t.location!==challenge.place){t.location=challenge.place;t.walkMap='';t.storyArrived=false;t.cooldown=2;
  emit(t,'story',`🔭 ${t.name} segue para ${challenge.place} para explorar o pós-jogo.`,false);return true}
 if(!t.storyArrived)return true;
 if(species){
  if(!startBattle(t,{species,level:challenge.level},'postgameWild')){q.done[challenge.key]='indisponivel';return true}
  t.battle.postgameKey=challenge.key;
  emit(t,'rare',`🌟 ${t.name} encontrou ${species} Nv. ${challenge.level} em ${challenge.place}!`,true);
  return true;
 }
 if(challenge.roster){
  startBattle(t,challenge.roster.map(([name,level])=>({species:name,level})),'postgame');
  if(t.battle)t.battle.postgameKey=challenge.key;
  emit(t,'rare',`🏆 ${t.name} desafiou Steven Stone em Meteor Falls!`,true);
  return true;
 }
 return false;
}

// Pós-jogo: sete instalações com desafios simplificados, pontuações e símbolos.
// Não equivale à implementação completa dos minijogos da ROM.
const FRONTIER=[
 ['Battle Tower','Anabel','🏰','Batalhas consecutivas com três Pokémon'],
 ['Battle Dome','Tucker','🏟️','Chave de confrontos e seleção de equipe'],
 ['Battle Arena','Greta','🥊','Julgamento após três turnos'],
 ['Battle Factory','Noland','🏭','Equipes alugadas para o desafio'],
 ['Battle Palace','Spenser','🏯','Golpes selecionados automaticamente'],
 ['Battle Pike','Lucy','🐍','Salas com riscos e encontros inesperados'],
 ['Battle Pyramid','Brandon','🔺','Andares e batalhas sob pressão']
];
function frontierStep(t){
 if(!settings.frontierEnabled)return;
 t.frontier??={wins:{},losses:{},symbols:{},last:null};t.postgameSteps=(t.postgameSteps||0)+1;
 if(t.postgameSteps%3!==0)return;
 const place=FRONTIER[(Math.floor(t.postgameSteps/3)+t.id)%FRONTIER.length];const [name,brain,icon]=place;
 const count=t.frontier.wins[name]||0,elite=Math.max(54,Math.min(85,58+Math.floor(count/2)));
 const stageMon=t.team.filter(x=>x.hp>0).slice(0,3);
 if(stageMon.length<2){requestCenterVisit(t,'preparar equipe para a Battle Frontier');return}
 if(settings.postgameTraining&&t.postgameSteps%9===0){const trainee=partyTrainingMembers(t)[0];if(trainee&&trainee.level<80){expGain(t,trainee,trainee.level*13);return}}
 const pool=['Metagross','Salamence','Gardevoir','Milotic','Flygon','Walrein','Dusclops','Aggron','Sceptile','Blaziken','Swampert','Absol'];
 let roster=Array.from({length:3},()=>pick(pool));if(name==='Battle Factory'){
  const temp={...t,team:Array.from({length:3},()=>createMon(pick(pool),elite))};
  const rival={...t,id:-10000,team:roster.map(species=>createMon(species,elite)),traits:{strategy:.66}};
  const r=tournamentDuel(temp,rival,{size:3});frontierResult(t,name,brain,r.winner===t.id,r.turns);return;
 }
 const rival={id:-10000,team:roster.map(species=>createMon(species,elite)),traits:{strategy:.66},strategyMemory:{}};
 let r=tournamentDuel(t,rival,{size:3,arena:name==='Battle Arena',randomMoves:name==='Battle Palace',limit:name==='Battle Pyramid'?45:65});
 if(name==='Battle Pike'&&Math.random()<.2)r.winner=-10000;
 frontierResult(t,name,brain,r.winner===t.id,r.turns);
}
function frontierResult(t,name,brain,won,turnCount){
 const f=t.frontier;f.wins[name]??=0;f.losses[name]??=0;
 if(won)f.wins[name]++;else f.losses[name]++;
 const wins=f.wins[name],symbol=f.symbols[name]||0;
 if(won&&wins>=3&&symbol===0){f.symbols[name]=1;emit(t,'rare',`🥈 ${t.name} conseguiu o símbolo de prata de ${name}, após enfrentar desafios de ${brain}!`,true)}
 else if(won&&wins>=8&&symbol===1){f.symbols[name]=2;emit(t,'rare',`🥇 ${t.name} conseguiu o símbolo de ouro de ${name}!`,true)}
 else if(t.postgameSteps%9===0)emit(t,'battle',`${t.name} ${won?'venceu':'perdeu'} em ${name} (${turnCount} turnos).`);
 f.last={name,brain,won,turnCount,turns};
 t.location='Battle Frontier';t.walkMap='';t.cooldown=2;
}
function eventStep(t){
 if(t.battle){if(t.isUserBot&&settings.gameMode==='player'&&t.manualBattleEnabled!==false){if(t.queuedBattleAction)battleTurn(t);return}t.battle.delay=(t.battle.delay||0)+1;if(t.battle.delay>=settings.battlePace){t.battle.delay=0;battleTurn(t)}return}
 if(t.healing){centerVisitStep(t);return}
 if(t.cooldown>0){t.cooldown--;return}
 t.steps++;const s=t.stage;
 // Seu treinador também é uma IA: o usuário escolhe PRIORIDADES, mas
 // a história obrigatória continua na ordem dos mapas e eventos.
 if(t.isUserBot&&s>=10&&s<=27&&!t.battle&&!t.healing&&t.storyArrived){
  const goal=t.botGoal||'story';
  if(goal==='train'&&t.steps%5===0&&t.team.length){train(t);return}
  if(goal==='capture'&&s>=14&&t.steps%4===0&&t.bag.Pokeball>0&&wildHabitat(t)){if(wild(t))return}
  if(goal==='battle'&&s>=16&&s<27&&t.steps%5===0&&settings.trainerEncounters){if(routeTrainerFight(t))return}
  if(goal==='explore'&&s>=16&&t.steps%6===0&&wildHabitat(t)){if(wild(t))return}
 }
 if(s===8){if(!t.starter){starterChoice(t);return}advance(t,'Professor Birch foi salvo do Zigzagoon!');return}
 if(s===9){advance(t,`Professor Birch entregou oficialmente ${t.starter}.`);return}
 if(s===11){if(t.team.length&&healingNeeded(t)&&!t.healing){requestCenterVisit(t,'visitar o Centro de Oldale');return}advance(t,'Nurse Joy apresentou o Centro Pokémon de Oldale.');return}
   if(s===13){if(!t.team.length)return;
   if(personalRivalGate(t,'first-rival','May/Brendan na Rota 103'))return;
   if(!t.isUserBot&&(Math.max(...t.team.map(m=>m.level))<7||(t.losses>0&&Math.max(...t.team.map(m=>m.level))<10))){train(t);return}
   if(healingNeeded(t,true)){requestCenterVisit(t,'enfrentar o rival');return}
   const rivalStarter=window.EmeraldStarters?.counter(t.starter)||'Treecko';startBattle(t,{species:rivalStarter,level:5},'rival');if(t.battle&&t.isUserBot)t.battle.userRivalKey='first-rival';return} 
 // A trainer with fainted/injured Pokémon travels to a real Pokémon Center scene.
 if(s>=16&&!(s===27&&t.leagueRound>0&&!settings.leagueHeal)&&healingNeeded(t,GYMS[s]!==undefined||s===27)){requestCenterVisit(t,'recuperar os Pokémon antes de continuar a jornada');return}
 if(ensurePartyStep(t))return;if(finishPartyTrip(t))return;
 const target=getTrainingTarget(t);if(target&&!readiness(t,target).ready){grindOneStep(t,target);return}if(t.trainingLoan){finishProspectTraining(t);return}if(t.grindTrip){finishTrainingTrip(t);return}
 if(settings.collectionGoal&&s>=16&&s<27&&collectionStep(t))return;
 if(s>=16&&s<=27&&questStep(t))return;
 // Exploração opcional apenas depois dos eventos obrigatórios da etapa.
 if(s>=16&&s<=27&&sideRouteStep(t))return;
 if(GYMS[s]){
 const gymByStage={19:'RustboroCity_Gym',20:'DewfordTown_Gym',21:'MauvilleCity_Gym',22:'LavaridgeTown_Gym_1F',23:'PetalburgCity_Gym',24:'FortreeCity_Gym',25:'MossdeepCity_Gym',26:'SootopolisCity_Gym_1F'};
 const targetGym=gymByStage[s];
 if(t.officialMap!==targetGym||!t.storyArrived){t.location=targetGym;t.storyArrived=false;return}
 const [leader,type,pokemon,requiredLv]=GYMS[s];if(healingNeeded(t,true)){requestCenterVisit(t,`se preparar para enfrentar ${leader}`);return}if(settings.requireGuards&&gymGuardFight(t,s,requiredLv))return;
 startBattle(t,pokemon.map(([species,level])=>({species,level})),'gym');emit(t,'battle',`🏟️ ${t.name} desafia ${leader} com uma equipe treinada!`,true);return}
 if(s===27){leagueStep(t);return}
 if(s===2){t.bag.Potion++;advance(t,'Retirou uma Potion do PC.');return}
 if(s===14){t.bag.Pokeball+=5;advance(t,'Recebeu Pokédex e 5 Pokébolas.');return}
 if(s===10||s===12||s>=16){
  if(settings.trainerEncounters&&s>=16&&s<27){if(routeTrainerFight(t))return}
  if(t.bag.Pokeball<3&&t.money>=600){t.bag.Pokeball+=5;t.money-=600;emit(t,'story',`${t.name} comprou 5 Pokébolas para continuar as capturas.`)}
  const choice=Math.random();if(choice<t.traits.explore*.45&&wildHabitat(t)){wild(t);return}if(choice<t.traits.explore*.45+.22){train(t);return}if(settings.rivalries&&s>=16&&choice>.9){meet(t);return}
 }
 advance(t,STAGES[s]?.[1]||'Continuou a jornada.')
}
const WILD=['Surskit','Whismur','Meditite','Trapinch','Swablu','Barboach','Corphish','Absol','Torkoal','Spoink','Snorunt','Spheal','Poochyena','Zigzagoon','Wurmple','Lotad','Seedot','Taillow','Ralts','Shroomish','Wingull','Geodude','Electrike','Makuhita','Aron','Numel','Skitty','Spinda','Slakoth','Magikarp','Roselia','Nincada'];
const REGIONAL_WILD={
'Route 101':['Poochyena','Zigzagoon','Wurmple'],
 'Route 103':['Poochyena','Zigzagoon','Wingull'],
'Route 104':['Poochyena','Zigzagoon','Wurmple','Wingull','Taillow'],
'Route 106':['Makuhita','Geodude','Aron','Zubat'],
'Route 107':['Wingull','Tentacool','Magikarp'],
'Route 108':['Wingull','Tentacool','Magikarp'],
'Route 110':['Electrike','Plusle','Minun','Wingull','Oddish'],
'Route 111':['Trapinch','Sandshrew','Numel','Cacnea'],
'Route 112':['Numel','Machop','Zubat'],
'Route 113':['Spinda','Skarmory','Slugma'],
'Route 114':['Swablu','Lotad','Zangoose'],
'Route 117':['Roselia','Illumise','Volbeat','Marill'],
'Route 118':['Electrike','Wingull','Zigzagoon'],
'Route 119':['Tropius','Kecleon','Linoone','Oddish'],
'Route 120':['Absol','Kecleon','Oddish','Marill'],
'Route 121':['Shuppet','Duskull','Oddish','Kecleon'],
'Route 124':['Wingull','Tentacool','Magikarp','Wailmer'],
'Route 126':['Chinchou','Relicanth','Tentacool','Magikarp'],
'Route 128':['Tentacool','Wailmer','Magikarp'],
'Granite Cave':['Aron','Makuhita','Sableye','Zubat'],
'Rusturf Tunnel':['Whismur','Geodude'],
'Fiery Path':['Numel','Slugma','Torkoal'],
'Jagged Pass':['Numel','Machop','Spoink'],
'Meteor Falls':['Solrock','Zubat','Golbat'],
'Victory Road':['Golbat','Lairon','Hariyama','Sableye'],
'Mt. Pyre':['Duskull','Shuppet','Vulpix'],
'New Mauville':['Voltorb','Magnemite'],
'Shoal Cave':['Spheal','Snorunt','Zubat'],
'Safari Zone':['Oddish','Doduo','Girafarig','Pikachu','Natu'],
'Mirage Tower':['Trapinch','Sandshrew','Cacnea'],
'Route 102':['Poochyena','Zigzagoon','Lotad','Seedot','Ralts'],
'Route 103':['Poochyena','Wingull','Zigzagoon'],
'Petalburg Woods':['Shroomish','Wurmple','Slakoth','Nincada'],
'Rustboro City':['Geodude','Aron','Nosepass'],
'Dewford Town':['Makuhita','Geodude','Aron','Sableye'],
'Mauville City':['Electrike','Roselia','Volbeat','Illumise'],
'Lavaridge Town':['Numel','Torkoal','Spoink'],
'Petalburg City':['Slakoth','Zigzagoon','Shroomish'],
'Fortree City':['Swablu','Tropius','Kecleon'],
'Mossdeep City':['Spheal','Wingull','Barboach'],
'Sootopolis City':['Magikarp','Gyarados','Barboach'],
'Ever Grande City':['Absol','Altaria','Gardevoir']
};
const HOENN_MAP=[
['Littleroot Town','Início'],['Route 101','Rota inicial'],['Oldale Town','Centro Pokémon'],
['Route 103','Rival'],['Route 102','Capturas'],['Petalburg City','Norman'],
['Petalburg Woods','Floresta'],['Rustboro City','1ª insígnia'],['Dewford Town','2ª insígnia'],
['Slateport City','Porto'],['Mauville City','3ª insígnia'],['Verdanturf Town','Descanso'],
['Fallarbor Town','Meteor Falls'],['Lavaridge Town','4ª insígnia'],['Petalburg City','5ª insígnia'],
['Fortree City','6ª insígnia'],['Lilycove City','Compras'],['Mossdeep City','7ª insígnia'],
['Sootopolis City','8ª insígnia'],['Pacifidlog Town','Mar'],['Ever Grande City','Liga']
];
function wildHabitat(t){
 const loc=String(t.location||'');if(!t.starter||t.healing||t.battle||t.stage<10)return null;
 // A partir da V31 nenhum encontro selvagem depende de grama desenhada
 // artificialmente: usa metatile_attributes.bin do local real da IA.
 const api=window.emeraldOfficialWorld;
 if(api){
  const map=api.cache.get(t.officialMap||api.resolve(loc))?.value;
  if(!map)return null;
  const x=Math.round(t.walkX||0),y=Math.round(t.walkY||0),tile=api.infoAt(map,x,y);
  if(!tile||!api.walkable(map,x,y))return null;
   // Emerald: 0x02 grama alta, 0x03 grama longa, 0x09 borda de grama,
   // 0x24 grama coberta por cinzas. Grama curta (0x07) não gera encontros.
   if([0x02,0x03,0x09,0x24].includes(tile.behavior))return 'grass';
   // Encontros especiais são permitidos SOMENTE dentro de cavernas reais.
   if([0x08,0x0b].includes(tile.behavior)&&['MAP_TYPE_UNDERGROUND','MAP_TYPE_INDOOR'].includes(map.meta.map_type)&&/cave|tunnel|falls|road|path|hideout|chamber/i.test(map.name))return 'cave';
  return null;
 }
 const scene=getScene(loc),kind=scene.kind;
 if(kind==='indoor'||settings.protectedCities!==false&&['village','cross','garden','metro','electric','flowers','ash','spa','treehouse','mall','space','crater','league','harbor','island','floating'].includes(kind))return null;
 const x=Math.round(t.walkX||0),y=Math.round(t.walkY||0),terrain=fieldTile(loc,x,y);
 if(terrain==='tallgrass')return 'grass';
 if(kind==='cave'&&terrain==='cavefloor')return 'cave';
 if(kind==='ocean'&&terrain==='surf')return 'surf';
 if(kind==='desert'&&['sand','dune'].includes(terrain))return 'desert';
 if(kind==='volcano'&&['ash','stone'].includes(terrain))return 'volcano';
 return null;
}
function naturalEncounter(t){if(t.isUserBot&&settings.gameMode==='player'&&t.userRivalChoice?.choice==='pending')return false;if(!settings.enableTileEncounters||t.battle||t.healing||!t.walkJustStepped||t.stage<10||!t.starter)return false;
 if((t.wildCooldown||0)>0){t.wildCooldown--;return false}
 const habitat=wildHabitat(t);if(!habitat)return false;
 if(Math.random()>=Math.max(1,Math.min(70,Number(settings.encounterOdds)||18))/100)return false;
 t.encountersByTerrain??={};t.encountersByTerrain[habitat]=(t.encountersByTerrain[habitat]||0)+1;
 if(wild(t,habitat)){t.wildCooldown=7;return true}return false;
}

const LEGEND_SPECIES=['Rayquaza','Kyogre','Groudon','Latias','Latios'];
// A posse e os encontros ativos do mundo salvo são a fonte da unicidade.
function legendaryAvailable(species,exceptBattle=null){
 return !LEGEND_SPECIES.includes(species)||!trainers.some(t=>allOwned(t).some(m=>m.species===species)||(t!==exceptBattle&&t.battle?.enemy?.some(m=>m.species===species)));
}
function refreshLegend(m){if(!LEGEND_PROFILES[m.species])return;const ratio=clamp(m.hp/Math.max(1,m.maxHp),0,1);Object.assign(m,levelStats(m.species,m.level,m.ivs,m.evs,m.nature));m.hp=ratio>0?Math.max(1,Math.round(m.maxHp*ratio)):0;m.moves=[...new Set([...(m.moves||[]),...learnedMoves(m.species,m.level)])].filter(n=>MOVES[n]).slice(-4);m.pp??={};for(const move of m.moves)if(!Number.isFinite(m.pp[move]))m.pp[move]=movePP(move);}
function normalizeLegendaries(){
 for(const t of trainers)for(const m of [...allOwned(t),...(t.battle?.enemy||[])])refreshLegend(m);
 const seen=new Set();let removed=0;
 const keep=m=>{if(!LEGEND_SPECIES.includes(m.species))return true;if(seen.has(m.species)){removed++;return false}seen.add(m.species);return true};
 for(const t of trainers){
  const active=t.team[t.battle?.ownIndex];
  t.team=t.team.filter(keep);t.pc=t.pc.filter(keep);
  if(t.battle){if(!t.team.includes(active))t.battle=null;else t.battle.ownIndex=t.team.indexOf(active)}
 }
 for(const t of trainers){if(t.battle?.kind==='wild'&&!t.battle.enemy.every(keep))t.battle=null}
 if(removed&&trainers[0])emit(trainers[0],'rare',`🌟 Regra de lendários únicos aplicada: ${removed} exemplares duplicados removidos. Cada espécie lendária possui apenas um exemplar no mundo.`,true);
}

function collectionProgress(t){
 const owned=new Set([...(t.dex||[]),...allOwned(t).map(m=>m.species)]);
 const catalog=(NATIONAL_ENTRIES.length?NATIONAL_ENTRIES.filter(e=>e.kind==='species').map(e=>e.key):Object.keys(SPEC)).filter(n=>!LEGEND_SPECIES.includes(n)||(settings.legendaries&&(owned.has(n)||!trainers.some(other=>other!==t&&allOwned(other).some(m=>m.species===n)))));
 return {total:catalog.length,caught:catalog.filter(n=>owned.has(n)).length,missing:catalog.filter(n=>!owned.has(n))};
}
function collectionStep(t){
  if(!wildHabitat(t))return false;
  const progress=collectionProgress(t);
 if(!progress.missing.length){if(!t.collectionComplete){t.collectionComplete=true;emit(t,'rare',`${t.name} completou o catálogo do simulador!`,true)}return false}
 t.collectionComplete=false;
 // A campanha continua entre expedições; completar o catálogo é obrigatório antes da Liga.
 if(t.stage<27&&t.steps%8!==0)return false;
 if(!settings.capture){t.teamReason='Objetivo de coleção pausado: ative as capturas nas regras.';t.cooldown=4;return true}
 if(t.bag.Pokeball<5){if(t.money<600){train(t);t.money+=120;t.teamReason='Pesquisa de campo: treino remunerado para comprar Pokébolas.';return true}t.money-=600;t.bag.Pokeball+=5}
 const localSpecies=new Set(NATIONAL_POOL.pool(NATIONAL_ENTRIES,{location:t.location,badges:t.badges,champion:t.champion,matchHabitat:true}).map(row=>row.key));
 const available=progress.missing.filter(n=>localSpecies.has(n)&&legendaryAvailable(n));
 if(!available.length){t.teamReason='Nenhuma espécie nova disponível neste local: explore outra rota.';return false}
 const species=pick(available);
 t.teamReason=`Expedição de pesquisa: capturar ${species} (${progress.caught}/${progress.total}).`;
 // Encontro selecionado apenas da tabela fixa desta área, não do catálogo global.
 const level=Math.max(3,Math.min(45,Math.round(t.team.reduce((n,m)=>n+m.level,0)/t.team.length)-3));
 emit(t,'story',`${t.name} iniciou uma expedição de pesquisa para encontrar ${species}.`);
 startBattle(t,{species,level},'wild');return true;
}

function wild(t,forcedHabitat){const habitat=forcedHabitat||wildHabitat(t);if(!habitat||!NATIONAL_POOL.hasEncounters(t.location))return false;let pool=(REGIONAL_WILD[t.location]||[]).filter(n=>SPEC[n]);const legends=LEGEND_SPECIES.filter(n=>legendaryAvailable(n));pool=pool.filter(n=>!LEGEND_SPECIES.includes(n));
 // 65% chance to encounter an eligible National species in a compatible biome;
 // remaining encounters preserve the recognizable classic Emerald routes.
 const national=settings.nationalEncounters&&NATIONAL_ENTRIES.length&&Math.random()<.65
  ?NATIONAL_POOL.pick(NATIONAL_ENTRIES,{location:t.location,habitat,badges:t.badges,champion:t.champion,allowForms:settings.nationalForms,owned:t.dex})
  :null;
 if(!national&&!pool.length)return false;let species=national?.key||((settings.legendaries&&legends.length&&t.stage>=24&&Math.random()<1/settings.legendaryOdds)?pick(legends):pick(pool));let lv=clamp(Math.max(2,Math.floor((PROGRESSION_LEVELS[t.stage]||Math.max(3,t.stage))/1.3)-7)+rnd(6),2,45),shiny=settings.shinies&&rnd(settings.shinyOdds)===0;if(LEGEND_PROFILES[species])lv=Math.max(lv,LEGEND_PROFILES[species].minLevel);if(shiny)rareEvents++;emit(t,shiny?'rare':'wild',`${t.name} encontrou ${shiny?'✨ SHINY ':''}${species} selvagem (Nv. ${lv})!`,shiny);startBattle(t,{species,level:lv,shiny},'wild');return true}
function train(t){if(!t.team.length)return;
 if(t.badges>=3){for(const m of t.team){const stone=EVO_STONES[m.species];if(stone&&m.level>=20&&t.money>=2500){t.money-=2500;t.bag[stone]=(t.bag[stone]||0)+1;emit(t,'story',`💎 ${t.name} comprou ${stone} para ${m.species}.`);maybeEvolve(t,m)}}}
if(t.pc?.length&&t.steps%12===0)rebalanceTeam(t,'treinamento');const sorted=partyTrainingMembers(t);const mon=sorted[Math.random()<.7?0:rnd(sorted.length)];
 expGain(t,mon,Math.max(35,Math.round(expNeeded(mon.level)*(.65+Math.random()*.45))));if(settings.shareTraining&&sorted.length>1)expGain(t,sorted[1],Math.round(expNeeded(mon.level)*.3));
 if(Math.random()<.15){t.bag.Potion=Math.min(9,t.bag.Potion+1);emit(t,'story',`${t.name} treinou ${mon.species} e encontrou uma Potion.`)}else emit(t,'level',`${t.name} treinou ${mon.species}.`);t.cooldown=1+rnd(3)
}
function meet(t){let candidates=trainers.filter(o=>o.id!==t.id&&o.team.length&&o.stage>=16&&!o.battle&&o.team.some(m=>m.hp>0));if(!candidates.length)return;let other=pick(candidates);if(settings.friendships&&Math.random()<.55){t.friends??={};other.friends??={};t.friends[other.id]=(t.friends[other.id]||0)+1;other.friends[t.id]=(other.friends[t.id]||0)+1;emit(t,'story',`🤝 ${t.name} encontrou ${other.name}; amizade fortalecida (${t.friends[other.id]}).`);remember(t,`Fez amizade com ${other.name} em ${t.location}.`);return}startBattle(t,other.team.filter(m=>m.hp>0).slice(0,3).map(m=>({species:m.species,level:m.level,shiny:m.shiny})),'ai',other.id);emit(t,'battle',`🔥 Rivalidade: ${t.name} desafia ${other.name}!`,true)}
function rank(t){return t.badges*300+t.wins*12+t.stage*18+t.dex.length*9+(t.champion?2500:0)-t.losses*3}
function percent(n,d){return clamp(Math.round(100*n/Math.max(1,d)),0,100)}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function spriteFallbackScript(species){const rom=`assets/pokemon_fit/${encodeURIComponent(species.toLowerCase())}.png`, gif=`assets/pokemon_fit/${encodeURIComponent(species.toLowerCase())}.gif`, placeholder='assets/ui/pokemon_missing.svg';return `if(this.dataset.fallback==='1'){this.dataset.fallback='2';this.src='${placeholder}';return;} this.dataset.fallback='1'; this.src='${gif}'`;}
function tacticalBrief(t){
 const next=nextGymType(t),answers=t.team.filter(m=>(m.moves||[]).some(n=>effective(MOVES[n]?.[0],next)>1));
 const weak=TOURNAMENT_TYPES.map(type=>({type,count:t.team.filter(m=>multiEffect(type,m)>1&&!(type==='Ground'&&ability(m)==='Levitate')).length})).sort((a,b)=>b.count-a.count)[0];
 const upgrades=t.team.map(m=>{for(let lv=m.level+1;lv<=Math.min(100,m.level+15);lv++){const moves=learnedMoves(m.species,lv).filter(n=>!m.moves.includes(n));if(moves.length)return `${m.species} · Nv. ${lv}: ${moves.join(', ')}`}return null}).filter(Boolean);
 const foe=t.battle?.enemy[t.battle.enemyIndex],profile=foe&&LEGEND_PROFILES[foe.species];
 return `<div class="tacticalBrief"><div class="tacticalHeading"><span class="eyebrow">PLANO DE BATALHA</span><b>${t.champion?'Preparação para o pós-jogo':`Próximo desafio: ${esc(next)}`}</b></div><p>${answers.length?`Cobertura favorável: <strong>${answers.map(m=>esc(m.species)).join(', ')}</strong>.`:'A equipe ainda precisa de golpes super efetivos para o próximo desafio.'}</p><p>${weak?.count>=2?`Ponto de atenção: ${weak.count} parceiros são vulneráveis a <strong>${esc(weak.type)}</strong>. Diversificar a equipe reduz esse risco.`:'Boa distribuição de resistências. Níveis, HP e habilidades também decidem a batalha.'}</p>${upgrades.length?`<div class="trainingRoadmap"><small>NO HORIZONTE · PRÓXIMOS 15 NÍVEIS</small>${upgrades.map(text=>`<span>${esc(text)}</span>`).join('')}</div>`:''}${profile?`<div class="legendThreat"><small>AMEAÇA LENDÁRIA · ${esc(profile.title)}</small><b>${esc(foe.species)} · Nv. ${foe.level}</b><p>${esc(profile.detail)}</p><span>Enfraqueça até 30% de HP para a IA priorizar a captura. Chance atual: ${Math.round(captureChance(foe)*100)}% por Pokébola.</span></div>`:''}</div>`;
}
function officialTrainerEncounter(t,sentry,mapName=''){if(!t||t.battle||t.healing||!t.team?.length)return false;const key=String(sentry?.key||'route');const hash=[...key].reduce((n,ch)=>((n*33)^ch.charCodeAt(0))>>>0,5381);let pool=(REGIONAL_WILD[t.location]||[]).filter(n=>SPEC[n]);const count=t.badges>=6?3:t.badges>=3?2:1;const base=Math.max(5,Math.min(52,(PROGRESSION_LEVELS[t.stage]||Math.max(8,t.stage))-1+((hash>>3)%4)));const label=String(sentry?.label||'Treinador da rota');const rosterCandidates=[...(GYM_NPC_ROSTERS[mapName]||[]),...(NAMED_ROUTE_TRAINERS[t.stage]||[])];const scripted=rosterCandidates.find(row=>label.toLowerCase().includes(String(row[0]).split(' ').at(-1).toLowerCase()));const enemy=scripted?scripted[1].map(([species,level])=>({species,level})):Array.from({length:count},(_,i)=>({species:pool[(hash+i*7)%pool.length],level:clamp(base+i,5,55)}));const started=startBattle(t,enemy,'routeTrainer');if(!t.battle)return false;t.battle.label=label;t.battle.source='official';t.battle.sourceMap=mapName||t.location;t.battle.sentryKey=key;emit(t,'battle',`👀 ${t.name} entrou no campo de visão de ${label} em ${mapName||t.location}!`,true);remember(t,`Foi desafiado por ${label} em ${mapName||t.location}.`);t.cooldown=1;return true}

function battleKindLabel(b){if(!b)return 'Batalha';if(b.kind==='gym')return 'Ginásio';if(b.kind==='elite')return 'Elite Four';if(b.kind==='wild')return 'Pokémon selvagem';if(b.kind==='ai')return 'Duelo entre IAs';if(b.kind==='routeTrainer')return b.label?`Treinador da rota · ${b.label}`:'Treinador da rota';if(b.kind==='gymTrainer')return 'Treinador do ginásio';if(b.kind==='rival')return 'Rival';if(b.kind==='rescue')return 'Resgate';return 'Batalha de jornada'}

function legendaryLedger(){return `<div class="legendLedger"><div class="tacticalHeading"><span class="eyebrow">LENDÁRIOS DE HOENN</span><small>UM EXEMPLAR POR ESPÉCIE</small></div>${Object.entries(LEGEND_PROFILES).map(([species,p])=>{const owner=trainers.find(t=>allOwned(t).some(m=>m.species===species)),encounter=trainers.find(t=>t.battle?.enemy?.some(m=>m.species===species));return `<div class="legendLedgerRow"><div><b>${species}</b><small>${esc(p.title)} · ${p.ability}</small></div><span>${owner?`Com ${esc(owner.name)}`:encounter?`Encontro com ${esc(encounter.name)}`:`Livre · Nv. ${p.minLevel}+`}</span></div>`}).join('')}</div>`}
function pokeImg(m,small=false){if(!m)return '';const species=String(m.species||'Unknown');const data=NATIONAL_BY_NAME.get(species);return window.EmeraldPokemonArt.tag(species.split('@')[0],{dex:data?.dex,kind:data?.kind||'species',className:`pokeSprite romSprite ${m.shiny?'shinyRom':''} ${small?'sm':''}`});}

function render(){selected=clamp(selected,0,trainers.length-1);featured=clamp(featured,0,trainers.length-1);let t=trainers[selected],f=trainers[camera==='auto'?featured:selected],sorted=[...trainers].sort((a,b)=>rank(b)-rank(a));
$('#status').textContent=paused?'● Pausado':'● Ao vivo';$('#featured').innerHTML=`<strong class="highlight">🎥 ${esc(f.name)} • ${esc(f.location)}</strong><div style="margin-top:6px">${esc(f.events[0]?.msg||'Preparando a jornada...')}</div><small>${esc(f.personality)} • ${f.badges} insígnias • ${f.wins} vitórias</small>`;
if(selected>=trainers.length)selected=0;if(featured>=trainers.length)featured=0;$('#dashNumbers').innerHTML=`<div><b>${trainers.length}</b><small>Treinadores</small></div><div><b>${trainers.filter(x=>x.battle).length}</b><small>Batalhas</small></div><div><b>${trainers.reduce((n,x)=>n+(x.captures||0),0)}</b><small>Capturas</small></div><div><b>${trainers.filter(x=>x.champion).length}</b><small>Campeões</small></div>`;$('#worldProgress').textContent=`${trainers.filter(x=>x.starter).length}/${trainers.length} iniciais escolhidos • ${trainers.reduce((s,x)=>s+x.badges,0)} insígnias conquistadas • ${clock} eventos registrados`;
$('#worldBar').style.width=percent(trainers.reduce((s,x)=>s+x.stage,0),trainers.length*27)+'%';
$('#trainerTitle').textContent=`🧢 ${t.name} — ${t.personality}`;$('#place').textContent=window.emeraldOfficialWorld?.label?.(t.location)||t.location;$('#objective').textContent=settings.collectionGoal&&t.stage>=16?`Coleção ${collectionProgress(t).caught}/${collectionProgress(t).total} · ${STAGES[Math.min(t.stage,27)][1]}`:STAGES[Math.min(t.stage,27)][1];$('#badges').textContent=t.badges+'/8';$('#record').textContent=t.wins+' / '+t.losses;$('#dex').textContent=t.dex.length+' espécies';$('#money').textContent=`₽${t.money} • 🧴${t.bag.Potion} ⚪${t.bag.Pokeball}`;$('#trainerProgress').textContent=`Etapa ${Math.min(t.stage+1,28)} de 28 • ${t.steps} decisões • ${t.grindSessions||0} treinos • ${t.healingCount||0} Centros Pokémon`;$('#trainerBar').style.width=percent(t.stage,27)+'%';
const rd=readiness(t,getTrainingTarget(t)||1);const targetLv=getTrainingTarget(t);$('#trainingStatus').innerHTML=`<div class="trainingTop"><b>${t.champion?'👑 Campeão de Hoenn':t.healing?'🏥 No Centro Pokémon':t.battle?'⚔️ Batalhando':targetLv&& !rd.ready?'💪 Grinding em andamento':t.stage>=27?'🏆 Desafio da Liga': '✅ Pronto para avançar'}</b><span>${targetLv?'Meta Nv. '+targetLv:'Jornada inicial'} • ${t.healingCount||0} visitas ao Centro</span></div><div class="trainingBottom">${t.champion?`Venceu os oito ginásios e a Elite Four com ${t.team.length} Pokémon!`:t.healing?`Centro de ${esc(t.healing.city)} — ${esc(t.healing.phase==='arrival'?'Aguardando recuperação':'Voltando à rota')}`:targetLv?`Equipe preparada: ${rd.required} Pokémon avaliados • nível mínimo ${rd.min} / ${targetLv} • ${t.grindSessions||0} sessões de treino`:`Siga a jornada de Hoenn`}</div><div class="bar"><div class="fill" style="width:${targetLv?percent(rd.min,targetLv):0}%"></div></div>`;$('#tacticalBrief').innerHTML=tacticalBrief(t);$('#legendaryLedger').innerHTML=legendaryLedger();$('#teamCount').textContent=`${t.team.length}/${settings.teamSize}`;$('#journeyTeam').innerHTML=`<b>${esc(t.name)}</b> • ${esc(t.location)} • ${t.badges}/8 insígnias • ${t.leagueRound||0}/5 Liga • ${t.tournamentWins||0} torneios • ${(t.pc||[]).length} no PC • Próximo objetivo: ${esc(STAGES[Math.min(t.stage,27)][1])}`;$('#team').innerHTML=Array.from({length:6},(_,i)=>{const m=t.team[i];if(!m)return `<div class="mon emptyMon"><span class="emptySymbol">＋</span><small>Espaço ${i+1} vazio</small></div>`;const hp=percent(m.hp,m.maxHp);return `<div class="mon teamMon"><div class="pokeCardTop"><div class="spriteWell">${pokeImg(m,true)}</div><div class="monBody"><div class="monHeading"><b>${m.shiny?'✨ ':''}${esc(m.species)}</b><span class="levelTag">Nv. ${m.level}</span></div><small class="monIdentity">${LEGEND_PROFILES[m.species]?'LENDÁRIO · ':''}${esc(roleOf(m))} · ${esc(ability(m)||'Sem habilidade especial')}</small>${monTypes(m).map(tp=>`<span class="typeTag type-${esc(tp)}">${esc(tp)}</span>`).join(' ')}<div class="hpCaption"><span>HP</span><span>${m.hp}/${m.maxHp}</span></div><div class="bar hpBar"><div class="fill" style="width:${hp}%;background:${hp<25?'#f37b74':hp<50?'#e8c86a':'#56d9a3'}"></div></div></div></div><div class="monStats" aria-label="Atributos atuais"><span>Ataque <b>${m.atk}</b></span><span>Defesa <b>${m.def}</b></span><span>At. Esp. <b>${m.spAtk}</b></span><span>Def. Esp. <b>${m.spDef}</b></span><span>Velocidade <b>${m.speed}</b></span></div><div class="hpCaption"><span>EXP</span><span>${m.exp}/${m.level>=levelCapFor(t)?0:expNeeded(m.level)}</span></div><div class="bar expBar" aria-label="Experiência para o próximo nível"><div class="fill" style="width:${percent(m.exp,m.level>=levelCapFor(t)?1:expNeeded(m.level))}%"></div></div><small class="growthHint">Level Cap individual: ${levelCapFor(t)} • ${esc(m.nature||"Hardy")} • IVs e EVs persistentes</small><div class="moveRow monAttackPreview">${window.EmeraldMonDetails?.moveList(m)||(m.moves||[]).map(x=>`<span>${esc(x)}</span>`).join('')}</div></div>`}).join('');
$('#battle').innerHTML=t.battle?(()=>{let b=t.battle,a=t.team[b.ownIndex],e=b.enemy[b.enemyIndex];const health=m=>Math.max(0,Math.min(100,100*(m?.hp||0)/Math.max(1,m?.maxHp||1)));const bar=m=>`<div class="combatHp"><div style="width:${health(m)}%;background:${health(m)<25?'#f17a7a':health(m)<55?'#e3c36d':'#61d9a0'}"></div></div>`;return `<div class="battle"><div class="battleHeader"><span>⚔️ ${esc(battleKindLabel(b))}</span><span>Turno ${b.round||0} · ${b.enemy.length-b.enemyIndex} adversário(s)</span></div><div class="versus pokeScene"><div>${pokeImg(a)}<b>${esc(a?.species||'?')}</b><small style="display:block">Nv. ${a?.level||'?'} • ${a?.hp||0}/${a?.maxHp||0} HP</small>${bar(a)}</div><span>VS</span><div>${pokeImg(e)}<b>${esc(e?.species||'?')}</b><small style="display:block">Nv. ${e?.level||'?'} • ${e?.hp||0}/${e?.maxHp||0} HP</small>${bar(e)}</div></div><p class="note">Clima: ${esc(WEATHER_NAMES[b.weather]||WEATHER_NAMES.clear)} · ${b.weatherTurns||0} turnos restantes</p>${b.decision?`<details class="decisionInspect"><summary>Decisão da IA · ${esc(b.decision.profile)}</summary><p>${esc(b.decision.selected.reason)}</p>${b.decision.alternatives.map(a=>`<p>${esc(a.reason)} <small>Nota ${Math.round(a.score)}</small></p>`).join('')}</details>`:''}<div class="battlelog">${b.history.slice(0,6).map(x=>`<div class="battleTurnEntry">${esc(x)}</div>`).join('')||'Batalha começando...'}</div></div>`})():'<p class="muted">Nenhuma batalha em andamento. O próximo duelo importante aparecerá aqui, com HP e histórico dos turnos.</p>';
$('#memory').innerHTML=t.mem.length?t.mem.map(m=>`<div class="memory">🧠 ${esc(m)}</div>`).join(''):'<p class="muted">As experiências importantes aparecerão aqui.</p>';
const badgeSorted=[...trainers].sort((a,b)=>(b.badges||0)-(a.badges||0)||(b.champion?1:0)-(a.champion?1:0)||(b.wins||0)-(a.wins||0)||(a.id||0)-(b.id||0));
$('#ranking').innerHTML=badgeSorted.map((x,i)=>`<div class="rank cleanBadgeRow"><span class="num">${i+1}º</span><span class="grow"><b>${esc(x.name)}</b><small>${x.champion?'👑 Campeão de Hoenn':'Jornada em andamento'}</small></span><b class="cleanBadgeScore">🏅 ${x.badges||0}/8</b></div>`).join('');
$('#feed').innerHTML=feed.filter(e=>filter==='all'||(filter==='battle'?e.kind==='battle':e.kind==='rare')).slice(0,90).map(e=>`<div class="entry"><strong>#${e.time} ${esc(trainers[e.id]?.name||'Treinador')}</strong><div>${esc(e.msg)}</div></div>`).join('')||'<p class="muted">Aguardando eventos...</p>';
let rival=Object.entries(pairScores).map(([key,val])=>{let [a,b]=key.split('-').map(Number);return{a,b,scoreA:val.a,scoreB:val.b,n:val.a+val.b}}).sort((x,y)=>y.n-x.n).slice(0,8);
$('#rivalries').innerHTML=rival.length?rival.map(r=>`<div class="memory"><b>${esc(trainers[r.a]?.name||'Treinador')} × ${esc(trainers[r.b]?.name||'Treinador')}</b><div class="muted">${pairScores[[r.a,r.b].join('-')]?.a??0} × ${pairScores[[r.a,r.b].join('-')]?.b??0} vitórias</div></div>`).join(''):'<p class="muted">As rivalidades aparecerão quando duas IAs batalharem.</p>';
$('#hallEntries').innerHTML=hall.length?hall.slice().reverse().map((h,i)=>`<div class="memory">👑 <b>${esc(h.name)}</b> • Temporada ${h.season} • ${h.wins} vitórias • ${h.badges} insígnias<div class="muted">Equipe: ${h.team.map(esc).join(', ')}</div></div>`).join(''):'<p class="muted">Ainda não há campeões. Acompanhe a corrida pelas 8 insígnias e pela Liga!</p>';
$('#regionMap').innerHTML=HOENN_MAP.map(([name,detail],i)=>{let here=trainers.filter(x=>x.location===name).length;let reached=trainers.some(x=>x.stage>=Math.min(27,Math.floor(i*27/(HOENN_MAP.length-1))));return `<div class="regionCell ${here?'occupied':''}"><b>${esc(name)}</b><small>${esc(detail)}</small><span>${here} IAs presentes ${reached?'• explorada':'• futura'}</span><div class="mapNames">${trainers.filter(x=>x.location===name).slice(0,7).map(x=>esc(x.name)).join(' · ')}</div></div>`}).join('');
const formatTicks=n=>{let h=Math.floor(n/3600),m=Math.floor(n%3600/60),sec=n%60;return [h,m,sec].map(v=>String(v).padStart(2,'0')).join(':')};
const winners=trainers.filter(x=>x.champion&&Number.isFinite(x.finishTick)).sort((a,b)=>a.finishTick-b.finishTick);const contenders=[...trainers].filter(x=>!x.champion).sort((a,b)=>b.stage-a.stage||b.badges-a.badges||b.wins-a.wins).slice(0,10);
$('#raceClock').textContent=formatTicks(turns);
$('#raceLeader').textContent=winners.length?winners[0].name+' • '+formatTicks(winners[0].finishTick):'Aguardando...';
$('#raceTop').innerHTML=winners.length?winners.slice(0,10).map((x,i)=>`<div class="rank"><span class="num">${i===0?'🥇':i===1?'🥈':i===2?'🥉':i+1}</span><span class="grow"><b>${esc(x.name)}</b><small>8 insígnias • ${x.wins} vitórias</small></span><b>${formatTicks(x.finishTick)}</b></div>`).join('') :`<p class="note">Classificação provisória por progresso, até aparecer o primeiro campeão.</p>${contenders.map((x,i)=>`<div class="rank"><span class="num">${i+1}</span><span class="grow"><b>${esc(x.name)}</b><small>Etapa ${x.stage+1}/28 • ${x.badges} insígnias</small></span><b>${x.wins} vitórias</b></div>`).join('')}`;
$('#raceRecords').innerHTML=records.length?records.slice().sort((a,b)=>a.ticks-b.ticks).slice(0,10).map((x,i)=>`<div class="rank"><span class="num">${i+1}</span><span class="grow"><b>${esc(x.name)}</b><small>Temporada ${x.season} • ${esc(x.team.join(', '))}</small></span><b>${formatTicks(x.ticks)}</b></div>`).join(''):'<p class="muted">Nenhum recorde salvo ainda.</p>';
const challenges=[
['🌱 Todos com inicial',trainers.filter(x=>x.starter).length,trainers.length],
['🏅 Primeiras 10 insígnias',Math.min(10,trainers.reduce((n,x)=>n+x.badges,0)),10],
['⚔️ 100 vitórias',Math.min(100,trainers.reduce((n,x)=>n+x.wins,0)),100],
['✨ Primeiro shiny capturado',trainers.some(x=>x.team.some(m=>m.shiny))?1:0,1],
['👑 Primeiro campeão',winners.length?1:0,1],
['🏆 Meta de campeões',Math.min(winners.length,settings.seasonGoal),settings.seasonGoal]
];
$('#challenges').innerHTML=challenges.map(([label,done,total])=>`<div class="challenge"><div class="toolbar" style="justify-content:space-between"><b>${esc(label)}</b><small>${done}/${total}</small></div><div class="bar"><div class="fill" style="width:${percent(done,total)}%"></div></div></div>`).join('');
$('#pcInfo').innerHTML=`<p><b>${esc(t.name)}</b> • ${t.team.length} na equipe • ${(t.pc||[]).length} no PC • ${t.captures||0} capturas • ${t.teamChanges||0} reorganizações</p><div class="team pcTeamDetailed">${(t.pc||[]).slice(0,36).map(m=>`<div class="mon pcMonCard"><div class="pcMonHeading">${pokeImg(m,true)}<b>${esc(m.species)}</b> • Nv. ${m.level}</div>${window.EmeraldMonDetails?.html(m)||''}</div>`).join('')||'<p class="muted">Nenhum Pokémon guardado ainda.</p>'}</div>`;
$('#teamChanges').innerHTML=(t.teamLog||[]).slice(0,5).map(x=>`<div class="memory">${esc(x)}</div>`).join('');
$('#frontierSelected').innerHTML=t.champion?`<div class="frontierOverview"><h3>👑 ${esc(t.name)} • Battle Frontier</h3><p>🥈 ${Object.values(t.frontier?.symbols||{}).filter(v=>v>=1).length}/7 pratas • 🥇 ${Object.values(t.frontier?.symbols||{}).filter(v=>v>=2).length}/7 ouros • ${t.postgameSteps||0} passos de pós-jogo</p><p>${t.frontier?.last?`Último desafio: ${esc(t.frontier.last.name)} — ${t.frontier.last.won?'vitória':'derrota'}`:'Primeira visita ao pós-jogo em preparação.'}</p></div>`:`<div class="frontierOverview">Acompanhe ${esc(t.name)} até vencer Wallace para liberar o pós-jogo.</div>`;
$('#frontierFacilities').innerHTML=FRONTIER.map(([name,brain,icon,info])=>{const f=t.frontier||{wins:{},losses:{},symbols:{}};const symbol=f.symbols?.[name]||0;return `<div class="frontierFacility"><div class="frontierIcon">${icon}</div><div><b>${esc(name)}</b><small>${esc(brain)} • ${esc(info)}</small><small>${f.wins?.[name]||0} vitórias · ${f.losses?.[name]||0} derrotas</small></div><span class="frontierMedal">${symbol>=2?'🥇':symbol===1?'🥈':'○'}</span></div>`}).join('');
$('#campaignTrainer').innerHTML=`<b>${esc(t.name)}</b> • ${esc(t.location)} • ${t.badges}/8 insígnias • ${t.leagueRound||0}/5 Liga${settings.collectionGoal?`<p>Pesquisa de campo: ${collectionProgress(t).caught}/${collectionProgress(t).total} espécies. Colete novas espécies sem bloquear a Liga.</p>`:''}`;$('#campaignMissions').innerHTML=Object.entries(CAMPAIGN).map(([stage,qs])=>`<div class="card"><h3>Etapa ${stage} ${Number(stage)<27?'• Hoenn':'• Victory Road'}</h3>${qs.map(([place,description],i)=>`<div class="missionItem ${t.stage>Number(stage)||t.stage===Number(stage)&&(t.quests?.[stage]||0)>i?'done':''}">${t.stage>Number(stage)||t.stage===Number(stage)&&(t.quests?.[stage]||0)>i?'✓':'○'} ${esc(place)} — ${esc(description)}</div>`).join('')}</div>`).join('');$('#tournamentList').innerHTML=tournaments.length?tournaments.map((x,i)=>`<div class="card"><h3>🏆 ${esc(x.winner)} • Rodada ${x.turns}</h3><small>${x.entrants} participantes</small><div class="scroll">${(x.matches?.length?x.matches:x.rounds.map(y=>({summary:y}))).map(m=>`<details class="matchReplay"><summary>${esc(m.summary||`${m.a} × ${m.b} → ${m.winner} (${m.turns} turnos)`)}</summary><div class="replayMoves">${(m.log||[]).map(y=>`<div class="replayMove">${esc(y)}</div>`).join('')||'<small>Histórico resumido de versão antiga.</small>'}</div></details>`).join('')}</div></div>`).join(''):'<p class="muted">O primeiro torneio será realizado quando houver treinadores preparados.</p>';$('#worldStats').innerHTML=`<div class="stats" style="grid-template-columns:1fr 1fr"><div class="stat"><small>Capturas</small><b>${feed.filter(e=>e.kind==='capture').length}</b></div><div class="stat"><small>Shinies</small><b>${trainers.flatMap(x=>x.team).filter(m=>m.shiny).length}</b></div><div class="stat"><small>Batalhas ativas</small><b>${trainers.filter(x=>x.battle).length}</b></div><div class="stat"><small>Campeões</small><b>${trainers.filter(x=>x.champion).length}</b></div></div>`;
Array.from($('#trainerGrid').children).forEach((b,i)=>{b.classList.toggle('active',i===selected);b.title=trainers[i].location})}
function buildTrainerGrid(){let g=$('#trainerGrid');g.innerHTML='';trainers.forEach((t,i)=>{let b=document.createElement('button');b.className='trainerTile';b.textContent=t.name;b.style.fontSize='11px';b.title=t.name;b.onclick=()=>{selected=i;camera='manual';$('#camera').value='manual';render()};g.append(b)})}try{const saved=JSON.parse(localStorage.getItem('emerald_living_world_v8_records')||'[]');if(Array.isArray(saved)&&saved.length&&!records.length)records=saved}catch(e){}
if(trainers[0]?.isUserBot){trainers[0].name=String(trainers[0].botName||trainers[0].name).slice(0,24)}
buildTrainerGrid();$('#playerCount').value=String(trainers.length);syncSpeedUi();$('#applyCount').textContent='⚙️ Ajustar bots';$('#applyCount').onclick=()=>window.emeraldOpenWorldControl?.({count:Number($('#playerCount').value)});

// v16 — terreno compartilhado entre a logica de trajetos e o desenho da câmera.
/* v17 — cenários regionais distintos e caminhos individuais de Hoenn. */
const MAP_W=42, MAP_H=30;
const sceneCache=new Map();
function fieldHash(x,y,z){let h=Math.imul(x+z,374761393)+Math.imul(y-z,668265263);h=Math.imul(h^(h>>>13),1274126177);return (h^(h>>>16))>>>0}
function fieldSeed(s){let h=2166136261;for(const c of String(s))h=Math.imul(h^c.charCodeAt(0),16777619);return h>>>0}
const isInterior=loc=>/Caminh[aã]o|Quarto|Casa|Laborat[oó]rio|Centro Pok[eé]mon|Pok[eé]mon Center|Gin[aá]sio|Loja|Mercado|Pok[eé]mart|Liga Pok[eé]mon|Elite Four/i.test(loc);
const sceneNames=['Caminhão','Casa','Quarto','Casa do rival','Quarto do rival','Laboratório','Littleroot','Route 101','Oldale Town','Centro Pokémon • Oldale Town','Route 103','Route 102','Petalburg City','Petalburg Woods','Rustboro City','Dewford Town','Granite Cave','Slateport City','Route 110','Mauville City','Verdanturf Town','Route 111','Deserto da Route 111','Fallarbor Town','Meteor Falls','Mt. Chimney','Jagged Pass','Lavaridge Town','Route 119','Fortree City','Route 120','Lilycove City','Safari Zone','Route 124','Mossdeep City','Route 126','Sootopolis City','Seafloor Cavern','Sky Pillar','Pacifidlog Town','Ever Grande City','Victory Road','Liga Pokémon'];
const cityKinds={
 'Littleroot':'village', 'Oldale Town':'cross', 'Petalburg City':'garden', 'Rustboro City':'metro',
 'Dewford Town':'island','Slateport City':'harbor','Mauville City':'electric','Verdanturf Town':'flowers',
 'Fallarbor Town':'ash','Lavaridge Town':'spa','Fortree City':'treehouse','Lilycove City':'mall',
 'Mossdeep City':'space','Sootopolis City':'crater','Pacifidlog Town':'floating','Ever Grande City':'league',
 'Liga Pokémon':'league'
};
function getKind(loc){
 if(isInterior(loc))return 'indoor';if(cityKinds[loc])return cityKinds[loc];
 if(/Woods|Forest|Safari/i.test(loc))return 'forest';
 if(/Granite Cave|Meteor Falls|Seafloor Cavern|Victory Road/i.test(loc))return 'cave';
 if(/Chimney|Jagged|Volcano|Lava/i.test(loc))return 'volcano';
 if(/Deserto|Desert/i.test(loc))return 'desert';
 if(/Sky Pillar/i.test(loc))return 'tower';
 if(/Route 12[4-9]|Route 13[0-4]|Ocean|Sea|Dive/i.test(loc))return 'ocean';
 if(/Route/i.test(loc))return 'route';return 'village'
}
function buildScene(loc){
 const z=fieldSeed(loc),kind=getKind(loc),g=Array.from({length:MAP_H},(_,y)=>Array.from({length:MAP_W},(_,x)=>{
  const h=fieldHash(x,y,z)%100;
  if(kind==='indoor')return 'floor';
  if(kind==='ocean'||kind==='floating')return 'water';
  if(kind==='cave')return 'wall';
  if(kind==='volcano')return h<18?'lava':'stone';
  if(kind==='desert')return h<13?'dune':'sand';
  if(kind==='ash')return h<16?'boulder':'ash';
  if(kind==='crater')return h<25?'stone':'cliff';
  if(kind==='forest'||kind==='treehouse')return h<64?'tree':h<79?'tallgrass':'grass';
  if(kind==='island'||kind==='harbor'||kind==='space')return h<10?'flower':'grass';
  if(kind==='metro'||kind==='electric'||kind==='mall')return h<5?'flower':'grass';
  if(kind==='flowers'||kind==='garden'||kind==='league')return h<26?'flower':h<35?'tallgrass':'grass';
  if(kind==='route')return h<19?'tree':h>83?'tallgrass':'grass';
  return h<16?'tree':h>91?'flower':'grass';
 }));
 const inside=(x,y)=>x>=0&&x<MAP_W&&y>=0&&y<MAP_H;
 const put=(x,y,k)=>{x=Math.round(x);y=Math.round(y);if(inside(x,y))g[y][x]=k};
 const rect=(x,y,w,h,k)=>{for(let yy=Math.max(0,y);yy<Math.min(MAP_H,y+h);yy++)for(let xx=Math.max(0,x);xx<Math.min(MAP_W,x+w);xx++)put(xx,yy,k)};
 const disc=(cx,cy,rx,ry,k)=>{for(let y=Math.floor(cy-ry);y<=Math.ceil(cy+ry);y++)for(let x=Math.floor(cx-rx);x<=Math.ceil(cx+rx);x++)if(((x-cx)/rx)**2+((y-cy)/ry)**2<=1)put(x,y,k)};
 const paint=(pts,tile='path',w=1)=>{for(let i=1;i<pts.length;i++){
  const [ax,ay]=pts[i-1],[bx,by]=pts[i],n=Math.ceil(Math.hypot(bx-ax,by-ay)*3);
  for(let j=0;j<=n;j++){const x=Math.round(ax+(bx-ax)*j/n),y=Math.round(ay+(by-ay)*j/n);for(let dx=-w;dx<=w;dx++)for(let dy=-w;dy<=w;dy++)if(Math.abs(dx)+Math.abs(dy)<=w+1)put(x+dx,y+dy,tile)}
 }};
 const landmarks=[];
 const building=(x,y,w,h,roof='roof',name='Casa')=>{rect(x,y,w,h-2,roof);rect(x,y+h-2,w,2,'house');put(x+Math.floor(w/2),y+h-1,'door');for(let i=2;i<w-2;i+=5)put(x+i,y+h-2,'window');landmarks.push({x:x+w/2,y:y+h,name})};
 const scatter=(tile,n,condition)=>{for(let i=0;i<n;i++){let x=2+fieldHash(i,2,z)%(MAP_W-4),y=2+fieldHash(i,7,z)%(MAP_H-4);if(!condition||condition(x,y))put(x,y,tile)}};
 let waypoints=[],description='';let indoors=kind==='indoor';
 if(kind==='indoor'){
  rect(0,0,42,30,'wall');rect(3,3,36,24,'floor');rect(17,26,9,4,'floor');
  rect(3,3,36,2,'carpet');paint([[20,26],[20,20],[21,14],[21,7]],'carpet',1);
  if(/Caminh/.test(loc)){
    rect(3,3,36,24,'wall');rect(10,4,22,22,'floor');rect(17,26,9,4,'floor');
    rect(12,6,5,9,'crate');rect(27,6,4,10,'crate');rect(12,19,5,5,'crate');rect(27,19,4,5,'crate');
    paint([[20,8],[20,17],[20,26]],'floor',1);
    waypoints=[[20,8],[20,17],[20,26]];
    description='Interior do caminhão • caixas, corredor de carga e saída traseira';
   }
  else if(/Laborat/.test(loc)){rect(8,7,9,5,'machine');rect(25,7,9,5,'machine');rect(6,17,8,4,'desk');rect(27,17,8,4,'desk');rect(18,9,7,5,'machine');description='Laboratório do Professor Birch • máquinas e mesas'}
  else if(/Quarto do rival/.test(loc)){
    rect(6,6,7,11,'bed');rect(27,7,9,5,'desk');put(31,10,'pokeball');
    rect(7,20,10,3,'desk');description='Quarto do rival • Pokébola sobre a mesa e escada de saída';
  }
  else if(/Quarto/.test(loc)){
    rect(6,6,7,11,'bed');rect(30,7,7,6,'machine');rect(6,21,10,3,'desk');put(15,20,'clock');
    description='Seu quarto • PC, relógio, cama e escada';
  }
  else if(/Centro Pok[eé]mon/i.test(loc)){rect(11,6,20,4,'desk');rect(17,5,8,4,'machine');rect(6,12,8,6,'bed');rect(28,12,8,6,'bed');rect(7,21,8,3,'desk');rect(29,21,7,3,'machine');description='Centro Pokémon • balcão de Nurse Joy, máquinas de cura e PCs'}
  else if(/Casa/.test(loc)){rect(5,7,9,7,'carpet');rect(29,8,7,6,'desk');rect(8,21,8,4,'bed');description='Interior da casa • sala e mobília'}
  else{rect(5,7,12,4,'desk');rect(26,7,10,4,'desk');rect(10,18,6,5,'carpet');description='Interior do edifício'}
  if(!waypoints.length)waypoints=[[20,26],[21,18],[8,18],[21,10],[33,18],[20,26]];
 }
 else if(kind==='cave'){
  const mapRoute=[[3,17],[8,17],[11,8],[20,8],[23,20],[33,20],[38,13]];
  if(loc==='Victory Road'){mapRoute.splice(3,0,[14,23],[28,23],[30,8]);}
  paint(mapRoute,'cavefloor',3);for(let [cx,cy] of [[10,16],[21,8],[25,19],[34,20]])disc(cx,cy,5,4,'cavefloor');
  scatter('boulder',40,(x,y)=>g[y][x]==='cavefloor'&&fieldHash(x,y,z)%5===0);
  scatter('crystal',15,(x,y)=>g[y][x]==='wall');
  waypoints=mapRoute;description=loc==='Victory Road'?'Caverna de pedra com túneis e cristais • Victory Road':'Caverna com corredores de pedra e formações rochosas';
 }
 else if(kind==='forest'){
  const pts=loc==='Petalburg Woods'?[[3,24],[9,24],[12,15],[19,15],[19,6],[30,6],[33,15],[39,15]]:[[3,16],[9,16],[12,7],[22,7],[24,22],[33,22],[39,14]];
  paint(pts,'path',1);for(let [cx,cy] of [[8,24],[18,15],[33,16]])disc(cx,cy,3,3,'grass');
  scatter('flower',24,(x,y)=>g[y][x]==='grass');
  waypoints=pts;description='Floresta densa • trilhas curvas entre árvores';
 }
 else if(kind==='volcano'){
  disc(11,9,8,6,'lava');disc(31,24,9,6,'lava');disc(33,5,4,4,'lava');
  let pts=[[3,17],[8,17],[11,23],[19,23],[22,15],[28,13],[34,13],[39,8]];paint(pts,'ash',2);
  scatter('boulder',65,(x,y)=>g[y][x]==='stone'||g[y][x]==='ash');
  waypoints=pts;description='Trilha vulcânica • lava, cinzas e rochas';
 }
 else if(kind==='desert'){
  const pts=[[3,15],[8,15],[11,10],[21,8],[27,17],[33,20],[39,16]];paint(pts,'sand',2);
  scatter('boulder',34);waypoints=pts;description='Deserto com dunas e uma trilha sinuosa';
 }
 else if(kind==='ocean'){
  disc(7,7,6,5,'sand');disc(35,23,6,5,'sand');disc(23,13,4,3,'island');
  const pts=[[3,17],[10,17],[18,10],[28,10],[32,17],[39,17]];paint(pts,'surf',2);
  waypoints=pts;description='Rota marítima • águas profundas, recifes e ilhotas';
 }
 else if(kind==='tower'){
  rect(3,3,36,24,'cliff');rect(7,6,28,20,'stone');rect(10,9,22,15,'floor');
  for(let y of [12,19])for(let x of [12,19,27])if((x+y+z)%2)put(x,y,'crack');
  const pts=[[20,26],[20,21],[11,20],[11,11],[30,11],[30,20]];paint(pts,'floor',1);waypoints=pts;
  description='Sky Pillar • pisos antigos, ruínas e rachaduras';
 }
 else if(kind==='floating'){
  rect(0,0,42,30,'water');disc(22,16,17,9,'surf');
  const pts=[[3,16],[10,16],[10,10],[20,10],[20,19],[31,19],[38,17]];paint(pts,'bridge',1);
  building(8,5,9,7,'hutRoof','Casa flutuante');building(25,7,9,7,'hutRoof','Casa na água');building(19,20,8,6,'hutRoof','Cabana');
  waypoints=pts;description='Pacifidlog • casas flutuantes e passarelas de madeira';
 }
 else{
  const main=Math.abs(fieldSeed(loc)%7),r=kind==='route';
  if(r){
   let idx=Number((loc.match(/\d+/)||[])[0]||101);let pts=[];
   if(idx%3===0){pts=[[3,7],[11,7],[12,18],[22,18],[25,10],[34,10],[38,23]]}
   else if(idx%3===1){pts=[[3,24],[9,24],[9,14],[17,14],[20,6],[30,6],[30,22],[39,22]]}
   else{pts=[[3,15],[10,15],[13,7],[22,7],[26,22],[34,22],[39,14]]}
   if(idx===110){rect(26,1,6,28,'water');paint([[28,3],[28,25]],'bridge',2);pts=[[3,14],[14,14],[28,14],[39,14]]}
   if(idx===119){rect(19,0,6,30,'water');paint([[3,18],[15,18],[23,18],[36,18],[39,12]],'path',1);rect(21,16,4,5,'bridge');pts=[[3,18],[12,18],[23,18],[36,18],[39,12]]}
   paint(pts,'path',1);
   for(let [x,y] of [[15,7],[32,23]])if(g[y][x]==='grass')disc(x,y,3,3,'tallgrass');
   scatter('flower',25,(x,y)=>g[y][x]==='grass');waypoints=pts;
   description=idx===119?'Rota tropical com rio e ponte':idx===110?'Rota com ciclovia e ponte':'Route '+idx+' • trilha sinuosa e grama alta';
  } else {
   // Cada cidade tem seu próprio traçado de ruas, edifícios e vegetação.
   let roads=[],bn=[];
   switch(kind){
    case 'village':roads=[[21,28],[21,21],[21,14],[21,5]];paint(roads,'path',2);
      paint([[21,17],[12,17],[12,12]],'path',1);paint([[21,19],[31,19],[31,15]],'path',1);
      bn=[[5,7,12,8,'roof','Casa da família'],[26,7,11,8,'roofBlue','Casa do rival'],[25,21,12,6,'labRoof','Laboratório Birch']];description='Littleroot • duas casas, laboratório e saída norte';break;
    case 'cross':roads=[[2,15],[20,15],[39,15]];paint(roads,'path',2);paint([[20,3],[20,15],[20,26]],'path',2);
      bn=[[4,4,11,8,'centerRoof','Centro Pokémon'],[27,5,10,8,'martRoof','Poké Mart'],[25,20,11,7,'roof','Casas']];description='Oldale • cruzamento, Centro Pokémon e Poké Mart';break;
    case 'garden':disc(7,23,7,5,'water');roads=[[3,13],[14,13],[22,17],[39,17]];paint(roads,'path',2);paint([[23,17],[23,4]],'path',1);
      bn=[[5,4,13,7,'roofBlue','Casas'],[27,6,11,8,'gymRoof','Ginásio Petalburg'],[28,21,9,7,'centerRoof','Centro Pokémon']];description='Petalburg • lago ornamental e ginásio de Norman';break;
    case 'metro':rect(0,0,42,30,'brick');paint([[10,1],[10,28]],'road',2);paint([[3,17],[39,17]],'road',2);
      bn=[[3,3,12,10,'towerRoof','Devon Corporation'],[22,3,13,11,'gymRoof','Ginásio Roxanne'],[22,21,13,7,'centerRoof','Centro Pokémon'],[3,21,11,7,'roofBlue','Prédios']];description='Rustboro • cidade grande, Devon e ginásio';break;
    case 'island':rect(0,0,42,30,'water');disc(22,16,18,12,'sand');disc(21,14,13,9,'grass');
      roads=[[3,17],[12,17],[23,17],[39,17]];paint(roads,'sand',2);bn=[[7,7,11,7,'hutRoof','Casas da ilha'],[23,7,13,8,'gymRoof','Ginásio Brawly'],[26,20,11,6,'centerRoof','Centro Pokémon']];description='Dewford • ilha cercada de mar e ginásio';break;
    case 'harbor':rect(32,0,10,30,'water');rect(29,0,3,30,'sand');rect(31,17,11,3,'bridge');
      roads=[[2,15],[16,15],[30,15],[37,17]];paint(roads,'road',2);
      bn=[[4,3,11,8,'martRoof','Mercado'],[18,3,12,8,'centerRoof','Centro Pokémon'],[4,21,12,6,'roofBlue','Museu Oceânico'],[20,21,10,6,'roof','Docas']];description='Slateport • mercado, cais e oceano';break;
    case 'electric':rect(0,0,42,30,'brick');roads=[[20,2],[20,26]];paint(roads,'road',3);paint([[2,15],[39,15]],'road',3);
      bn=[[3,3,13,9,'gymRoof','Ginásio Wattson'],[26,3,12,9,'centerRoof','Centro Pokémon'],[3,21,13,7,'martRoof','Bike Shop'],[26,21,12,7,'roofBlue','Shopping']];description='Mauville • cruzamento central e lojas';break;
    case 'flowers':roads=[[3,20],[11,18],[22,15],[39,13]];paint(roads,'path',2);
      bn=[[6,5,11,8,'roofBlue','Casas floridas'],[27,19,11,8,'centerRoof','Centro Pokémon']];scatter('flower',140,(x,y)=>g[y][x]==='grass');description='Verdanturf • jardins e muitas flores';break;
    case 'ash':roads=[[3,16],[10,16],[22,13],[39,13]];paint(roads,'ash',2);bn=[[6,4,12,9,'roof','Centro de fósseis'],[25,19,12,8,'centerRoof','Centro Pokémon']];scatter('boulder',45);
      description='Fallarbor • vila coberta de cinzas';break;
    case 'spa':disc(8,23,6,5,'water');disc(35,6,6,5,'lava');roads=[[3,15],[16,15],[27,18],[39,18]];paint(roads,'sand',2);
      bn=[[7,3,11,8,'gymRoof','Ginásio Flannery'],[23,4,12,8,'centerRoof','Centro Pokémon'],[27,22,11,6,'hutRoof','Banhos termais']];description='Lavaridge • fontes termais e vulcão';break;
    case 'treehouse':roads=[[3,16],[12,16],[17,9],[29,9],[35,18],[39,18]];paint(roads,'bridge',1);
      bn=[[7,4,10,7,'hutRoof','Casa nas árvores'],[25,3,13,9,'gymRoof','Ginásio Winona'],[26,21,10,7,'hutRoof','Casa suspensa']];description='Fortree • passarelas de madeira nas copas';break;
    case 'mall':rect(33,0,9,30,'water');rect(30,0,3,30,'sand');roads=[[2,14],[16,14],[31,14]];paint(roads,'road',3);paint([[19,3],[19,26]],'road',2);
      bn=[[4,3,12,9,'towerRoof','Shopping Lilycove'],[23,3,9,8,'centerRoof','Centro Pokémon'],[4,20,12,7,'roofBlue','Concurso Pokémon'],[23,21,9,6,'roof','Hotel']];description='Lilycove • shopping, concursos e praia';break;
    case 'space':rect(0,0,42,30,'water');disc(21,15,19,13,'sand');disc(21,14,14,10,'grass');roads=[[4,16],[18,16],[39,16]];paint(roads,'path',2);
      bn=[[7,5,13,9,'spaceRoof','Centro Espacial'],[26,5,11,9,'gymRoof','Ginásio Tate & Liza'],[25,21,12,7,'centerRoof','Centro Pokémon']];description='Mossdeep • ilha e Centro Espacial';break;
    case 'crater':rect(0,0,42,30,'cliff');disc(21,15,16,12,'stone');disc(21,15,11,8,'water');
      paint([[4,17],[12,18],[17,22],[23,23],[30,20],[38,15]],'bridge',2);paint([[21,26],[21,19],[21,13]],'bridge',1);
      bn=[[4,5,10,7,'roofBlue','Casas da cratera'],[26,5,13,8,'gymRoof','Ginásio Juan'],[27,23,11,6,'centerRoof','Centro Pokémon']];
      description='Sootopolis • cratera circular e lago central';break;
    case 'league':disc(22,15,18,12,'grass');roads=[[4,26],[14,25],[22,19],[22,7]];paint(roads,'path',3);
      bn=[[13,3,18,11,'leagueRoof','Liga Pokémon'],[29,19,10,8,'centerRoof','Centro Pokémon']];scatter('flower',80,(x,y)=>g[y][x]==='grass');description='Ever Grande • jardins e entrada da Liga';break;
    default: roads=[[3,15],[20,15],[39,15]];paint(roads,'path',2);bn=[[7,4,11,9,'roof','Casas'],[26,18,11,9,'centerRoof','Centro Pokémon']];
   }
   for(const b of bn)building(...b);
   if(kind==='village'){
    // Caminhão de mudanças estacionado: existe de verdade no mapa exterior.
    rect(5,20,11,5,'truckBody');rect(6,19,8,2,'truckRoof');
    rect(13,22,3,3,'truckCab');
    landmarks.push({x:11,y:25,name:'Caminhão de mudança'});
   }
   waypoints=roads.length?roads:[[4,15],[22,15],[38,15]];
   if(kind==='crater')waypoints=[[4,17],[12,18],[17,22],[23,23],[30,20],[38,15]];
   if(kind==='village')waypoints=[[21,28],[21,20],[12,17],[21,14],[30,19],[21,5]];
   if(kind==='metro')waypoints=[[10,27],[10,18],[20,17],[35,17],[10,5],[10,18]];
   if(kind==='electric')waypoints=[[20,27],[20,15],[35,15],[20,15],[20,4],[5,15]];
   if(kind==='space')waypoints=[[4,16],[18,16],[37,16],[18,16]];
   if(kind==='garden')waypoints=[[3,13],[14,13],[22,17],[39,17],[23,10]];
   if(kind==='island')waypoints=[[4,17],[13,17],[24,17],[38,17],[18,17]];
  }
 }
 if(!waypoints.length)waypoints=[[4,14],[20,14],[38,14]];
 const passable=t=>['floor','carpet','grass','flower','tallgrass','path','sand','ash','dune','road','brick','cavefloor','bridge','surf','island','stone','door'].includes(t);
 const nearest=(p)=>{let [sx,sy]=p;if(inside(sx,sy)&&passable(g[sy][sx]))return {x:sx,y:sy};for(let rad=1;rad<20;rad++)for(let dy=-rad;dy<=rad;dy++)for(let dx=-rad;dx<=rad;dx++){
  const x=sx+dx,y=sy+dy;if(inside(x,y)&&passable(g[y][x]))return {x,y}
 }return {x:20,y:15}}
 const points=waypoints.map(nearest);
 const entry=points[0];
 const scene={loc,kind,g,entry,points,landmarks,description,passable};sceneCache.set(loc,scene);return scene;
}
function getScene(loc){return sceneCache.get(loc)||buildScene(loc)}
function fieldTile(loc,x,y){if(x<0||y<0||x>=MAP_W||y>=MAP_H)return 'void';return getScene(loc).g[y][x]}
function passableTile(loc,x,y){return x>=0&&y>=0&&x<MAP_W&&y<MAP_H&&getScene(loc).passable(fieldTile(loc,x,y))}
function findWalkPath(loc,from,to){
 const enc=(x,y)=>y*MAP_W+x,first=enc(from.x,from.y),last=enc(to.x,to.y);
 if(!passableTile(loc,to.x,to.y)||!passableTile(loc,from.x,from.y))return [];
 let q=[first],head=0,seen=new Set([first]),previous=new Map();
 while(head<q.length){let id=q[head++];if(id===last)break;let x=id%MAP_W,y=Math.floor(id/MAP_W);
 for(const [dx,dy] of [[1,0],[0,1],[-1,0],[0,-1]]){let xx=x+dx,yy=y+dy,k=enc(xx,yy);if(!seen.has(k)&&passableTile(loc,xx,yy)){seen.add(k);previous.set(k,id);q.push(k)}}}
 if(!seen.has(last))return [];let path=[];for(let at=last;at!==first;at=previous.get(at)){path.push({x:at%MAP_W,y:Math.floor(at/MAP_W)});if(path.length>MAP_W*MAP_H)break}return path.reverse();
}
window.emeraldTerrain={tile:fieldTile,scene:getScene,locations:sceneNames,width:MAP_W,height:MAP_H,interior:isInterior,passable:passableTile};
// V19 — Objetivos concretos para a introdução de Emerald.
// Cada marco tem um mapa, uma entrada física e o local de interação.
const INTRO_PATHS={
 0:[['Caminhão',20,9,20,26,'Sair pela traseira do caminhão'],['Littleroot',18,25,11,15,'Ir até a porta de casa'],['Casa',20,26,20,19,'Entrar em casa']],
 1:[['Casa',20,19,21,7,'Subir as escadas'],['Quarto',20,26,21,17,'Conhecer o quarto']],
 2:[['Quarto',21,17,29,9,'Usar o PC para pegar a Potion']],
 3:[['Quarto',29,9,16,20,'Acertar o relógio']],
 4:[['Quarto',16,20,20,26,'Descer as escadas'],['Casa',21,7,21,18,'Conversar com a mãe']],
 5:[['Casa',21,18,20,26,'Sair da própria casa'],['Littleroot',11,15,31,15,'Caminhar até a casa do rival'],['Casa do rival',20,26,21,7,'Subir ao quarto do rival']],
 6:[['Casa do rival',21,7,21,7,'Entrar no quarto do rival'],['Quarto do rival',20,26,29,9,'Examinar a Pokébola']],
 7:[['Quarto do rival',29,9,20,26,'Deixar o quarto do rival'],['Casa do rival',21,7,20,26,'Sair da casa do rival'],['Littleroot',31,15,21,5,'Caminhar até a saída norte de Littleroot']],
 8:[['Route 101',3,15,22,7,'Encontrar Birch e Zigzagoon na rota']],
 9:[['Route 101',22,7,3,15,'Voltar para Littleroot'],['Littleroot',21,5,31,26,'Ir ao laboratório do Professor Birch'],['Laboratório',20,26,20,14,'Falar com o professor no laboratório']],
 10:[['Laboratório',20,14,20,26,'Sair do laboratório'],['Littleroot',31,26,21,5,'Deixar Littleroot pela saída norte'],['Route 101',3,15,39,14,'Percorrer a Route 101']],
 11:[['Oldale Town',20,26,9,12,'Procurar o Centro Pokémon'],['Centro Pokémon • Oldale Town',20,26,20,10,'Falar com Nurse Joy e recuperar a equipe']],
 12:[['Centro Pokémon • Oldale Town',20,10,20,26,'Sair do Centro Pokémon'],['Oldale Town',9,12,20,3,'Seguir ao norte de Oldale'],['Route 103',3,24,30,21,'Encontrar o rival na Route 103']],
 13:[['Route 103',30,21,34,22,'Aproximar-se do rival para batalhar']],
 14:[['Route 103',34,22,3,24,'Retornar pela Route 103'],['Oldale Town',20,3,20,26,'Atravessar Oldale Town'],['Route 101',39,14,3,15,'Descer a Route 101'],['Littleroot',21,5,31,26,'Retornar ao laboratório'],['Laboratório',20,26,20,14,'Receber Pokédex e Pokébolas']],
 15:[['Laboratório',20,14,20,26,'Sair do laboratório'],['Littleroot',31,26,11,15,'Encontrar a mãe para receber Running Shoes']],
 16:[['Littleroot',11,15,21,5,'Partir rumo a Oldale'],['Route 101',3,15,39,14,'Percorrer a Route 101'],['Oldale Town',20,26,3,15,'Sair de Oldale para a Route 102'],['Route 102',3,7,38,23,'Explorar toda a Route 102']]
};
function introPoint(loc,x,y){
 if(passableTile(loc,x,y))return {x,y};
 for(let r=1;r<=8;r++)for(let dy=-r;dy<=r;dy++)for(let dx=-r;dx<=r;dx++)if(Math.abs(dx)+Math.abs(dy)===r&&passableTile(loc,x+dx,y+dy))return {x:x+dx,y:y+dy};
 return getScene(loc).entry;
}
window.emeraldIntroPaths=INTRO_PATHS;
function introWalk(t){
 if(window.emeraldOfficialWorld)return window.emeraldOfficialWorld.stepTrainer(t,{intro:true});
 const plan=INTRO_PATHS[t.stage];if(!plan)return false;
 if(t.introStage!==t.stage){t.introStage=t.stage;t.introIndex=0;t.introSegment=false;t.introReady=false;t.walkObjective='Preparando o próximo trajeto';t.walkPath=[];t.walkMap='';t.walkCount??=0;t.introHistory??=[]}
 if(t.introReady){t.walkMoving=false;return true}
 // Saídas desencontradas: cada IA tem ritmo próprio, não formam uma fila idêntica.
 if(t.stage===0&&turns<((t.id*17)%27)){t.walkMoving=false;return true}
 if(t.id%7===0&&((turns+t.id)%3===0)){t.walkMoving=false;return true}
 if(t.battle){t.walkMoving=false;return true}
 const n=t.introIndex||0;
 if(n>=plan.length){t.introReady=true;t.walkMoving=false;return true}
 const [loc,fx,fy,gx,gy,obj]=plan[n];
 if(!t.introSegment){
   const start=introPoint(loc,fx,fy),dest=introPoint(loc,gx,gy);
   t.location=loc;t.walkX=start.x;t.walkY=start.y;t.walkMap='v19:'+loc;
   t.walkObjective=obj;t.walkGoal=dest;t.walkPath=findWalkPath(loc,start,dest);
   t.introSegment=true;t.walkDir=2;t.walkMoving=false;
   if(n>0)emit(t,'story',`🚪 ${t.name} chegou a ${loc}.`);
   return true;
 }
 if(t.walkPath?.length){
   const next=t.walkPath.shift(),dx=next.x-t.walkX,dy=next.y-t.walkY;
   t.walkDir=dx>0?1:dx<0?3:dy>0?2:0;t.walkX=next.x;t.walkY=next.y;
   t.walkCount=(t.walkCount||0)+1;t.walkMoving=true;
   return true;
 }
 if(t.walkX!==t.walkGoal.x||t.walkY!==t.walkGoal.y){
   // Não atravessar parede: tentar outra passagem transitável.
   t.walkPath=findWalkPath(loc,{x:t.walkX,y:t.walkY},t.walkGoal);
   if(!t.walkPath.length){t.walkObjective='Caminho bloqueado: '+obj;t.walkMoving=false;return true}
   return true;
 }
 t.introHistory.unshift(obj);t.introHistory=t.introHistory.slice(0,8);
 t.introIndex=n+1;t.introSegment=false;t.walkMoving=false;
 if(t.introIndex>=plan.length){t.introReady=true;emit(t,'story',`📍 ${t.name} concluiu: ${obj}.`)}
 return true;
}
function moveTrainer(t){
 if(window.emeraldOfficialWorld)return window.emeraldOfficialWorld.stepTrainer(t,{intro:t.stage<=16&&!t.healing});
 // Without collision data there is no safe movement: halt rather than
 // simulate map travel by assigning a new position.
 t.walkMoving=false;t.walkObjective='Mapa ainda não carregado: navegação suspensa';return false;
 if(t.stage<=16&&!t.healing)return introWalk(t);
 const loc=t.location,scene=getScene(loc);
 const changed=t.walkMap!=='v19:'+loc||t.walkStage!==t.stage||!Number.isFinite(t.walkX)||!Number.isFinite(t.walkY)||!passableTile(loc,Math.round(t.walkX),Math.round(t.walkY));
 if(changed){
  const startIndex=((t.id*7)+Math.floor(t.id/7))%Math.max(1,scene.points.length);
  const safeStart=scene.points[startIndex];
  t.walkX=safeStart.x;t.walkY=safeStart.y;t.walkDir=2;t.walkMap='v19:'+loc;t.walkStage=t.stage;
  t.walkCount=t.walkCount||0;t.walkStepsOnMap=0;t.walkPointIndex=startIndex;
  t.travelRemaining=scene.kind==='indoor'?5:scene.kind==='cave'||scene.kind==='forest'||scene.kind==='ocean'?27:scene.kind==='route'?24:18;
  t.walkGoal=null;t.walkPath=[];
 }
 if(t.battle){t.walkMoving=false;return}
 if(!t.walkGoal||!Array.isArray(t.walkPath)||!t.walkPath.length){
  const num=scene.points.length;
  t.walkPointIndex=((t.walkPointIndex||0)+1)%Math.max(1,num);
  let dest=scene.points[t.walkPointIndex];
  if(t.stage>=16&&t.starter&&!t.healing&&!t.battle&&['route','forest','cave','ocean','desert'].includes(scene.kind)&&Math.random()<(t.grindTrip?.zone===loc?.75:.43)){
    const tiles=[];for(let y=3;y<MAP_H-3;y++)for(let x=3;x<MAP_W-3;x++)if(scene.passable(scene.g[y][x])&&(['tallgrass','cavefloor','surf','sand','dune'].includes(scene.g[y][x])||(scene.kind==='forest'&&scene.g[y][x]==='grass')))tiles.push({x,y});
    if(tiles.length)dest=tiles[(fieldHash(t.walkCount||0,t.id,fieldSeed(loc))%tiles.length)];
  }
  if(dest.x===t.walkX&&dest.y===t.walkY){t.walkPointIndex=(t.walkPointIndex+1)%num;dest=scene.points[t.walkPointIndex]}
  t.walkGoal={x:dest.x,y:dest.y};t.walkPath=findWalkPath(loc,{x:t.walkX,y:t.walkY},t.walkGoal);
  if(!t.walkPath.length){const other=scene.points.find(p=>p.x!==t.walkX||p.y!==t.walkY);if(other){t.walkGoal={x:other.x,y:other.y};t.walkPath=findWalkPath(loc,{x:t.walkX,y:t.walkY},t.walkGoal)}}
 }
 let next=t.walkPath?.shift();if(!next){t.walkMoving=false;return}
 const dx=next.x-t.walkX,dy=next.y-t.walkY;
 t.walkDir=dx>0?1:dx<0?3:dy>0?2:0;t.walkX=next.x;t.walkY=next.y;
 t.walkCount=(t.walkCount||0)+1;t.walkStepsOnMap=(t.walkStepsOnMap||0)+1;t.walkMoving=true;
 if(t.walkX===t.walkGoal.x&&t.walkY===t.walkGoal.y){t.walkGoal=null;t.walkPath=[]}
}

function saveWorld(){localStorage.setItem('emerald_living_world_v26',JSON.stringify({schemaVersion:4,trainers,feed,pairScores,clock,turns,selected,featured,hall,season,rareEvents,records,tournaments,worldWeather,settings}))}
function resetBots(count){const n=clamp(Math.round(Number(count)||20),1,100);trainers=Array.from({length:n},(_,i)=>newTrainer(i));feed=[];pairScores={};clock=0;turns=0;selected=0;featured=0;nextBotIndex=0;season++;tournaments=[];rareEvents=0;try{saveWorld()}catch(e){console.warn('Save falhou',e)}buildTrainerGrid();const el=$('#playerCount');if(el)el.value=String(n);render();}
// Redimensiona o mundo sem substituir os treinadores que já progrediram.
// O bot pessoal é sempre o índice 0; outros IDs correspondem ao índice.
function resizeBotsKeepingProgress(count){
 const n=clamp(Math.round(Number(count)||20),1,100),before=trainers.length;
 if(n===before)return {previous:before,current:n,changed:false};
 if(n>before){for(let i=before;i<n;i++)trainers.push(newTrainer(i))}
 else{
  trainers.length=n;
  for(const key of Object.keys(pairScores)){
   const ids=key.split('-').map(Number);
   if(ids.some(id=>!Number.isInteger(id)||id<0||id>=n))delete pairScores[key];
  }
  feed=feed.filter(item=>item&&Number.isInteger(item.id)&&item.id>=0&&item.id<n);
 }
 selected=clamp(selected,0,n-1);featured=clamp(featured,0,n-1);nextBotIndex%=n;
 const counter=$('#playerCount');if(counter)counter.value=String(n);
 buildTrainerGrid();
 try{saveWorld()}catch(err){console.warn('Não foi possível salvar a alteração da quantidade de bots',err)}
 render();
 return {previous:before,current:n,changed:true};
}
function step(){turns++;if(settings.tournamentEnabled&&settings.tournamentInterval>0&&turns%settings.tournamentInterval===0)runTournament();if(settings.weather&&turns%160===0){worldWeather=settings.weatherMode==='dynamic'?pick(['clear','sun','rain','sand','snow']):settings.weatherMode;const w=WEATHER_NAMES[worldWeather];const x=pick(trainers);emit(x,'story',`🌦️ Clima em Hoenn: ${w}.`)}if(settings.autosave&&turns%settings.autosave===0&&Date.now()-lastAutosaveAt>=45000){lastAutosaveAt=Date.now();try{saveWorld()}catch(e){console.warn('Autosave falhou',e)}}if(settings.worldEvents&&turns%240===0){let t=pick(trainers.filter(x=>x.starter))||trainers[0];let event=pick(['🌧️ Uma tempestade começou sobre Hoenn.','🌈 Um arco-íris apareceu após a chuva.','☄️ Meteoros iluminaram o céu próximo a Meteor Falls.','🐉 Rumores sobre Rayquaza se espalham por Hoenn.','🌊 O mar está agitado perto de Sootopolis.']);emit(t,'rare',event,true);rareEvents++}const nBots=trainers.length;const soloMode=settings.gameMode==='player';
 const tickBudget=nBots>75?7:nBots>45?10:nBots>25?14:nBots;
 const playerIndex=soloMode?Math.max(0,trainers.findIndex(t=>t.isUserBot)):-1;
 for(let handled=0;handled<tickBudget;handled++){
  const i=soloMode&&handled===0?playerIndex:(nextBotIndex+handled-(soloMode?1:0)+nBots)%nBots;
  if(soloMode&&handled>0&&i===playerIndex)continue;
  const t=trainers[i];if(t.stage===0&&turns<((t.id*13)%180))continue;
  const controlling=soloMode&&i===playerIndex;
  if(controlling&&!t.battle&&!t.healing&&!t.playerJourneyCommand)continue;
  if(controlling&&!t.battle&&!t.healing){
   const command=t.playerJourneyCommand;
   if(command==='train'){train(t);t.playerJourneyCommand=null;continue;}
   if(command==='capture'){if(wild(t)){t.playerJourneyCommand=null;}else{t.playerJourneyCommand=null;t.playerCommandFeedback='Nenhum Pokémon selvagem disponível nesta área.';}continue;}
   if(command==='battle'){if(routeTrainerFight(t)){t.playerJourneyCommand=null;}else{t.playerJourneyCommand=null;t.playerCommandFeedback='Não há desafios de treinadores disponíveis nesta rota.';}continue;}
   if(command==='explore'){
    const before=t.walkX+':'+t.walkY+':'+(t.officialMap||t.location);
    moveTrainer(t);
    const after=t.walkX+':'+t.walkY+':'+(t.officialMap||t.location);
    if(before!==after)t.playerExploreSteps=(t.playerExploreSteps||0)+1;
    if((t.playerExploreSteps||0)>=5||Date.now()-(t.playerExploreStartedAt||Date.now())>5500){
     t.playerJourneyCommand=null;t.playerCommandFeedback='Exploração concluída. Escolha a próxima ação.';
    }
    continue;
   }
  }
  const previousStage=t.stage;
  moveTrainer(t);if(!t.champion&&!(settings.collectionGoal&&t.stage>=27)&&naturalEncounter(t)){if(controlling)t.playerJourneyCommand=null;continue;}
 if(t.champion&&settings.collectionGoal&&(t.battle||t.healing||collectionProgress(t).missing.length)){eventStep(t);continue}
 if(t.champion&&t.battle){eventStep(t);continue}
 if(t.champion&&t.healing){centerVisitStep(t);continue}
 if(t.champion&&!t.storyArrived){continue}
 if(t.champion&&postgameQuestStep(t))continue;
 if(t.champion&&settings.postgameTraining&&t.team.some(m=>m.level<100)&&turns%(Math.max(3,nBots))===0){train(t);continue}if(t.champion&&settings.frontierEnabled){if(t.healing){centerVisitStep(t);continue}if(t.cooldown>0)t.cooldown--;else frontierStep(t);continue}
 if(!t.battle&&t.needsRebalance&&settings.teamOptimization&&(turns+t.id)%4===0)rebalanceTeam(t,'evolução e níveis');
 if(!t.battle&&!t.healing&&!t.storyArrived)continue; // Não executar eventos antes de chegar fisicamente ao mapa da missão
 if(!t.battle&&t.travelRemaining>0){t.travelRemaining--;continue}
 eventStep(t);
  if(controlling&&(t.stage!==previousStage||t.battle))t.playerJourneyCommand=null;
}nextBotIndex=(nextBotIndex+tickBudget-(soloMode?1:0)+nBots)%nBots;if(camera==='auto'&&turns%8===0){let active=trainers.filter(x=>x.battle);if(active.length)featured=pick(active).id;else if(feed.length)featured=feed[0].id}}
window.emeraldNationalSimulation={records:NATIONAL_ENTRIES,count:NATIONAL_ENTRIES.filter(e=>e.kind==='species').length,choose:(options,random)=>NATIONAL_POOL.pick(NATIONAL_ENTRIES,options,random),pool:options=>NATIONAL_POOL.pool(NATIONAL_ENTRIES,options),locationsFor:name=>NATIONAL_POOL.locationsFor(NATIONAL_BY_NAME.get(name))};
window.emeraldOfficialTrainerEncounter=officialTrainerEncounter;
window.emeraldFrontier=FRONTIER;window.emeraldTournamentDuel=tournamentDuel;window.emeraldRunTournament=runTournament;window.emeraldDebugStep=step;let previous=0,acc=0;function loop(now){
if(document.hidden){previous=now;requestAnimationFrame(loop);return}
const dt=Math.min(100,now-previous||0);previous=now;
if(!paused){
 // Até 200× solicitado. A execução real é adaptativa para preservar a
 // responsividade dos botões e do canvas, sobretudo com 100 treinadores.
 acc=Math.min(acc+dt*SIM_SPEED.effectiveMultiplier(speed),SIM_SPEED.MAX_BACKLOG_MS);
 const started=performance.now();let framesWorked=0;
 const maxSteps=SIM_SPEED.frameLimit(speed);
 while(acc>=SIM_SPEED.TICK_MS&&framesWorked<maxSteps){
  step();acc-=SIM_SPEED.TICK_MS;framesWorked++;
  if(performance.now()-started>=SIM_SPEED.CPU_BUDGET_MS)break;
 }
}
if(now-(loop.last||0)>(document.getElementById('page-jogador')?.hidden===false?650:Math.max(trainers.length>45?1300:900,settings.renderMs))){render();loop.last=now}
requestAnimationFrame(loop)}
$('#clearRecords').onclick=()=>{if(!confirm('Apagar os recordes históricos deste navegador?'))return;records=[];try{localStorage.removeItem('emerald_living_world_v8_records')}catch(e){}render()};
// O mundo SEMPRE inicia pausado, mesmo quando há save. Não executar turnos antes
// de uma escolha explícita de Continuar ou Nova Jornada.
let bootAuthorized=false;
function setPause(value){paused=!!value;$('#pause').textContent=paused?'▶ Continuar':'⏸ Pausar';if(!paused){acc=0;previous=0;}render();}
window.emeraldResumeWorld=()=>{bootAuthorized=true;setPause(false);return true;};
window.emeraldPauseWorld=()=>{setPause(true);return true;};
Object.defineProperty(window,'emeraldBootAuthorized',{get:()=>bootAuthorized});
$('#pause').onclick=()=>{if(!bootAuthorized){window.emeraldShowEntry?.();return;}setPause(!paused)};
$('#step').onclick=()=>{if(!bootAuthorized){window.emeraldShowEntry?.();return;}step();render()};
$('#speed').onchange=e=>{speed=SIM_SPEED.normalize(e.target.value);settings.speed=speed;storeOptions();syncSpeedUi()};
$('#camera').onchange=e=>{camera=e.target.value;render()};
document.querySelectorAll('[data-filter]').forEach(b=>b.onclick=()=>{filter=b.dataset.filter;document.querySelectorAll('[data-filter]').forEach(x=>x.classList.toggle('active',x===b));render()});
$('#save').onclick=()=>{try{saveWorld();window.ELWTelemetry?.event('save');alert('Progresso salvo neste navegador!')}catch(e){alert('Não foi possível salvar: '+e.message)}};
$('#reset').onclick=()=>window.emeraldOpenWorldControl?.({restart:true});
const BOT_PREF_KEY='emerald_my_auto_bot_v2';
const BOT_STARTERS=window.EmeraldStarters?.ALL||['Treecko','Torchic','Mudkip'];
const BOT_GOALS=['story','train','capture','battle','explore'];
const BOT_STYLES=['balanced','aggressive','defensive','catcher'];
function readBotPrefs(){try{return JSON.parse(localStorage.getItem(BOT_PREF_KEY)||'{}')||{}}catch(e){return {}}}
function sanitizeBotPrefs(obj){obj=obj&&typeof obj==='object'?obj:{};return {
 name:String(obj.name||'Meu Treinador').trim().slice(0,24)||'Meu Treinador',
 starter:BOT_STARTERS.includes(obj.starter)?obj.starter:'Mudkip',
 goal:BOT_GOALS.includes(obj.goal)?obj.goal:'story',
 style:BOT_STYLES.includes(obj.style)?obj.style:'balanced'
}}
function setBotPrefs(obj,{persist=true}={}){
 const pref=sanitizeBotPrefs(obj),t=trainers[0];
 if(!t)return pref;
 t.isUserBot=true;t.botName=pref.name;t.name=pref.name;
  t.botStarter=pref.starter;t.botGoal=pref.goal;t.botStyle=pref.style;t.manualBattleEnabled??=true;
 if(pref.style==='aggressive'){t.personality='Competitivo';t.traits={strategy:.8,explore:.5,aggression:.95,care:.4}}
 else if(pref.style==='defensive'){t.personality='Cauteloso';t.traits={strategy:.82,explore:.35,aggression:.24,care:.9}}
 else if(pref.style==='catcher'){t.personality='Colecionador';t.traits={strategy:.65,explore:.8,aggression:.4,care:.87}}
 else{t.personality='Estrategista';t.traits={strategy:.75,explore:.65,aggression:.6,care:.72}}
 if(persist)try{localStorage.setItem(BOT_PREF_KEY,JSON.stringify(pref))}catch(e){}
 selected=0;featured=0;camera='manual';const sel=document.getElementById('camera');if(sel)sel.value='manual';
 try{saveWorld()}catch(e){};render();return pref
}
window.emeraldGetBotPrefs=()=>sanitizeBotPrefs(readBotPrefs());
window.emeraldSetMyBotSettings=data=>setBotPrefs(data);
window.emeraldMyBot=()=>trainers.find(x=>x.isUserBot)||null;
window.emeraldChooseRivalPath=choice=>{
 const t=trainers.find(x=>x.isUserBot);const d=t?.userRivalChoice;
 if(!d||d.choice!=='pending'||!['train','fight'].includes(choice))return {ok:false,error:'Nenhuma decisão do rival está pendente.'};
 d.choice=choice;d.trainingLeft=choice==='train'?3:0;
 emit(t,'story',choice==='train'?'💪 Você escolheu três treinos antes do rival.':'⚔️ Você decidiu enfrentar o rival agora.',true);
 try{saveWorld()}catch(e){};render();window.emeraldRefreshMyBot?.();return {ok:true,choice};
};
window.emeraldChooseJourneyAction=action=>{
 const t=trainers.find(x=>x.isUserBot);
 if(settings.gameMode!=='player'||!t)return {ok:false,error:'Entre no modo Meu Treinador para decidir sua jornada.'};
 if(t.battle)return {ok:false,error:'Conclua a batalha antes de escolher uma ação de exploração.'};
 if(t.healing)return {ok:false,error:'Aguarde a recuperação no Centro Pokémon.'};
 if(!['story','train','capture','battle','explore'].includes(action))return {ok:false,error:'Ação inválida.'};
 if(action!=='story'&&!t.team?.length)return {ok:false,error:'Primeiro receba seu Pokémon inicial seguindo a história.'};
 if(action==='capture'&&(!settings.capture||!t.bag?.Pokeball||!wildHabitat(t)||!NATIONAL_POOL.hasEncounters(t.location)))return {ok:false,error:'Você precisa de Pokébolas e estar em uma área com Pokémon selvagens.'};
 if(action==='battle'&&(!settings.trainerEncounters||t.stage<16||(t.routeFights?.[t.stage]||0)>=settings.routeTrainers))return {ok:false,error:'Não há treinadores disponíveis para desafiar nesta etapa.'};
 t.playerJourneyCommand=action;t.playerCommandFeedback='';t.playerExploreSteps=0;t.playerExploreStartedAt=Date.now();
 emit(t,'story',({story:'Você escolheu continuar a história.',train:'Você escolheu treinar a equipe.',capture:'Você decidiu procurar um Pokémon selvagem.',battle:'Você decidiu procurar um desafiante.',explore:'Você escolheu explorar a região.'})[action]);
 try{saveWorld()}catch(e){}
 window.emeraldRefreshMyBot?.();return {ok:true,action};
};
window.emeraldMyBotBattleMode=manual=>{
 const t=trainers.find(x=>x.isUserBot);if(!t)return false;
 t.manualBattleEnabled=!!manual;t.queuedBattleAction=null;
 try{saveWorld()}catch(e){};render();window.emeraldRefreshMyBot?.();return true;
};
window.emeraldMyBotBattleAction=(kind,value)=>{
 const t=trainers.find(x=>x.isUserBot),b=t?.battle;
 if(!b||settings.gameMode!=='player'||t.manualBattleEnabled===false||t.queuedBattleAction)return {ok:false,error:'Não é possível escolher agora.'};
 if(!t.team[b.ownIndex]||t.team[b.ownIndex].hp<=0){b.ownIndex=alive(t.team);if(b.ownIndex<0)return {ok:false,error:'Seu time está sem Pokémon aptos.'};}
 const mon=t.team[b.ownIndex];
 let choice=null;
 if(kind==='attack'&&typeof value==='string'&&mon.moves.includes(value)&&(mon.pp?.[value]??20)>0)choice={kind:'attack',name:value};
 if(kind==='switch'&&Number.isInteger(Number(value))&&Number(value)!==b.ownIndex&&t.team[Number(value)]?.hp>0)choice={kind:'switch',index:Number(value)};
 if(kind==='potion'&&t.bag.Potion>0&&mon.hp<mon.maxHp)choice={kind:'potion'};
 if(kind==='capture'&&['wild','trainingWild','postgameWild'].includes(b.kind)&&t.bag.Pokeball>0)choice={kind:'capture'};
 if(!choice)return {ok:false,error:'Escolha inválida ou item indisponível.'};
 t.queuedBattleAction=choice;
 try{saveWorld()}catch(e){};render();window.emeraldRefreshMyBot?.();return {ok:true};
};
try{const raw=localStorage.getItem('emerald_living_world_v26')||localStorage.getItem('emerald_living_world_v25')||localStorage.getItem('emerald_living_world_v24')||localStorage.getItem('emerald_living_world_v23')||localStorage.getItem('emerald_living_world_v22')||localStorage.getItem('emerald_living_world_v21')||localStorage.getItem('emerald_living_world_v20')||localStorage.getItem('emerald_living_world_v19');if(raw){const data=JSON.parse(raw);applyWorld(data);savedDataRestored=true}}catch(e){console.warn('Save inválido',e)}
function applyWorld(data){if(Array.isArray(data.trainers)&&data.trainers.length>=1&&data.trainers.length<=100){trainers=data.trainers;trainers.forEach((t,i)=>{t.name=t.isUserBot?String(t.botName||readBotPrefs().name||'Meu Treinador').slice(0,24):UNIQUE_NAMES[i%UNIQUE_NAMES.length];if((t.campaignSequence||1)<2){
    // Progresso e insígnias preservados; reinicia só a visita pendente que
    // pertencia à campanha antiga e podia apontar para uma localidade errada.
    t.quests??={};delete t.quests[t.stage];t.campaignSequence=2;
    // Migração de saves antigos: nunca mover o treinador para outra cidade
    // ao carregar a página. A navegação decidirá a rota depois de Continuar.
    if(t.stage>=16&&t.stage<=27&&CAMPAIGN[t.stage]?.length){
      t.walkObjective='Encontrar caminho para '+CAMPAIGN[t.stage][0][0];
    }
   }t.gymGuards??={};t.routeFights??={};t.leagueRound??=0;t.pc??=[];t.healing??=null;t.healingCount??=0;t.grindWins??=0;t.grindSessions??=0;t.grindTarget??=0;t.centersVisited??=[];t.lastHealTick??=-100;t.leaguePrepared??=false;t.wildCooldown??=0;t.encountersByTerrain??={};t.needsRebalance=true;t.detoursDone??={};t.detour??=null;t.routeLog??=[];t.teamReason??='Analisando a equipe';t.trainingProject??=null;t.trainingLoan??=null;t.loanDoneStages??={};t.frontier??={wins:{},losses:{},symbols:{},last:null};t.postgameSteps??=0;t.manualBattleEnabled??=true;t.queuedBattleAction=null;t.playerJourneyCommand=['story','train','capture','battle','explore'].includes(t.playerJourneyCommand)?t.playerJourneyCommand:null;t.playerExploreSteps=0;t.officialPending=null;t.officialPortal=null;t.walkPath=[];t.walkFacingDir=Number.isInteger(t.walkFacingDir)?t.walkFacingDir:(Number.isInteger(t.walkDir)?t.walkDir:2);t.walkNextAt=0;t.walkStepMs=205;t.officialSpawn=!t.officialMap;t.storyArrived=false;t.introReady=false;t.storyNavStage=-1;t.storyDwell=0;for(const m of [...t.team,...t.pc]){ensureMonUid(m);normalizeMon(m,t,!(data.schemaVersion>=3));}});feed=data.feed||[];pairScores=data.pairScores||{};clock=data.clock||0;turns=data.turns||0;selected=clamp(Math.trunc(Number(data.selected))||0,0,trainers.length-1);featured=clamp(Math.trunc(Number(data.featured))||0,0,trainers.length-1);hall=data.hall||[];season=data.season||1;rareEvents=data.rareEvents||0;records=data.records||[];tournaments=data.tournaments||[];worldWeather=WEATHER_NAMES[data.worldWeather]?data.worldWeather:'clear';if(data.settings){for(const k of Object.keys(DEFAULTS))if(typeof data.settings[k]===typeof DEFAULTS[k])settings[k]=data.settings[k];if(data.settings.speedScaleVersion!==2){settings.speed=SIM_SPEED.fromLegacy(data.settings.speed);settings.speedScaleVersion=2;}storeOptions();speed=SIM_SPEED.normalize(settings.speed,true);settings.speed=speed}settings.levelCap=true;settings.leagueLevel=58;settings.damageMultiplier=1;storeOptions();nextBotIndex=0;normalizeLegendaries()}}
window.emeraldStartWorld=(count,mode)=>{if(!['mixed','watch','player'].includes(mode))mode='mixed';settings.gameMode=mode;storeOptions();resetBots(count);setBotPrefs(readBotPrefs());window.emeraldResumeWorld();render()};
window.emeraldResizeBots=resizeBotsKeepingProgress;
window.emeraldChooseMode=mode=>{if(!['mixed','watch','player'].includes(mode))return;settings.gameMode=mode;storeOptions();if(!trainers.some(t=>t.isUserBot))setBotPrefs(readBotPrefs());window.emeraldResumeWorld();render()};window.emeraldImport=data=>{applyWorld(data);paused=true;$('#pause').textContent='▶ Continuar';buildTrainerGrid();render()};window.emeraldWeather=()=>({world:worldWeather,names:WEATHER_NAMES,mode:settings.weatherMode});window.emeraldSetWeather=mode=>{if(mode!=='dynamic'&&!WEATHER_NAMES[mode])return;settings.weatherMode=mode;if(mode!=='dynamic')worldWeather=mode;storeOptions()};
try{const saved=JSON.parse(localStorage.getItem('emerald_living_world_v8_records')||'[]');if(Array.isArray(saved)&&saved.length&&!records.length)records=saved}catch(e){}
buildTrainerGrid();$('#playerCount').value=String(trainers.length);syncSpeedUi();
$('#romFile').addEventListener('change',async e=>{
 const file=e.target.files?.[0],label=$('#romInfo');if(!file)return;
 if(!/\.gba$/i.test(file.name)){
  label.textContent='Selecione um arquivo .gba local. Arquivos ZIP precisam ser extraídos no seu dispositivo.';return;
 }
 try{
  if(file.size<0xC0||file.size>64*1024*1024)throw Error('Tamanho incompatível com uma ROM GBA convencional.');
  const bytes=new Uint8Array(await file.slice(0,0xC0).arrayBuffer());
  const result=window.EmeraldRomHeader?.readGbaHeader(bytes);
  if(!result||!result.valid){label.textContent='Arquivo não reconhecido: '+(result?.error||'validador indisponível');return;}
  if(!result.emerald){label.textContent=`ROM GBA identificada (${result.gameCode}), mas incompatível com o leitor Emerald: ${result.title||'título desconhecido'}.`;return;}
  label.textContent=`Pokémon Emerald identificado: ${result.title} (${result.gameCode}), revisão ${result.revision} • ${(file.size/1048576).toFixed(1)} MB. Apenas o cabeçalho foi verificado. Extração de sprites e mapas ainda não implementada. Arquivo mantido neste navegador.`;
 }catch(err){label.textContent='Erro na validação local: '+err.message}
});
window.emeraldPlayerDuelResult=(id,playerName,won)=>{const t=trainers[id];if(!t)return;const name=String(playerName).slice(0,24);if(won){t.losses++;emit(t,'battle',`🎮 ${name} venceu ${t.name} em uma batalha contra IA!`,true)}else{t.wins++;emit(t,'battle',`🤖 ${t.name} venceu o jogador ${name}!`,true)};render()};window.emeraldCollectionProgress=collectionProgress;window.emeraldDexAPI={LEGEND_PROFILES,ability,levelStats,monTypes,learnedMoves,SPEC,MON_SECONDARY,LEARN,MOVES,MOVE_PP,SPECIES_LEVEL_MOVES,roleOf,speciesValue,futureValue,esc};window.emeraldSelectTrainer=(id)=>{selected=clamp(Number(id)||0,0,trainers.length-1);camera='manual';$('#camera').value='manual';render()};window.emeraldRender=render;Object.defineProperty(window,'emeraldPaused',{get:()=>paused});Object.defineProperty(window,'emeraldTrainers',{get:()=>trainers});window.emeraldSpecies=SPEC;window.emeraldSetOption=(k,v)=>{if(!(k in DEFAULTS))return;if(k==='levelCap'||k==='leagueLevel'||k==='damageMultiplier')return;settings[k]=v;storeOptions();if(k==='speed'){speed=SIM_SPEED.normalize(v,true);settings.speed=speed;storeOptions();syncSpeedUi()}if(k==='uiDensity')document.body.classList.toggle('compact',v==='compact');if(k==='animations')document.body.classList.toggle('reduced-motion',!v)};document.body.classList.toggle('reduced-motion',!settings.animations);document.body.classList.toggle('compact',settings.uiDensity==='compact');window.emeraldExport=()=>({schemaVersion:4,trainers,feed,pairScores,clock,turns,selected,featured,hall,season,rareEvents,records,tournaments,worldWeather,settings});window.emeraldStep=()=>{step();window.emeraldRefreshMyBot?.()};window.emeraldFrontierStep=frontierStep;window.emeraldReadiness=(id)=>readiness(trainers[id],getTrainingTarget(trainers[id]));window.emeraldRebalanceAll=()=>trainers.forEach(t=>{if(!t.battle)rebalanceTeam(t,'mudança de configuração')});window.emeraldPower=combatPower;window.emeraldStrength=strengthOfTeam;window.emeraldTeamAnalysis=teamAnalysis;window.emeraldMonRole=roleOf;window.emeraldComputeIdealTeam=computeIdealTeam;window.emeraldBestMon=bestOwnedMon;window.emeraldHabitat=wildHabitat;// Salvar quando o jogador troca de aba/fecha a página (além do autosave por turnos).
window.addEventListener?.('pagehide',()=>{if(bootAuthorized||savedDataRestored)try{saveWorld()}catch(err){console.warn('Save ao fechar falhou:',err)}});
document.addEventListener?.('visibilitychange',()=>{if(document.hidden&&(bootAuthorized||savedDataRestored))try{saveWorld()}catch(err){console.warn('Save ao ocultar falhou:',err)}});
window.emeraldPostgame={POSTGAME_CHALLENGES,postgameQuestStep};window.emeraldProgression={levelCapFor,expNeeded,levelStats,normalizeMon,awardEffort,maybeEvolve,teachMove,NATURES,STAT_KEYS};window.emeraldDiagnostics={LEGEND_PROFILES,captureChance,tacticalBrief,legendaryLedger,levelStats,moveScore,ability,legendaryAvailable,normalizeLegendaries,acquireMon,wild,battleTurn,battleDecision,battleSpeed,endBattleTurn,enterBattle,weatherBoost,createMon,monTypes,multiEffect,attack,chooseMove,expGain,collectionStep,shouldCapture,startBattle,gyms:GYMS,league:LEAGUE,rebalanceTeam,wildHabitat,scoreTeamComposition,individualValue,roleOf,computeIdealTeam};render();requestAnimationFrame(loop);
})();