(()=>{'use strict';
function boot(){
const $=id=>document.getElementById(id);
const formerSidebar=document.querySelector('#gamePage>aside.stack');if(formerSidebar&&!formerSidebar.children.length)formerSidebar.remove();
// Keep the original controls and event handlers, in a more useful location.
for(const id of ['pause','step','speed','save','reset'])$('primaryControls').append($(id));
if($('speed')?.tagName==='SELECT')$('speed').value=String(window.emeraldOptions.speed||1);
const guide=$('guideDialog');$('openGuide').onclick=()=>guide.showModal();
const closeGuide=()=>guide?.close();if($('closeGuide'))$('closeGuide').onclick=closeGuide;if($('startExploring'))$('startExploring').onclick=closeGuide;
guide.addEventListener('click',e=>{if(e.target===guide){const r=guide.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)guide.close()}});
document.querySelectorAll('[data-shortcut]').forEach(b=>b.onclick=()=>window.emeraldShowPage?.(b.dataset.shortcut));
$('cinemaMode').onclick=()=>{const on=document.body.classList.toggle('cinema');$('cinemaMode').setAttribute('aria-pressed',String(on));$('cinemaMode').textContent=on?'Recolher transmissão ↙':'Expandir transmissão ↗';if(on)$('directorPanel').scrollIntoView({block:'start'})};
function updateOverview(){const state=window.emeraldExport();const t=state.trainers;$('overviewTrainers').textContent=t.length;$('overviewBattles').textContent=t.filter(x=>x.battle).length;$('overviewBadges').textContent=t.reduce((n,x)=>n+x.badges,0);$('overviewChampions').textContent=t.filter(x=>x.champion).length;$('seasonLabel').textContent='Temporada '+state.season;const paused=$('status').textContent.includes('Pausado');$('pause').setAttribute('aria-pressed',String(paused));}
updateOverview();setInterval(updateOverview,1000);
const filters=document.createElement('div');filters.className='trainerFilters';filters.innerHTML='<input id="trainerSearch" class="trainerSearch" type="search" placeholder="Filtrar por nome ou cidade…" aria-label="Filtrar treinadores por nome ou cidade"><label><input id="championsOnly" type="checkbox"> Apenas campeões</label><small id="trainerMatches" role="status"></small>';
const grid=$('trainerGrid');grid.before(filters);const empty=document.createElement('p');empty.className='emptyResult';empty.textContent='Nenhum treinador corresponde aos filtros. Experimente outro nome ou cidade.';empty.hidden=true;grid.after(empty);
function filterTrainers(){const q=$('trainerSearch').value.trim().toLocaleLowerCase('pt-BR');const champions=$('championsOnly').checked;const trainers=window.emeraldTrainers;let count=0;[...grid.children].forEach((b,i)=>{const t=trainers[i];const match=t&&(!champions||t.champion)&&(!q||(t.name+' '+t.location).toLocaleLowerCase('pt-BR').includes(q));b.hidden=!match;if(match)count++});$('trainerMatches').textContent=count+' de '+trainers.length+' treinadores';empty.hidden=count>0}
$('trainerSearch').oninput=filterTrainers;$('championsOnly').onchange=filterTrainers;filterTrainers();setInterval(()=>{if(!$('page-treinadores').hidden)filterTrainers()},1500);
document.addEventListener('keydown',e=>{if(e.ctrlKey||e.metaKey||e.altKey||e.target.closest('input,select,textarea,[contenteditable="true"]')||!guide.open&&document.body.classList.contains('drawerOpen'))return;if(guide.open)return;if(e.key==='?'){e.preventDefault();guide.showModal()}else if(!$('gamePage').hidden&&e.code==='Space'){e.preventDefault();$('pause').click()}else if(!$('gamePage').hidden&&e.key==='ArrowRight'){e.preventDefault();$('step').click()}});
}if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
})();
