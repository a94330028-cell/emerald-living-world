/* V9.10 — recovery and save tools: no artificial healing or save deletion. */
(()=>{'use strict';
 const $=id=>document.getElementById(id);
 const safe=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 function activeTrainer(){const state=window.emeraldExport?.();if(!state?.trainers?.length)return null;
  if(document.body.dataset.worldMode==='player')return window.emeraldMyBot?.()||state.trainers[0];
  return state.trainers[state.selected]||state.trainers[0];
 }
 function refresh(){if($('page-recuperacao')?.hidden)return;
  const t=activeTrainer(),node=$('recoveryTeamStatus');if(!node)return;
  if(!t){node.textContent='Nenhum treinador carregado.';return}
  const team=(t.team||[]).slice(0,6);
  node.innerHTML=`<p class="note">${safe(t.name)} · ${t.badges||0}/8 insígnias · ${team.length} Pokémon</p>`+
   (team.length?`<div class="recoveryStatusGrid">${team.map(m=>{const hp=Math.max(0,Number(m.hp)||0),max=Math.max(1,Number(m.maxHp)||1);return `<article class="recoveryMon"><b>${safe(m.species)}</b><small>Nível ${Math.max(1,Number(m.level)||1)} · HP ${hp}/${max}</small><progress max="${max}" value="${Math.min(hp,max)}"></progress></article>`}).join('')}</div>`:'<p class="note">Ainda não há Pokémon na equipe.</p>');
 }
 $('recoveryBackGame')?.addEventListener('click',()=>window.emeraldShowPage?.('jogo'));
 $('recoveryExportSave')?.addEventListener('click',()=>{
  if(typeof window.emeraldExport!=='function')return;
  try{const data=JSON.stringify(window.emeraldExport()),blob=new Blob([data],{type:'application/json'}),a=document.createElement('a');
   a.href=URL.createObjectURL(blob);a.download='emerald_living_world_backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000);
   $('recoverySaveMessage').textContent='Backup preparado. Guarde o arquivo em um lugar seguro.';
  }catch(e){$('recoverySaveMessage').textContent='Não foi possível exportar: '+e.message}
 });
 $('recoveryImportSave')?.addEventListener('change',async e=>{
  const f=e.target.files?.[0];if(!f)return;
  try{const data=JSON.parse(await f.text());if(!Array.isArray(data.trainers)||data.trainers.length<1||data.trainers.length>100)throw Error('Save inválido.');
   if(!confirm('Importar este save vai substituir o progresso local atual. Deseja continuar?'))return;
   localStorage.setItem('emerald_living_world_v26',JSON.stringify(data));
   $('recoverySaveMessage').textContent='Save importado. Recarregue a página para continuar.';
  }catch(e){$('recoverySaveMessage').textContent='Falha ao importar: '+e.message}
  finally{e.target.value=''}
 });
 window.addEventListener('emerald:pagechange',e=>{if(e.detail.page==='recuperacao')refresh()});
 setInterval(()=>{if(!document.hidden&&!$('page-recuperacao')?.hidden)refresh()},3000);
})();
