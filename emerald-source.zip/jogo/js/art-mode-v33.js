(()=>{'use strict';
function boot(){const sel=document.getElementById('elwPokemonArtMode');const art=window.EmeraldPokemonArt;if(!sel||!art)return;
const status=document.getElementById('elwPokemonArtStatus');
sel.value=art.getVisualMode();
sel.addEventListener('change',()=>{
 art.setVisualMode(sel.value);
 if(status)status.textContent=sel.value==='classic'?'Sprites clássicos ativados.':'Ilustrações detalhadas ativadas; imagens locais continuam de reserva.';
 });
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
})();
