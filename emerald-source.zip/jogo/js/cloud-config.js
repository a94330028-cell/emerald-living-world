/* Emerald Living World — Configuração pública do Supabase (não inclui credenciais privadas).
   A publishable/anon key é pública e as políticas RLS protegem o banco.
   Nunca insira service_role, sb_secret ou senha neste arquivo. */
window.EMERALD_CLOUD_CONFIG = Object.freeze({
  supabaseUrl: 'https://hvujsnvyqydlmeyveuuf.supabase.co',
  supabaseAnonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh2dWpzbnZ5cXlkbG1leXZldXVmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTM5ODY3NzEsImV4cCI6MjEwOTU2Mjc3MX0.Yb5RIG3HIza0ss4wp05yVgFmmQlEiRw5e8INYIkWcjU'
});
