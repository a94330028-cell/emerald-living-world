/* Emerald Living World 3.0 — Chat global somente para contas Supabase verificadas.
 * Mensagens por REST + atualizações periódicas; Realtime é um aprimoramento opcional.
 * Nenhum dado pessoal da conta é enviado além do token e do texto ao Supabase configurado. */
(()=>{'use strict';
const $=id=>document.getElementById(id);
const root=$('elwChatPanel');if(!root)return;
const config=window.EMERALD_CLOUD_CONFIG||{},base=String(config.supabaseUrl||'').trim().replace(/\/+$/,''),key=String(config.supabaseAnonKey||'').trim();
const configured=/^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(base)&&key.length>15;
const STORAGE='elw_cloud_session_v1',MUTED='elw_chat_muted_v30';
let room='geral',open=false,busy=false,fetching=false,lastRendered='',poller=null,realtime=null,realtimeClient=null,blocked=new Set();
try{blocked=new Set(JSON.parse(localStorage.getItem(MUTED)||'[]'))}catch{}
let lastFocus=null;
function status(msg,error=false){const el=$('elwChatStatus');if(el){if(el.textContent===msg&&el.dataset.error===String(error))return;el.textContent=msg;el.dataset.error=String(error)}}
function getSession(){try{const s=JSON.parse(localStorage.getItem(STORAGE)||'null');return s?.user?.id&&s?.access_token?s:null}catch{return null}}
async function getToken(){let s=getSession();if(!s)throw Error('Entre na sua conta para conversar.');if((s.expires_at||0)*1000-Date.now()>45000)return s.access_token;
 if(!s.refresh_token)throw Error('Sua sessão expirou. Entre novamente.');
 const r=await fetch(base+'/auth/v1/token?grant_type=refresh_token',{method:'POST',headers:{'Content-Type':'application/json',apikey:key},body:JSON.stringify({refresh_token:s.refresh_token}),cache:'no-store'});
 const v=await r.json();if(!r.ok||!v.access_token)throw Error('Sua sessão expirou. Entre novamente.');
 // Keep the existing save/account storage key unchanged, so older saves remain compatible.
 s={...s,...v,expires_at:Math.floor(Date.now()/1000)+Number(v.expires_in||3600),user:v.user||s.user};localStorage.setItem(STORAGE,JSON.stringify(s));return s.access_token;
}
async function rpc(name,data){const token=await getToken();const r=await fetch(base+'/rest/v1/rpc/'+name,{method:'POST',headers:{'apikey':key,'Authorization':'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify(data),cache:'no-store'});if(!r.ok){const error=await r.json().catch(()=>({}));throw Error(String(error.message||'Não foi possível enviar.').slice(0,160))}return r.json()}
function clearRealtime(){try{realtimeClient?.removeChannel(realtime)}catch{}realtime=null;realtimeClient=null}
function close(){open=false;root.hidden=true;document.body.classList.remove('elw-chat-open');clearInterval(poller);poller=null;clearRealtime();lastFocus?.focus?.()}
function fallback(message){$('elwChatMessages').replaceChildren();const p=document.createElement('p');p.className='elw-chat-placeholder';p.textContent=message;$('elwChatMessages').append(p)}
function makeMessage(m){const own=m.author_id===getSession()?.user?.id,hidden=blocked.has(m.author_id);
 const item=document.createElement('article');item.className='elw-chat-message'+(own?' is-own':'');item.dataset.messageId=String(m.id);
 if(hidden){item.classList.add('is-muted');const note=document.createElement('span');note.textContent='Mensagem ocultada';item.append(note);return item}
 const head=document.createElement('div');head.className='elw-chat-message-head';
 const author=document.createElement('strong');author.textContent=(m.nickname||'Treinador')+(own?' · você':'');
 const time=document.createElement('time');time.dateTime=m.created_at;time.textContent=new Date(m.created_at).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'});
 head.append(author,time);if(!own){const more=document.createElement('button');more.type='button';more.className='elw-chat-more';more.textContent='⋯';more.setAttribute('aria-label','Opções para mensagem de '+(m.nickname||'treinador'));
 more.addEventListener('click',()=>{
  const old=item.querySelector('.elw-chat-options');if(old){old.remove();return}
  const actions=document.createElement('div');actions.className='elw-chat-options';
  const mute=document.createElement('button');mute.type='button';mute.textContent='Ocultar treinador';mute.addEventListener('click',()=>{blocked.add(m.author_id);try{localStorage.setItem(MUTED,JSON.stringify([...blocked]))}catch{}refresh(true)});
  const form=document.createElement('form');form.className='elw-chat-report-form';
  const select=document.createElement('select');select.setAttribute('aria-label','Motivo da denúncia');for(const [value,label] of [['spam','Spam'],['ofensa','Ofensa'],['dados_pessoais','Dados pessoais'],['outro','Outro motivo']]){const option=document.createElement('option');option.value=value;option.textContent=label;select.append(option)}
  const send=document.createElement('button');send.type='submit';send.textContent='Denunciar';form.append(select,send);
  form.addEventListener('submit',e=>{e.preventDefault();report(m.id,select.value);actions.remove()});actions.append(mute,form);item.append(actions);
 });head.append(more)}
 const body=document.createElement('p');body.className='elw-chat-content';body.textContent=m.body||'';item.append(head,body);return item;
}
async function report(id,reason){
 try{await rpc('elw_report_chat_message',{p_message_id:Number(id),p_reason:reason});status('Denúncia registrada para análise.')}catch(err){status(err.message,true)}
}

async function refresh(force=false){if(!open||fetching||!configured)return;let token;try{token=await getToken()}catch(err){fallback(err.message);status(err.message,true);$('elwChatSubmit').disabled=true;return}
 fetching=true;const requestedRoom=room;
 try{const r=await fetch(base+'/rest/v1/elw_chat_messages?select=id,room,author_id,nickname,body,created_at&room=eq.'+encodeURIComponent(requestedRoom)+'&order=id.desc&limit=60',{headers:{apikey:key,Authorization:'Bearer '+token},cache:'no-store'});
  if(!r.ok){const v=await r.json().catch(()=>({}));throw Error(v.message||'Chat indisponível. Execute community_chat.sql no Supabase.')}
  const messages=(await r.json()).reverse();if(!open||requestedRoom!==room)return;
  const signature=requestedRoom+':'+messages.map(m=>m.id).join(',')+':'+[...blocked].join(',');if(signature!==lastRendered||force){const list=$('elwChatMessages');const atBottom=list.scrollTop+list.clientHeight>=list.scrollHeight-85;list.replaceChildren();
   if(!messages.length)fallback('Esta sala ainda não tem mensagens. Seja o primeiro a conversar!');else list.append(...messages.map(makeMessage));
   if(atBottom||force)list.scrollTop=list.scrollHeight;lastRendered=signature;
  }
  $('elwChatSubmit').disabled=false;status('Conectado · '+messages.length+' mensagens recentes');
 }catch(err){status(err.message,true);if(!lastRendered)fallback('Não foi possível carregar as mensagens. Confira a configuração do Supabase.')}finally{fetching=false}
}
// The official Realtime SDK is optional. Polling still works on restricted/CDN-offline phones.
async function startRealtime(){clearRealtime();if(!open||!configured)return;try{
 const mod=await import('https://esm.sh/@supabase/supabase-js@2.57.0');if(!open)return;
 const token=await getToken();const client=mod.createClient(base,key,{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false}});
 client.realtime.setAuth(token);realtimeClient=client;
 realtime=client.channel('emerald-chat-'+room).on('postgres_changes',{event:'INSERT',schema:'public',table:'elw_chat_messages',filter:'room=eq.'+room},()=>refresh()).subscribe();
 }catch{clearRealtime()}
}
async function connect(){if(!configured){fallback('O chat mundial ainda não foi ativado. O administrador precisa configurar o Supabase e executar community_chat.sql.');$('elwChatSubmit').disabled=true;status('Aguardando configuração do servidor',true);return}
 if(!getSession()){fallback('Entre na sua conta e confirme seu e-mail para participar.');$('elwChatSubmit').disabled=true;status('Conta necessária para conversar',true);return}
 await refresh(true);if(!open)return;clearInterval(poller);poller=setInterval(()=>{if(!document.hidden)refresh()},5000);startRealtime();
}
function show(){if(open)return;open=true;lastFocus=document.activeElement;root.hidden=false;document.body.classList.add('elw-chat-open');$('elwChatClose').focus();connect()}
for(const btn of document.querySelectorAll('[data-elw-open-chat]'))btn.addEventListener('click',show);
$('elwChatClose')?.addEventListener('click',close);$('elwChatBackdrop')?.addEventListener('click',close);
document.addEventListener('keydown',e=>{
 if(!open)return;
 if(e.key==='Escape'){e.preventDefault();close();return}
 if(e.key==='Tab'){
  const focusable=[...root.querySelectorAll('button:not([disabled]),textarea:not([disabled]),select:not([disabled]),a[href]')].filter(el=>el.getClientRects().length);
  if(!focusable.length)return;const first=focusable[0],last=focusable[focusable.length-1];
  if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}
  else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}
 }
});
for(const btn of root.querySelectorAll('[data-chat-room]'))btn.addEventListener('click',()=>{if(btn.dataset.chatRoom===room)return;room=btn.dataset.chatRoom;lastRendered='';root.querySelectorAll('[data-chat-room]').forEach(b=>b.setAttribute('aria-selected',String(b===btn)));fallback('Carregando sala…');refresh(true);startRealtime()});
$('elwChatLogin')?.addEventListener('click',()=>{close();if(typeof window.EmeraldCloud?.openAccount==='function')window.EmeraldCloud.openAccount();else $('headerAccountOpen')?.click()});
$('elwChatReload')?.addEventListener('click',()=>{lastRendered='';connect()});
$('elwChatInput')?.addEventListener('input',e=>{$('elwChatCounter').textContent=String(e.target.value.length)+'/280'});
$('elwChatForm')?.addEventListener('submit',async e=>{e.preventDefault();if(busy)return;const input=$('elwChatInput'),content=input.value.trim();if(!content)return;if(content.length>280){status('O limite é de 280 caracteres.',true);return}
 busy=true;$('elwChatSubmit').disabled=true;
 try{await rpc('elw_send_chat_message',{p_room:room,p_message:content});input.value='';$('elwChatCounter').textContent='0/280';lastRendered='';await refresh(true);input.focus()}catch(err){status(err.message,true)}finally{busy=false;$('elwChatSubmit').disabled=false}
});
document.addEventListener('visibilitychange',()=>{if(open&&!document.hidden)refresh()});
})();
