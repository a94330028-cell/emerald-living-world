/* Emerald Living World 3.4: shared, read-only ranks; compatible with existing saves. */
(function(factory){
 const api=factory();
 if(typeof module==='object'&&module.exports)module.exports=api;
 if(typeof window!=='undefined')window.EmeraldTrainerRankings=api;
})(function(){'use strict';
 const num=x=>Number.isFinite(Number(x))?Number(x):0;
 const stage=t=>Math.max(0,Math.min(27,Math.floor(num(t?.stage))));
 const round=t=>Math.max(0,Math.min(5,Math.floor(num(t?.leagueRound))));
 const badges=t=>Math.max(0,Math.min(8,Math.floor(num(t?.badges))));
 const progressValue=t=>t?.champion?100:(stage(t)+round(t)/5)/28*100;
 const gyms=['Roxanne','Brawly','Wattson','Flannery','Norman','Winona','Tate e Liza','Juan'];
 function chapter(t){
  if(t?.champion)return '👑 Campeão de Hoenn';
  const s=stage(t);
  if(s>=27)return `🏆 Liga Pokémon · ${round(t)}/5 desafios`;
  if(s>=19)return `🏅 Próximo ginásio: ${gyms[Math.min(s-19,7)]}`;
  if(s>=16)return '🌿 Jornada pelos ginásios';
  if(s>=9)return '🎒 Preparando a jornada';
  return '🏡 Começo em Littleroot';
 }
 function storyCompare(a,b){
  const ax=num(!!a.champion),bx=num(!!b.champion);
  return bx-ax||stage(b)-stage(a)||round(b)-round(a)||badges(b)-badges(a)||num(b?.wins)-num(a?.wins)||String(a?.name||'').localeCompare(String(b?.name||''),'pt-BR');
 }
 function ranks(train, teamStrength,limit=10){
  const trainers=Array.isArray(train)?train.filter(Boolean):[];
  const power=typeof teamStrength==='function'?teamStrength:()=>0;
  const strength=trainers.filter(t=>Array.isArray(t.team)&&t.team.length)
   .map(t=>({t,score:Math.max(0,Math.round(num(power(t))))}))
   .sort((a,b)=>b.score-a.score||(b.t.team?.length||0)-(a.t.team?.length||0)||String(a.t.name||'').localeCompare(String(b.t.name||''),'pt-BR'))
   .slice(0,limit);
  const story=[...trainers].sort(storyCompare).slice(0,limit)
   .map(t=>({t,stage:stage(t),round:round(t),badges:badges(t),chapter:chapter(t),percent:progressValue(t)}));
  return {strength,story};
 }
 return {ranks,stage,round,badges,chapter,storyCompare,progressValue};
});
