/* Emerald Living World 2.5 - interactive classic Pokédex, using the existing local National catalogue. */
(()=>{'use strict';
const get=id=>document.getElementById(id),root=get('pokedexDevice');if(!root)return;
const list=get('classicDexEntries'),detail=get('classicDexDetails'),search=get('classicDexSearch'),region=get('classicDexRegion');
const total=get('classicDexTotal'),owned=get('classicDexOwned'),results=get('classicDexResultCount'),pageLabel=get('classicDexPage'),prev=get('classicDexPrev'),next=get('classicDexNext');
const art=window.EmeraldPokemonArt;
const placeholder='assets/ui/pokemon_missing.svg';
const regions={kanto:[1,151],johto:[152,251],hoenn:[252,386],sinnoh:[387,493],unova:[494,649],kalos:[650,721],alola:[722,809],galar:[810,905],paldea:[906,1025]};
const labels={HP:'HP',Attack:'Ataque',Defense:'Defesa',SpAtk:'At. Esp.',SpDef:'Def. Esp.',Speed:'Veloc.'};
const typeNames={Normal:'Normal',Fire:'Fogo',Water:'Água',Electric:'Elétrico',Grass:'Planta',Ice:'Gelo',Fighting:'Lutador',Poison:'Venenoso',Ground:'Terra',Flying:'Voador',Psychic:'Psíquico',Bug:'Inseto',Rock:'Pedra',Ghost:'Fantasma',Dragon:'Dragão',Dark:'Sombrio',Steel:'Aço',Fairy:'Fada'};
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const norm=s=>String(s??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
const countPerPage=8;let rows=[],shown=[],page=0,selection=null,waiting=false;
const num=n=>'#'+String(n).padStart(3,'0');
function sprite(img,record){
 img.src=placeholder;
 if(art?.apply)art.apply(img,record.name,{dex:record.dex,pixel:true});
 else {const name=encodeURIComponent(record.name.toLowerCase());img.src=`assets/pokemon_fit/${name}.png`;img.onerror=()=>{img.onerror=null;img.src=placeholder}}
}
function ownedNames(){const names=new Set();for(const trainer of window.emeraldTrainers||[]){for(const p of [...trainer.team||[],...trainer.pc||[]])if(p?.species)names.add(norm(p.species))}return names}
function updateOwned(){const names=ownedNames();let n=0;for(const r of rows)if(names.has(norm(r.name)))n++;owned.textContent=`Na coleção: ${n}`}
function entriesHTML(slice){return slice.map(r=>`<button class="pokedexEntry" type="button" role="option" data-dex-entry="${Number(r.dex)}" aria-selected="${r.dex===selection}"><img data-dex-sprite="${Number(r.dex)}" src="${placeholder}" alt="" loading="lazy"><span class="entryDexNo">${num(r.dex)}</span><span class="entrySpeciesName">${escape(r.name)}</span></button>`).join('')}
function renderList(){
 const max=Math.max(0,Math.ceil(shown.length/countPerPage)-1);page=Math.min(max,Math.max(0,page));
 const slice=shown.slice(page*countPerPage,(page+1)*countPerPage);
 list.innerHTML=slice.length?entriesHTML(slice):'<p class="dexDeviceEmpty">Nenhum Pokémon encontrado. Tente outro nome ou número.</p>';
 list.querySelectorAll('button[data-dex-entry]').forEach(btn=>btn.addEventListener('click',()=>choose(Number(btn.dataset.dexEntry))));
 for(const img of list.querySelectorAll('img[data-dex-sprite]')){const r=rows.find(x=>x.dex===Number(img.dataset.dexSprite));if(r)sprite(img,r)}
 pageLabel.textContent=`${page+1} / ${Math.max(1,max+1)}`;
 prev.disabled=page===0;next.disabled=page===max;
 results.textContent=`${shown.length} registros`;
}
function choose(dex){
 const r=rows.find(row=>row.dex===dex);if(!r)return;selection=r.dex;
 list.querySelectorAll('[data-dex-entry]').forEach(b=>b.setAttribute('aria-selected',String(Number(b.dataset.dexEntry)===selection)));
 const nums=Array.isArray(r.base)?r.base.map(Number):[0,0,0,0,0,0];const bst=nums.reduce((a,b)=>a+b,0);
 const t=(r.types||[]).map(type=>`<span class="dexType-${escape(type)}">${escape(typeNames[type]||type)}</span>`).join('');
 const cap=window.EmeraldNationalHabitats?.ENTRIES?.[r.name];
 const where=cap?.locations?.length?`Locais adaptados de captura: <b>${cap.locations.slice(0,5).map(escape).join(', ')}</b>. ${cap.minBadges?`A partir de ${cap.minBadges} insígnias.`:''}`:'Local de encontro comum não definido nesta versão.';
 const bar=Object.keys(labels).map((key,i)=>`<div class="dexStatBar"><b>${labels[key]}</b><strong>${nums[i]||0}</strong><span class="track"><span style="width:${Math.min(100,Math.max(1,nums[i]/2.55))}%"></span></span></div>`).join('');
 // Show the actual moves supported by the simulator; do not present fallback
 // move guesses as the complete original Quetzal learnset.
 const api=window.emeraldDexAPI||{},progression=api.SPECIES_LEVEL_MOVES?.[r.name];
 const names=Array.isArray(progression)?progression.filter(([level,move])=>api.MOVES?.[move]).map(([level,move])=>({level,move})):
  (api.learnedMoves?.(r.name,50)||[]).map(move=>({level:null,move}));
 const movesMarkup=names.length?`<div class="dexDeviceMoveList">${names.map(({level,move})=>{
  const def=api.MOVES?.[move]||[],parts=[def[0]||'',Number(def[1])>0?'Poder '+def[1]:'Status',Number.isFinite(Number(def[2]))?'Precisão '+def[2]+'%':''].filter(Boolean);
  return `<div><b>${escape(move)}</b><small>${level==null?'':`Nv. ${level} · `}${parts.map(escape).join(' · ')}</small></div>`;
 }).join('')}</div>`:'<p class="dexDeviceMoveNote">Ainda sem golpes individuais cadastrados nesta versão.</p>';
 const movesFootnote=Array.isArray(progression)?'Progressão de golpes implementada neste simulador.':'Exemplos de golpes disponíveis no motor, não a lista completa do Quetzal.';
 detail.innerHTML=`<div class="pokedexIdTag">${num(r.dex)}</div><h3>${escape(r.name)}</h3><div class="pokedexSpriteStage"><img id="classicDexPortrait" src="${placeholder}" alt="Imagem de ${escape(r.name)}"></div><div class="pokedexTypes">${t}</div><div class="dexDataSummary"><div><small>HP base</small><strong>${nums[0]||0}</strong></div><div><small>BST</small><strong>${bst}</strong></div><div><small>Taxa de captura</small><strong>${Number(r.catch)||0}</strong></div></div><div class="dexStatBars" aria-label="Atributos-base">${bar}</div><section class="dexMovesPanel"><h4>⚔️ Golpes e força no simulador</h4>${movesMarkup}<small>${movesFootnote}</small></section><div class="dexInfoBox">${where}<p style="margin:8px 0 0;color:#5c7161;font-size:11px">Atributos da tabela local do Quetzal. Os locais são adaptados ao simulador, não oficiais da ROM.</p></div>`;
 sprite(get('classicDexPortrait'),r);
}
function filter(){const q=norm(search.value);const range=regions[region.value];shown=rows.filter(r=>{if(range&&(r.dex<range[0]||r.dex>range[1]))return false;return !q||norm(r.name).includes(q)||String(r.dex).includes(q.replace('#',''))});page=0;if(!shown.some(r=>r.dex===selection))selection=shown[0]?.dex??null;renderList();if(selection)choose(selection);else detail.innerHTML='<p class="dexDeviceEmpty">Nenhum registro corresponde aos filtros.</p>'}
search.addEventListener('input',filter);region.addEventListener('change',filter);
prev.addEventListener('click',()=>{page=Math.max(0,page-1);renderList()});next.addEventListener('click',()=>{page++;renderList()});
function init(data){rows=(data?.pokemon||[]).filter(x=>x.kind==='species'&&Number.isInteger(x.dex)&&x.dex>=1&&x.dex<=1025).sort((a,b)=>a.dex-b.dex);total.textContent=`${rows.length.toLocaleString('pt-BR')} espécies`;updateOwned();selection=rows.find(x=>x.dex===25)?.dex||rows[0]?.dex||null;filter();}
fetch('data/quetzal-catalog.json').then(res=>{if(!res.ok)throw Error('Catálogo não encontrado');return res.json()}).then(init).catch(err=>{console.error('Pokédex clássica:',err);rows=Object.keys(window.emeraldSpecies||{}).map((name,i)=>({name,dex:i+1,base:[],types:[]}));if(rows.length){init({pokemon:rows.map(x=>({...x,kind:'species'}))})}else {list.innerHTML='<p class="dexDeviceEmpty">Não foi possível carregar os dados da Pokédex. Abra o projeto pelo servidor local ou pela hospedagem.</p>';detail.textContent='Catálogo indisponível.'}});
window.addEventListener('emerald:pagechange',e=>{if(e.detail?.page==='pokedex')updateOwned()});
})();
