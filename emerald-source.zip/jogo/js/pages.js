
(()=>{
const $=id=>document.getElementById(id);
const slots=[
['trainersSlot','trainerGrid'],
['rankingSlot','ranking'],['rivalriesSlot','rivalries'],

['feedSlot','feed'],['memorySlot','memory'],
['romSlot','romFile'],['aboutSlot',null]
];
for(const [slot,id] of slots){
const target=$(slot);
const card=id?$(id)?.closest('.card'):Array.from(document.querySelectorAll('#gamePage .card')).find(x=>x.textContent.includes('Sobre o motor'));
if(card&&target)target.appendChild(card);
}
const settingDefs=[
['Simulação','speed','Velocidade','select',[1,3,10,40]],
['Simulação','autosave','Salvar a cada N rodadas','number',10,1000,10],
['Simulação','renderMs','Atualizar tela (ms)','number',200,2000,100],
['Simulação','starter','Escolha do inicial','select',['adaptive','random','Treecko','Torchic','Mudkip']],
['Simulação','seasonGoal','Meta de campeões','number',1,100,1],
['Capturas','capture','Capturas automáticas','check'],
['Capturas','nationalEncounters','Pokédex Nacional nos encontros das IAs (1.025 espécies)','check'],
['Capturas','nationalForms','Permitir formas alternativas identificadas em encontros (experimental)','check'],
['Capturas','captureAggression','Interesse em capturar (%)','number',5,100,5],
['Capturas','shinies','Permitir shiny','check'],
['Capturas','shinyOdds','Chance shiny (1 em N)','number',32,8192,32],
['Capturas','legendaries','Lendários (1 exemplar por espécie no mundo)','check'],
['Capturas','legendaryOdds','Chance lendária (1 em N)','number',100,10000,100],
['Equipe inteligente','teamPolicy','Estratégia de equipe','select',['intelligent','balanced','counter','strongest']],
['Equipe inteligente','teamOptimization','Reorganizar equipe automaticamente','check'],
['Equipe inteligente','pcStorage','Armazenar no PC','check'],
['Equipe inteligente','teamSize','Máximo na equipe','number',1,6,1],
['Equipe inteligente','partyRebalance','Diferença mínima para trocar','number',0,100,5],
['Equipe inteligente','squadStability','Resistência a mudanças sem benefício','number',0,60,2],
['Equipe inteligente','futureInvestment','Guardar Pokémon de potencial futuro','check'],
['Rotas','explorationFreedom','Liberdade de exploração (%)','number',0,100,5],
['Rotas','routeProfile','Preferência de caminhos','select',['personality','explorer','speedrun','balanced']],
['Treinamento','grinding','Grinding por níveis','check'],
['Treinamento','grindIntensity','Intensidade do treino (%)','number',20,300,10],
['Treinamento','partyReadiness','Pokémon exigidos no nível-alvo','number',1,6,1],
['Treinamento','shareTraining','Experiência para reservas','check'],
['Treinamento','grindWildBattles','Grind com batalhas selvagens','check'],
['Centro Pokémon','centerVisits','Visitas ao Centro Pokémon','check'],
['Centro Pokémon','centerThreshold','Visitar Centro quando HP médio abaixo de (%)','number',25,95,5],
['Combates','smartMoves','Escolha estratégica de golpes','check'],
['Combates','smartSwitch','Trocas durante batalha','check'],
['Combates','potions','Usar poções','check'],
['Combates','critical','Golpes críticos','check'],
['Combates','status','Condições de status','check'],
['Combates','evolution','Evoluções','check'],
['Combates','expMultiplier','Multiplicador de experiência','select',[0.5,0.75,1,1.5,2,3]],
['Competições','tournamentMatchTurns','Limite de turnos por confronto','number',15,220,5],
['Pós-jogo','frontierEnabled','Ativar Battle Frontier','check'],
['Pós-jogo','postgameTraining','Treinar após vencer a Liga','check'],
['Mundo','enableTileEncounters','Encontros ao pisar no terreno','check'],
['Mundo','encounterOdds','Chance de encontro na grama (%)','number',1,70,1],
['Mundo','protectedCities','Cidades e interiores seguros','check'],
['Mundo','worldEvents','Eventos raros','check'],
['Mundo','weather','Clima variável (visual)','check'],
['Mundo','friendships','Amizades','check'],
['Mundo','rivalries','Rivalidades','check'],
['Interface','animations','Animações','check'],
['Interface','uiDensity','Densidade','select',['normal','compact']]
];
const panel=$('settingsPanel');
panel.innerHTML=settingDefs.map(([group,key,label,kind,a,b,step])=>`<div class="settingField"><small>${group}</small><label for="set_${key}">${label}</label>${kind==='check'?`<input id="set_${key}" type="checkbox">`:kind==='select'?`<select id="set_${key}">${a.map(v=>`<option value="${v}">${v}</option>`).join('')}</select>`:`<input id="set_${key}" type="number" min="${a}" max="${b}" step="${step}">`}</div>`).join('');
function syncSettings(){for(const [,key,,kind] of settingDefs){const el=$('set_'+key);if(!el)continue;if(kind==='check')el.checked=!!window.emeraldOptions[key];else el.value=String(window.emeraldOptions[key])}document.body.classList.toggle('compact',window.emeraldOptions.uiDensity==='compact')}
for(const [,key,,kind,a,b] of settingDefs){const el=$('set_'+key);el.onchange=()=>{let v=kind==='check'?el.checked:kind==='number'?Math.max(a,Math.min(b,Number(el.value)||a)):el.value;window.emeraldSetOption(key,v);if(key==='teamPolicy'||key==='teamSize'){window.emeraldRebalanceAll?.()}syncSettings();window.emeraldRender?.()}}
$('defaultsButton').onclick=()=>{for(const [k,v] of Object.entries(window.emeraldDefaults))window.emeraldSetOption(k,v);syncSettings()};
$('exportButton').onclick=()=>{const data=window.emeraldExport();const blob=new Blob([JSON.stringify(data)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='emerald_living_world_v26_save.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)};
$('importFile').onchange=async e=>{try{const f=e.target.files[0];if(!f)return;const obj=JSON.parse(await f.text());if(!Array.isArray(obj.trainers)||obj.trainers.length<1||obj.trainers.length>100)throw Error('Save inválido');localStorage.setItem('emerald_living_world_v26',JSON.stringify(obj));alert('Save importado. Recarregue a página para continuar.')}catch(err){alert('Falha ao importar: '+err.message)}};
syncSettings();
const ruleDefs=[['enemyLevelBonus','Níveis extras em duelos entre bots (não altera a história)',0,15,1],['gymTrainers','Treinadores antes de cada líder',0,10,1],['routeTrainers','Treinadores em cada rota/etapa',0,5,1],['battlePace','Rodadas por turno de batalha',1,15,1],['tournamentInterval','Intervalo entre torneios',100,3000,100],['tournamentMinStage','Etapa mínima para torneio',0,27,1],['tournamentTeamSize','Pokémon avaliados por torneio',1,6,1],['captureAggression','Chance de tentar captura (%)',5,100,5],['teamSize','Limite de equipe',1,6,1],['partyRebalance','Diferença para trocar Pokémon',0,100,5]];
const toggleDefs=[['collectionGoal','Completar catálogo antes da Liga'],['requireGuards','Exigir treinadores antes do líder'],['trainerEncounters','Batalhas com treinadores nas rotas'],['tournamentEnabled','Campeonatos automáticos'],['frontierEnabled','Battle Frontier depois da Liga'],['leagueHeal','Recuperação entre lutas da Liga'],['teamOptimization','Equipe adaptativa'],['rivalries','Rivalidades'],['capture','Capturas automáticas']];
const rulesEl=$('ruleControls');rulesEl.innerHTML=ruleDefs.map(([k,label,min,max,step])=>`<div class="settingField"><label>${label}</label><input type="number" id="rule_${k}" min="${min}" max="${max}" step="${step}"></div>`).join('')+toggleDefs.map(([k,label])=>`<div class="settingField"><label><input type="checkbox" id="rule_${k}"> ${label}</label></div>`).join('');
function syncRules(){syncSettings();for(const [k] of ruleDefs)$('rule_'+k).value=window.emeraldOptions[k];for(const [k] of toggleDefs)$('rule_'+k).checked=!!window.emeraldOptions[k]}
for(const [k,,min,max] of ruleDefs)$('rule_'+k).onchange=e=>{window.emeraldSetOption(k,Math.max(min,Math.min(max,Number(e.target.value)||min)));syncRules()};for(const [k] of toggleDefs)$('rule_'+k).onchange=e=>window.emeraldSetOption(k,e.target.checked);
$('rulesReset').onclick=()=>{for(const [k] of [...ruleDefs,...toggleDefs,['expMultiplier'],['potions'],['shareTraining'],['partyReadiness']])window.emeraldSetOption(k,window.emeraldDefaults[k]);syncRules()};
$('rulesExport').onclick=()=>{const blob=new Blob([JSON.stringify(window.emeraldOptions,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='regras_emerald_v26.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)};
$('rulesImport').onchange=async e=>{try{const obj=JSON.parse(await e.target.files[0].text());for(const [k,v] of Object.entries(obj))if(k in window.emeraldDefaults&&typeof v===typeof window.emeraldDefaults[k])window.emeraldSetOption(k,v);syncRules();alert('Regras importadas')}catch(err){alert('Erro: '+err.message)}};syncRules();
const expeditionPanel=document.createElement('section');expeditionPanel.className='card expeditionPanel';
expeditionPanel.innerHTML=`<small class="eyebrow">LABORATÓRIO DE BIRCH</small><h2>Novas regras, novas jornadas</h2><p>As IAs escolhem capturas inéditas, usam os dois tipos e treinam para o próximo desafio. Escolha um conjunto de regras para os próximos eventos.</p><div class="toolbar"><button data-mode="classic">Clássico</button><button data-mode="collector">Colecionador</button><button data-mode="veteran">Veterano</button><button data-mode="expert">Especialista</button></div><p id="modeFeedback" role="status">Clássico: equipe de seis e dificuldade original.</p><p class="note">Colecionador: exige registrar todas as espécies do catálogo disponível antes da Liga. Expedições adaptadas permitem encontrar iniciais e evoluções fora dos habitats comuns. Lendários desativados ou pertencentes a outro treinador ficam fora da meta. Cada espécie lendária tem um único exemplar no mundo, incluindo equipes, PC e encontros ativos. Veterano: adversários +3 níveis, experiência ×0,75, sem poções. Especialista: adversários +6, equipe de três, Level Cap obrigatório, sem experiência compartilhada nem poções. Os modos substituem essas regras; o editor permite combiná-las. O Level Cap por insígnias e o dano de Geração III permanecem ativos em todos os modos.</p><div id="collectionStatus"></div>`;
$('ruleControls').closest('.card').before(expeditionPanel);
const presets={classic:{collectionGoal:false,enemyLevelBonus:0,expMultiplier:1,potions:true,shareTraining:true,teamSize:6,partyReadiness:6,levelCap:true,gymTrainers:2,routeTrainers:2},collector:{collectionGoal:true,enemyLevelBonus:0,expMultiplier:1,potions:true,shareTraining:true,teamSize:6,partyReadiness:6,levelCap:true,gymTrainers:2,routeTrainers:2},veteran:{collectionGoal:false,enemyLevelBonus:3,expMultiplier:.75,potions:false,shareTraining:true,teamSize:6,partyReadiness:6,levelCap:true,gymTrainers:4,routeTrainers:3},expert:{collectionGoal:false,enemyLevelBonus:6,expMultiplier:.75,potions:false,shareTraining:false,teamSize:3,partyReadiness:3,levelCap:true,gymTrainers:6,routeTrainers:4}};
expeditionPanel.querySelectorAll('[data-mode]').forEach(button=>button.onclick=()=>{for(const [key,value] of Object.entries(presets[button.dataset.mode]))window.emeraldSetOption(key,value);if(button.dataset.mode==='collector'){window.emeraldSetOption('capture',true);window.emeraldSetOption('pcStorage',true)}window.emeraldSetOption('teamOptimization',true);window.emeraldSetOption('grinding',true);window.emeraldSetOption('requireGuards',true);window.emeraldSetOption('trainerEncounters',true);window.emeraldRebalanceAll();syncRules();$('modeFeedback').textContent=button.textContent+' aplicado aos próximos eventos. Ajustes adicionais estão no editor abaixo.';window.emeraldRender()});
function updateCollection(){if(document.hidden||$('page-regras').hidden)return;const state=window.emeraldExport();const t=state.trainers[state.selected]||state.trainers[0];const p=window.emeraldCollectionProgress(t);$('collectionStatus').innerHTML=`<h3>${safeCollection(t.name)} · caderno de campo</h3><label for="collectionMeter">${p.caught}/${p.total} espécies registradas</label><progress id="collectionMeter" max="${p.total}" value="${p.caught}"></progress><p>${window.emeraldOptions.collectionGoal?'Meta obrigatória ativa':'Coleção livre'} · ${p.missing.length?'Próximas descobertas: '+p.missing.slice(0,8).map(safeCollection).join(', '):'Catálogo completo!'}</p><p class="note">${safeCollection(t.teamReason||'A jornada começa com a escolha do inicial.')}</p>`}
function safeCollection(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
setInterval(updateCollection,1500);
const routeNodes=[['Littleroot',60,390],['Oldale Town',150,345],['Petalburg City',245,340],['Rustboro City',250,225],['Dewford Town',95,480],['Slateport City',395,400],['Mauville City',480,300],['Verdanturf Town',375,275],['Fallarbor Town',405,175],['Lavaridge Town',510,210],['Fortree City',630,195],['Lilycove City',785,205],['Mossdeep City',830,350],['Sootopolis City',715,440],['Ever Grande City',880,500]];
const mapEl=$('hoennMapCanvas');const mapEdges=[[0,1],[1,2],[2,3],[3,4],[4,5],[5,6],[6,7],[6,8],[8,9],[9,6],[6,10],[10,11],[11,12],[12,13],[13,14]];
mapEl.innerHTML=`<svg viewBox="0 0 950 570" role="img" aria-label="Mapa esquemático de Hoenn, com cidades clicáveis"><defs><pattern id="waves" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M0 20 Q10 10 20 20 T40 20" fill="none" stroke="#2b626b" opacity=".4"/></pattern></defs><rect width="950" height="570" fill="url(#waves)"/><path d="M120 90 L610 80 670 160 640 290 500 335 330 300 245 440 100 435 45 300Z" fill="#1c524c" stroke="#368b70" stroke-width="5" opacity=".6"/>${mapEdges.map(([a,b])=>`<path class="mapEdge" d="M${routeNodes[a][1]} ${routeNodes[a][2]} L${routeNodes[b][1]} ${routeNodes[b][2]}"/>`).join('')}${routeNodes.map(([name,x,y],i)=>`<g class="mapNode" data-place="${name}" tabindex="0" role="button" aria-label="${name}"><circle cx="${x}" cy="${y}" r="15"/><text x="${x}" y="${y-23}" text-anchor="middle">${name}</text><text x="${x}" y="${y+5}" text-anchor="middle" font-size="11">${i+1}</text></g>`).join('')}</svg>`;
const regionAliases={
 'Route 101':'Littleroot','Route 102':'Petalburg City','Route 103':'Oldale Town','Route 104':'Rustboro City','Route 105':'Dewford Town','Route 106':'Dewford Town','Route 107':'Dewford Town','Route 108':'Slateport City','Route 109':'Slateport City','Route 110':'Mauville City','Route 111':'Mauville City','Route 112':'Lavaridge Town','Route 113':'Fallarbor Town','Route 114':'Fallarbor Town','Route 115':'Rustboro City','Route 116':'Rustboro City','Route 117':'Verdanturf Town','Route 118':'Mauville City','Route 119':'Fortree City','Route 120':'Fortree City','Route 121':'Lilycove City','Route 122':'Lilycove City','Route 123':'Lilycove City','Route 124':'Mossdeep City','Route 125':'Mossdeep City','Route 126':'Sootopolis City','Route 127':'Mossdeep City','Route 128':'Ever Grande City','Route 129':'Sootopolis City','Route 130':'Sootopolis City','Route 131':'Sootopolis City','Route 132':'Slateport City','Route 133':'Slateport City','Route 134':'Slateport City',
 'Petalburg Woods':'Petalburg City','Granite Cave':'Dewford Town','Meteor Falls':'Fallarbor Town','Mt. Chimney':'Lavaridge Town','Jagged Pass':'Lavaridge Town','Victory Road':'Ever Grande City','Liga Pokémon':'Ever Grande City','Sky Pillar':'Sootopolis City','Seafloor Cavern':'Sootopolis City','Pacifidlog Town':'Sootopolis City','Safari Zone':'Lilycove City','Oceanic Museum':'Slateport City','Weather Institute':'Fortree City','Laboratório':'Littleroot','Casa':'Littleroot','Quarto':'Littleroot','Caminhão':'Littleroot','Casa do rival':'Littleroot','Quarto do rival':'Littleroot'
};
function regionNode(loc){const str=String(loc||'');const route=str.match(/Route \d+/)?.[0];const mapped=regionAliases[str]||regionAliases[route]||str;return routeNodes.find(n=>n[0]===mapped)||routeNodes.find(n=>mapped.includes(n[0].split(' ')[0]))||routeNodes[0]}
window.emeraldRegion={nodes:routeNodes,edges:mapEdges,node:regionNode};
const safe=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let selectedPlace='',placeSignature='';
function selectPlace(name,refresh=false){selectedPlace=name;const state=window.emeraldExport();const nearby=state.trainers.filter(t=>regionNode(t.location)[0]===name);const signature=name+'|'+nearby.map(t=>t.id+':'+t.badges).join(',');if(refresh&&signature===placeSignature)return;placeSignature=signature;mapEl.querySelectorAll('.mapNode').forEach(n=>n.setAttribute('aria-pressed',String(n.dataset.place===name)));$('mapSelection').innerHTML=`<b>${safe(name)}</b> · ${nearby.length} treinadores na região<div class="toolbar" style="margin-top:10px"><button id="visitMapScene">Explorar cenário</button>${nearby.map(t=>`<button data-maptrainer="${t.id}">${safe(t.name)} · ${t.badges}/8</button>`).join('')||'<small>Nenhum treinador neste momento. Explore o cenário livremente.</small>'}</div>`;$('visitMapScene').onclick=()=>{showPage('jogo');$('scenePreview').value=name;$('scenePreview').onchange()};$('mapSelection').querySelectorAll('[data-maptrainer]').forEach(b=>b.onclick=()=>{window.emeraldSelectTrainer(Number(b.dataset.maptrainer));$('liveFocus').value='selected';$('scenePreview').value='';showPage('jogo')})}
mapEl.querySelectorAll('.mapNode').forEach(n=>{n.onclick=()=>selectPlace(n.dataset.place);n.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();n.click()}}});
setInterval(()=>{if(!document.hidden&&!$('page-mapa').hidden&&selectedPlace)selectPlace(selectedPlace,true)},2000);
const find=$('quickFind'),results=$('quickResults');let historyPages=['jogo'];const labelPages=[...document.querySelectorAll('.siteNav [data-page]')].map(b=>({name:b.textContent.trim(),id:b.dataset.page}));
function quickItems(query){const q=query.toLocaleLowerCase('pt-BR');if(!q)return [];const state=window.emeraldExport();return [...labelPages.filter(x=>x.name.toLocaleLowerCase('pt-BR').includes(q)).map(x=>({label:'📄 '+x.name,page:x.id})),...state.trainers.filter(t=>t.name.toLocaleLowerCase('pt-BR').includes(q)).slice(0,12).map(t=>({label:'👤 '+t.name+' • '+t.location,page:'jogo',id:t.id})),...routeNodes.filter(n=>n[0].toLowerCase().includes(q)).map(n=>({label:'🗺️ '+n[0],page:'mapa',place:n[0]}))].slice(0,25)}
find.oninput=()=>{const items=quickItems(find.value.trim());results.hidden=!items.length;results.innerHTML=items.map((x,i)=>`<button data-index="${i}">${x.label}</button>`).join('');results.querySelectorAll('button').forEach(b=>b.onclick=()=>{const x=items[Number(b.dataset.index)];if(x.id!==undefined)window.emeraldSelectTrainer(x.id);showPage(x.page);if(x.place)selectPlace(x.place);find.value='';results.hidden=true})};find.onkeydown=e=>{if(e.key==='Escape'){find.value='';results.hidden=true}if(e.key==='Enter'){const b=results.querySelector('button');if(b)b.click()}};
// Navegação centralizada: os botões fixos, menu e abas usam a MESMA função.
const pages=['jogo','recuperacao','forca','jogador','treinadores','ranking','mundial','conta','projeto','corrida','torneios','frontier','campanha','regras','desafios','mapa','hall','equipes','pokedex','historico','config','creditos'];
const pageTitles=Object.fromEntries(labelPages.map(x=>[x.id,x.name]));
Object.assign(pageTitles,{
 recuperacao:'🏥 Recuperação e saves',forca:'💪 Rankings de força',historico:'📰 Histórico',config:'⚙️ Configurações',
 mundial:'🌍 Top Mundial',conta:'☁️ Minha Conta',projeto:'🌿 Sobre o Projeto',creditos:'✦ Créditos',hall:'👑 Hall da Fama',corrida:'⏱️ Corrida Top 10',mapa:'🗺️ Mapa de Hoenn',
 campanha:'📜 Campanha',desafios:'🎯 Desafios',frontier:'🌟 Battle Frontier',treinadores:'🤖 Treinadores',
 torneios:'🥊 Torneios',regras:'📜 Regras',equipes:'🎒 Equipes'
});
const drawer=document.createElement('div');drawer.id='navDrawer';drawer.hidden=true;
const groups=[
 ['PRINCIPAL',['jogo','pokedex','ranking','mundial']],
 ['JORNADA',['recuperacao','historico','campanha','mapa','hall','corrida']],
 ['COMPETIÇÃO',['forca','treinadores','torneios','desafios','frontier']],
 ['PROJETO E CONTROLES',['conta','projeto','config','regras','creditos']]
];
drawer.innerHTML=`<div class="drawerShade" data-close="1"></div><section class="drawerSheet" role="dialog" aria-modal="true" aria-label="Outras páginas do jogo"><div class="drawerHeader"><b>🧭 Outras páginas</b><button id="drawerClose" type="button" aria-label="Fechar menu">✕</button></div>${groups.map(([title,entries])=>`<div class="secondaryGroup"><span class="secondaryLabel">${title}</span><div class="drawerLinks">${entries.map(x=>`<button type="button" data-drawer-page="${x}">${pageTitles[x]||x}</button>`).join('')}</div></div>`).join('')}</section>`;
document.body.appendChild(drawer);
function closeDrawer(){drawer.hidden=true;document.body.classList.remove('drawerOpen')}
function openDrawer(){drawer.hidden=false;document.body.classList.add('drawerOpen');$('drawerClose').focus()}
$('navMore').onclick=openDrawer;$('bottomMore').onclick=openDrawer;$('headerMorePages').onclick=openDrawer;
$('drawerClose').onclick=closeDrawer;drawer.querySelector('[data-close]').onclick=closeDrawer;
drawer.querySelectorAll('[data-drawer-page]').forEach(btn=>btn.onclick=()=>{closeDrawer();showPage(btn.dataset.drawerPage)});
const pagesBack=[];
function showPage(page,remember=true){
 if(page==='jogador')page='jogo'; // legacy link: keep one visible Jogo tab
 if(!pages.includes(page))page='jogo';
 const current=document.querySelector('.bottomNav [aria-selected="true"]')?.dataset.page||location.hash.slice(1)||'jogo';
 if(remember&&current!==page)pagesBack.push(current);
 // In solo, Jogo shows the controllable trainer. In watch mode, it shows the world.
 const visiblePage=page==='jogo'&&document.body.dataset.worldMode==='player'?'jogador':page;
 $('gamePage').hidden=visiblePage!=='jogo';
 for(const name of pages.filter(x=>x!=='jogo')){const el=$('page-'+name);if(el)el.hidden=name!==visiblePage}
 document.querySelectorAll('.siteNav [data-page],.bottomNav [data-page],.drawerLinks [data-drawer-page]').forEach(b=>b.setAttribute('aria-selected',String((b.dataset.page||b.dataset.drawerPage)===page)));
 closeDrawer();
 window.dispatchEvent(new CustomEvent('emerald:pagechange',{detail:{page,visiblePage}}));
 if(location.hash!=='#'+page)try{history.replaceState(null,'','#'+page)}catch(e){}
 window.scrollTo({top:0,left:0,behavior:'instant'});
}
window.emeraldShowPage=showPage;
$('navBack').onclick=()=>showPage(pagesBack.pop()||'jogo',false);
document.querySelectorAll('.siteNav [data-page],.bottomNav [data-page]').forEach(b=>b.addEventListener('click',e=>{e.preventDefault();showPage(b.dataset.page)}));
window.addEventListener('hashchange',()=>showPage(location.hash.slice(1),false));
window.addEventListener('keydown',e=>{if(e.key==='Escape')closeDrawer();if((e.ctrlKey||e.metaKey)&&e.key==='k'){e.preventDefault();find.focus();find.select()}});
$('quickFrontier').onclick=()=>showPage('frontier');$('quickPokedex').onclick=()=>showPage('pokedex');showPage(location.hash.slice(1)||'jogo',false);
})();
