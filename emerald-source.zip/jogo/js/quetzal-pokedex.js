(()=>{'use strict';
const $=id=>document.getElementById(id);
const PAGE_SIZE=48;
let pokemon=[],metadata={},current=0,lastPage=1,filtered=[];
const normalize=s=>String(s??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const ranges=[[1,151],[152,251],[252,386],[387,493],[494,649],[650,721],[722,809],[810,905],[906,1025]];
function generations(id){return ranges.findIndex(([a,b])=>id>=a&&id<=b)+1;}
function format(r){return r.kind==='species'?`#${String(r.dex).padStart(4,'0')}`:`ROM #${r.id}`;}
function result(r){let button=document.createElement('button');button.type='button';button.className='entry';
 const code=document.createElement('small');code.textContent=format(r)+(r.kind==='variant'?' · Forma interna':r.kind==='experimental'?' · Experimental':'');
 const picture=document.createElement('span');picture.className='entryPicture';const img=document.createElement('img');window.EmeraldPokemonArt.apply(img,r,{dex:r.dex,pixel:true});picture.append(img);
 const name=document.createElement('b');name.textContent=r.name;
 const type=document.createElement('span');type.className='types';type.textContent=r.types.join(' / ')+' · BST '+r.base.reduce((a,b)=>a+b,0);
 button.append(picture,code,name,type);button.addEventListener('click',()=>details(r));return button;}
function details(r){const el=$('details');el.hidden=false;el.replaceChildren();
 const hero=document.createElement('div');hero.className='detailHero';const portrait=document.createElement('img');window.EmeraldPokemonArt.apply(portrait,r,{dex:r.dex,pixel:false,eager:true});const heroWords=document.createElement('div');
 const head=document.createElement('h2');head.textContent=`${r.name} — ${format(r)}`;heroWords.append(head);
 const legend=document.createElement('small');legend.textContent=r.kind==='species'?'Imagem de referência externa ou sprite local':r.kind==='variant'?'Imagem da espécie-base: esta forma ainda não foi identificada':'Sem imagem identificada para este registro';heroWords.append(legend);hero.append(portrait,heroWords);el.append(hero);
 const p=document.createElement('p');p.textContent=`${r.types.join(' / ')} · ${r.kind==='species'?'Espécie oficial na Pokédex Nacional':r.kind==='variant'?'Forma interna (identidade específica ainda não verificada)':'Registro experimental Quetzal'}.`;
 el.append(p);
 const stats=document.createElement('div');stats.className='statGrid';
 for(const [i,label] of ['HP','Ataque','Defesa','Ataque Esp.','Defesa Esp.','Velocidade'].entries()){
  const row=document.createElement('div'),span=document.createElement('span'),strong=document.createElement('b');span.textContent=label;strong.textContent=r.base[i];row.append(span,strong);stats.append(row);
 }
 el.append(stats);const extra=document.createElement('p');extra.textContent=`Taxa de captura (valor-base): ${r.catch} · EXP-base: ${r.exp} · BST: ${r.base.reduce((a,b)=>a+b,0)}.`;el.append(extra);
 if(r.kind!=='species'){const warn=document.createElement('p');warn.className='warning';warn.textContent='A identidade desta forma ainda não foi confirmada. O número interno não identifica automaticamente uma Mega, forma regional ou Gigamax.';el.append(warn);}
 const foot=document.createElement('p');foot.textContent='Os golpes no modo online ainda utilizam um conjunto simplificado por tipo; evoluções especiais e tabelas oficiais da ROM não foram extraídas.';el.append(foot);
 const locations=document.createElement('p');
 const info=window.EmeraldNationalPools?.encounterInfo({...r,key:r.key||r.name});
 const simulated=info?.locations||[];
 const badges=Number(info?.minBadges)||0;
 locations.textContent=simulated.length
  ?'📍 Locais de encontro ADAPTADOS (não oficiais do Quetzal): '+simulated.join(' · ')+(badges?' · Desbloqueio: '+badges+' insígnias':' · Disponível desde o início')
  :info?.method==='special'?'📍 Encontro especial: não disponível na captura selvagem comum.':
  '📍 Sem encontro selvagem comum identificado nesta fase.';
 el.append(locations);
 el.scrollIntoView({behavior:'smooth',block:'nearest'});
}
function update(){const q=normalize($('search').value),type=$('type').value,kind=$('kind').value,gen=Number($('generation').value)||0;
 filtered=pokemon.filter(r=>(kind==='all'||r.kind===kind)&&(!type||r.types.includes(type))&&(!gen||generations(r.dex)===gen)&&(!q||normalize(r.name).includes(q)||String(r.dex??'')===q));
 lastPage=Math.max(1,Math.ceil(filtered.length/PAGE_SIZE));current=Math.min(current,lastPage-1);
 $('results').replaceChildren(...filtered.slice(current*PAGE_SIZE,(current+1)*PAGE_SIZE).map(result));
 $('count').textContent=`${filtered.length} registro(s) · ${metadata.nationalSpecies||0} espécies nacionais cadastradas`;
 $('pageNo').textContent=`Página ${current+1} de ${lastPage}`;
 $('previous').disabled=current===0;$('next').disabled=current===lastPage-1;
}
for(const id of ['search','type','kind','generation'])$(id).addEventListener(id==='search'?'input':'change',()=>{current=0;update();});
$('previous').addEventListener('click',()=>{current--;update();});$('next').addEventListener('click',()=>{current++;update();});
fetch('data/quetzal-catalog.json',{cache:'force-cache'}).then(r=>{if(!r.ok)throw Error(`HTTP ${r.status}`);return r.json()}).then(d=>{
 metadata=d.metadata;pokemon=d.pokemon;window.EmeraldPokemonArt.register(pokemon);
 if(pokemon.length!==1528||metadata.nationalSpecies!==1025)throw Error('Dados incompletos da Pokédex Quetzal');
 const types=[...new Set(pokemon.flatMap(x=>x.types))].sort();for(const t of types){const opt=document.createElement('option');opt.value=t;opt.textContent=t;$('type').append(opt)}
 $('overview').textContent=`${metadata.nationalSpecies} espécies nacionais, ${metadata.internalVariants} formas internas e ${metadata.experimentalFormSlots} registros experimentais. Catálogo baseado na versão PT-BR Alpha 9 v1.`;
 update();
}).catch(err=>{$('overview').textContent='Falha ao carregar o catálogo local.';$('count').textContent=err.message;});
})();
