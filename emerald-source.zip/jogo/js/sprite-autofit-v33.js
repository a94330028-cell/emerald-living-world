(()=>{
'use strict';
const SELECTOR=[
 '#page-ranking #rankTopSix .cleanStatRow img',
 '#rankStrongestPokemon img',
 '#rankTopSix img',
 '#page-forca .cleanStatRow img',
 '#gamePage .gameTopPoke img',
 '#gamePage .cleanMini img',
 '#page-pokedex .cleanPokemonCard img',
 '#gamePage .homeMonImage',
 '#myBotPanel .personalTopSixRow img',
 '#myBotPanel .personalParty img',
 '.classicPcMons img'
].join(',');

const seen=new WeakMap();
function alphaBox(img){
  try{
    const w=img.naturalWidth||0,h=img.naturalHeight||0;
    if(!w||!h) return null;
    const c=document.createElement('canvas'); c.width=w; c.height=h;
    const ctx=c.getContext('2d',{willReadFrequently:true});
    ctx.drawImage(img,0,0,w,h);
    const {data}=ctx.getImageData(0,0,w,h);
    let minX=w,minY=h,maxX=-1,maxY=-1;
    for(let y=0;y<h;y++){
      const row=y*w*4;
      for(let x=0;x<w;x++){
        if(data[row+x*4+3]>8){
          if(x<minX)minX=x; if(y<minY)minY=y; if(x>maxX)maxX=x; if(y>maxY)maxY=y;
        }
      }
    }
    if(maxX<0||maxY<0) return null;
    return {x:minX,y:minY,w:maxX-minX+1,h:maxY-minY+1,cx:(minX+maxX+1)/2,cy:(minY+maxY+1)/2,nw:w,nh:h};
  }catch(e){ return null; }
}

function targetFill(img){
  if(img.closest('#page-ranking #rankTopSix')) return 0.94;
  if(img.closest('.gameTopPoke')) return 0.91;
  if(img.closest('.cleanMini')) return 0.9;
  if(img.closest('.cleanPokemonCard')) return 0.9;
  return 0.9;
}

function fit(img){
  if(!img || !img.isConnected) return;
  if(!img.complete || !img.naturalWidth) return;
  const key=(img.currentSrc||img.src||'')+'|'+(img.clientWidth||0)+'x'+(img.clientHeight||0);
  if(seen.get(img)===key) return;
  const box=alphaBox(img); if(!box) return;
  const stageW=img.clientWidth || parseFloat(getComputedStyle(img).width) || 64;
  const stageH=img.clientHeight || parseFloat(getComputedStyle(img).height) || 64;
  const spriteW=(box.w/box.nw)*stageW;
  const spriteH=(box.h/box.nh)*stageH;
  if(!spriteW||!spriteH) return;
  const fill=targetFill(img);
  let scale=Math.min((stageW*fill)/spriteW,(stageH*fill)/spriteH);
  scale=Math.max(1,Math.min(scale,2.6));
  const currentCenterX=(box.cx/box.nw)*stageW;
  const currentCenterY=(box.cy/box.nh)*stageH;
  const offsetX=currentCenterX-stageW/2;
  const offsetY=currentCenterY-stageH/2;
  const dx=-(offsetX*scale);
  const dy=-(offsetY*scale);
  img.classList.add('elw-autofit-sprite');
  img.style.setProperty('--elw-fit-scale',String(scale));
  img.style.setProperty('--elw-fit-x',dx.toFixed(2)+'px');
  img.style.setProperty('--elw-fit-y',dy.toFixed(2)+'px');
  seen.set(img,key);
  img.dataset.spriteAutofit='true';
}

function watch(img){
  if(!img) return;
  if(img.complete) fit(img);
  else img.addEventListener('load',()=>fit(img),{once:true});
}

function scan(root=document){ root.querySelectorAll(SELECTOR).forEach(watch); }

const mo=new MutationObserver((entries)=>{
  for(const entry of entries){
    if(entry.type==='childList'){
      entry.addedNodes.forEach(node=>{
        if(!(node instanceof Element)) return;
        if(node.matches?.(SELECTOR)) watch(node);
        scan(node);
      });
    }else if(entry.type==='attributes' && entry.target instanceof HTMLImageElement){
      watch(entry.target);
    }
  }
});

function boot(){
  scan();
  mo.observe(document.body,{subtree:true,childList:true,attributes:true,attributeFilter:['src']});
  window.addEventListener('resize',()=>scan(),{passive:true});
  document.addEventListener('visibilitychange',()=>{ if(!document.hidden) scan(); });
  setInterval(()=>{ if(!document.hidden) scan(); },1500);
}
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot,{once:true});
else boot();
})();
