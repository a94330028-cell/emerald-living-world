/* V2.5 — Detalhes reais dos Pokémon da equipe/PC. Não modifica dados do save. */
(function(root){'use strict';
 const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const number=n=>Number.isFinite(Number(n))?String(Math.round(Number(n))):'—';
 const label={maxHp:'HP máximo',atk:'Ataque',def:'Defesa',spAtk:'Ataque Especial',spDef:'Defesa Especial',speed:'Velocidade'};
 function stats(m){return Object.entries(label).map(([k,title])=>({key:k,label:title,value:m?.[k]}));}
 function moveList(m){
  const dex=root.emeraldDexAPI||{};
  const defs=dex.MOVES||{};
  const known=Array.isArray(m?.moves)?m.moves:[];
  if(!known.length)return '<p class="monNoMoves">Nenhum golpe registrado neste Pokémon.</p>';
  return `<div class="monAttackGrid">${known.map(move=>{
   const raw=defs[move],type=Array.isArray(raw)?raw[0]:null,power=Array.isArray(raw)?raw[1]:null,accuracy=Array.isArray(raw)?raw[2]:null;
   const powerText=Number(power)>0?`Poder ${number(power)}`:power===0?'Status':null;
   const info=[type,powerText,accuracy!=null?`Precisão ${number(accuracy)}%`:null].filter(Boolean).map(escape).join(' · ');
   const pp=m?.pp?.[move];
   return `<div class="monAttackItem"><strong>${escape(move)}</strong><small>${info||'Golpe do simulador'}${Number.isFinite(Number(pp))?' · '+number(pp)+' PP':''}</small></div>`;
  }).join('')}</div>`;
 }
 function statGrid(m){return `<div class="monCombatStats">${stats(m).map(x=>`<div class="monCombatStat"><span>${escape(x.label)}</span><b>${number(x.value)}</b></div>`).join('')}</div>`;}
 function html(m,opts={}){
  const hp=`${number(m?.hp)} / ${number(m?.maxHp)}`;
  const meta=[`HP atual ${hp}`,`Natureza ${escape(m?.nature||'não informada')}`,Number.isFinite(Number(m?.exp))?`EXP ${number(m.exp)}`:null].filter(Boolean).join(' · ');
  return `<details class="monFullDetails"${opts.open?' open':''}><summary>📊 Atributos e ataques</summary><div class="monFullDetailsBody"><p class="monStatMeta">${meta}</p>${statGrid(m)}<h4>⚔️ Golpes conhecidos (${Array.isArray(m?.moves)?m.moves.length:0}/4)</h4>${moveList(m)}<p class="monDetailNote">Valores atuais deste Pokémon na simulação. O conjunto de golpes do Quetzal ainda não está integralmente implementado.</p></div></details>`;
 }
 root.EmeraldMonDetails=Object.freeze({html,moveList,statGrid,stats});
})(typeof window!=='undefined'?window:globalThis);
