/* Emerald Living World 2.5 — illustrated dashboard, switchable dark theme, trainer PC.
   These are UI-only enhancements. No Pokémon/battle/save mutations. */
(()=>{'use strict';
const $=id=>document.getElementById(id);
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const keys=()=>window.EmeraldTrainerSprites?.IDS||['brendan','may','red','leaf'];
const art=()=>window.EmeraldPokemonArt;
const state=()=>window.emeraldExport?.();
const current=()=>{const bots=state();return document.body.dataset.worldMode==='player'
  ?window.emeraldMyBot?.()||bots?.trainers?.find(t=>t.isUserBot)||bots?.trainers?.[0]
  :bots?.trainers?.[bots?.selected]||bots?.trainers?.[0]};
function portraitId(t){const choices=keys();return choices.includes(t?.avatar)?t.avatar:choices[Math.abs(Number(t?.id)||0)%choices.length]||'brendan'}
function portrait(t,el){if(!el)return;const id=portraitId(t);const asset=window.EmeraldTrainerSprites.get(id).sheet;
 if(el.dataset.portrait===id)return;el.dataset.portrait=id;el.setAttribute('aria-label',`Retrato do treinador ${String(t?.name||'Pokémon').slice(0,80)}`);el.style.backgroundImage=`url("${asset}")`;
}
function safeImg(species,small=false){const name=esc(species||'Pokémon');const path=art().sources(species)[0];return `<img src="${path}" data-polished-mon="${name}" alt="${name}" loading="eager" decoding="async" width="${small?44:64}" height="${small?44:64}">`}
let artReady=null;
function paint(el){if(!el)return;const draw=()=>{for(const img of el.querySelectorAll('img[data-polished-mon]')){
 if(img.dataset.artApplied==='true')continue;img.dataset.artApplied='true';
 if(art()?.apply)art().apply(img,img.dataset.polishedMon,{pixel:true});
 else img.onerror=()=>{img.onerror=null;img.src='assets/ui/pokemon_missing.svg'};
 }};
 draw();
}
const toggle=$('themeToggle');const themeKey='elw_visual_theme_25';
function setTheme(mode){const next=mode==='dark'?'dark':'emerald';document.documentElement.dataset.pokeTheme=next;
 if(toggle){toggle.textContent=next==='dark'?'☀️ Claro':'🌙 Escuro';toggle.setAttribute('aria-label',next==='dark'?'Ativar tema esmeralda claro':'Ativar tema escuro');toggle.setAttribute('aria-pressed',String(next==='dark'));}
 const secondary=$('themeToggleSettings');if(secondary)secondary.textContent=next==='dark'?'☀️ Tema Esmeralda':'🌙 Tema Escuro';
 const meta=document.querySelector('meta[name="theme-color"]');if(meta)meta.content=next==='dark'?'#101f33':'#086b54';
 try{localStorage.setItem(themeKey,next)}catch(_){/* private mode: preference lasts for this page */}
}
setTheme(document.documentElement.dataset.pokeTheme||'emerald');
toggle?.addEventListener('click',()=>setTheme(document.documentElement.dataset.pokeTheme==='dark'?'emerald':'dark'));
// The map remains the original interactive canvas. It comes first; camera/debug
// controls remain accessible inside a native expandable section below it.
const panel=$('directorPanel'),scene=panel?.querySelector('.scenePickerBar');
const mapGrid=panel?.querySelector('.directorGrid');const heading=panel?.querySelector('.directorHeading');
// The map now comes first in static HTML, before any JavaScript initializes.
// For older cached HTML, migrate once; never duplicate tools or create a second map.
if(panel&&mapGrid){
 if(panel.firstElementChild!==mapGrid)panel.insertBefore(mapGrid,panel.firstChild);
 let tools=$('classicMapTools');
 if(!tools){
  tools=document.createElement('details');tools.id='classicMapTools';tools.className='classicMapTools';
  const label=document.createElement('summary');label.textContent='⚙️ Câmera, colisões e ferramentas do mapa';tools.appendChild(label);
  if(heading)tools.appendChild(heading);if(scene)tools.appendChild(scene);panel.appendChild(tools);
 }
 // Advanced controls are opt-in; avoid an expanded panel burying the map on reload.
 tools.open=false;
}
// Battle feed and the tactical inspector remain fully functional, but outside
// the map frame. A native details control keeps them available on demand.
if(panel&&!$('classicLiveExtras')){
 const cinema=$('liveBattleCinema'),squad=panel.querySelector('.directorSquad');
 if(cinema||squad){const details=document.createElement('details');details.id='classicLiveExtras';details.className='classicLiveExtras';
  const summary=document.createElement('summary');summary.textContent='⚔️ Batalhas ao vivo e decisões da IA';details.appendChild(summary);
  if(cinema)details.appendChild(cinema);if(squad)details.appendChild(squad);
  panel.insertAdjacentElement('afterend',details);
 }
}
const mapStage=panel?.querySelector('.directorStage');if(mapStage&&!$('classicMapReplan')){
 const btn=document.createElement('button');btn.type='button';btn.className='classicMapReplan';btn.id='classicMapReplan';btn.textContent='🧭 Recalcular rota';btn.addEventListener('click',()=>$('replanSelectedBot')?.click());
 mapStage.insertBefore(btn,mapStage.querySelector('#liveBattleCinema'));
}
// Compact trainer strip, using the actual selected trainer and its current team.
const watchProfile=$('watchTrainerPortrait');let watchKey='';
function updateWatch(){if(!$('watchPartyQuick'))return;const t=current();if(!t)return;
 const sig=String(t.id)+':'+t.name+':'+t.badges+':'+(t.team?.length||0)+':'+portraitId(t);if(sig===watchKey)return;watchKey=sig;
 portrait(t,watchProfile);if($('watchTrainerName'))$('watchTrainerName').textContent=t.name||'Treinador';
 if($('watchTrainerBadges'))$('watchTrainerBadges').textContent=`🛡️ Insígnias: ${t.badges||0}/8`;
 if($('watchTrainerTeamCount'))$('watchTrainerTeamCount').textContent=`🔴 Pokémon na equipe: ${(t.team||[]).length}/6`;
}
// The solo trainer keeps the existing living roster, now visually beside the portrait.
let soloProfile=null;
function setupSolo(){const party=document.querySelector('#myBotPanel .personalPartyCard'),roster=$('botRoster');if(!party||!roster||party.querySelector('.classicSoloLayout'))return;
 const row=document.createElement('div');row.className='classicSoloLayout';const profile=document.createElement('div');profile.className='classicTrainerProfile';profile.innerHTML='<div id="soloTrainerPortrait" class="classicPortrait" role="img" aria-label="Meu treinador"></div><div class="classicTrainerWords"><strong id="soloPortraitName">Meu Treinador</strong><small id="soloPortraitBadges">🛡️ 0/8</small></div>';
 row.append(profile,roster);party.appendChild(row);soloProfile=profile;
}
setupSolo();let soloKey='';
function updateSolo(){const t=window.emeraldMyBot?.();if(!t)return;const sig=[t.name,t.badges,portraitId(t)].join(':');if(sig===soloKey)return;soloKey=sig;
 portrait(t,$('soloTrainerPortrait'));if($('soloPortraitName'))$('soloPortraitName').textContent=t.name||'Meu Treinador';
 if($('soloPortraitBadges'))$('soloPortraitBadges').textContent=`🛡️ ${t.badges||0}/8 insígnias`;
}
// A usable featured entry, not a screenshot: opens the full searchable Pokédex.
function makeTeaser(id,anchor){if(!anchor)return null;const card=document.createElement('section');card.className='classicDexTeaser';card.id=id;card.setAttribute('aria-label','Prévia da Pokédex');
 card.innerHTML='<div class="teaserTop"><span class="teaserLens" aria-hidden="true"></span><h2>POKÉDEX</h2><small>Conheça seus parceiros</small></div><div class="teaserBody"><div class="teaserSprite" data-teaser-sprite></div><div><span class="classicKicker">REGISTRO DA EQUIPE</span><h3 data-teaser-species>Pokémon</h3><p data-teaser-text>Seu parceiro aparecerá aqui após a escolha do inicial.</p><button type="button" data-teaser-open>📕 Abrir Pokédex</button></div></div>';
 anchor.insertAdjacentElement('afterend',card);card.querySelector('[data-teaser-open]').addEventListener('click',()=>{
  window.emeraldShowPage?.('pokedex');const species=card.dataset.species;const input=$('classicDexSearch');if(input&&species){input.value=species;input.dispatchEvent(new Event('input',{bubbles:true}));}
 });return card;
}
const watchTeaser=null;
const soloTeaser=null;
let teaserSig='';
function updateTeasers(){const watched=state();const chosen=watched?.trainers?.[watched.selected]||watched?.trainers?.[0];const owner=window.emeraldMyBot?.();
 const list=[[watchTeaser,chosen],[soloTeaser,owner]];let currentSig='';for(const [card,t] of list){if(!card)continue;const mon=t?.team?.[0];const sig=(t?.id||'')+'|'+(mon?.species||'')+'|'+(mon?.level||'');currentSig+=sig;
 if(card.dataset.signature===sig)continue;card.dataset.signature=sig;card.dataset.species=mon?.species||'';
 card.querySelector('[data-teaser-species]').textContent=mon?.species||'Primeiro parceiro';
 card.querySelector('[data-teaser-text]').textContent=mon?`${t.name||'Treinador'} · Nível ${mon.level||1} · ${(t.team||[]).length} na equipe`:'Escolha seu Pokémon inicial para iniciar a jornada.';
 const holder=card.querySelector('[data-teaser-sprite]');holder.innerHTML=mon?safeImg(mon.species):'<span aria-hidden="true" style="font-size:46px">◉</span>';paint(holder);
 }teaserSig=currentSig;
}
// Show the same six team members alongside the trainer portrait above PC storage.
const pc=$('classicTrainerPC');let pcKey='';
function updatePC(){if(!pc)return;const st=state(),t=document.body.dataset.worldMode==='player'?current():(st?.trainers?.[st.selected]||current());if(!t)return;
 const mons=(t.team||[]).slice(0,6),sig=[t.id,t.name,t.badges,mons.map(m=>m.species+':'+m.level).join('|')].join(':');if(sig===pcKey)return;pcKey=sig;
 pc.innerHTML=`<div class="classicTrainerBar"><div class="classicTrainerProfile"><div class="classicPortrait" role="img" data-pc-portrait></div><div class="classicTrainerWords"><span class="classicKicker">PC DO TREINADOR</span><strong>${esc(t.name)}</strong><small>🛡️ ${t.badges||0}/8 insígnias</small><small>📦 ${(t.pc||[]).length} nas reservas</small></div></div><div class="classicPcMons" aria-label="Seis Pokémon da equipe">${Array.from({length:6},(_,i)=>mons[i]?`<div title="${esc(mons[i].species)} Nv.${mons[i].level}">${safeImg(mons[i].species,true)}<small>Nv.${Number(mons[i].level)||1}</small></div>`:'<div aria-label="Espaço vazio"><small>+</small></div>').join('')}</div></div>`;
 portrait(t,pc.querySelector('[data-pc-portrait]'));paint(pc);
}
// A settings-page switch uses the same persisted theme state.
const configs=$('page-config');if(configs&&!$('themeToggleSettings')){
 const btn=document.createElement('button');btn.id='themeToggleSettings';btn.type='button';btn.className='pokeThemeToggle';btn.style.margin='10px 0';btn.addEventListener('click',()=>setTheme(document.documentElement.dataset.pokeTheme==='dark'?'emerald':'dark'));
 configs.querySelector('.pageHero')?.appendChild(btn);setTheme(document.documentElement.dataset.pokeTheme);
}
function update(){if(document.hidden)return;updateWatch();updateSolo();updateTeasers();updatePC();}
window.addEventListener('emerald:pagechange',update);setInterval(update,1400);update();
})();
