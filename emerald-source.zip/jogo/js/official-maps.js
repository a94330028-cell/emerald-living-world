/* Emerald Living World — visualizador técnico dos arquivos de pret/pokeemerald.
 * Não redistribui os gráficos originais. Tudo é buscado sob demanda no repositório.
 * Não substitui o motor da campanha e não simula scripts de eventos nem colisão 100%.
 */
(() => {
'use strict';
const ROOT='https://raw.githubusercontent.com/pret/pokeemerald/master/';
const get=id=>document.getElementById(id);
const canvas=get('map'); if(!canvas)return;
const ctx=canvas.getContext('2d',{alpha:false});
const FALLBACK=['LittlerootTown','Route101','OldaleTown','Route102','PetalburgCity','Route103','Route104'];
const GYM_NAMES={RustboroCity_Gym:'Ginásio de Rustboro',DewfordTown_Gym:'Ginásio de Dewford',MauvilleCity_Gym:'Ginásio de Mauville',LavaridgeTown_Gym_1F:'Ginásio de Lavaridge — térreo',LavaridgeTown_Gym_B1F:'Ginásio de Lavaridge — subsolo',PetalburgCity_Gym:'Ginásio de Petalburg',FortreeCity_Gym:'Ginásio de Fortree',MossdeepCity_Gym:'Ginásio de Mossdeep',SootopolisCity_Gym_1F:'Ginásio de Sootopolis — térreo',SootopolisCity_Gym_B1F:'Ginásio de Sootopolis — subsolo'};
const labelOf=n=>GYM_NAMES[n]||n.replace(/^Route(\d+)$/,'Rota $1').replaceAll('_',' — ').replace(/([a-z])([A-Z])/g,'$1 $2');
const esc=x=>String(x??'—').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const caches={source:new Map(),tiles:new Map(),pixels:new Map()};
const catalog=new Map();const constToMap=new Map();
let active=null,base=null,pointer=null,path=[],start=null, history=[],loadedToken=0;
// Human-controlled test avatar. Keeps official map data separate from the bot simulation.
const nav=window.EmeraldNavigation;
let walker=null,changingMap=false,manualStep=0;
const Sprites=window.EmeraldTrainerSprites;
const avatars={};for(const kind of ['brendan','may']){const img=Sprites?.image(kind);if(img)img.onload=()=>draw();avatars[kind]=img;}
function navMap(st){return {width:st.layout.width,height:st.layout.height,blocks:st.blocks,
 primaryAttrs:st.primary.attributes,secondaryAttrs:st.secondary.attributes,layout:st.layout,
 // The manual explorer shares the same NPC collision as autonomous walkers.
 solidObjects:new Set((st.data?.object_events||[]).filter(o=>Number.isInteger(Number(o.x))&&Number.isInteger(Number(o.y))).map(o=>Number(o.x)+':'+Number(o.y)))};}
function walkTerrain(st,x,y){return nav?nav.walkable(navMap(st),x,y):walkable(st,x,y)}
function findSafe(st,point,radius=4){
 const pt={x:Math.floor(point?.x??st.layout.width/2),y:Math.floor(point?.y??st.layout.height/2)};
 for(let r=0;r<=radius;r++)for(let dy=-r;dy<=r;dy++)for(let dx=-r;dx<=r;dx++){
  if(Math.abs(dx)+Math.abs(dy)!==r)continue;
  const x=pt.x+dx,y=pt.y+dy;if(walkTerrain(st,x,y))return {x,y};
 }return null;
}
function walkerSpawn(st,arrival){
 if(arrival){const dest=st.data.warp_events?.[arrival.warpId];
  if(!dest){throw Error('A entrada de destino não existe no mapa oficial.');}
  const mapped=constToMap.get(dest.dest_map);
  if(mapped!==arrival.from)throw Error('A porta não aponta de volta para o mapa anterior.');
  const pos=findSafe(st,{x:dest.x,y:dest.y},3);
  if(!pos)throw Error('Entrada sem posição livre próxima.');return pos;
 }
 // Fresh map preview: spawning is a diagnostic action, not walking from a neighboring route.
 const middle=findSafe(st,{x:Math.floor(st.layout.width/2),y:Math.floor(st.layout.height/2)},Math.max(st.layout.width,st.layout.height));
 return middle;
}
function drawWalker(){if(!walker||!active||!get('walkMode').checked)return;
 const kind=get('walkAvatar').value==='may'?'may':'brendan',x=walker.x*16,y=walker.y*16;
 ctx.fillStyle='#153d27ad';ctx.fillRect(x+3,y+12,10,3);
 if(!(Sprites?.draw(ctx,kind,walker.dir,false,0,0,x,y-8,16,24))){ctx.fillStyle='#fbf4aa';ctx.fillRect(x+4,y-4,8,20);}
 ctx.strokeStyle='#f6e282';ctx.lineWidth=1;ctx.strokeRect(x,y,16,16);
}
async function manualMove(direction){
 if(!get('walkMode').checked||!active||!walker||changingMap)return;
 const vectors={up:[0,-1,0],right:[1,0,1],down:[0,1,2],left:[-1,0,3]};
 const vec=vectors[direction];if(!vec)return;walker.dir=vec[2];
 const next={x:walker.x+vec[0],y:walker.y+vec[1]};
 const m=navMap(active);
 if(!nav?.canStep(m,walker,next,'walk')){draw();status('🚧 Passagem bloqueada pela colisão oficial (ou pela regra de água/relevo).');return;}
 const w=(active.data.warp_events||[]).find(p=>p.x===next.x&&p.y===next.y);
 if(w){const destination=constToMap.get(w.dest_map),index=Number(w.dest_warp_id);
  if(!destination||!Number.isInteger(index)||index<0){draw();status('Esta porta exige uma ação/script ainda não interpretado. Transição bloqueada para evitar teleporte inválido.',true);return;}
  changingMap=true;try{await go(destination,{arrival:{warpId:index,from:active.name},remember:true});}
  finally{changingMap=false;}return;
 }
 walker.x=next.x;walker.y=next.y;manualStep++;draw();
 status(`Caminhada manual: ${labelOf(active.name)} · (${walker.x}, ${walker.y}) · passo ${manualStep}.`);
}

function status(str,bad=false){const el=get('state');el.textContent=str;el.classList.toggle('bad',bad)}
function mapConstant(name){return 'MAP_'+name.replace(/([a-z])([A-Z])/g,'$1_$2').replace(/([A-Z])([A-Z][a-z])/g,'$1_$2').toUpperCase()}
function register(name,group){if(!/^[a-zA-Z0-9_]+$/.test(name))return;catalog.set(name,group);constToMap.set(mapConstant(name),name)}
FALLBACK.forEach(n=>register(n,'Início da jornada'));
function setOptions(){
 const selected=get('mapPick').value;
 const term=get('mapSearch').value.trim().toLowerCase();
 const grouped=new Map();
 for(const [name,group] of catalog){if(term&&!`${name} ${labelOf(name)} ${group}`.toLowerCase().includes(term))continue;if(!grouped.has(group))grouped.set(group,[]);grouped.get(group).push(name)}
 const frag=document.createDocumentFragment();
 for(const [group,names] of grouped){const opt=document.createElement('optgroup');opt.label=group;
  for(const name of names){const o=document.createElement('option');o.value=name;o.textContent=labelOf(name);opt.appendChild(o)}frag.appendChild(opt)}
 get('mapPick').replaceChildren(frag);
 if(catalog.has(selected)&&[...get('mapPick').options].some(o=>o.value===selected))get('mapPick').value=selected;
 else if([...get('mapPick').options].length)get('mapPick').selectedIndex=0;
 get('loadBtn').disabled=!get('mapPick').value;
}
async function request(path,type='json'){
 const key=type+'|'+path;
 if(caches.source.has(key))return caches.source.get(key);
 const p=(async()=>{
  const ctr=new AbortController(),t=setTimeout(()=>ctr.abort(),18000);
  let res;
  try{res=await fetch(ROOT+path,{mode:'cors',cache:'force-cache',signal:ctr.signal})}finally{clearTimeout(t)}
  if(!res.ok)throw Error('HTTP '+res.status+': '+path);
  if(type==='json')return res.json();if(type==='text')return res.text();return res.arrayBuffer();
 })();
 caches.source.set(key,p);
 try{return await p}catch(e){caches.source.delete(key);throw e}
}
// PNG indexado (4 ou 8 bits) decodificado exatamente, sem adivinhar indices por RGB.
// PNGs 8-bit greyscale sao aceitos como alternativa; outros tipos exibem erro claro.
async function decodeIndexedPng(buffer){
 const bytes=new Uint8Array(buffer);if(bytes.length<33||[137,80,78,71,13,10,26,10].some((v,i)=>bytes[i]!==v))throw Error('Arquivo PNG inválido');
 const dv=new DataView(buffer);let offset=8,width=0,height=0,depth=0,color=0,interlace=0;const idats=[];
 while(offset+12<=bytes.length){const size=dv.getUint32(offset);const type=String.fromCharCode(...bytes.slice(offset+4,offset+8));const start=offset+8,end=start+size;if(end+4>bytes.length)throw Error('Bloco PNG incompleto');
  if(type==='IHDR'){width=dv.getUint32(start);height=dv.getUint32(start+4);depth=bytes[start+8];color=bytes[start+9];interlace=bytes[start+12]}
  else if(type==='IDAT')idats.push(bytes.subarray(start,end));
  else if(type==='IEND')break;
  offset=end+4;
 }
 if(!width||!height||width*height>10000000||![1,2,4,8].includes(depth)||![0,3].includes(color)||interlace!==0||!idats.length)throw Error('Formato do PNG indexado não suportado');
 if(typeof DecompressionStream==='undefined')throw Error('O navegador não suporta a descompressão de imagens indexadas');
 const compressed=new Uint8Array(idats.reduce((n,b)=>n+b.length,0));let at=0;for(const b of idats){compressed.set(b,at);at+=b.length}
 const stream=new Blob([compressed]).stream().pipeThrough(new DecompressionStream('deflate'));
 const raw=new Uint8Array(await new Response(stream).arrayBuffer());const rowLength=Math.ceil(width*depth/8);
 if(raw.length<(rowLength+1)*height)throw Error('Imagem PNG truncada');
 const unpacked=new Uint8Array(width*height);let prev=new Uint8Array(rowLength),pos=0;
 for(let y=0;y<height;y++){
  const filter=raw[pos++];if(filter>4)throw Error('Filtro PNG desconhecido');
  const row=new Uint8Array(rowLength);
  for(let x=0;x<rowLength;x++){
   const val=raw[pos++],left=x?row[x-1]:0,up=prev[x],upleft=x?prev[x-1]:0;let pred=0;
   if(filter===1)pred=left;else if(filter===2)pred=up;else if(filter===3)pred=Math.floor((left+up)/2);
   else if(filter===4){const p=left+up-upleft,a=Math.abs(p-left),b=Math.abs(p-up),c=Math.abs(p-upleft);pred=a<=b&&a<=c?left:b<=c?up:upleft}
   row[x]=(val+pred)&255;
  }
  const mask=(1<<depth)-1;
  for(let x=0;x<width;x++){const bit=x*depth,byte=row[bit>>>3],shift=8-depth-(bit%8);unpacked[y*width+x]=(byte>>>shift)&mask}
  prev=row;
 }
 return {width,height,index:unpacked};
}
function palette(txt){const lines=txt.trim().split(/\r?\n/);if(lines.shift()!=='JASC-PAL')throw Error('Paleta JASC inválida');lines.shift();const count=+lines.shift();return lines.slice(0,count).map(line=>line.trim().split(/\s+/).slice(0,3).map(Number))}
function slug(s){return s.replace(/^gTileset_/,'').replace(/([a-z])([A-Z])/g,'$1_$2').replace(/([A-Z])([A-Z][a-z])/g,'$1_$2').toLowerCase()}
async function tileset(level,original){const name=slug(original),key=level+':'+name;if(caches.tiles.has(key))return caches.tiles.get(key);
 const p=(async()=>{
  const dir=`data/tilesets/${level}/${name}/`;
  const [png,meta,attrs]=await Promise.all([request(dir+'tiles.png','bin'),request(dir+'metatiles.bin','bin'),request(dir+'metatile_attributes.bin','bin')]);
  const image=await decodeIndexedPng(png);return {level,name,image,metatiles:new DataView(meta),attributes:new DataView(attrs)};
 })();caches.tiles.set(key,p);try{return await p}catch(e){caches.tiles.delete(key);throw e}}
async function loadMap(name){
 const [data,layouts]=await Promise.all([request(`data/maps/${name}/map.json`),request('data/layouts/layouts.json')]);
 const layout=layouts.layouts.find(a=>a?.id===data.layout);if(!layout)throw Error('Layout não encontrado: '+data.layout);
 const [blocks,primary,secondary]=await Promise.all([request(layout.blockdata_filepath,'bin'),tileset('primary',layout.primary_tileset),tileset('secondary',layout.secondary_tileset)]);
 if(blocks.byteLength!==layout.width*layout.height*2)throw Error('Tamanho do mapa não corresponde ao layout oficial');
 const palettes=await Promise.all(Array.from({length:13},(_,i)=>{
  const t=i<6?primary:secondary;
  return request(`data/tilesets/${t.level}/${t.name}/palettes/${String(i).padStart(2,'0')}.pal`,'text').then(palette);
 }));
 return {name,data,layout,blocks:new DataView(blocks),primary,secondary,palettes};
}
function tileImage(st,which,id,palId){const key=`${which.level}:${which.name}:${id}:${palId}`;let img=caches.pixels.get(key);if(img)return img;
 const {index,width,height}=which.image;const cols=width/8,sx=id%cols*8,sy=Math.floor(id/cols)*8;if(!Number.isInteger(cols)||sy+8>height)return null;
 const colors=st.palettes[palId]||st.palettes[0];const c=document.createElement('canvas');c.width=c.height=8;
 const cx=c.getContext('2d');const pixels=cx.createImageData(8,8);
 for(let y=0;y<8;y++)for(let x=0;x<8;x++){const v=index[(sy+y)*width+sx+x]&15;const rgb=colors[v]||[0,0,0],i=(y*8+x)*4;
  pixels.data[i]=rgb[0];pixels.data[i+1]=rgb[1];pixels.data[i+2]=rgb[2];pixels.data[i+3]=v?255:0;
 }
 cx.putImageData(pixels,0,0);caches.pixels.set(key,c);
 if(caches.pixels.size>8500)caches.pixels.delete(caches.pixels.keys().next().value);
 return c;
}
function subTile(st,entry,context,x,y){const id=entry&1023,flipX=!!(entry&1024),flipY=!!(entry&2048),pal=(entry>>>12)&15;
 const secondary=id>=512,t=secondary?st.secondary:st.primary,local=id-(secondary?512:0);const img=tileImage(st,t,local,pal);if(!img)return;
 if(flipX||flipY){context.save();context.translate(x+(flipX?8:0),y+(flipY?8:0));context.scale(flipX?-1:1,flipY?-1:1);context.drawImage(img,0,0);context.restore()}
 else context.drawImage(img,x,y);
}
function block(st,x,y){const raw=st.blocks.getUint16((y*st.layout.width+x)*2,true);const id=raw&1023;
 const t=id>=512?st.secondary:st.primary,local=id>=512?id-512:id;
 const attr=local*2+2<=t.attributes.byteLength?t.attributes.getUint16(local*2,true):0;
 return {id,collision:(raw>>10)&3,elevation:raw>>12,behavior:attr&255,layer:(attr>>12)&15};
}
function walkable(st,x,y){return x>=0&&y>=0&&x<st.layout.width&&y<st.layout.height&&block(st,x,y).collision===0}
function paintBase(st){
 const w=st.layout.width,h=st.layout.height;caches.pixels.clear();
 const out=document.createElement('canvas');out.width=w*16;out.height=h*16;
 const c=out.getContext('2d',{alpha:false});c.imageSmoothingEnabled=false;c.fillStyle='#152d23';c.fillRect(0,0,out.width,out.height);
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){
  const info=block(st,x,y),t=info.id>=512?st.secondary:st.primary,local=info.id>=512?info.id-512:info.id,offset=local*16;
  if(offset+16>t.metatiles.byteLength)continue;
  // Interpretação correta dos 8 subtiles, respeitando a ordem de duas camadas do Emerald.
  for(let layer=0;layer<2;layer++)for(let i=0;i<4;i++){
   const entry=t.metatiles.getUint16(offset+(layer*4+i)*2,true);
   subTile(st,entry,c,x*16+(i&1)*8,y*16+(i>>1)*8);
  }
 }
 return out;
}
function draw(){if(!active||!base)return;
 canvas.width=base.width;canvas.height=base.height;canvas.style.width=base.width*2+'px';ctx.imageSmoothingEnabled=false;ctx.drawImage(base,0,0);
 const st=active,w=st.layout.width,h=st.layout.height;
 if(get('collisions').checked){ctx.fillStyle='rgba(246,61,73,.43)';for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(!walkable(st,x,y))ctx.fillRect(x*16,y*16,16,16)}
 if(get('objects').checked){for(const [arr,color] of [[st.data.object_events||[],'#ffe08c'],[st.data.warp_events||[],'#81efff']])for(const o of arr){if(!Number.isInteger(o.x)||!Number.isInteger(o.y))continue;
  const xx=o.x*16+8,yy=o.y*16+8;ctx.fillStyle='#0d2720';ctx.fillRect(xx-5,yy-5,10,10);ctx.fillStyle=color;ctx.fillRect(xx-3,yy-3,6,6)}}
 if(path.length){ctx.fillStyle='rgba(110,245,149,.55)';for(const p of path)ctx.fillRect(p.x*16+3,p.y*16+3,10,10)}
 if(start){ctx.strokeStyle='#feea80';ctx.lineWidth=2;ctx.strokeRect(start.x*16+1,start.y*16+1,14,14)}
 if(pointer){ctx.strokeStyle='#fef0b0';ctx.lineWidth=2;ctx.strokeRect(pointer.x*16+1,pointer.y*16+1,14,14)}
 drawWalker();
}
function route(st,a,b){if(!walkable(st,a.x,a.y)||!walkable(st,b.x,b.y))return null;
 const w=st.layout.width,h=st.layout.height,n=w*h,seen=new Int32Array(n);seen.fill(-1);
 const q=new Int32Array(n);let head=0,tail=0,startIdx=a.y*w+a.x,endIdx=b.y*w+b.x;seen[startIdx]=startIdx;q[tail++]=startIdx;
 while(head<tail){const cur=q[head++];if(cur===endIdx)break;const x=cur%w,y=(cur-x)/w;
  for(const [dx,dy] of [[0,-1],[0,1],[-1,0],[1,0]]){const xx=x+dx,yy=y+dy;if(!walkable(st,xx,yy))continue;const next=yy*w+xx;
   if(seen[next]!==-1)continue;seen[next]=cur;q[tail++]=next}}
 if(seen[endIdx]===-1)return null;
 const path=[];let curr=endIdx;while(curr!==startIdx){path.push({x:curr%w,y:Math.floor(curr/w)});curr=seen[curr]}path.push(a);path.reverse();return path;
}
function clickableMap(name,label){return name&&catalog.has(name)?`<button type="button" class="mapLink" data-openmap="${esc(name)}">${esc(label||labelOf(name))}</button>`:esc(label||name)}
function info(st){const {data,layout}=st;
 const list=(items,render)=>items?.length?'<ul>'+items.slice(0,75).map(x=>'<li>'+render(x)+'</li>').join('')+'</ul>':'<p>Nenhum registro neste mapa.</p>';
 get('details').innerHTML=`<h2>${esc(labelOf(st.name))} — dados oficiais</h2>
 <div class="metadataGrid"><div class="meta"><small>Dimensão</small><b>${layout.width} × ${layout.height}</b></div><div class="meta"><small>Tileset primário</small><b>${esc(layout.primary_tileset)}</b></div><div class="meta"><small>Tileset secundário</small><b>${esc(layout.secondary_tileset)}</b></div><div class="meta"><small>NPCs</small><b>${(data.object_events||[]).length}</b></div><div class="meta"><small>Portas/Warps</small><b>${(data.warp_events||[]).length}</b></div></div>
 <h3>Conexões entre mapas</h3>${list(data.connections,o=>clickableMap(constToMap.get(o.map),o.map)+' · '+esc(o.direction)+' · offset '+esc(o.offset))}
 <h3>Entradas e interiores</h3>${list(data.warp_events,o=>`(${o.x}, ${o.y}) → ${clickableMap(constToMap.get(o.dest_map),o.dest_map)} · entrada ${esc(o.dest_warp_id)}`)}
 <h3>Personagens no mapa</h3>${list(data.object_events,o=>`(${o.x},${o.y}) — ${esc(o.graphics_id)} · ${esc(o.movement_type)}`)}
 <h3>Arquivos do projeto original</h3><p><a target="_blank" rel="noopener noreferrer" href="https://github.com/pret/pokeemerald/blob/master/data/maps/${encodeURIComponent(st.name)}/map.json">map.json</a> · <a target="_blank" rel="noopener noreferrer" href="https://github.com/pret/pokeemerald/blob/master/${encodeURI(layout.blockdata_filepath)}">map.bin</a> · <a target="_blank" rel="noopener noreferrer" href="https://github.com/pret/pokeemerald/blob/master/data/layouts/layouts.json">layouts.json</a></p>
 <p class="routeCaption">Nota: o mapa usa os blocos oficiais. A rota traçada considera somente os bits de colisão; não garante o caminho permitido para cada ação do jogo.</p>`;
}
async function go(name,{remember=true,arrival=null}={}){
 if(!name||!catalog.has(name))return;
 const token=++loadedToken,btn=get('loadBtn');btn.disabled=true;
 status('Carregando os dados de '+labelOf(name)+' do projeto original...');
 try{
  const st=await loadMap(name);if(token!==loadedToken)return;
  const bmp=paintBase(st);if(token!==loadedToken)return;
  // Validate the new spawn before mutating the current map; a failed warp must not strand anyone.
  const spawn=walkerSpawn(st,arrival);
  if(!spawn)throw Error('O mapa não contém local caminhável para iniciar a exploração.');
  if(remember&&active&&active.name!==name)history.push(active.name);
  active=st;base=bmp;pointer=null;start=null;path=[];walker={...spawn,dir:walker?.dir??2};
  get('mapSearch').value='';setOptions();get('mapPick').value=name;
  get('backBtn').disabled=!history.length;draw();info(st);
  status(`${labelOf(name)} carregado: ${st.layout.width}×${st.layout.height} blocos · ${(st.data.warp_events||[]).length} entradas · dados pret/pokeemerald.`);
 }catch(e){if(token!==loadedToken)return;console.warn('[emerald-maps]',e);status('Falha ao carregar este mapa: '+(e?.message||e)+'. Confira a conexão e tente novamente.',true)}
 finally{if(token===loadedToken)btn.disabled=false}
}
async function openMap(name){if(!catalog.has(name))return;await go(name)}
get('loadBtn').addEventListener('click',()=>go(get('mapPick').value));
get('backBtn').addEventListener('click',()=>{const prev=history.pop();if(prev)go(prev,{remember:false})});
get('mapSearch').addEventListener('input',setOptions);
get('mapPick').addEventListener('change',()=>{get('loadBtn').disabled=false});
get('collisions').addEventListener('change',draw);get('objects').addEventListener('change',draw);
get('clearPath').addEventListener('click',()=>{path=[];start=null;pointer=null;draw();status('Trajeto apagado.')});
get('viewMode').addEventListener('change',()=>{path=[];start=null;pointer=null;draw()});
get('details').addEventListener('click',e=>{const b=e.target.closest('button[data-openmap]');if(b)openMap(b.dataset.openmap)});
get('walkMode').addEventListener('change',e=>{if(e.target.checked){get('viewMode').value='inspect';if(active&&!walker)walker={...walkerSpawn(active,null),dir:2};status('Caminhada experimental ativada. Use as setas ou toque nos botões.')}else status('Caminhada desativada.');draw()});
get('walkAvatar').addEventListener('change',draw);
for(const b of document.querySelectorAll('[data-walk]'))b.addEventListener('click',()=>manualMove(b.dataset.walk));
const KEY_DIR={ArrowUp:'up',ArrowRight:'right',ArrowDown:'down',ArrowLeft:'left',w:'up',a:'left',s:'down',d:'right'};
document.addEventListener('keydown',e=>{if(e.target.closest('input:not([type=checkbox]),select,textarea'))return;const dir=KEY_DIR[e.key];if(dir&&get('walkMode').checked){e.preventDefault();if(!e.repeat)manualMove(dir);}});

canvas.addEventListener('click',e=>{
 if(!active)return;
 const r=canvas.getBoundingClientRect(),x=Math.floor((e.clientX-r.left)*active.layout.width/r.width),y=Math.floor((e.clientY-r.top)*active.layout.height/r.height);
 if(x<0||y<0||x>=active.layout.width||y>=active.layout.height)return;
 const p={x,y},b=block(active,x,y);pointer=p;
 if(get('viewMode').value==='path'){
  if(!start||path.length){start=p;path=[];status(`Início marcado em (${x},${y}). Agora toque no destino.`)}
  else {path=route(active,start,p)||[];status(path.length?`Trajeto ilustrativo: ${path.length-1} passos, considerando somente os bloqueios do layout.`:'Não foi encontrado caminho sem blocos marcados como bloqueados. O jogo ainda pode exigir ações especiais.',!path.length)}
 }else{
  const npcs=(active.data.object_events||[]).filter(o=>o.x===x&&o.y===y).map(o=>o.graphics_id),warps=(active.data.warp_events||[]).filter(o=>o.x===x&&o.y===y).map(o=>o.dest_map);
  status(`(${x},${y}) · bloco ${b.id} · colisão ${b.collision} · elevação ${b.elevation} · comportamento ${b.behavior} · camada ${b.layer}`+(npcs.length?' · NPC '+npcs.join(', '):'')+(warps.length?' · porta '+warps.join(', '):''));
 }draw();
});
async function catalogInit(){setOptions();try{const groups=await request('data/maps/map_groups.json');let total=0;
 for(const group of groups.group_order||[]){const category=group.replace(/^gMapGroup_/,'').replace(/([a-z])([A-Z])/g,'$1 $2');for(const name of groups[group]||[]){register(name,category);total++}}
 setOptions();status(`Catálogo oficial pronto: ${total} mapas encontrados. Escolha um mapa e toque em Carregar.`);
 const requested=new URLSearchParams(location.search).get('map');if(requested&&catalog.has(requested))await go(requested,{remember:false});
 }catch(e){console.warn('Catálogo remoto indisponível',e);status('Catálogo completo não carregou. Os 7 mapas iniciais continuam disponíveis. Confira a conexão e recarregue.',true)}}
catalogInit();
// Exposição mínima para testes em navegador, sem modificar estado do simulador.
window.emeraldMapDiagnostics={decodeIndexedPng,slug,mapConstant,route};
})();
