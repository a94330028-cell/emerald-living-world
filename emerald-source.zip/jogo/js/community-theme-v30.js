/* Theme preference shared by landing, world, cloud and community. No save-state changes. */
(()=>{'use strict';const key='elw_visual_theme_25';
const label=()=>{const dark=document.documentElement.dataset.pokeTheme==='dark';for(const b of document.querySelectorAll('[data-elw-theme-toggle]')){b.textContent=dark?'☀️ Tema claro':'🌙 Tema escuro';b.setAttribute('aria-pressed',String(dark))}document.documentElement.style.colorScheme=dark?'dark':'light';const meta=document.querySelector('meta[name="theme-color"]');if(meta)meta.content=dark?'#0a1119':'#086b54'};
const update=()=>{const next=document.documentElement.dataset.pokeTheme==='dark'?'emerald':'dark';const primary=document.getElementById('themeToggle');if(primary){primary.click()}else{document.documentElement.dataset.pokeTheme=next;try{localStorage.setItem(key,next)}catch{}}label()};
for(const btn of document.querySelectorAll('[data-elw-theme-toggle]'))btn.addEventListener('click',update);
new MutationObserver(label).observe(document.documentElement,{attributes:true,attributeFilter:['data-poke-theme']});label();
})();
