
(()=>{'use strict';
const $=id=>document.getElementById(id);
const canvas=$('liveWorld');let ctx=canvas?.getContext('2d',{alpha:false});
if(!canvas||!ctx||!window.emeraldExport||!window.emeraldTerrain)return;
const terrain=window.emeraldTerrain,official=window.emeraldOfficialWorld,TILE=32,W=640,H=416;
const {nodes,edges,node:findNode}=window.emeraldRegion;
function rank(t){return (t.badges||0)*300+(t.wins||0)*12+(t.stage||0)*18+(t.dex||[]).length*9+(t.champion?2500:0)-(t.losses||0)*3}
function escapeHtml(v){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function seed(str){let h=2166136261;for(let i=0;i<str.length;i++)h=Math.imul(h^str.charCodeAt(i),16777619);return h>>>0}
function hash(x,y,z){let h=Math.imul(x+z,374761393)+Math.imul(y-z,668265263);h=Math.imul(h^(h>>>13),1274126177);return (h^(h>>>16))>>>0}
function fill(x,y,w,h,c){ctx.fillStyle=c;ctx.fillRect(Math.round(x),Math.round(y),Math.ceil(w),Math.ceil(h))}
function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function state(){return window.emeraldExport()}
let focusId=0,lastUiSignature='',lastMapTick=-1,lastFrame=0,lastPanelUpdate=0,frames=0,mapCamera={x:0,y:0,loc:''},avatarHits=[],overview=false;
const smoothing=new Map(),Movement=window.EmeraldMovementFacing;
function focusTrainer(st){if(st.settings?.gameMode==='player')return st.trainers.find(t=>t.isUserBot)||st.trainers[st.selected]||st.trainers[0];const mode=$('liveFocus').value;if(mode==='selected')return st.trainers[st.selected]||st.trainers[0];if(mode==='battle'){const battling=st.trainers.find(t=>t.battle);if(battling)return battling}return st.trainers.reduce((best,t)=>rank(t)>rank(best)?t:best,st.trainers[0])}
function selectTrainer(id){window.emeraldSelectTrainer(id);$('liveFocus').value='selected';$('scenePreview').value='';overview=false;$('sceneZoom').textContent='🗺️ Mapa inteiro';$('sceneZoom').setAttribute('aria-pressed','false');mapCamera.loc='';draw(true)}
function position(t,dt){
 const loc=t.walkMap||t.location;
 const tx=Number.isFinite(t.walkX)?t.walkX:20,ty=Number.isFinite(t.walkY)?t.walkY:14;
 const seq=t.walkStepSeq||0,now=performance.now();
 const wallStarted=Number(t.walkStepStartedAt||0);
 const ageMs=wallStarted>0?Math.max(0,Date.now()-wallStarted):null;
 const initialFacing=Number.isInteger(t.walkFacingDir)?t.walkFacingDir:(Number.isInteger(t.walkDir)?t.walkDir:2);
 let p=smoothing.get(t.id);
 if(!p||p.loc!==loc||Math.abs(tx-p.tx)>3||Math.abs(ty-p.ty)>3){
  p={loc,x:tx,y:ty,fromX:tx,fromY:ty,tx,ty,seq,started:now,duration:205,dir:initialFacing};
  smoothing.set(t.id,p);
 }
 if(p.seq!==seq){
  const px=Number.isInteger(t.walkPrevX)?t.walkPrevX:p.tx;
  const py=Number.isInteger(t.walkPrevY)?t.walkPrevY:p.ty;
  const adjacent=Math.abs(tx-px)+Math.abs(ty-py)===1;
  p.fromX=adjacent?px:tx;p.fromY=adjacent?py:ty;
  p.tx=tx;p.ty=ty;p.seq=seq;
  p.duration=Math.max(140,Math.min(650,Number(t.walkStepMs)||205));
  // Comece a interpolação no mesmo instante do passo físico, não no frame em
  // que a câmera percebeu a atualização do motor.
  p.started=ageMs!==null&&ageMs<p.duration*3?now-ageMs:now;
  // Só virar quando um passo ortogonal realmente ocorreu; não ao parar,
  // recalcular destino, esperar um evento ou atualizar a câmera.
  if(adjacent)p.dir=Movement?.hold(p.dir,{x:px,y:py},{x:tx,y:ty})??(tx>px?1:tx<px?3:ty>py?2:0);
 }
 const progress=Math.max(0,Math.min(1,(now-p.started)/p.duration));
 p.x=p.fromX+(p.tx-p.fromX)*progress;
 p.y=p.fromY+(p.ty-p.fromY)*progress;
 const moving=progress<1&&(Math.abs(p.tx-p.fromX)+Math.abs(p.ty-p.fromY)===1);
 // Nunca retornar t.walkDir no idle: esse campo é suscetível a resets durante
 // teleporte de porta/carregamento. p.dir guarda o último deslocamento real.
 return {...p,moving,progress,dir:p.dir};
}
function teamPanel(st,leader,sorted){
 const rankPosition=sorted.findIndex(t=>t.id===leader.id)+1;
 $('liveSquadName').textContent='🎒 '+leader.name+' · '+official.label(leader.officialMap||leader.location)+(leader.officialMap&&leader.officialMap!==official.resolve(leader.location)?' → '+official.label(leader.location):'');
 $('liveSquadRank').textContent=rankPosition+'º • '+(leader.badges||0)+'/8 insígnias';
 const monsters=leader.team||[];
 const strength=window.emeraldStrength||(()=>0),power=window.emeraldPower||(()=>0);
 const best=window.emeraldBestMon?.(leader);
 $('liveTeamPower').textContent=strength(leader).toLocaleString('pt-BR');
 $('liveBestMon').textContent=best?best.species+' · Nv. '+best.level+' · '+power(best)+' pts':'Aguardando captura';
 const h=window.emeraldHabitat?.(leader);const n=leader.officialMap&&official?.cache.get(leader.officialMap)?.value;
 const block=n&&official.infoAt(n,Math.round(leader.walkX||0),Math.round(leader.walkY||0));
 const tileName=block?`metatile ${block.id} · elevação ${block.elevation}`:'carregando mapa oficial';
 $('liveHabitatInfo').innerHTML=h?`<span class="terrainPill">🌿 Área com encontros: ${escapeHtml(h)}</span> • Terreno: ${escapeHtml(tileName)}`:`<span class="terrainPill">🛡️ Área segura</span> • Terreno: ${escapeHtml(tileName)} · Sem Pokémon selvagens aqui`;

 const insight=window.emeraldTeamAnalysis?.(leader);
 $('liveTeamStrategy').innerHTML=insight?`<strong>🧠 Estratégia · próximo: ${escapeHtml(insight.next)}</strong><div class="roleTags">${insight.roles.map(r=>`<span class="rolePill">${escapeHtml(r)}</span>`).join('')}</div><small>${escapeHtml(insight.reason)}</small>${insight.abilities?.length?`<small>🧬 Habilidades consideradas: ${escapeHtml(insight.abilities.slice(0,5).join(', '))}</small>`: ''}${insight.project?`<small>🌱 Reserva promissora no PC: <b>${escapeHtml(insight.project.species)}</b> Nv. ${insight.project.level} — meta ${insight.project.target}</small>`:''}${insight.loan?`<small>💪 Treinamento ativo de reserva antes do próximo ginásio</small>`:''}`:'<small>Preparando estratégia...</small>';
 $('liveRouteChoices').innerHTML=(insight?.routes?.length?`<b>🧭 Caminhos escolhidos</b><div>${insight.routes.map(x=>`<span class="routeToken">${escapeHtml(x)}</span>`).join('')}</div>`:'🧭 A IA escolherá trajetos opcionais de acordo com sua personalidade.');
 const signature=leader.id+'|'+monsters.map(m=>[m.species,m.hp,m.maxHp,m.level,power(m)].join(':')).join('|');
 if($('liveTeam').dataset.signature===signature)return;
 $('liveTeam').dataset.signature=signature;
 $('liveTeam').innerHTML=Array.from({length:6},(_,i)=>{
 const m=monsters[i];if(!m)return `<div class="livePoke empty"><span style="font-size:22px">＋</span><small>Vaga ${i+1}</small></div>`;
 const name=escapeHtml(m.species),pct=clamp(100*(m.hp||0)/Math.max(1,m.maxHp||1),0,100),color=pct<=25?'#ef7776':pct<=50?'#f4c66e':'#68d6a1';
 const src='assets/pokemon_fit/'+encodeURIComponent(m.species.toLowerCase())+'.png';const backup='assets/pokemon_fit/'+encodeURIComponent(m.species.toLowerCase())+'.gif';const placeholder='assets/ui/pokemon_missing.svg';
 return `<div class="livePoke ${m.hp<=0?'fainted':''}" title="${name} • HP ${m.hp}/${m.maxHp}">${window.EmeraldPokemonArt.tag(m.species)}<b>${m.shiny?'✨ ':''}${name}</b><small>Nv. ${m.level} · ${m.hp}/${m.maxHp} HP</small><span class="powerMark">${window.emeraldMonRole?.(m)==='Muralha'?'🛡️':window.emeraldMonRole?.(m)==='Veloz'?'💨':'⚔️'} ${escapeHtml(window.emeraldMonRole?.(m)||'Em treinamento')} · ⚡ ${power(m)}</span><div class="tinyHp"><span style="width:${pct}%;background:${color}"></span></div></div>`
 }).join('');
}
function leaderboard(st,sorted){
 const power=window.emeraldPower||(()=>0),strength=window.emeraldStrength||(()=>0);
 const topPower=st.trainers.filter(t=>t.team?.length).map(t=>({t,score:strength(t)})).sort((a,b)=>b.score-a.score).slice(0,5).map(x=>x.t);
 $('livePowerRanking').innerHTML=topPower.map((t,i)=>`<div class="liveRow" role="button" tabindex="0" data-power-id="${t.id}"><span class="pos">${i+1}º</span><span class="who">${escapeHtml(t.name)}<span class="where">${t.team.length} Pokémon · ${t.badges} insígnias</span></span><span class="badges">⚡ ${strength(t).toLocaleString('pt-BR')}</span></div>`).join('')||'<small>Aguardando as capturas.</small>';
 $('livePowerRanking').querySelectorAll('[data-power-id]').forEach(e=>{e.onclick=()=>selectTrainer(+e.dataset.powerId);e.onkeydown=ev=>{if(ev.key==='Enter'){e.click()}}});
 const story=window.EmeraldTrainerRankings?.ranks(st.trainers,strength,6)?.story||[];
 $('liveTopPokemon').innerHTML=story.length?story.map((x,i)=>`<div class="liveRow"><span class="pos">${i+1}º</span><span class="who"><b>${escapeHtml(x.t.name||'Treinador')}</b><span class="where">${escapeHtml(x.chapter)}</span></span><span class="badges">${x.t.champion?'👑':`🏅 ${x.badges}/8`}</span></div>`).join(''):'<small>Esperando a jornada começar.</small>';
 // All generations: image resolver uses the National Dex ID if the local asset
 // does not exist, then a visible placeholder when external images are offline.
 $('liveTick').textContent='Rodada '+st.turns.toLocaleString('pt-BR');
 $('liveLeaderboard').innerHTML=sorted.slice(0,10).map((t,i)=>`<div class="liveRow ${t.id===st.selected?'active':''}" role="button" tabindex="0" data-live-id="${t.id}"><span class="pos">${i+1}º</span><span class="who">${escapeHtml(t.name)}<span class="where">${escapeHtml(official.label(t.location))} · ${t.wins||0} vitórias · ${t.team?.length||0} Pokémon</span></span><span class="badges">🏅 ${t.badges}/8</span></div>`).join('');
 $('liveLeaderboard').querySelectorAll('[data-live-id]').forEach(el=>{el.onclick=()=>selectTrainer(+el.dataset.liveId);el.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();el.click()}}});
}
// Catálogo centralizado de sprites: Brendan/May compartilham o mesmo
// esquema de atlas, hitbox e seleção de quadros em todo o projeto.
const TRAINER_SPRITES=window.EmeraldTrainerSprites;
function trainerFrameIndex(total,dir,moving,progress,stepSeq=0){
 return TRAINER_SPRITES?.frameIndex('brendan',dir,moving,progress,stepSeq)
  ?? window.EmeraldTrainerFrames.frameIndex(dir,moving,progress,stepSeq);
}
function drawTrainerHitbox(kind,px,py,w,h){
 return TRAINER_SPRITES?.drawHitbox(ctx,kind,px,py,w,h,'#44ebd9','rgba(68,235,217,.16)');
}
function sprite(x,y,kind,selected,name,dir=2,moving=false,progress=0,scale=2,stepSeq=0){
 const spriteKind=TRAINER_SPRITES?.DEFINITIONS[kind]?kind:'brendan';

 ctx.save();ctx.imageSmoothingEnabled=false;
 // Every sprite is read from an actual 32x48 frame. The tile footprint
 // remains 16x16; drawing scaled down to 16x24 keeps buildings readable.
 const w=16*scale,h=24*scale,px=Math.round(x-w/2),py=Math.round(y-h+8*scale);
 if(!(TRAINER_SPRITES?.draw(ctx,spriteKind,dir,moving,progress,stepSeq,px,py,w,h))){
  ctx.fillStyle='#fcf5f0';ctx.fillRect(px+w*.25,py+h*.20,w*.5,h*.65);
  ctx.fillStyle='#bb5454';ctx.fillRect(px+w*.12,py+h*.12,w*.76,h*.19);
 }
 if(selected){ctx.strokeStyle='#fff09b';ctx.lineWidth=Math.max(1,scale*.6);ctx.strokeRect(px,py,w,h)}
 if($('showOfficialHitboxes')?.checked)drawTrainerHitbox(spriteKind,px,py,w,h);
 ctx.restore();
 if(name&&scale>1.5){ctx.textAlign='center';ctx.font='bold 11px system-ui';const tw=Math.min(135,ctx.measureText(name).width+12);fill(x-tw/2,y-h+4*scale-18,tw,15,'#0b3036e0');ctx.fillStyle='#fff';ctx.fillText(name,x,y-h+4*scale-7)}
}
window.emeraldTrainerFrameIndex=trainerFrameIndex;
window.emeraldSpriteDirections={0:'cima',1:'direita',2:'baixo',3:'esquerda'};
function renderSentries(map,xoff,yoff,scale,now,leader){const sentries=official.trainerSentries?.(map)||[];for(const s of sentries.slice(0,18)){const dir=official.sentryFacing?.(s,now)??s.dir??2;const defeated=!!leader?.defeatedOfficialTrainers?.[s.key];const vec=[[0,-1],[1,0],[0,1],[-1,0]][dir]||[0,1];ctx.save();ctx.fillStyle=defeated?'rgba(142,203,176,.035)':'rgba(255,232,152,.16)';for(let step=1;step<=s.sight;step++){const tx=s.x+vec[0]*step,ty=s.y+vec[1]*step;if(!official.walkable(map,tx,ty))break;ctx.fillRect(xoff+(tx*16-officialCamera.x)*scale,yoff+(ty*16-officialCamera.y)*scale,16*scale,16*scale);}ctx.restore();const x=xoff+(s.x*16+8-officialCamera.x)*scale,y=yoff+(s.y*16+8-officialCamera.y)*scale;if(x<-30||x>W+30||y<-35||y>H+35)continue;sprite(x,y,TRAINER_SPRITES.IDS[s.id%TRAINER_SPRITES.IDS.length],false,'',dir,false,0,scale/1.1,s.id);ctx.save();ctx.fillStyle='#ffe898';ctx.font='bold 10px system-ui';ctx.textAlign='center';ctx.fillText(defeated?'✓':'!',x,y-30*(scale/2));ctx.restore();}}
// Exterior costurado por connections oficiais. O mapa interior continua no
// renderizador antigo, com suas portas/warps intactos. Nunca gerar atalhos.
const Continuous=window.EmeraldContinuousHoenn;
const EdgeScenery=window.EmeraldEdgeScenery;
const continuousWorld=Continuous?.createWorld(official,{maxConcurrent:2});
const outdoorMotion=new Map();
let outdoorCameraComponent=0,outdoorCameraTrainer=null;
function worldAvatar(t,dt){
 const rect=continuousWorld.position(t.officialMap);
 if(!rect)return null;
 const p=position(t,dt),loc=official.resolve(t.officialMap);
 const raw={x:rect.x+p.x,y:rect.y+p.y};
 const prev=outdoorMotion.get(t.id);
 let next={loc,x:raw.x,y:raw.y};
 if(prev&&prev.loc!==loc&&Math.abs(raw.x-prev.x)+Math.abs(raw.y-prev.y)<=3){
  next={...next,fromX:prev.x,fromY:prev.y,started:performance.now(),duration:Math.max(140,Math.min(330,Number(t.walkStepMs)||205))};
 }else if(prev&&prev.loc===loc&&prev.started&&performance.now()-prev.started<prev.duration){
  next={...next,fromX:prev.fromX,fromY:prev.fromY,started:prev.started,duration:prev.duration};
 }
 outdoorMotion.set(t.id,next);
 if(next.started){
  const a=clamp((performance.now()-next.started)/next.duration,0,1);
  return {x:next.fromX+(raw.x-next.fromX)*a,y:next.fromY+(raw.y-next.fromY)*a,move:p};
 }
 return {...raw,move:p};
}
function renderContinuous(st,leader,now,dt,whole,name,map){
 const active=continuousWorld.seed(name);
 if(!active)return false;
 const current=position(leader,dt),focusX=active.x+current.x,focusY=active.y+current.y;
 continuousWorld.prefetchNear(name,current.x,current.y,34);
 ctx.imageSmoothingEnabled=false;fill(0,0,W,H,'#102c32');avatarHits=[];
 const placed=continuousWorld.allPositions().filter(p=>p.component===active.component);
 if(whole){
  // Vista topológica: não tenta decodificar centenas de setores para desenhar
  // toda Hoenn em 640×416 pixels. É um panorama leve das áreas descobertas.
  const x0=Math.min(...placed.map(p=>p.x)),y0=Math.min(...placed.map(p=>p.y));
  const x1=Math.max(...placed.map(p=>p.x+p.width)),y1=Math.max(...placed.map(p=>p.y+p.height));
  const scale=Math.min((W-24)/(x1-x0||1),(H-38)/(y1-y0||1),2);
  const ox=(W-(x1-x0)*scale)/2,oy=(H-(y1-y0)*scale)/2;
  for(const r of placed){
   const x=ox+(r.x-x0)*scale,y=oy+(r.y-y0)*scale,w=Math.max(1,r.width*scale),h=Math.max(1,r.height*scale);
   ctx.fillStyle=r.name===name?'#467c73':'#284f54';ctx.fillRect(x,y,w,h);
   ctx.strokeStyle='rgba(160,228,194,.48)';ctx.lineWidth=.8;ctx.strokeRect(x,y,w,h);
   if(w>=48&&h>=13){ctx.font='10px system-ui';ctx.fillStyle='#e7fff2';ctx.textAlign='center';ctx.fillText(official.label(r.name),x+w/2,y+h/2,Math.max(30,w-4));}
  }
  const mx=ox+(focusX-x0+.5)*scale,my=oy+(focusY-y0+.5)*scale;
  ctx.fillStyle='#ffef9a';ctx.beginPath();ctx.arc(mx,my,4,0,2*Math.PI);ctx.fill();
  $('liveLocation').textContent='🌍 Hoenn · setores externos conectados';
  $('liveStatus').textContent='🗺️ Panorama sem carregar gráficos distantes';
  $('liveCaption').textContent=`${placed.length} mapas externos posicionados pelas conexões oficiais; interiores independentes`;
  $('sceneType').textContent='Mundo conectado · prévia de setores';
  $('liveSteps').textContent=`🧭 ${leader.name}: ${official.label(name)} · (${tCoord(current.x)}, ${tCoord(current.y)})`;
  return true;
 }
 const sw=W/2,sh=H/2,targetX=(focusX*16+8)-sw/2,targetY=(focusY*16+8)-sh/2;
 const far=!Number.isFinite(officialCamera.x)||Math.abs(targetX-officialCamera.x)>600||Math.abs(targetY-officialCamera.y)>600;
 if(outdoorCameraComponent!==active.component||outdoorCameraTrainer!==leader.id||far){
  officialCamera.x=targetX;officialCamera.y=targetY;
  outdoorCameraComponent=active.component;outdoorCameraTrainer=leader.id;
 }else{
  const a=1-Math.exp(-dt/155);
  officialCamera.x+=(targetX-officialCamera.x)*a;
  officialCamera.y+=(targetY-officialCamera.y)*a;
 }
 officialCamera.name='HoennContinuous:'+active.component;
 const camera={x:officialCamera.x,y:officialCamera.y,width:sw,height:sh};
 // Preenche apenas o vazio VISUAL atrás dos mapas: bosque/ondas/rochas.
 // Os chunks oficiais, desenhados a seguir, têm prioridade e cobrem o cenário.
 // Nenhuma árvore decorativa passa a fazer parte das colisões ou navegação.
 EdgeScenery?.draw(ctx,camera,placed,{width:W,height:H,scale:2,official});
 const locals=continuousWorld.visible(camera,260);
 const sectors=[];
 // Chunks por demanda, limitados ao campo de visão e seus vizinhos.
 for(const r of locals)for(const tile of continuousWorld.chunks(r,camera,256)){
  const chunk=official.ensureChunk(tile.name,tile.cx,tile.cy);
  sectors.push({...tile,chunk});
 }
 for(const tile of sectors){
  const x=(tile.x-camera.x)*2,y=(tile.y-camera.y)*2;
  if(tile.chunk.value){const b=tile.chunk.value.base;ctx.drawImage(b,Math.round(x),Math.round(y),b.width*2,b.height*2);}
  else{fill(x,y,Math.min(512,W),Math.min(512,H),EdgeScenery?.biomeForName(tile.name)==='sea'?'#2878a4':EdgeScenery?.biomeForName(tile.name)==='rocky'?'#777461':'#397e59');}
 }
 if($('showOfficialCollision')?.checked){
  const mode=official.travelMode?.(leader,map)||'walk';
  for(const r of locals){
   const nav=continuousWorld.loaded(r.name);if(!nav)continue;
   const minX=Math.max(0,Math.floor((camera.x-r.x*16)/16));
   const maxX=Math.min(nav.width,Math.ceil((camera.x+sw-r.x*16)/16));
   const minY=Math.max(0,Math.floor((camera.y-r.y*16)/16));
   const maxY=Math.min(nav.height,Math.ceil((camera.y+sh-r.y*16)/16));
   for(let ty=minY;ty<maxY;ty++)for(let tx=minX;tx<maxX;tx++){
    const info=official.infoAt(nav,tx,ty);
    if(!official.walkable(nav,tx,ty,mode)){
     ctx.fillStyle=info?.behavior>=0x38&&info.behavior<=0x3f?'rgba(255,191,48,.36)':'rgba(236,62,70,.35)';
     ctx.fillRect(Math.round(((r.x+tx)*16-camera.x)*2),Math.round(((r.y+ty)*16-camera.y)*2),32,32);
    }
   }
  }
 }
 if($('showOfficialPaths')?.checked&&leader.walkPath?.length){
  ctx.save();ctx.beginPath();ctx.lineWidth=2;ctx.strokeStyle='#ffe898';ctx.setLineDash([4,5]);
  ctx.moveTo((focusX*16+8-camera.x)*2,(focusY*16+8-camera.y)*2);
  for(const p of leader.walkPath.slice(0,60))ctx.lineTo(((active.x+p.x)*16+8-camera.x)*2,((active.y+p.y)*16+8-camera.y)*2);
  ctx.stroke();ctx.restore();
 }
 // A simulação das 100 IAs nunca depende deste filtro: só a renderização.
 // Sentinelas oficiais continuam presentes (sight/flags nao sao refeitos).
 const storedCamX=officialCamera.x,storedCamY=officialCamera.y;
 officialCamera.x=0;officialCamera.y=0;
 for(const r of locals){
  const nav=continuousWorld.loaded(r.name);
  if(nav)renderSentries(nav,(r.x*16-storedCamX)*2,(r.y*16-storedCamY)*2,2,now,leader);
 }
 officialCamera.x=storedCamX;officialCamera.y=storedCamY;
 const onScreen=[];let present=0;
 for(const t of st.trainers){
  if(st.settings?.gameMode==='player'&&!t.isUserBot)continue;
  const origin=continuousWorld.position(t.officialMap);
  if(!origin||origin.component!==active.component)continue;
  if(t.officialMap===name)present++;
  const x=(origin.x+(Number(t.walkX)||0))*16-camera.x;
  const y=(origin.y+(Number(t.walkY)||0))*16-camera.y;
  if(x< -35||x>sw+35||y< -35||y>sh+35)continue;
  onScreen.push({t,d:Math.abs(x-sw/2)+Math.abs(y-sh/2)});
 }
 onScreen.sort((a,b)=>(a.t.id===leader.id?-999999:a.d)-(b.t.id===leader.id?-999999:b.d));
 for(const {t} of onScreen.slice(0,24)){
  const pos=worldAvatar(t,dt);if(!pos)continue;
  const x=((pos.x*16+8)-camera.x)*2,y=((pos.y*16+8)-camera.y)*2;
  if(x<-40||x>W+40||y<-40||y>H+40)continue;
  sprite(x,y,t.avatar&&TRAINER_SPRITES.DEFINITIONS[t.avatar]?t.avatar:TRAINER_SPRITES.IDS[(Number(t.id)||0)%TRAINER_SPRITES.IDS.length],
   t.id===leader.id,t.id===leader.id?t.name:'',pos.move.dir,pos.move.moving&&!t.battle,pos.move.progress,2,pos.move.seq);
  avatarHits.push({id:t.id,x,y});
 }
 for(const tile of sectors){
  if(!tile.chunk.value?.foreground)continue;
  const f=tile.chunk.value.foreground,x=(tile.x-camera.x)*2,y=(tile.y-camera.y)*2;
  ctx.drawImage(f,Math.round(x),Math.round(y),f.width*2,f.height*2);
 }
 fill(8,H-27,Math.min(490,W-16),23,'#0b3039e9');ctx.textAlign='left';ctx.font='bold 12px system-ui';ctx.fillStyle='#e9fff4';
 ctx.fillText(`${official.label(name)} · ${present} IAs locais · ${locals.length} áreas visíveis · ${sectors.length} setores`,15,H-12);
 if(!renderContinuous.lastStatusAt||performance.now()-renderContinuous.lastStatusAt>450){
  renderContinuous.lastStatusAt=performance.now();
  const stats=official.chunkStats?.();
  $('liveLocation').textContent='📍 '+official.label(name);
  $('liveStatus').textContent=leader.battle?'⚔️ Em batalha':leader.officialError?'⚠️ Verificando passagem':'🌿 Mundo externo contínuo';
  $('sceneType').textContent='🌍 Hoenn conectado · chunks oficiais 16×16';
  $('liveCaption').textContent=`${leader.name} · ${leader.badges}/8 insígnias · ${present} IAs em ${official.label(name)} · ${onScreen.length} próximas da câmera`;
  $('liveObjective').textContent=`🎯 ${leader.walkObjective||'Explorando'} · etapa ${leader.stage+1}`;
  $('liveSteps').textContent=`🧭 ${leader.walkCount||0} passos · (${tCoord(current.x)}, ${tCoord(current.y)}) · ${stats?.cached||0} setores em cache · ${stats?.queued||0} pendentes`;
 }
 return true;
}
function tCoord(value){return Number.isFinite(value)?Math.round(value):0}

// Camada principal: as IAs e a câmera usam EXCLUSIVAMENTE os blocos e
// a imagem oficial 16×16 do mesmo mapa, e nunca o cenário gerado sinteticamente.
const officialCamera={name:'',x:0,y:0};
function renderOfficial(st,leader,now,dt,whole){
 const preview=$('scenePreview')?.value||'';
 const source=preview||leader.officialMap||leader.location;
 const name=official.resolve(source);
 // Tela contínua para locais externos com conexões oficiais. Os interiores,
 // seleções manuais e mapas adaptados seguem pelo renderizador compatível.
 if(!preview&&Continuous?.isOutdoorName(name)){
  official.prefetch(name);
  const outdoors=official.cache.get(name)?.value;
  if(outdoors&&!outdoors.fallback&&Continuous.isOutdoorMap(outdoors)&&renderContinuous(st,leader,now,dt,whole,name,outdoors))return;
  if(!outdoors){
   fill(0,0,W,H,'#102c32');ctx.fillStyle='#eafff1';ctx.textAlign='center';ctx.font='bold 17px system-ui';
   ctx.fillText('🌿 Localizando setor oficial de Hoenn',W/2,H/2);
   $('liveLocation').textContent='🗺️ '+official.label(name);
   $('liveStatus').textContent='⏳ Preparando região';
   $('liveCaption').textContent='Carregando somente os dados da área atual';
   $('sceneType').textContent='Mundo externo contínuo · setores sob demanda';
   return;
  }
 }
 const state=official.ensureArt(name);
 const map=official.cache.get(name)?.value;
 const img=state.value;
 const layers=official.artLayers(name);
 const ground=layers?.base||img;
 const top=layers?.foreground||null;
 fill(0,0,W,H,'#102c32');avatarHits=[];
 if(!img||!map){
  const error=state.error||official.cache.get(name)?.error;
  ctx.fillStyle='#eafff1';ctx.textAlign='center';ctx.font='bold 18px system-ui';
  ctx.fillText(error?'⚠️ Mapa oficial indisponível':'🗺️ Preparando terreno oficial de Hoenn',W/2,H/2-12);
  ctx.font='13px system-ui';ctx.fillStyle='#a9dfd1';
  ctx.fillText(name,W/2,H/2+20);
  ctx.fillText(error?'Verifique a internet e abra o visualizador de mapas.':'Carregando imagens, layout e colisões do projeto original...',W/2,H/2+45);
  $('liveLocation').textContent='🗺️ '+official.label(name);
  $('liveStatus').textContent=error?'⚠️ Arquivo indisponível':'⏳ Carregando dados oficiais';
  $('liveCaption').textContent=error?String(error.message||error):'O bot aguarda os dados reais de colisão antes de andar.';
  $('sceneType').textContent='Mapa de Hoenn · pret/pokeemerald';
  $('liveSteps').textContent=error?'Não foi possível carregar este mapa; não serão inventados caminhos.':`${leader.name} · ${leader.walkObjective||'Aguardando as colisões'}`;
  return;
 }
 ctx.imageSmoothingEnabled=false;
 // Ativos locais carregados uma vez, sem depender do GitHub em cada mapa.
 const allPresent=st.trainers.filter(t=>t.officialMap===name&&(st.settings?.gameMode!=='player'||t.isUserBot));
 const indoors=map.meta.map_type==='MAP_TYPE_INDOOR';
 // O motor continua processando todas as IAs; a câmera mostra até 7 numa sala
 // pequena ou 16 ao ar livre para preservar a leitura do mapa no celular.
 const crowdCap=indoors?7:16;
 const leaderPresent=allPresent.some(t=>t.id===leader.id);
 const visibleFirst=leaderPresent?[leader,...allPresent.filter(t=>t.id!==leader.id)]:allPresent;
 const trainers=visibleFirst.slice(0,crowdCap);
 const extraHidden=allPresent.length-trainers.length;
 const current=preview?{x:map.width/2,y:map.height/2}:position(leader,dt);
 if(whole){
  const scale=Math.min(W/img.width,H/img.height,2);
  const ox=(W-img.width*scale)/2,oy=(H-img.height*scale)/2;
  ctx.drawImage(ground,ox,oy,img.width*scale,img.height*scale);
  for(const t of trainers){const pt=position(t,dt);const x=ox+(pt.x*16+8)*scale,y=oy+(pt.y*16+8)*scale;
   if(x<0||x>W||y<0||y>H)continue;
   sprite(x,y,t.avatar&&TRAINER_SPRITES.DEFINITIONS[t.avatar]?t.avatar:TRAINER_SPRITES.IDS[(Number(t.id)||0)%TRAINER_SPRITES.IDS.length],t.id===leader.id,t.id===leader.id?t.name:'',pt.dir,pt.moving,pt.progress,scale,pt.seq);
   avatarHits.push({id:t.id,x,y});
  }
  if(top)ctx.drawImage(top,ox,oy,img.width*scale,img.height*scale);
 }else{
  const sw=Math.min(img.width,W/2),sh=Math.min(img.height,H/2);
  const cx=preview?img.width/2:current.x*16+8,cy=preview?img.height/2:current.y*16+8;
  if(officialCamera.name!==name){officialCamera.name=name;officialCamera.x=Math.max(0,Math.min(img.width-sw,cx-sw/2));officialCamera.y=Math.max(0,Math.min(img.height-sh,cy-sh/2))}
  const targetX=Math.max(0,Math.min(img.width-sw,cx-sw/2)),targetY=Math.max(0,Math.min(img.height-sh,cy-sh/2));
  const smooth=preview?1:1-Math.exp(-dt/180);
  officialCamera.x+=(targetX-officialCamera.x)*smooth;
  officialCamera.y+=(targetY-officialCamera.y)*smooth;
  const xoff=(W-sw*2)/2,yoff=(H-sh*2)/2;
  ctx.drawImage(ground,officialCamera.x,officialCamera.y,sw,sh,xoff,yoff,sw*2,sh*2);
  if($('showOfficialCollision')?.checked){
   const beginX=Math.max(0,Math.floor(officialCamera.x/16)),endX=Math.min(map.width,Math.ceil((officialCamera.x+sw)/16));
   const beginY=Math.max(0,Math.floor(officialCamera.y/16)),endY=Math.min(map.height,Math.ceil((officialCamera.y+sh)/16));
   for(let y=beginY;y<endY;y++)for(let x=beginX;x<endX;x++){
    const cell=official.infoAt(map,x,y);
    const ledge=cell&&cell.behavior>=0x38&&cell.behavior<=0x3f;
    if(ledge||!official.walkable(map,x,y,official.travelMode?.(leader,map)||'walk')){
     ctx.fillStyle=ledge?'rgba(255,191,48,.42)':'rgba(236,62,70,.40)';
     ctx.fillRect(xoff+(x*16-officialCamera.x)*2,yoff+(y*16-officialCamera.y)*2,32,32);
    }
   }
   ctx.fillStyle='rgba(68,235,217,.85)';
   for(const warp of map.meta.warp_events||[]){const x=xoff+(Number(warp.x)*16+8-officialCamera.x)*2,y=yoff+(Number(warp.y)*16+8-officialCamera.y)*2;
    if(x>0&&x<W&&y>0&&y<H)ctx.fillRect(x-5,y-5,10,10);
   }
  }
  // Caminho calculado em blocos reais do map.bin (sem cruzar colisão).
  if($('showOfficialPaths')?.checked&&!preview&&leader.walkPath?.length){
   const points=leader.walkPath.slice(0,60);ctx.save();ctx.strokeStyle='#ffe898';ctx.lineWidth=2;ctx.setLineDash([4,5]);ctx.beginPath();
   ctx.moveTo(xoff+(current.x*16+8-officialCamera.x)*2,yoff+(current.y*16+8-officialCamera.y)*2);
   for(const p of points)ctx.lineTo(xoff+(p.x*16+8-officialCamera.x)*2,yoff+(p.y*16+8-officialCamera.y)*2);
   ctx.stroke();ctx.restore();
  }
  renderSentries(map,xoff,yoff,2,now,leader);
  for(const t of trainers){const pt=position(t,dt),x=xoff+(pt.x*16+8-officialCamera.x)*2,y=yoff+(pt.y*16+8-officialCamera.y)*2;
   if(x<-30||x>W+30||y<-35||y>H+35)continue;
   sprite(x,y,t.avatar&&TRAINER_SPRITES.DEFINITIONS[t.avatar]?t.avatar:TRAINER_SPRITES.IDS[(Number(t.id)||0)%TRAINER_SPRITES.IDS.length],t.id===leader.id,t.id===leader.id?t.name:'',pt.dir,pt.moving&&!t.battle,pt.progress,2,pt.seq);
   avatarHits.push({id:t.id,x,y});
  }
  if(top)ctx.drawImage(top,officialCamera.x,officialCamera.y,sw,sh,xoff,yoff,sw*2,sh*2);
 }
 // O jogador acompanha a campanha sem controlar a movimentação pelo teclado.
 // Seu marcador no mapa corresponde à etapa atual, sem inventar passos.
 const human=window.emeraldHuman?.getLocation?.();
 if(human?.map===name){
  const pos=official.nearest(map,{x:Math.floor(map.width/2),y:Math.floor(map.height/2)});
  if(pos){let x,y;
   if(whole){const scale=Math.min(W/img.width,H/img.height,2);x=(W-img.width*scale)/2+(pos.x*16+8)*scale;y=(H-img.height*scale)/2+(pos.y*16+8)*scale;}
   else{x=(W-Math.min(img.width,W/2)*2)/2+(pos.x*16+8-officialCamera.x)*2;y=(H-Math.min(img.height,H/2)*2)/2+(pos.y*16+8-officialCamera.y)*2;}
   if(x>=0&&x<=W&&y>=0&&y<=H){ctx.save();ctx.fillStyle='#ffe18f';ctx.strokeStyle='#123c3a';ctx.lineWidth=2;ctx.beginPath();ctx.arc(x,y-16,7,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.fillStyle='#173d37';ctx.font='bold 11px system-ui';ctx.textAlign='center';ctx.fillText('VOCÊ',x,y-28);ctx.restore();}
  }
 }
 fill(8,H-27,Math.min(470,W-16),23,'#0b3039e9');ctx.textAlign='left';ctx.font='bold 12px system-ui';ctx.fillStyle='#e9fff4';
 ctx.fillText(`${name} · ${allPresent.length} IAs · ${map.width}×${map.height} blocos ${map.fallback?'adaptados':'oficiais'}`,15,H-12);
 if(!renderOfficial.lastStatsAt||performance.now()-renderOfficial.lastStatsAt>400){renderOfficial.lastStatsAt=performance.now();
 $('liveLocation').textContent='📍 '+official.label(name);
 $('liveStatus').textContent=preview?((map.fallback||map.artFallback)?'🛠️ Prévia adaptada':'🗺️ Prévia oficial'):leader.battle?'⚔️ Em batalha':leader.officialError?'⚠️ Procurando passagem':leader.storyArrived?'📜 Evento da missão':'🚶 Movimentação com colisões';
 $('sceneType').textContent=(map.fallback||map.artFallback)?'🛠️ Mapa adaptado (sem arquivos gráficos oficiais)':`pret/pokeemerald · ${({'MAP_TYPE_INDOOR':'Interior','MAP_TYPE_ROUTE':'Rota','MAP_TYPE_TOWN':'Cidade ou vila','MAP_TYPE_UNDERWATER':'Fundo do mar','MAP_TYPE_UNDERGROUND':'Caverna'})[map.meta.map_type]||'Mapa oficial'}`;
 $('liveCaption').textContent=`${leader.name} · ${leader.badges}/8 insígnias · ${allPresent.length} IAs presentes${extraHidden?' ('+extraHidden+' sem desenhar no interior)':''} · ${map.width}×${map.height} blocos`;
 $('liveObjective').textContent=preview?'🔍 Visualização do mapa oficial':`🎯 ${leader.walkObjective||'Explorando'} · etapa ${leader.stage+1}`;
 $('liveSteps').textContent=preview?`🗺️ Mapa de ${name} · dados originais de colisão e warps`:
 `🚶 ${leader.walkCount||0} passos oficiais · (${leader.walkX}, ${leader.walkY}) · ${leader.officialPending?'Entrando no interior…':leader.officialError||'Rota livre'}`;
 }
}
function renderOverview(st,leader,now,dt){renderOfficial(st,leader,now,dt,true)}
function renderLocal(st,leader,now,dt){renderOfficial(st,leader,now,dt,false)}
function renderRegion(st,leader,now){
 fill(0,0,640,416,'#123d56');
 for(let i=0;i<80;i++){let x=hash(i,0,77)%640,y=hash(i,1,77)%416;fill(x,y,26,2,'#265b6a')}
 ctx.beginPath();ctx.moveTo(40,74);ctx.lineTo(425,35);ctx.lineTo(480,120);ctx.lineTo(382,258);ctx.lineTo(248,306);ctx.lineTo(160,362);ctx.lineTo(38,342);ctx.closePath();ctx.fillStyle='#3b7f55';ctx.fill();ctx.strokeStyle='#81ad76';ctx.lineWidth=4;ctx.stroke();
 const xy=n=>[n[1]*.64,n[2]*.7+18];ctx.lineWidth=2;ctx.strokeStyle='#c5bb90';for(const [from,to] of edges){const a=xy(nodes[from]),b=xy(nodes[to]);ctx.beginPath();ctx.moveTo(...a);ctx.lineTo(...b);ctx.stroke()}
 for(const n of nodes){const [x,y]=xy(n);fill(x-4,y-4,8,8,'#f6d7a1');ctx.fillStyle='#ecfff4';ctx.font='10px system-ui';ctx.textAlign='center';ctx.fillText(n[0].replace(' City','').replace(' Town',''),x,y-10)}
 avatarHits=[];for(const t of st.trainers.filter(t=>st.settings?.gameMode!=='player'||t.isUserBot)){const n=findNode(t.location),[x,y]=xy(n),dx=(hash(t.id,4,8)%23)-11,dy=(hash(t.id,5,8)%19)-9;ctx.beginPath();avatarHits.push({id:t.id,x:x+dx,y:y+dy});ctx.arc(x+dx,y+dy,t.id===leader.id?6:3,0,Math.PI*2);ctx.fillStyle=t.id===leader.id?'#ffe47d':t.battle?'#ff826e':'#65f0ac';ctx.fill()}
 $('liveLocation').textContent='🗺️ Hoenn • '+st.trainers.length+' IAs';$('liveStatus').textContent='🏆 '+leader.name;$('liveCaption').textContent='Pontos mostram a localização regional; altere para Local para ver os passos.';
 $('liveSteps').textContent=`🗺️ ${leader.name} · ${leader.location} · ${leader.walkCount||0} passos na jornada`;
}
let markerSignature='';
function updateMapMarkers(st){const svg=document.querySelector('#hoennMapCanvas svg');if(!svg)return;const signature=st.selected+'|'+st.trainers.map(t=>t.id+':'+findNode(t.location)[0]+':'+t.badges).join(',');if(signature===markerSignature)return;markerSignature=signature;svg.querySelector('#liveWorldMarkers')?.remove();const ns='http://www.w3.org/2000/svg',g=document.createElementNS(ns,'g');g.id='liveWorldMarkers';const selected=st.trainers[st.selected];if(!selected)return;const counts=new Map();for(const t of st.trainers.filter(t=>st.settings?.gameMode!=='player'||t.isUserBot)){const n=findNode(t.location);counts.set(n[0],(counts.get(n[0])||0)+1)}
 nodes.forEach(n=>{const num=counts.get(n[0])||0;if(!num)return;const marker=document.createElementNS(ns,'g');marker.setAttribute('class','worldMarker');marker.setAttribute('tabindex','0');marker.setAttribute('role','button');marker.setAttribute('aria-label',n[0]+': '+num+' treinadores');marker.setAttribute('transform',`translate(${n[1]+19} ${n[2]+17})`);const c=document.createElementNS(ns,'circle');c.setAttribute('r','12');c.setAttribute('fill',findNode(selected.location)[0]===n[0]?'#ffe27a':'#73e7a5');const txt=document.createElementNS(ns,'text');txt.setAttribute('text-anchor','middle');txt.setAttribute('y','4');txt.textContent=num;marker.append(c,txt);marker.onclick=()=>{const near=st.trainers.filter(t=>(st.settings?.gameMode!=='player'||t.isUserBot)&&findNode(t.location)[0]===n[0]);$('liveMapRoster').innerHTML=near.map(t=>`<button data-choose-id="${t.id}">${escapeHtml(t.name)} • ${t.badges}/8</button>`).join('');$('liveMapRoster').querySelectorAll('button').forEach(b=>b.onclick=()=>{selectTrainer(+b.dataset.chooseId);document.querySelector('.bottomNav [data-page="jogo"]')?.click()})};marker.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();marker.onclick()}};g.append(marker)});svg.append(g)
}
function draw(force=false,now=performance.now(),dt=35){
 const st=state();if(!st.trainers?.length)return;const leader=focusTrainer(st);if(!leader)return;
 focusId=leader.id;
 if($('liveView').value==='region')renderRegion(st,leader,now);else if(overview)renderOverview(st,leader,now,dt);else renderLocal(st,leader,now,dt);
 now=performance.now();
 const signature=st.turns+'|'+st.selected+'|'+leader.id+'|'+$('liveView').value+'|'+$('scenePreview').value;
 if(force||signature!==lastUiSignature&&(leader.id!==draw.lastLeader||now-lastPanelUpdate>=(st.trainers.length>=50?1800:1000))){const sorted=[...st.trainers].sort((a,b)=>rank(b)-rank(a));leaderboard(st,sorted);teamPanel(st,leader,sorted);lastUiSignature=signature;lastPanelUpdate=now;draw.lastLeader=leader.id}
 if(force||st.turns-lastMapTick>=5||st.turns<lastMapTick){updateMapMarkers(st);lastMapTick=st.turns}
}
$('liveFullRanking').onclick=()=>window.emeraldShowPage?.('ranking');
$('oneTeamViewer')?.addEventListener('click',()=>document.querySelector('.bottomNav [data-page="pokedex"]')?.click());
$('liveFollow').onclick=()=>{selectTrainer(focusId);$('liveWorld')?.scrollIntoView({behavior:'smooth',block:'nearest'})};
$('replanSelectedBot').onclick=()=>{const t=state().trainers.find(x=>x.id===focusId);if(t&&official.replan?.(t)){$('liveSteps').textContent='🧭 '+t.name+': rota recalculada na posição atual';draw(true)}};
const sceneSelect=$('scenePreview');for(const name of terrain.locations){const opt=document.createElement('option');opt.value=name;opt.textContent=official.label(name);sceneSelect.append(opt)}
sceneSelect.onchange=()=>{$('liveView').value='local';if(sceneSelect.value){overview=true;$('sceneZoom').textContent='🔍 Aproximar';$('sceneZoom').setAttribute('aria-pressed','true')}mapCamera.loc='';draw(true)};
$('sceneNext').onclick=()=>{const locs=terrain.locations,idx=locs.indexOf(sceneSelect.value);sceneSelect.value=locs[(idx+1)%locs.length];sceneSelect.onchange()};
$('sceneZoom').onclick=()=>{overview=!overview;$('sceneZoom').textContent=overview?'🔍 Aproximar':'🗺️ Mapa inteiro';$('sceneZoom').setAttribute('aria-pressed',String(overview));$('liveView').value='local';mapCamera.loc='';draw(true)};
$('liveView').onchange=()=>{mapCamera.loc='';draw(true)};$('liveFocus').onchange=()=>{mapCamera.loc='';sceneSelect.value='';draw(true)};['showOfficialCollision','showOfficialPaths','showOfficialHitboxes'].forEach(id=>$(id)?.addEventListener('change',()=>draw(true)));
canvas.addEventListener('click',e=>{const rect=canvas.getBoundingClientRect(),x=(e.clientX-rect.left)*640/rect.width,y=(e.clientY-rect.top)*416/rect.height;let found=avatarHits.filter(v=>Math.abs(v.x-x)<16&&Math.abs(v.y-y)<24).sort((a,b)=>(a.x-x)**2+(a.y-y)**2-(b.x-x)**2-(b.y-y)**2)[0];if(found)selectTrainer(found.id)});
let sceneVisible=true;
if('IntersectionObserver' in window)new IntersectionObserver(entries=>{sceneVisible=entries[0].isIntersecting;lastFrame=0},{rootMargin:'120px'}).observe(canvas);
const reducedMotion=window.matchMedia('(prefers-reduced-motion: reduce)');
let animationTime=0;
function animate(now){
 const elapsed=now-(lastFrame||now);
 if(!document.hidden&&sceneVisible&&(!$('gamePage').hidden||!$('page-jogador').hidden||document.body.classList.contains('landing-active'))){
  const quiet=window.emeraldPaused||window.emeraldOptions.gameMode==='player'||!window.emeraldOptions.animations||reducedMotion.matches;
  const population=window.emeraldTrainers?.length||20;
  const quality=window.ELWQuality?.get?.()||'auto';
  const smallDevice=(navigator.deviceMemory&&navigator.deviceMemory<=3)||(navigator.hardwareConcurrency&&navigator.hardwareConcurrency<=4);
  const targetFps=quiet?3:quality==='economy'?15:quality==='high'?60:
   smallDevice?(population>=75?18:25):(population>=75?24:population>=35?30:45);
  if(!lastFrame||elapsed>=1000/targetFps-1){
   const dt=clamp(lastFrame?elapsed:16.67,1,100);lastFrame=now;
   if(!quiet)animationTime+=dt;
   draw(false,animationTime,quiet?0:dt);frames++;
  }
 }else lastFrame=0;
 requestAnimationFrame(animate);
}
window.emeraldLiveDraw=()=>draw(true);
window.emeraldLiveDebug=()=>({frames,overview,focusId,camera:{...officialCamera},position:smoothing.get(focusId),teamVisible:!!$('liveTeam').children.length,preview:$('scenePreview').value,officialMap:focusTrainer(state()).officialMap,officialStats:official?.navStats(),continuous:continuousWorld?.metrics(),chunks:official?.chunkStats?.()});
setInterval(()=>{if(!document.hidden&&!$('page-mapa').hidden)updateMapMarkers(state())},1000);
draw(true);requestAnimationFrame(animate);
})();
