(()=>{'use strict';
const $=id=>document.getElementById(id),can=$('onlineCanvas'),ctx=can.getContext('2d'),SZ=16;
window.EmeraldPokemonArt?.loadCatalog().catch(()=>{});
const Sprites=window.EmeraldTrainerSprites;const avatars={};for(const kind of ['brendan','may']){const img=Sprites?.image(kind)||new Image();if(!img.src)img.src=`assets/overworld/${kind}_v2.png`;img.onload=render;avatars[kind]=img;}
const dirs={up:0,right:1,down:2,left:3},Facing=window.EmeraldMovementFacing,facingById=new Map();let snapshot=null,events=null,playing=false,lastMove=0,notice='';
let battleBusy=false;const inputState={},motions=new Map();let rafPending=false,stepSequence=0;let routeTarget=null,routeOverlay=null,routeBusy=false,lastRouteRequest=0;
const getApi=async(route)=>{const r=await fetch('/api/'+route,{credentials:'same-origin'});const data=await r.json();if(!r.ok)throw Error(data.error||'Erro ao consultar');return data};
const api=async(route,payload)=>{const r=await fetch('/api/'+route,{method:'POST',headers:{'content-type':'application/json'},credentials:'same-origin',body:JSON.stringify(payload)});const result=await r.json();if(!r.ok)throw Error(result.error||'Erro de conexão');return result};
function status(msg,bad=false){$('connection').textContent=msg;$('connection').classList.toggle('error',bad);}
function message(txt){$('notice').textContent=txt;}
function enter(){(window.ELWOnlineAuth?.makeSession||((body)=>api('session',body)))({name:$('name').value,avatar:$('avatar').value,starter:$('starter').value,channel:Number($('channel').value),mode:$('mode').value}).then(()=>{
 try{localStorage.setItem('emerald_online_prefs_v6',JSON.stringify({name:$('name').value,avatar:$('avatar').value,channel:$('channel').value,starter:$('starter').value,mode:$('mode').value}))}catch(e){}
 playing=true;$('setup').hidden=true;$('game').hidden=false;connect();refreshBotRoster();refreshRanking();
 }).catch(err=>{status('Falha ao conectar',true);message(err.message);$('setup').querySelector('.muted').textContent='Não foi possível acessar o servidor. Abra este site através do servidor Node.js, não de hospedagem estática. '+err.message;});}
function connect(){events?.close();events=new EventSource('/api/stream',{withCredentials:true});events.addEventListener('snapshot',e=>{try{const fresh=JSON.parse(e.data);trackMotion(fresh);snapshot=fresh;render();animateMotion();updateUi();status('Online · '+snapshot.self.channel);if(routeTarget&&Date.now()-lastRouteRequest>2200)refreshRoute();}catch(err){console.error(err)}});
 events.addEventListener('error',()=>status('Reconectando...',true));events.addEventListener('open',()=>{status('Conectado');message('Servidor conectado. Use as setas para andar.');});}
function move(dir){if(!playing||!snapshot||snapshot.self.battle||snapshot.self.mode==='spectator'||!Object.hasOwn(dirs,dir))return;const at=Date.now();if(at-lastMove<180)return;lastMove=at;
 api('move',{dir}).catch(err=>{if(!/rápido demais|bloqueado/.test(err.message))message(err.message)});}
// Visual positions are interpolated only between tile positions approved by the server.
// Never send predicted coordinates back to the server or animate arbitrary jumps.
function trackMotion(next){
 const previous=snapshot;
 if(!previous||previous.map?.name!==next.map?.name){motions.clear();return}
 const prior=new Map([...previous.players,...previous.bots].map(p=>[p.id,p]));
 const tick=performance.now();
 for(const p of [...next.players,...next.bots]){
  const old=prior.get(p.id);
  if(!old||old.area!==p.area){motions.delete(p.id);continue}
  if(old.x===p.x&&old.y===p.y)continue;
  if(Math.abs(p.x-old.x)+Math.abs(p.y-old.y)!==1){motions.delete(p.id);continue}
  const direction=Facing?.fromStep(old.x,old.y,p.x,p.y)??dirs[p.facing]??2;
  facingById.set(p.id,direction);
  motions.set(p.id,{fromX:old.x,fromY:old.y,toX:p.x,toY:p.y,start:tick,duration:180,seq:stepSequence++,dir:direction});
 }
 const present=new Set([...next.players,...next.bots].map(p=>p.id));
 for(const id of motions.keys())if(!present.has(id))motions.delete(id);
 for(const id of facingById.keys())if(!present.has(id))facingById.delete(id);
}
function animateMotion(){
 if(rafPending||!motions.size)return;
 rafPending=true;
 const loop=()=>{
  const now=performance.now();let moving=false;
  for(const [id,m] of motions){if(now-m.start<m.duration)moving=true;else motions.delete(id)}
  render();if(moving)requestAnimationFrame(loop);else rafPending=false;
 };
 requestAnimationFrame(loop);
}
const portal=(m,x,y)=>(m.portals||[]).find(p=>p.x===x&&p.y===y);
function terrain(x,y,seed){const n=((Math.imul(x+1,116867)+Math.imul(y+2,86753)+seed*7649)>>>0)%17;return n;}
function drawMap(m){ctx.imageSmoothingEnabled=false;ctx.clearRect(0,0,can.width,can.height);
 const walls=new Set();for(const r of m.walls)for(let y=r.y;y<r.y+r.h;y++)for(let x=r.x;x<r.x+r.w;x++)walls.add(x+':'+y);
 const npcs=new Map((m.npcs||[]).map(p=>[p.x+':'+p.y,p]));
 for(let y=0;y<m.height;y++)for(let x=0;x<m.width;x++){
  const v=terrain(x,y,m.seed);const wx=x*SZ,wy=y*SZ,wall=walls.has(x+':'+y),npc=npcs.get(x+':'+y);
  const indoor=/Gym$|^League/.test(m.name)||['Lab','House','Center','Mart','BrineyHouse','StevenChamber','HallOfFame'].includes(m.name);
  ctx.fillStyle=indoor?(v%2?'#b6a680':'#c4b38f'):(v<3?'#73ac69':v<5?'#87b96e':'#7baa60');ctx.fillRect(wx,wy,SZ,SZ);
  if(wall){ctx.fillStyle=indoor?'#756756':'#2e683b';ctx.fillRect(wx,wy,SZ,SZ);ctx.fillStyle=indoor?'#998a72':'#428549';ctx.fillRect(wx,wy,SZ,4);if(!indoor){ctx.fillStyle='#438c4f';ctx.fillRect(wx+3,wy+4,10,7)}}
  else if(!indoor&&v===0){ctx.fillStyle='#529c52';ctx.fillRect(wx+4,wy+6,2,3);ctx.fillRect(wx+10,wy+5,2,4)}
  if(npc){ctx.fillStyle='#67493b';ctx.fillRect(wx+4,wy+7,8,8);ctx.fillStyle='#f1b17a';ctx.fillRect(wx+5,wy+3,6,6);ctx.fillStyle='#f8ecb9';ctx.fillRect(wx+4,wy+2,8,2);}
  if($('showOnlineCollisions')?.checked&&(wall||npc)){
   ctx.fillStyle=wall?'#e65e6466':'#e7b55466';ctx.fillRect(wx,wy,SZ,SZ);
   ctx.strokeStyle=wall?'#f29d9b':'#f9e3a8';ctx.strokeRect(wx+.5,wy+.5,SZ-1,SZ-1);
  }
  const p=portal(m,x,y);if(p){
   const me=snapshot?.self;
   const locked=me?.mode!=='spectator'&&((p.requiresBadges&&Number(me.badges||0)<p.requiresBadges)||(p.requiresStory&&!me.story?.[p.requiresStory]));
   ctx.fillStyle=locked?'#d5a06d':'#65d8e6';ctx.fillRect(wx+2,wy+2,12,12);
   ctx.fillStyle=locked?'#593428':'#163c55';ctx.fillRect(wx+5,wy+4,6,8);
   if(locked){ctx.fillStyle='#fff1cd';ctx.fillRect(wx+6,wy+4,4,2)}
  }
 }
}
function sprite(p,me=false){const kind=p.avatar==='may'?'may':'brendan',img=avatars[kind],ready=Sprites?.ready(kind)||!!(img?.naturalWidth===48&&img?.naturalHeight===128);
 const m=motions.get(p.id),progress=m?Math.max(0,Math.min(1,(performance.now()-m.start)/m.duration)):1;
 const x=(m?m.fromX+(m.toX-m.fromX)*progress:p.x)*SZ;
 const y=(m?m.fromY+(m.toY-m.fromY)*progress:p.y)*SZ;
 // Server snapshots may change facing after the animation has already started.
 // The displayed frame must follow the verified tile displacement instead.
 const dir=m?.dir??facingById.get(p.id)??dirs[p.facing]??2;
 if(!facingById.has(p.id))facingById.set(p.id,dir);
 const walking=!!m&&progress<1;
 if(!(ready&&Sprites?.draw(ctx,kind,dir,walking,progress,m?.seq||0,x,y-16,16,32))){
  ctx.fillStyle=me?'#fff6a1':'#d4f5e1';ctx.fillRect(x+4,y+1,9,15);ctx.fillStyle='#bc4747';ctx.fillRect(x+3,y,10,5)
 }
 const text=p.name||'?';ctx.font='7px system-ui';ctx.textAlign='center';const w=Math.max(16,ctx.measureText(text).width+6);ctx.fillStyle=me?'#2b4633':'#102b29';ctx.fillRect(x+8-w/2,y-24,w,10);ctx.fillStyle=me?'#ffeb97':'#fafbe9';ctx.fillText(text,x+8,y-17);
 if(me){ctx.strokeStyle='#ffec87';ctx.lineWidth=1;ctx.strokeRect(x,y,16,16)}
 if($('showOnlineHitboxes')?.checked)Sprites?.drawHitbox(ctx,kind,x,y-16,16,32);
}
function renderRoute(){
 if(!$('showOnlinePaths')?.checked||!routeOverlay?.ok||!routeOverlay.trail?.length||routeOverlay.destination?.area!==snapshot?.map?.name)return;
 ctx.save();ctx.fillStyle='#fff5a8';for(const t of routeOverlay.trail){ctx.globalAlpha=.6;ctx.fillRect(t.x*SZ+6,t.y*SZ+6,4,4)}ctx.globalAlpha=1;
 const t=routeOverlay.trail[routeOverlay.trail.length-1];ctx.strokeStyle='#ffe875';ctx.lineWidth=2;ctx.strokeRect(t.x*SZ+2,t.y*SZ+2,12,12);ctx.restore();
}
function renderNpc(n){const x=n.x*SZ,y=n.y*SZ;
 sprite({id:'npc-'+(n.id||n.name),name:n.name||'NPC',avatar:n.avatar||'rosa',
  x:n.x,y:n.y,facing:'down'},false);
 if(n.challenge){ctx.fillStyle='#f7dc6b';ctx.font='bold 12px system-ui';ctx.textAlign='center';ctx.fillText('!',x+8,y-27);}
}
function render(){if(!snapshot?.map)return;drawMap(snapshot.map);renderRoute();
 for(const npc of snapshot.map.npcs||[])renderNpc(npc);
 const people=[...snapshot.bots,...snapshot.players].sort((a,b)=>a.y-b.y);for(const p of people)sprite(p,p.id===snapshot.self.id);}
function battlefield(mon,element,title){element.replaceChildren();const img=document.createElement('img');
 window.EmeraldPokemonArt.apply(img,mon.species,{pixel:true});
 const details=document.createElement('div'),head=document.createElement('b'),hp=document.createElement('p'),bar=document.createElement('progress');
 head.textContent=title+' · '+mon.species+' Nv. '+mon.level;hp.textContent='HP '+mon.hp+'/'+mon.maxHp+(mon.status?' · '+mon.status.toUpperCase():'');
 bar.max=Math.max(1,mon.maxHp||1);bar.value=Math.max(0,mon.hp||0);details.append(head,hp,bar);element.append(img,details);
}
function renderArena(){if(!snapshot)return;const me=snapshot.self,locked=me.mode==='spectator';
 $('bagInfo').textContent=`${me.bag?.pokeballs??0} Poké Bolas · ₽${me.money??0}`;
 const battle=me.battle,controls=$('battleControls'),view=$('battleView'),summary=$('battleSummary');
 controls.hidden=!!battle;view.hidden=!battle;
 $('findWild').disabled=locked||battleBusy;$('findNational').disabled=locked||battleBusy;$('healTeam').disabled=locked||battleBusy||me.area!=='Center';
 const botSel=$('challengeBot'),current=botSel.value;botSel.replaceChildren();
 const near=(snapshot.bots||[]).filter(b=>Math.abs(b.x-me.x)+Math.abs(b.y-me.y)<=3);
 if(!near.length){const item=document.createElement('option');item.textContent='Nenhum bot por perto';item.value='';botSel.append(item)}
 else for(const bot of near){const option=document.createElement('option');option.value=bot.id;option.textContent=bot.name+' · '+bot.team?.[0]?.species;botSel.append(option)}
 if(near.some(b=>b.id===current))botSel.value=current;
 $('fightBot').disabled=locked||battleBusy||!botSel.value;
 const interact=snapshot.interactions||{};
 $('fightGym').disabled=locked||battleBusy||!interact.gym;
 $('fightGym').textContent='🏅 Desafiar '+(interact.gym||'líder');
 $('fightStory').disabled=locked||battleBusy||!interact.trainer;
 if($('fightLeague')){$('fightLeague').disabled=locked||battleBusy||!interact.league;$('fightLeague').textContent='🏆 Enfrentar '+(interact.league||'Liga Pokémon');}
 $('fightNpc').disabled=locked||battleBusy||!interact.npc;
 const npc=(snapshot.map.npcs||[]).find(n=>n.id===interact.npc);
 $('fightNpc').textContent=npc?'⚔️ Desafiar '+npc.name:'⚔️ Desafiar NPC próximo';
 $('talkStory').disabled=locked||battleBusy||!interact.story;
 $('talkStory').textContent='💬 '+(interact.story?.label||'Conversar com Steven');
 $('buyBalls').disabled=locked||battleBusy||me.area!=='Mart'||(me.money||0)<600;
 if(!battle){summary.textContent=`${me.badges||0} insígnia(s) · Liga ${me.leagueWins||0}/5${me.champion?' · 👑 Campeão de Hoenn':''}. Enfrente treinadores, líderes e Pokémon selvagens.`;return;}
 const owner=me.team?.find(mon=>mon.id===battle.activePokemonId)||me.team?.find(mon=>(mon.hp||0)>0)||me.team?.[0];
 if(owner)battlefield(owner,$('ownMon'),'Você');battlefield(battle.enemy,$('enemyMon'),'Adversário');
 if(battle.format==='double'){
  if(battle.ally){const allyView=document.createElement('div');allyView.className='double-partner';battlefield(battle.ally,allyView,'Seu parceiro');$('ownMon').append(allyView);}
  if(battle.enemyPartner){const rivalView=document.createElement('div');rivalView.className='double-partner';battlefield(battle.enemyPartner,rivalView,'Segundo adversário');$('enemyMon').append(rivalView);}
 }
 const actions=$('battleActions');actions.replaceChildren();
 let partnerSelect=null,primaryTarget=null,partnerTarget=null;
 if(battle.format==='double'){
  const caption=document.createElement('p');caption.className='muted';caption.textContent='⚔️ Double Battle: escolha o golpe de cada Pokémon e seus alvos.';actions.append(caption);
  const makeTarget=(label)=>{const wrap=document.createElement('label');wrap.textContent=label+' ';
   const select=document.createElement('select');for(const [value,title] of [['B1',battle.enemy?.species||'Adversário 1'],['B2',battle.enemyPartner?.species||'Adversário 2']]){
    if(!(value==='B2'&&!battle.enemyPartner)){const op=document.createElement('option');op.value=value;op.textContent=title;select.append(op);}}
   wrap.append(select);actions.append(wrap);return select;};
  primaryTarget=makeTarget('Alvo do primeiro Pokémon');
  if(battle.ally){const label=document.createElement('label');label.textContent='Golpe de '+battle.ally.species+' ';
   partnerSelect=document.createElement('select');
   for(const m of battle.ally.moves||[]){const pp=battle.ally.pp?.[m];const op=document.createElement('option');op.value=m;op.textContent=m+(Number.isInteger(pp)?' · PP '+pp:'');op.disabled=(Number.isInteger(pp)&&pp<=0)||(battle.ally.item==='ChoiceBand'&&battle.ally.choiceLock&&battle.ally.choiceLock!==m);partnerSelect.append(op);}
   if(![...partnerSelect.options].some(op=>!op.disabled)){const op=document.createElement('option');op.value='Struggle';op.textContent='Struggle (sem PP)';partnerSelect.append(op);}
   partnerSelect.selectedIndex=[...partnerSelect.options].findIndex(op=>!op.disabled);
   label.append(partnerSelect);actions.append(label);partnerTarget=makeTarget('Alvo do parceiro');
  }
 }
 const doublePayload=(move)=>battle.format==='double'?{type:'move',move,partnerMove:partnerSelect?.value||undefined,target:primaryTarget?.value||'B1',partnerTarget:partnerTarget?.value||'B1'}:{type:'move',move};
 for(const move of owner?.moves||[]){const btn=document.createElement('button');
  const pp=owner.pp?.[move];const exhausted=Number.isInteger(pp)&&pp<=0;
  btn.textContent='⚔️ '+move+(Number.isInteger(pp)?' · PP '+pp:'');
  btn.title=exhausted?'Sem PP. Escolha outro golpe.':(owner.status?'Status: '+owner.status:'');
  btn.disabled=battleBusy||exhausted||(owner.item==='ChoiceBand'&&!!owner.choiceLock&&owner.choiceLock!==move);
  btn.onclick=()=>battleApi('battle/action',doublePayload(move));actions.append(btn);}
 if(owner&&owner.moves?.length&&owner.moves.every(m=>(owner.pp?.[m]??1)<=0)){
  const btn=document.createElement('button');btn.textContent='⚔️ Struggle (sem PP)';btn.disabled=battleBusy;
  btn.onclick=()=>battleApi('battle/action',doublePayload('Struggle'));actions.append(btn);
 }
 for(const [type,label] of [['ball','🔴 Poké Bola'],['run','🏃 Fugir']]){if(battle.type!=='wild')continue;const btn=document.createElement('button');btn.textContent=label;btn.disabled=battleBusy||(type==='ball'&&!me.bag?.pokeballs);btn.onclick=()=>battleApi('battle/action',{type});actions.append(btn)}
 for(const [i,m] of (me.team||[]).entries()){if(battle.format!=='double'&&m.hp>0&&m!==owner){const btn=document.createElement('button');btn.textContent='🔁 '+m.species+' Nv. '+m.level;btn.disabled=battleBusy;btn.onclick=()=>battleApi('battle/action',{type:'switch',move:i});actions.append(btn)}}
 const log=$('battleLog');log.replaceChildren();for(const line of battle.log||[]){const para=document.createElement('p');para.textContent=line;log.append(para)}log.scrollTop=log.scrollHeight;
 summary.textContent=`Rodada ${battle.turn+1} · ${['gym','trainer','npc','league'].includes(battle.type)?(battle.trainerName||'Treinador')+' (faltam '+battle.remaining+' Pokémon)':battle.type==='wild'?'Pokémon selvagem':'Bot treinador'}`;
}
async function battleApi(route,payload){if(battleBusy)return;battleBusy=true;try{
 const answer=await api(route,payload);
 if(answer.self&&snapshot){snapshot.self=answer.self;renderArena();updateUi()}
 const result=answer.result;
 if(result?.log?.length&&result.done)message(result.log.slice(-2).join(' • '));
 else if(result?.description)message(result.description);
 else if(result?.cost)message(`Comprou ${result.count} Poké Bolas por ₽${result.cost}.`);
 else if(result?.healed)message(`Centro Pokémon: ${result.healed} Pokémon recuperados.`);
 }catch(err){message(err.message)}finally{battleBusy=false;renderArena()}}
let habitatKey='',habitatPending=false;
async function refreshLocalHabitat(){
 const me=snapshot?.self,el=$('localEncounters');if(!me||!el||habitatPending)return;
 const key=me.area+'|'+me.badges;if(key===habitatKey)return;
 habitatPending=true;
 try{const data=await getApi('encounters');if(key!==snapshot?.self.area+'|'+snapshot?.self.badges)return;
  habitatKey=key;el.textContent=data.total?'🌿 '+data.area+': '+data.total+' espécies liberadas nesta rota. Ex.: '+data.sample.join(', ')+' (locais adaptados).':'🛡️ '+me.area+': sem encontros selvagens comuns.';
 }catch{el.textContent='📍 Consulte a Pokédex para os encontros desta área.'}
 finally{habitatPending=false}
}
function updateUi(){const s=snapshot;if(!s)return;refreshLocalHabitat();
 $('areaName').textContent=s.map.title;$('worldTick').textContent=`${s.simulation?.bots||0} bots · turno ${s.simulation?.tick||0}`;$('stageHint').textContent=s.camera?'📷 Acompanhando '+s.camera.name+' · '+s.camera.objective:(()=>{
  const locked=(s.map.portals||[]).find(p=>Math.abs(p.x-s.self.x)+Math.abs(p.y-s.self.y)<=1&&((p.requiresBadges&&s.self.badges<p.requiresBadges)||(p.requiresStory&&!s.self.story?.[p.requiresStory])));
  return locked?`🚪 Passagem bloqueada: ${locked.requiresBadges?locked.requiresBadges+' insígnia(s) ':''}${locked.requiresStory?'· evento '+locked.requiresStory:''}`:'Setas para andar · azul: passagem · marrom: bloqueada';
 })();$('myStatus').textContent=`${s.self.name} · ${s.self.x},${s.self.y}`;$('playerCount').textContent=`${s.online} online`;$('botCount').textContent=`${s.bots.length} bots próximos`;$('myName').textContent=s.self.name+(s.self.mode==='spectator'?' · espectador':'');$('myTeam').textContent=(s.self.team||[]).map(m=>`${m.species} Nv. ${m.level}`).join(' / ');$('inGameChannel').value=String(s.self.channel);document.querySelectorAll('[data-dir]').forEach(b=>b.disabled=s.self.mode==='spectator');
 const players=$('players');players.replaceChildren();for(const p of [...s.players,...s.bots]){const li=document.createElement('li');li.textContent=`${p.name}${p.id===s.self.id?' (você)':p.id.startsWith('bot-')?' (IA)':''}`;players.append(li)}
 renderArena();
 const box=$('messages');const pinned=box.scrollTop+box.clientHeight>=box.scrollHeight-30;box.replaceChildren();for(const c of s.chat){const line=document.createElement('p'),author=document.createElement('b'),msg=document.createElement('span');line.className='onlineChatItem'+(c.author===s.self.name?' mine':'');author.className='onlineChatAuthor';author.textContent=c.author;msg.textContent=c.message;line.append(author,msg);box.append(line)}if(pinned)box.scrollTop=box.scrollHeight;
}
{const select=$('starter'),names=window.EmeraldStarters?.ALL||[];if(select&&names.length){const previous=select.value;select.replaceChildren(...names.map(name=>{const opt=document.createElement('option');opt.value=name;opt.textContent=name+' · Geração '+window.EmeraldStarters.GENERATION[name];return opt;}));select.value=names.includes(previous)?previous:'Mudkip';}}
try{const saved=JSON.parse(localStorage.getItem('emerald_online_prefs_v6')||'null');if(saved){for(const key of ['name','avatar','channel','starter','mode'])if(saved[key]&&$(key))$(key).value=saved[key]}}catch(e){}
['showOnlineCollisions','showOnlinePaths','showOnlineHitboxes'].forEach(id=>$(id)?.addEventListener('change',render));
$('enter').addEventListener('click',enter);$('inGameChannel').addEventListener('change',e=>{api('channel',{channel:Number(e.target.value)}).catch(err=>message(err.message))});
$('findWild').addEventListener('click',()=>battleApi('battle/start',{type:'wild'}));
$('findNational').addEventListener('click',()=>battleApi('battle/start',{type:'wild',national:true}));
$('fightBot').addEventListener('click',()=>{const selected=$('challengeBot').value;if(selected)battleApi('battle/start',{type:'bot',botId:selected})});
$('fightGym').addEventListener('click',()=>battleApi('battle/start',{type:'gym'}));
$('fightLeague')?.addEventListener('click',()=>battleApi('battle/start',{type:'league'}));
$('fightNpc').addEventListener('click',()=>battleApi('battle/start',{type:'npc',trainerId:snapshot?.interactions?.npc}));
$('fightStory').addEventListener('click',()=>battleApi('battle/start',{type:'trainer',trainerId:snapshot?.interactions?.trainer}));
$('talkStory').addEventListener('click',()=>battleApi('story/interact',{}));
$('buyBalls').addEventListener('click',()=>battleApi('shop/buy',{item:'pokeballs',count:3}));
$('healTeam').addEventListener('click',()=>battleApi('battle/heal',{}));
$('chatForm').addEventListener('submit',e=>{e.preventDefault();const input=$('chatInput'),messageText=input.value.trim();if(!messageText)return;api('chat',{message:messageText}).then(()=>{input.value=''}).catch(err=>message(err.message))});
for(const btn of document.querySelectorAll('[data-dir]')){btn.addEventListener('pointerdown',e=>{e.preventDefault();const d=btn.dataset.dir;move(d);inputState[d]=true;btn.setPointerCapture(e.pointerId)});for(const ev of ['pointerup','pointercancel','lostpointercapture'])btn.addEventListener(ev,()=>delete inputState[btn.dataset.dir]);}
const keyMap={ArrowUp:'up',ArrowRight:'right',ArrowDown:'down',ArrowLeft:'left',w:'up',d:'right',s:'down',a:'left'};
document.addEventListener('keydown',e=>{if(e.target.closest('input,textarea,select'))return;const dir=keyMap[e.key];if(dir){e.preventDefault();inputState[dir]=true;move(dir);}});
document.addEventListener('keyup',e=>{const d=keyMap[e.key];if(d)delete inputState[d]});
window.addEventListener('blur',()=>{for(const k of Object.keys(inputState))delete inputState[k]});

// The observatory reads authoritative events, not client-simulated 'achievements'.
let rosterBusy=false,detailsBusy=false,rankingBusy=false;
async function refreshBotRoster(){if(!playing||rosterBusy)return;rosterBusy=true;try{
 const data=await getApi('bots'),select=$('watchBot'),selected=select.value;
 select.replaceChildren();for(const bot of data.bots){const opt=document.createElement('option');opt.value=bot.id;opt.textContent=`${bot.name} · ${bot.badges} insígnia(s) · ${bot.area}`;select.append(opt)}
 if(data.bots.some(b=>b.id===selected))select.value=selected;
 await refreshBotDetails();
 }catch(err){message('Observatório: '+err.message)}finally{rosterBusy=false}}
async function refreshBotDetails(){if(!playing||detailsBusy)return;const id=$('watchBot').value;if(!/^bot-\d+$/.test(id))return;
 detailsBusy=true;try{const {bot}=await getApi('bots/'+id);
  const team=(bot.team||[]).map(m=>`${m.species} Nv.${m.level} (${m.hp}/${m.maxHp} HP)`).join(' · ');
  $('botDetails').textContent=`${bot.name} · ${bot.area} (${bot.x},${bot.y}) · Canal ${bot.channel}\n${bot.badges} insígnia(s) · ${bot.wins} vitórias · ${bot.losses} derrotas\nInicial: ${bot.starter}\nEquipe: ${team}\nObjetivo: ${bot.objective}\nÚltima decisão: ${bot.lastAction||'Iniciando jornada'}`;
  const box=$('botEvents');box.replaceChildren();for(const event of [...bot.events].reverse()){
   const li=document.createElement('li'),metadata=document.createElement('small');li.textContent=event.message;metadata.textContent=`Turno ${event.tick} · ${event.area}`;li.append(metadata);box.append(li);
  }
 }catch(err){message(err.message)}finally{detailsBusy=false}}
async function refreshRanking(){if(!playing||rankingBusy)return;rankingBusy=true;try{
 const data=await getApi('ranking');const board=$('botRanking');board.replaceChildren();for(const bot of data.ranking.slice(0,20)){
  const li=document.createElement('li');li.textContent=`${bot.name}: ${bot.badges} insígnias · ${bot.wins} vitórias`;board.append(li);
 }
 $('hallOfFame').textContent=data.hallOfFame.length?'Hall da Fama: '+data.hallOfFame.map(b=>b.name).join(', '):'Hall da Fama: ainda não há Campeões reais (a campanha completa não está implementada).';
 const top=await getApi('top-pokemon'),list=$('topSixPokemon');list.replaceChildren();
 for(const item of top.top){const li=document.createElement('li');li.textContent=`${item.species} Nv.${item.level} · ${item.owner} · ⚡ ${item.power} pontos`;list.append(li);}

 }catch(err){message(err.message)}finally{rankingBusy=false}}
$('watchBot').addEventListener('change',()=>{refreshBotDetails();if(routeTarget){routeTarget=$('watchBot').value;refreshRoute();}});
const turnArrow={up:'↑ Cima',down:'↓ Baixo',left:'← Esquerda',right:'→ Direita'};
async function refreshRoute(){
 if(!playing||!routeTarget||routeBusy||snapshot?.self.mode==='spectator')return;
 routeBusy=true;lastRouteRequest=Date.now();
 try{const route=await getApi('route/'+routeTarget);routeOverlay=route.ok?route:null;
  let info;
  if(!route.ok)info=route.reason==='different-channel'?`A IA está no canal ${route.channel}. Mude de canal para encontrá-la.`:route.message;
  else if(route.arrived)info='Você chegou perto da IA. Selecione-a em Batalhas para desafiar.';
  else info=`Próximo passo: ${turnArrow[route.nextDirection]||'Aguarde a IA'} · ${route.steps} passos até ${route.destination.to?'passagem para '+route.destination.to:'posição da IA'} (${route.botArea}).`;
  $('routeInfo').textContent=info;render();
 }catch(err){routeOverlay=null;$('routeInfo').textContent='Não foi possível calcular a rota: '+err.message}finally{routeBusy=false}
}
$('routeBot').addEventListener('click',()=>{
 if(snapshot?.self.mode==='spectator'){message('Para caminhar até uma IA, entre como explorador.');return}
 routeTarget=$('watchBot').value;routeOverlay=null;if(routeTarget){$('showOnlinePaths').checked=true;refreshRoute();}
});
$('followBot').addEventListener('click',async()=>{if(snapshot?.self.mode!=='spectator'){message('Entre no modo Espectador para acompanhar outro treinador.');return}
 try{await api('spectate',{botId:$('watchBot').value});message('Câmera seguindo '+$('watchBot').selectedOptions[0]?.textContent)}catch(err){message(err.message)}});
setInterval(()=>{if(playing){refreshBotRoster();refreshRanking()}},7000);
setInterval(()=>{if(playing)refreshBotDetails()},2300);

// Read-only visual diagnostics; useful when an Android client reports spinning.
window.emeraldOnlineVisualDebug=()=>({
 facing:Object.fromEntries(facingById),
 moving:[...motions].map(([id,m])=>({id,dir:m.dir,from:[m.fromX,m.fromY],to:[m.toX,m.toY]}))
});
setInterval(()=>{if(!playing)return;const direction=Object.keys(inputState)[0];if(direction)move(direction)},190);
})();
