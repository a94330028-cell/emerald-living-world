/* Account access for the shared world. Only public Supabase credentials run here.
 * The Node server independently verifies every account token; this code is UI only. */
(()=>{'use strict';
const $=id=>document.getElementById(id),KEY='elw_cloud_session_v1';
const config=window.EMERALD_CLOUD_CONFIG||{},url=String(config.supabaseUrl||'').replace(/\/+$/,''),key=config.supabaseAnonKey||'';
let required=false,enabled=false,session=null;
function info(message,error=false){const el=$('onlineAuthNotice');if(el){el.textContent=message;el.dataset.error=error?'true':'false';}}
function readSession(){try{const value=JSON.parse(localStorage.getItem(KEY)||'null');return value?.access_token&&value?.user?.id?value:null;}catch{return null;}}
function persist(s){session={access_token:s.access_token,refresh_token:s.refresh_token,expires_at:s.expires_at||Math.floor(Date.now()/1000)+Number(s.expires_in||3600),user:s.user};localStorage.setItem(KEY,JSON.stringify(session));}
async function request(path,data,token){
 const res=await fetch(url+path,{method:'POST',headers:{'Content-Type':'application/json','apikey':key,...(token?{Authorization:'Bearer '+token}:{})},body:JSON.stringify(data)});
 let json={};try{json=await res.json();}catch{}
 if(!res.ok)throw Error(json.msg||json.error_description||json.message||json.error||'Falha na autenticação');return json;
}
async function access(){
 if(!session)session=readSession();if(!session)return null;
 if(Number(session.expires_at||0)>Math.floor(Date.now()/1000)+60)return session.access_token;
 if(!session.refresh_token){session=null;localStorage.removeItem(KEY);return null;}
 try{const next=await request('/auth/v1/token?grant_type=refresh_token',{refresh_token:session.refresh_token});persist(next);return session.access_token;}
 catch{session=null;localStorage.removeItem(KEY);return null;}
}
function display(){const box=$('onlineAuth'),enter=$('enter'),status=$('onlineAccountStatus');if(box)box.hidden=!enabled;
 if(enter&&required)enter.disabled=!session;
 if(status)status.textContent=session?'Conta conectada: '+(session.user.email||'treinador cadastrado'):(required?'É necessário entrar com uma conta para jogar.':'Você pode entrar como visitante ou conectar sua conta.');
 if($('onlineAuthLogout'))$('onlineAuthLogout').hidden=!session;
}
async function initialize(){
 try{const r=await fetch('/api/auth-config');if(!r.ok)throw Error();const data=await r.json();required=!!data.required;enabled=!!data.enabled;
  if(required&&!enabled)info('O servidor requer login, mas não tem Supabase configurado.',true);
  if(enabled&&(!url||!key))info('A configuração pública do Supabase está ausente nesta página.',true);
  session=readSession();if(session&&!(await access()))info('Sua sessão expirou. Entre novamente.',true);
  display();
 }catch{info('Não foi possível consultar a configuração de login.',true);}
}
async function makeSession(data){
 const token=enabled&&url&&key?await access():null;
 if(required&&!token)throw Error('Entre com sua conta antes de acessar o mundo compartilhado.');
 const r=await fetch('/api/session',{method:'POST',headers:{'content-type':'application/json',...(token?{'Authorization':'Bearer '+token}:{})},credentials:'same-origin',body:JSON.stringify(data)});
 const out=await r.json();if(!r.ok)throw Error(out.error||'Falha ao abrir sessão');return out;
}
$('onlineAuthForm')?.addEventListener('submit',async e=>{
 e.preventDefault();if(!url||!key){info('Supabase não está configurado.',true);return;}
 const mode=$('onlineAuthMode').value,email=$('onlineAuthEmail').value.trim(),password=$('onlineAuthPassword').value;
 if(!email||password.length<8){info('Informe e-mail e senha com pelo menos 8 caracteres.',true);return;}
 const submit=$('onlineAuthSubmit');submit.disabled=true;info(mode==='signup'?'Criando conta…':'Validando conta…');
 try{
  if(mode==='signup'){
   const r=await request('/auth/v1/signup',{email,password,data:{display_name:$('name').value.trim().slice(0,24)}});
   if(r.access_token&&r.user){persist(r);info('Conta criada e conectada. Você pode entrar no mundo.');}
   else info('Cadastro solicitado. Confirme o e-mail, se a confirmação estiver ativa, e depois entre.');
  }else{const r=await request('/auth/v1/token?grant_type=password',{email,password});persist(r);info('Conta autenticada. Clique em Entrar no mundo.');}
  $('onlineAuthPassword').value='';display();
 }catch(err){info(err.message,true);}finally{submit.disabled=false;}
});
$('onlineAuthLogout')?.addEventListener('click',async()=>{
 try{await fetch('/api/logout',{method:'POST',credentials:'same-origin'});}catch{}
 session=null;localStorage.removeItem(KEY);display();info('Você saiu da conta.');location.reload();
});
window.ELWOnlineAuth={makeSession};initialize();
})();
