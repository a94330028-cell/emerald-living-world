/* Stateless atlas selection for 3-column, 4-direction, 32x48 trainers. */
(function(root){'use strict';
 const FRAME_ROWS=Object.freeze({2:0,0:1,3:2,1:3}); // down, up, left, right
 function frameIndex(dir=2,moving=false,progress=0,stepSeq=0){
  const facing=Number.isInteger(dir)&&dir>=0&&dir<4?dir:2;
  const row=FRAME_ROWS[facing];
  // Uma caminhada usa AMBAS as poses dos pés dentro de cada tile.
  // Na versão anterior, cada passo mostrava quase só um quadro por 200 ms;
  // nas direções laterais, isso parecia um sprite estático deslizando.
  // Não alternar quadros quando moving=false: idle mantém a direção correta.
  const phase=Number.isFinite(progress)?Math.max(0,Math.min(1,progress)):0;
  const firstFoot=Math.abs(Math.trunc(Number(stepSeq)||0))%2===0?1:2;
  const column=moving?(phase<=0.5?firstFoot:3-firstFoot):0;
  return row*3+column;
 }
 const api=Object.freeze({frameIndex,FRAME_ROWS});
 if(typeof module==='object'&&module.exports)module.exports=api;
 if(root)root.EmeraldTrainerFrames=api;
})(typeof window==='object'?window:undefined);
