/* Emerald Living World V9.14 — source sprites are ALWAYS 32×48.
 * 20 user-provided 96×192 RGBA atlases, 3 columns × 4 direction rows.
 * Destination display sizes may be reduced for 16px tiles, but the
 * animation source is never a scaled-up 16×32 asset.
 */
(function(root){'use strict';
 const Frames=typeof module==='object'&&module.exports?require('./trainer-frames.js'):root?.EmeraldTrainerFrames;
 const IDS=Object.freeze(["brendan", "may", "red", "leaf", "ethan", "dawn", "rosa", "serena", "lyra", "lucas", "hilbert", "hilda", "nate", "calem", "elio", "selene", "victor", "gloria", "florian", "juliana"]);
 const FRAME_WIDTH=32,FRAME_HEIGHT=48,COLUMNS=3,ROWS=4;
 const ATLAS=Object.freeze({frameWidth:32,frameHeight:48,columns:3,rows:4,total:12,feetY:46});
 const DEFINITIONS=Object.freeze(Object.fromEntries(IDS.map(id=>[id,Object.freeze({
  id,label:id[0].toUpperCase()+id.slice(1),sheet:'assets/overworld/characters/'+id+'.png?v=9-14-32x48',
  atlas:ATLAS,hitbox:Object.freeze({x:10,y:32,width:12,height:16}),walkSpeed:205,collisionSize:16,
  directions:Object.freeze({up:0,right:1,down:2,left:3})
 })])));
 const images=new Map();
 function normalize(id){return Object.hasOwn(DEFINITIONS,id)?id:'brendan';}
 function get(id='brendan'){return DEFINITIONS[normalize(id)];}
 // Compatibility for old callers: accepted variant has no effect. There is ONLY a 32x48 atlas.
 function atlas(){return ATLAS;}
 function image(id='brendan'){
  id=normalize(id);if(images.has(id))return images.get(id);
  if(typeof Image==='undefined')return null;
  const img=new Image();img.decoding='async';img.src=get(id).sheet;images.set(id,img);return img;
 }
 function frameIndex(id='brendan',dir=2,moving=false,progress=0,stepSeq=0){return Frames?.frameIndex?.(dir,moving,progress,stepSeq)??0;}
 function frameRect(id='brendan',dir=2,moving=false,progress=0,stepSeq=0){
  const index=frameIndex(id,dir,moving,progress,stepSeq);
  return {index,sx:(index%3)*32,sy:Math.floor(index/3)*48,sw:32,sh:48};
 }
 function ready(id='brendan'){
  const img=image(id);return !!(img&&img.complete&&img.naturalWidth===96&&img.naturalHeight===192);
 }
 function draw(ctx,id='brendan',dir=2,moving=false,progress=0,stepSeq=0,dx=0,dy=0,dw=16,dh=24){
  if(!ctx||!ready(id))return false;const r=frameRect(id,dir,moving,progress,stepSeq);
  ctx.drawImage(image(id),r.sx,r.sy,r.sw,r.sh,dx,dy,dw,dh);return true;
 }
 // Hitbox is a map tile footprint, not the height of the picture.
 function drawHitbox(ctx,id='brendan',dx=0,dy=0,dw=16,dh=24,stroke='#44ebd9',fill='rgba(68,235,217,.15)'){
  if(!ctx)return false;
  const w=dw*.75,h=Math.min(16,dh*.7),x=dx+(dw-w)/2,y=dy+dh-h;
  ctx.save();ctx.fillStyle=fill;ctx.strokeStyle=stroke;ctx.lineWidth=1;ctx.fillRect(x,y,w,h);ctx.strokeRect(x,y,w,h);ctx.restore();
  return {x,y,width:w,height:h};
 }
 const api=Object.freeze({IDS,DEFINITIONS,ATLAS,get,atlas,image,ready,frameIndex,frameRect,draw,drawHitbox,FRAME_WIDTH,FRAME_HEIGHT,COLUMNS,ROWS});
 if(typeof module==='object'&&module.exports)module.exports=api;
 if(root){root.EmeraldTrainerSprites=api;
  // Somente protagonistas iniciais: outros 18 atlas sao buscados quando
  // uma IA entra no campo de visao, e cada Image e reutilizada por cache.
  image('brendan');image('may');
 }
})(typeof window==='object'?window:undefined);
