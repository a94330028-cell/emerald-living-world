/* Direction is derived from actual displacement, never from a planned path or camera. */
(function(root){'use strict';
 const DIR=Object.freeze({up:0,right:1,down:2,left:3});
 function normalize(value,fallback=2){
  return Number.isInteger(value)&&value>=0&&value<=3?value:fallback;
 }
 function fromStep(x0,y0,x1,y1){
  const dx=x1-x0,dy=y1-y0;
  if(!Number.isInteger(dx)||!Number.isInteger(dy)||Math.abs(dx)+Math.abs(dy)!==1)return null;
  return dx>0?DIR.right:dx<0?DIR.left:dy>0?DIR.down:DIR.up;
 }
 // Keep the last correct direction while idle, after blocked movement and after warps.
 function hold(last,from,to){
  return fromStep(from?.x,from?.y,to?.x,to?.y)??normalize(last);
 }
 function turns(from,path){
  if(!from||!Array.isArray(path))return Infinity;
  let prev=from,heading=null,count=0;
  for(const p of path){const d=fromStep(prev.x,prev.y,p.x,p.y);if(d===null)return Infinity;
   if(heading!==null&&heading!==d)count++;heading=d;prev=p;}
  return count;
 }
 // Eliminate a section of an optional scenic detour that returns to a visited tile.
 // The resulting path is composed exclusively of previously verified cardinal steps.
 function removeLoops(from,path){
  if(!from||!Array.isArray(path))return [];
  let prev={x:from.x,y:from.y};const result=[],seen=new Map([[`${from.x}:${from.y}`,0]]);
  for(const point of path){
   if(fromStep(prev.x,prev.y,point.x,point.y)===null)return null;
   const key=`${point.x}:${point.y}`,existing=seen.get(key);
   if(existing!==undefined){
    result.splice(existing);
    seen.clear();seen.set(`${from.x}:${from.y}`,0);
    result.forEach((p,i)=>seen.set(`${p.x}:${p.y}`,i+1));
   }else{result.push({x:point.x,y:point.y});seen.set(key,result.length);}
   prev=point;
  }
  return result;
 }
 const api=Object.freeze({DIR,normalize,fromStep,hold,turns,removeLoops});
 if(typeof module==='object'&&module.exports)module.exports=api;
 if(root)root.EmeraldMovementFacing=api;
})(typeof window==='object'?window:undefined);
