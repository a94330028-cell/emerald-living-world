'use strict';
const $=id=>document.getElementById(id);
const state={self:null,facility:'tower',teamIds:[],busy:false,source:null};
const names={tower:'🏢 Battle Tower',dome:'🏟️ Battle Dome',palace:'🌿 Battle Palace',arena:'⚖️ Battle Arena',factory:'🔄 Battle Factory',pike:'🐍 Battle Pike',pyramid:'🔺 Battle Pyramid'};
function tell(message,error=false){$('message').textContent=String(message);$('message').style.color=error?'#ffad94':'#9feabc';}
async function api(path,body=null){const res=await fetch('/api/'+path,{method:body?'POST':'GET',credentials:'same-origin',headers:body?{'content-type':'application/json'}:{},body:body?JSON.stringify(body):undefined});const data=await res.json();if(!res.ok)throw Error(data.error||'Falha no servidor');return data;}
function current(){return state.self?.frontier||{};}
function paintFacility(){const facilities=current().facilities||Object.keys(names).map(id=>({id,name:names[id],block:id==='dome'?4:7,status:'adapted'}));
 $('facilityGrid').replaceChildren();for(const item of facilities){const button=document.createElement('button');button.type='button';button.className='facility';button.dataset.selected=String(item.id===state.facility);
  const name=document.createElement('b');name.textContent=names[item.id]||item.name;
  const info=document.createElement('small');info.textContent=`${item.block} ${item.id==='pike'?'salas':item.id==='pyramid'?'andares':item.id==='dome'?'partidas':'batalhas'} por bloco`;
  button.append(name,info);button.addEventListener('click',()=>{state.facility=item.id;paintFacility();paintTeam();});$('facilityGrid').append(button);}}
function paintTeam(){const list=$('teamList');list.replaceChildren();if(state.facility==='factory'){const message=document.createElement('p');message.textContent='Você receberá seis Pokémon alugados; escolha três antes da primeira batalha.';list.append(message);return;}
 for(const mon of state.self?.team||[]){const label=document.createElement('label'),input=document.createElement('input'),span=document.createElement('span');input.type='checkbox';input.checked=state.teamIds.includes(mon.id);input.disabled=!mon.hp||!mon.id;input.addEventListener('change',()=>{
  if(input.checked&&state.teamIds.length>=3){input.checked=false;tell('Escolha apenas três Pokémon.',true);return;}
  state.teamIds=input.checked?[...state.teamIds,mon.id]:state.teamIds.filter(id=>id!==mon.id);
 });span.textContent=`${mon.species} · Nv. ${mon.level} · ${mon.hp}/${mon.maxHp} HP`;label.append(input,span);list.append(label);}
}
function paintPass(){
 const pass=current().labPass;
 $('fwsLab').textContent=pass?`${pass.value} / 1000`:'0 / 1000';
 const list=$('passList');list.replaceChildren();
 if(!pass){const p=document.createElement('p');p.textContent='Entre no mundo para ver os seus registros.';list.append(p);return;}
 for(const entry of pass.facilities){
  const section=document.createElement('div');section.className='pass-entry';
  const label=document.createElement('div');label.className='pass-entry-label';
  const name=document.createElement('strong');name.textContent=names[entry.id]||entry.id;
  const progress=document.createElement('span');
  const medal=entry.symbol==='gold'?'🥇':entry.symbol==='silver'?'🥈':'—';
  progress.textContent=`${medal} · ${entry.best}/${entry.goal} ${entry.metric}`;
  label.append(name,progress);
  const track=document.createElement('div');track.className='pass-progress';
  const fill=document.createElement('span');fill.style.width=`${Math.max(0,Math.min(100,entry.performanceFraction*100))}%`;
  track.append(fill);section.append(label,track);list.append(section);
 }
}
function paintRun(){const run=current().active,battle=state.self?.battle;$('bp').textContent=String(current().labBP||0);$('records').textContent=String(Object.keys(current().labRecords||{}).length);
 $('labSymbols').textContent=String(Object.keys(current().labSymbols||{}).length)+'/7';paintPass();
 $('trainer').textContent=state.self?`${state.self.name} · ${state.self.badges}/8 insígnias · ${state.self.team?.length||0} Pokémon`:'Entre primeiro no mundo compartilhado.';
 $('start').disabled=!state.self||!!run;$('next').disabled=!run||!!battle||(run.facility==='pike'&&!!run.pikeDoors)||(run.facility==='pyramid'&&!!run.pyramidFloor);$('retire').disabled=!run||!!battle;
 $('runName').textContent=run?(names[run.facility]||run.facility):'Nenhum';$('runStatus').textContent=run?`${run.practice?'Treino sem recompensas':'Progresso LAB (não oficial)'} · ${run.streak} desafios concluídos · bloco ${run.block+1} · ${run.levelRule}${run.nextBrain?' · próximo: Frontier Brain '+run.nextBrain:''}${run.room?' · sala/andar '+run.room:''}`:'Nenhuma sequência ativa.';
 const doors=$('pikeDoors');doors.hidden=!run||run.facility!=='pike'||!!battle||!run.pikeDoors;
 if(!doors.hidden){$('pikeHint').textContent=`Pista da funcionária — porta ${run.pikeDoors.hint?.door+1}: ${run.pikeDoors.hint?.text||'Nenhuma pista'}`;
  $('doorButtons').replaceChildren();for(const d of run.pikeDoors.doors){const button=document.createElement('button');button.type='button';button.textContent=`🚪 Porta ${d.index+1}`;button.disabled=state.busy;button.addEventListener('click',()=>interact('next',{door:d.index}));$('doorButtons').append(button);}}
 const bracket=$('domeBracket');bracket.hidden=!run||run.facility!=='dome'||!run.domeBracket;
 if(!bracket.hidden){
  $('domeMatches').replaceChildren();
  for(const round of run.domeBracket.rounds){
   const row=document.createElement('p');const team=round.registered?.length?` · Inscrição: ${round.registered.join(', ')}`:'';
   row.textContent=`${round.completed?'✅':'⚔️'} Rodada ${round.round}: ${round.opponent}${team}`;
   $('domeMatches').append(row);
  }
  const lookup=new Map((run.domeBracket.entrants||[]).map(e=>[e.id,e.name]));
  for(const group of run.domeBracket.matches||[]){
   const details=document.createElement('details');details.className='bracket-details';
   const summary=document.createElement('summary');summary.textContent=`Chave completa · Rodada ${group[0]?.round||'?'} (${group.length} confronto${group.length===1?'':'s'})`;
   details.append(summary);
   for(const match of group){
    const row=document.createElement('p');
    const winner=match.winnerId?` · ${match.winnerId==='player'?'Vitória registrada':'Avanço simulado: '+(lookup.get(match.winnerId)||'?')}`:' · Pendente';
    row.textContent=`${lookup.get(match.firstId)||match.firstId} × ${lookup.get(match.secondId)||match.secondId}${winner}`;
    details.append(row);
   }
   $('domeMatches').append(details);
  }
 }
 const pyramidExplore=$('pyramidExplore');pyramidExplore.hidden=!run||run.facility!=='pyramid'||!!battle||!run.pyramidFloor;
 if(!pyramidExplore.hidden){const floor=run.pyramidFloor;$('pyramidMap').replaceChildren();
  for(const cell of floor.cells){const tile=document.createElement('span');tile.className='pyramid-tile';tile.title=`${cell.x},${cell.y}`;
   const here=cell.x===floor.position.x&&cell.y===floor.position.y;
   tile.textContent=here?'🧢':({unknown:'·',wall:'⬛',exit:'🟦',start:'▫️',item:'🎒',trainer:'⚔️',wild:'🌿',status:'❗',empty:'▫️'})[cell.kind]||'▫️';
   tile.setAttribute('aria-label',here?'Sua posição':cell.kind);$('pyramidMap').append(tile);}
  $('pyramidDirections').replaceChildren();for(const [direction,caption] of [['north','⬆ Norte'],['west','⬅ Oeste'],['east','➡ Leste'],['south','⬇ Sul']]){
   const button=document.createElement('button');button.type='button';button.textContent=caption;button.disabled=state.busy;button.addEventListener('click',()=>interact('explore',{direction}));$('pyramidDirections').append(button);}
 }
 $('events').replaceChildren();for(const message of run?.events||[]){const p=document.createElement('p');p.textContent=message;$('events').append(p);}
 const lineup=$('lineup');lineup.hidden=!run||!!battle||!['factory','dome'].includes(run.facility)||(run.facility==='factory'&&run.lineupLocked);
 if(!lineup.hidden){
  const pool=run.facility==='factory'?run.rentals||[]:(state.self.team||[]).filter(m=>run.registeredTeamIds?.includes(m.id));
  const count=run.facility==='factory'?3:2;
  $('lineupTitle').textContent=run.facility==='factory'?'Escolher 3 dos 6 Pokémon alugados':'Escolher 2 dos 3 Pokémon registrados';
  $('lineupHint').textContent=run.facility==='factory'?'A seleção fica travada após a primeira partida.':'Você poderá alterar a dupla entre as partidas do torneio.';
  const selected=new Set(run.selectedTeamIds||[]);$('lineupOptions').replaceChildren();
  for(const mon of pool){const label=document.createElement('label'),input=document.createElement('input'),span=document.createElement('span');
   input.type='checkbox';input.value=mon.id;input.checked=selected.has(mon.id);input.disabled=mon.hp<=0;
   span.textContent=`${mon.species} · Nv. ${mon.level} · ${mon.hp}/${mon.maxHp} HP`;
   label.append(input,span);$('lineupOptions').append(label);}
  $('confirmLineup').textContent=`Confirmar ${count} Pokémon`;
 }

 const pyramid=$('pyramidBag');pyramid.hidden=!run||run.facility!=='pyramid'||!!battle;
 if(!pyramid.hidden){$('potionCount').textContent=`${run.battleBag?.potions||0} Potions restantes`; $('usePotion').disabled=!run.battleBag?.potions;
  $('potionPokemon').replaceChildren();for(const mon of state.self.team||[]){if(mon.hp<=0||mon.hp>=mon.maxHp)continue;const option=document.createElement('option');option.value=mon.id;option.textContent=`${mon.species}: ${mon.hp}/${mon.maxHp} HP`;$('potionPokemon').append(option);}}
 const factory=$('factory');factory.hidden=!run||run.facility!=='factory'||!run.swaps?.length||!!battle;
 if(!factory.hidden){$('swapOld').replaceChildren();for(const mon of (run.rentals||[]).filter(m=>run.selectedTeamIds?.includes(m.id))){const opt=document.createElement('option');opt.value=mon.id;opt.textContent=`${mon.species} · ${mon.hp}/${mon.maxHp} HP`;$('swapOld').append(opt);}
  $('swapNew').replaceChildren();for(const species of run.swaps){const opt=document.createElement('option');opt.value=species;opt.textContent=species;$('swapNew').append(opt);}}
 $('battlePanel').hidden=!battle;if(battle)paintBattle(battle);
}
function paintBattle(b){const pool=current().active?.facility==='factory'?(current().active?.rentals||[]):state.self?.team||[];
 const own=pool.find(m=>m.id===b.activePokemonId)||pool.find(m=>m.hp>0)||pool[0];
 const player=own;
 $('myMon').textContent=player?`🟩 ${player.species} · Nv. ${player.level} · ${player.hp}/${player.maxHp} HP`:'Escolha um Pokémon';
 $('foeMon').textContent=b.enemy?`🟥 ${b.trainerName?b.trainerName+' · ':''}${b.enemy.species} · Nv. ${b.enemy.level} · ${b.enemy.hp}/${b.enemy.maxHp} HP`:'Adversário';
 $('moveButtons').replaceChildren();if(b.frontierFacility==='palace'){const button=document.createElement('button');button.className='primary';button.type='button';button.textContent='Avançar turno — golpe automático';button.disabled=state.busy;button.addEventListener('click',()=>action({type:'move',move:own?.moves?.[0]||'Struggle'}));$('moveButtons').append(button);}
 else for(const move of own?.moves||[]){const button=document.createElement('button');button.type='button';const pp=own.pp?.[move];
  button.textContent=pp===undefined?move:`${move} · PP ${pp}`;
  button.disabled=state.busy||(pp!==undefined&&pp<=0);
  button.addEventListener('click',()=>action({type:'move',move}));$('moveButtons').append(button);}
 if((!own?.moves?.length||(own.moves||[]).every(m=>(own.pp?.[m]??1)<=0))&&b.frontierFacility!=='palace'){const button=document.createElement('button');button.textContent='Struggle (sem PP)';button.addEventListener('click',()=>action({type:'move',move:'Struggle'}));$('moveButtons').append(button);}
 $('switchButtons').replaceChildren();if(b.frontierFacility!=='arena'&&b.frontierFacility!=='factory'){for(let i=0;i<(state.self.team||[]).length;i++){
  const m=state.self.team[i];if(m.hp<=0||!b.selectedTeamIds?.includes(m.id))continue;
  const button=document.createElement('button');button.textContent=`Trocar: ${m.species}`;button.addEventListener('click',()=>action({type:'switch',move:i}));$('switchButtons').append(button);}}
 $('battleLog').replaceChildren();for(const row of b.log||[]){const p=document.createElement('p');p.textContent=row;$('battleLog').append(p);}
}
function accept(data){if(data.self){state.self=data.self;paintRun();paintFacility();paintTeam();}}
async function action(body){if(state.busy)return;state.busy=true;try{const data=await api('battle/action',body);accept(data);
  tell((data.result?.log||[]).slice(-1)[0]||'Ação concluída.');}catch(e){tell(e.message,true);}finally{state.busy=false;if(state.self)paintRun();}}
async function interact(command,body={}){if(state.busy)return;state.busy=true;try{const data=await api('frontier/'+command,body);accept(data);
  tell(command==='start'?'Desafio iniciado.':command==='next'||command==='explore'?(data.result?.event?'Evento: '+data.result.event:'Batalha iniciada.'):'Operação realizada.');
 }catch(e){tell(e.message,true);}finally{state.busy=false;if(state.self)paintRun();}}
$('start').addEventListener('click',()=>interact('start',{facility:state.facility,mode:$('mode').value,levelRule:$('levelRule').value,practice:$('practice').checked,teamIds:state.teamIds}));
$('next').addEventListener('click',()=>interact('next'));
$('retire').addEventListener('click',()=>{if(confirm('Abandonar o desafio atual?'))interact('retire')});
$('swap').addEventListener('click',()=>interact('swap',{oldId:$('swapOld').value,newSpecies:$('swapNew').value}));
$('usePotion').addEventListener('click',()=>interact('use-item',{item:'potion',pokemonId:$('potionPokemon').value}));
$('confirmLineup').addEventListener('click',()=>{
 const run=current().active,count=run?.facility==='factory'?3:2;
 const chosen=[...$('lineupOptions').querySelectorAll('input:checked')].map(x=>x.value);
 if(chosen.length!==count){tell(`Escolha exatamente ${count} Pokémon.`,true);return;}
 interact('select-lineup',{teamIds:chosen});
});
$('refresh').addEventListener('click',async()=>{try{const data=await api('frontier');if(state.self){state.self.frontier=data;paintRun();paintFacility();paintTeam();}tell('Dados atualizados.')}catch(e){tell(e.message,true)}});
paintFacility();
(async()=>{try{await api('frontier');state.source=new EventSource('/api/stream');state.source.addEventListener('snapshot',ev=>{try{const data=JSON.parse(ev.data);accept(data)}catch{}});
 state.source.onopen=()=>{$('connection').textContent='Servidor conectado';};state.source.onerror=()=>{$('connection').textContent='Reconectando…';};
 }catch(e){$('connection').textContent='Sem sessão';tell('Abra primeiro o mundo compartilhado e crie sua sessão de treinador. '+e.message,true);}})();
