# Pokémon Emerald Living — V2: caminhada natural

- Sprites oficiais de Brendan e May: quadros de frente, costas e laterais ligados à direção de movimento real (16×32 px por quadro).
- A alternância entre parado e passo ocorre apenas durante a travessia de um bloco; ao parar, o último sentido permanece correto.
- Movimento interpolado do centro do bloco A até o centro do bloco B, sem diagonais, sem animação de rotação e sem saltos durante a mesma etapa.
- Mesmo com o simulador acelerado, cada bot respeita um intervalo mínimo real entre duas células.
- A busca de caminho prefere seguir na direção atual entre caminhos igualmente curtos, reduzindo curvas gratuitas.
- Personagens deixam de circular aleatoriamente dentro de interiores e param no local da missão até o evento acontecer.
- Missões, ginásios, colisões, Pokémon, PC, Pokédex, imagem dos créditos e rótulo V2 preservados.

**Limites:** a geometria vem dos arquivos oficiais consultados via rede. Algumas conexões complexas e eventos da história ainda não estão completos; esta correção não os implementa nem promete uma emulação exata da ROM.
