# 🔴 EMERALD LIVING WORLD — VERSÃO 2
-# __**✦ Atualização — Meu Treinador IA + Tema Vermelho e Preto**__

**🧢﹒SEU PRÓPRIO TREINADOR AUTOMÁTICO**
-# ✦ Agora você pode criar um treinador que participa da simulação como os outros bots.
-# ✦ Escolha o nome e seu inicial: **Treecko, Torchic ou Mudkip**.
-# ✦ Defina o estilo da IA: equilibrado, ofensivo, defensivo ou focado em capturas.
-# ✦ Escolha a prioridade: avançar na história, treinar, capturar, desafiar treinadores ou explorar.
-# ✦ Sua IA acompanha o roteiro de Hoenn, podendo batalhar e evoluir durante a jornada.
-# ✦ Veja seu time, a localização, os objetivos e as batalhas na aba **Meu Bot**.

**🎮﹒MODOS DE JOGO**
-# ✦ **Seu Treinador + IAs:** viva sua jornada ao lado dos outros treinadores.
-# ✦ **Simulação das IAs:** acompanhe o mundo e as batalhas automáticas.
-# ✦ **Sua IA na História:** somente seu treinador avança; os demais ficam pausados.
-# ✦ Escolha a quantidade de bots antes de iniciar.

**🎨﹒NOVA IDENTIDADE VISUAL**
-# ✦ Site reformulado com cores **vermelhas e pretas**.
-# ✦ Painéis, botões, menus, seleção de modos e créditos renovados.
-# ✦ Interface adaptada para celular.

**📁﹒ARQUIVOS E PROGRESSO**
-# ✦ Estrutura reorganizada: só **index.html** na raiz, com o restante na pasta **jogo/**.
-# ✦ Saves do navegador e a campanha manual anterior continuam disponíveis.
-# ✦ Os mapas oficiais continuam carregando os dados do projeto Pokémon Emerald.

**🛠️﹒EM DESENVOLVIMENTO**
> Algumas transições e eventos especiais ainda precisam de validação nos mapas reais. O projeto continua recebendo melhorias.

-# __**EMERALD LIVING WORLD · V2**__
-# Criado por **André “Dezin”**.
