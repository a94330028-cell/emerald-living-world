# Emerald Living World — versão 2, correção dos ginásios

**Mapas originais do pret/pokeemerald:**

1. Roxanne — `RustboroCity_Gym`
2. Brawly — `DewfordTown_Gym`
3. Wattson — `MauvilleCity_Gym`
4. Flannery — `LavaridgeTown_Gym_1F` (também existe `LavaridgeTown_Gym_B1F`)
5. Norman — `PetalburgCity_Gym`
6. Winona — `FortreeCity_Gym`
7. Tate & Liza — `MossdeepCity_Gym`
8. Juan — `SootopolisCity_Gym_1F` (também existe `SootopolisCity_Gym_B1F`)

O simulador agora separa identificador exato do mapa e nome amigável exibido. A missão aguarda o bot chegar ao mapa certo e o combate do líder exige estar fisicamente no ginásio. As ligações entre regiões são planejadas, mas **só são atravessadas quando o arquivo oficial comprova conexão/porta**; locais com transporte ou script especial podem ficar bloqueados até serem programados. Os mapas continuam carregados do GitHub: sem conexão com a internet, não haverá imagens.

**Atenção:** o caminho marítimo, Surf/Dive, transporte de Mr. Briney, ginásios com puzzles complexos e eventos roteirizados ainda precisam de implementação específica; não são equivalentes ao motor completo da ROM. O ZIP não inclui uma cópia local de todos os tilesets.
