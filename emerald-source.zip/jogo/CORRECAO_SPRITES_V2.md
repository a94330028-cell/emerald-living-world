# Emerald Living V2 — sprites oficiais adaptados a partir dos arquivos enviados

## O que mudou
- As imagens fornecidas de Brendan e May foram recortadas em folhas transparentes de 48×128 pixels, com 12 quadros de 16×32 cada.
- Cada direção tem seu próprio conjunto de parada e animação: baixo, cima, esquerda e direita.
- O renderizador usa arquivos locais em `assets/overworld/` e NÃO precisa adivinhar a ordem de quadros do GitHub para mostrar a caminhada.
- Os personagens mantêm a direção do último passo quando param.
- Os arquivos da campanha, Pokédex, PC, EVs, batalhas, créditos do criador e save não foram modificados.
- Crédito dos sprites de referência: soulcaliburfan (Brendan), Marnic (May), conforme indicado nas folhas fornecidas.

## Limitações
- As imagens enviadas são uma montagem com texto e outros elementos; os quadros de caminhada foram selecionados manualmente. Outras poses (bicicleta, surf, pesca) não foram integradas.
- A correção é de direção e animação. A progressão física da história ainda pode exigir ajustes adicionais de navegação.
- Teste no Android após atualização do cache do navegador; os nomes versionados dos scripts ajudam no cache-busting.
