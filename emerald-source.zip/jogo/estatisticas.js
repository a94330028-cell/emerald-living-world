(()=>{'use strict';const c=window.EMERALD_CLOUD_CONFIG||{},base=String(c.supabaseUrl||'').replace(/\/+$/,''),key=String(c.supabaseAnonKey||'');
const $=id=>document.getElementById(id);const num=n=>Number(n||0).toLocaleString('pt-BR');
function card(title,value){const a=document.createElement('article'),v=document.createElement('strong'),h=document.createElement('span');a.className='stat';v.textContent=value;h.textContent=title;a.append(v,h);$('publicMetrics').append(a)}
(async()=>{if(!/^https:\/\/[^/]+\.supabase\.co$/.test(base)||key.length<15){$('statsStatus').textContent='As estatísticas mundiais serão exibidas após a ativação do Supabase.';return}
 try{const r=await fetch(base+'/functions/v1/public-stats',{headers:{apikey:key,Authorization:'Bearer '+key},cache:'no-store'});if(!r.ok)throw Error('Sem conexão com o serviço de estatísticas.');const d=await r.json();
 $('statsStatus').textContent='Dados agregados · última consulta: '+new Date(d.generatedAt).toLocaleString('pt-BR');
 card('Treinadores com ranking mundial',num(d.participatingTrainers));card('Contas cadastradas',num(d.accounts));card('Capturas registradas com permissão',num(d.captures));card('Campanhas concluídas registradas',num(d.finishedCampaigns));card('IAs máximas por mundo',num(d.aiTrainersPerSimulation));card('Batalhas registradas',d.reportedBattles==null?'Não medido':num(d.reportedBattles));
 $('starterRanks').textContent='';if(!d.topStarters?.length){$('starterRanks').textContent='Aguardando partidas com coleta autorizada.';return}
 for(const x of d.topStarters){const row=document.createElement('p');row.textContent=x.name+': '+num(x.total)+' escolhas';$('starterRanks').append(row)}
 }catch(e){$('statsStatus').textContent='Estatísticas indisponíveis: '+e.message}})();
})();
