# Emerald Living World — Versão 2 | Meu Treinador IA

- Organização: somente `index.html` na raiz; jogo e recursos dentro de `jogo/`.
- Tema vermelho e preto, com painéis e créditos no novo visual.
- Novo treinador automático: nome, Treecko/Torchic/Mudkip, prioridade e estilo de batalha.
- O seu treinador é um dos bots da simulação, caminha e segue a campanha de Hoenn.
- Modos: seu bot com IAs, transmissão de IAs ou só seu bot com os demais pausados.
- Escolhas editáveis na aba Meu bot; Pokémon inicial só entra quando a história chegar ao Prof. Birch.
- Save anterior de bots e a campanha manual continuam no mesmo domínio e não são apagados.
- Os arquivos oficiais continuam carregando do repositório original quando necessários; o projeto não emula a ROM.
- Eventos, mar e ginásios especiais ainda não estão todos reproduzidos exatamente.
