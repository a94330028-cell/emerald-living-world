# Emerald Living World V2 — Correção de áreas travadas

## Corrigido nesta entrega

- Blocos de escadas, passagens e pisos com movimento especial não são mais automaticamente tratados como água/parede.
- Água exige a condição de progressão simulada: o bot pode usar travessia após a quinta insígnia; mapas submersos são tratados em modo de mergulho.
- Cálculo de caminho, escolha de porta, passagens de borda, pontos da missão e desembarque usam o mesmo modo de locomoção, evitando discordância entre planejamento e movimento.
- Entradas com colisão são acionadas somente depois de o bot alcançar um piso adjacente válido.
- Ao trocar de mapa, o bot procura um piso válido perto da porta correspondente, em vez de aparecer sempre uma casa abaixo dela.
- O grafo de navegação inclui destinos anteriormente ausentes da história, como Granite Cave, cable car, Mt. Pyre, esconderijos, Seafloor Cavern, Sky Pillar e acesso à Liga.
- Conexões e portas adicionais descobertas pelo `map.json` entram no grafo de navegação.
- Viagens marítimas de Mr. Briney podem partir de Dewford/Route 109 em uma margem acessível no simulador.
- Quando o servidor dos mapas oficiais não responder, entra um mapa alternativo de recuperação claramente identificado, com corredores e entradas caminháveis, em vez de parar todas as IAs.
- Quando o mapa oficial carregar, mas o tileset gráfico falhar, o jogo preserva a geometria e desenha uma representação simplificada.
- O progresso salvo, escolhas do bot, batalhas e demais páginas não são apagados.

## Validação

Testes isolados em Node.js com a fonte de mapas simuladamente indisponível:
- Entrada e conclusão de evento nos **8 ginásios**: passou.
- Acesso aos mapas de Granite Cave, cable car, Mt. Pyre, Seafloor Cavern, Sky Pillar, hideouts e Liga: passou.
- Tiles especiais que antes eram confundidos com paredes: passou.
- Água bloqueada a pé e acessível em modo de travessia: passou.
- Sintaxe JavaScript: passou.

## Limitações

O simulador não é a ROM completa de Pokémon Emerald; puzzles específicos, scripts condicionais e eventos originais ainda podem exigir implementações próprias. Testes em grades de recuperação **não garantem** que todos os mapas reais remotos tenham passagem sem erros. O ambiente bloqueou o navegador automatizado com `ERR_BLOCKED_BY_ADMINISTRATOR`; o teste visual online e no Android precisa ser realizado após publicação.

**Importante:** os mapas simplificados exibidos durante falha de internet são **adaptações**, não os gráficos oficiais. Com conexão e arquivos oficiais disponíveis, a navegação prioriza `map.bin` e os tilesets originais.
