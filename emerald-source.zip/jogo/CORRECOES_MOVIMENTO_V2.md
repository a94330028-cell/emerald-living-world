# Versão 2 — correções de animação e história

- Bots caminham pela conexão ou porta original até a missão, sem saltar diretamente para outra região quando o grafo não encontra caminho.
- Eventos só avançam após a IA alcançar o mapa correspondente. Se não houver ligação oficial disponível, a IA espera e exibe o erro — não finge viagem.
- Portas aleatórias removidas da navegação automática; as missões têm prioridade sobre passeios.
- Entradas só são ativadas no bloco exato de `warp_events`.
- Animação dos treinadores usa quadros indexados por direção e avança apenas enquanto o personagem se desloca.
- Interpolação de posição evita saltos visuais durante cada movimento entre blocos.
- Em salas lotadas, apenas 14 avatares são desenhados para preservar legibilidade e FPS. Os demais **continuam simulados**; a contagem total permanece visível.
- Etapas iniciais têm inícios espaçados. Nenhum dado de batalha, time, EVs ou Pokédex foi removido.
- Limitação: não existe um grafo físico completo para todos os trechos marítimos e roteiros avançados. Nessas situações a IA aguardará a integração da rota, sem teletransportar.
- Arquivos oficiais continuam hospedados no GitHub e dependem de rede; esta compilação não contém toda a ROM.
