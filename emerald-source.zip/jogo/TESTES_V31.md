# Testes realizados — v31

**Passaram:**

- `node --check` nos 10 scripts JS.
- Referências locais de arquivos JS, CSS e imagens nos dois HTMLs.
- Decodificação de PNG indexado de teste (128 × 8).
- Leitura simulada de `map.bin` em little-endian, teste de bits de colisão e dimensões.
- Busca de rota contornando bloco bloqueado (BFS) sem atravessar a parede.
- 160 ticks de uma IA em mapas simulados, todos os passos dentro de área passável.
- Transição entre Littleroot Town e Route 101, via conexão do `map.json` simulado.
- Entrada na casa de Brendan por um `warp_event` simulado.
- Validação de URLs locais em `index.html` e `mapas-oficiais.html`.

**Não foi possível testar:**

- Descarga completa e renderização real de cada tileset do GitHub no navegador deste ambiente. O Chromium recusou a navegação ao servidor local com `ERR_BLOCKED_BY_ADMINISTRATOR`.
- Os centenas de mapas originais, scripts, puzzles, comportamento de NPCs, água, HM, portas condicionais e puzzles de elevação.
- Desempenho de centenas de mapas e dezenas de IAs em Android real conectado à internet.
- Publicação online no Cloudflare Pages (usuário precisa fazer o deploy).

Os testes simulados verificam a lógica implementada, **não** certificam equivalência completa ao jogo original.
