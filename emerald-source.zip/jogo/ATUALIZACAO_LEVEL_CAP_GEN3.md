# 🌿 Emerald Living World — Progressão, campanha e batalhas (atualização)

Esta atualização parte da versão com **mapas e portas corrigidos** e mantém os arquivos de sprites, estilos e menus anteriores.

## Regras novas

- **Level Cap independente para cada bot:** 0 insígnias = 15; 1 = 19; 2 = 24; 3 = 29; 4 = 31; 5 = 33; 6 = 42; 7 = 46; 8 = 58; Campeão = 100. O limite é obrigatório, inclusive nos presets Clássico/Colecionador.
- Chegar ao teto **zera a experiência excedente**. Aumentar o número de insígnias desbloqueia a progressão normal, sem pulos de níveis acumulados.
- Atributos HP, Ataque, Defesa, Velocidade, Ataque Especial e Defesa Especial calculados a partir de **base stats + nível + IVs + EVs + Nature**, usando a fórmula da geração III. Cada Pokémon captura IVs e Nature próprios; EVs são concedidos por vitória e limitados a 510 no total / 255 por atributo.
- Atributos são recalculados ao subir de nível e evoluir, sem curar artificialmente Pokémon desmaiados.
- Dano considera ataque e defesa calculados, tipos, imunidades, STAB, clima compatível, crítico ×2, variação aleatória e a divisão físico/especial por tipo da geração III.
- Novos golpes com estatísticas de batalha (como Calm Mind, Bulk Up, Swords Dance, Thunder Wave, Toxic, Recover), reajustes de PP e aprendizagem baseada em nível para algumas linhas evolutivas. Respeita quatro movimentos por Pokémon, priorizando não perder golpes bons.
- Evoluções por nível, por pedras compradas durante a jornada, amizade simplificada e uma regra de substituição para trocas indisponíveis na simulação.
- Missões que antes eram só texto agora incluem diversos confrontos obrigatórios de Aqua, Magma, May/Brendan e Wally. No Space Center, os chefes são enfrentados sequencialmente, **não em dupla como na ROM original**.
- Ginásios usam os times dos líderes previstos, e os treinadores internos mais comuns usam elencos nomeados. As batalhas obrigatórias precisam ser vencidas antes da missão avançar.
- O save passa a guardar uma versão de esquema, IVs, EVs e Nature; continua compatível com saves locais antigos. O progresso é salvo em intervalos e também ao ocultar/fechar a aba quando o navegador permite.
- Mapa oficial continua sendo a primeira opção; se o carregamento falhar, a versão de recuperação entra após uma espera menor.

## Limites e diferenças em relação ao Emerald de GBA

Este é um **simulador em navegador**, não uma emulação da ROM. As regras de batalha melhoraram, mas o catálogo **ainda não é uma implementação completa** dos 386 Pokémon, de todos os movimentos, itens, habilidades, mudanças de status ou de todos os treinadores opcionais de Hoenn. Alguns learnsets e rendimentos de experiência são simplificados. Os Pokémon de treinadores e os chefes incluídos mantêm os níveis definidos na história; os encontros genéricos podem usar equipes geradas.

Os valores-base dos Pokémon já presentes no simulador foram preservados em geral, com correções importantes nas linhas evolutivas dos iniciais. Os mapas de recuperação não possuem todos os puzzles originais.

O save é local **no navegador e aparelho onde você joga**. Ele normalmente sobrevive a recarregamentos, mas pode ser apagado ao limpar dados do navegador ou trocar de aparelho. Use a opção **Exportar Save** antes de limpar dados ou mudar de host. Ao migrar saves antigos com Pokémon acima do limite, os níveis são ajustados ao teto do bot para obedecer às regras novas. Faça backup antes de atualizar.

## Como publicar

Publique o conteúdo do ZIP na raiz do seu site, preservando a pasta `jogo/` e o `index.html` principal. Depois, abra `/jogo/#jogo`. A atualização **não altera automaticamente** o site já hospedado.
