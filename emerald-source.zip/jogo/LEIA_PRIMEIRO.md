> **Atualização de movimentação (V2):** esta compilação possui recuperação de mapa quando a fonte oficial estiver indisponível, com identificação de cenário adaptado. Veja `CORRECAO_MAPAS_TRAVADOS_V2.md` para correções, testes e limites.

# Emerald Living World — Versão 2 | Cloudflare Pages

Esta versão integra o visualizador oficial de mapas ao **motor de movimentação das IAs**.

## Publicação

- Envie os arquivos na raiz do projeto Cloudflare Pages, com `index.html` na raiz.
- Os arquivos locais foram preparados como site estático.
- A simulação depende de conexão com o `raw.githubusercontent.com` para buscar dados oficiais de mapas e tilesets. Quando a rede está lenta ou o GitHub não responde, as IAs aguardam os arquivos em vez de atravessar um cenário fictício.
- Use o botão **🚧 Colisões** no painel de simulação para visualizar obstáculos e entradas em azul-claro. Use **Mapa inteiro** para observar o layout completo.
- O progresso salvo de versões anteriores continua usando a mesma chave (`emerald_living_world_v26`) e os campos de navegação são normalizados na importação.

## Correções técnicas herdadas da versão anterior

- Na atualização técnica anterior, o sprite do Brendan/May é carregado das pastas oficiais; o tamanho acompanha o zoom do mapa. O avanço dos capítulos não fica bloqueado indefinidamente esperando uma sala pequena permitir muitos passos.
- A travessia de bordas de salto é direcional (não é permitido subir uma borda que só permite descer).
- Depois, telhados e árvores das camadas superiores ficam **à frente dos personagens** onde o jogo original exige; não parece mais que o personagem caminha em cima do telhado.
- A segunda fileira das telhas comuns no tileset General recebe proteção extra de colisão. A primeira fileira pode ser atravessada por trás, como no Emerald original.

## Novidades

- Arquivos oficiais `map.json`, `layouts.json`, `map.bin`, `metatile_attributes.bin` e tilesets passam a alimentar tanto os caminhos das IAs quanto o mapa na transmissão.
- IAs andam entre blocos passáveis, recalculam trajetos e podem passar por portas e conexões de mapas que constam nos arquivos originais.
- Água profunda, cachoeiras, áreas com saltos e obstáculos especiais são bloqueados para caminhadas normais (sem Surfar / HMs).
- Encontros de Pokémon selvagens usam os tipos de terreno oficiais, não a grama do cenário artificial.
- O jogador continua com a campanha separada de batalhas e gestão de Pokémon, mas pode aparecer como marcador estático na etapa correspondente do mapa das IAs.
- Pokédex, PC, itens equipados, EVs e a simulação por IA existentes foram preservados.

## Limites importantes

- Não é um emulador de Pokémon Emerald: scripts originais, HM, Surf, objetos dinâmicos, cutscenes, movimento direcional especial, elevação exata e todas as portas condicionais não foram reproduzidos.
- Conexões dos mapas adjacentes e portas são físicas. Avanços para capítulos distantes, como travessias marítimas, ainda são tratados como viagem de história para um ponto passável no novo mapa; não são caminhos completos ponto a ponto.
- O motor usa mapas online, não uma cópia offline de todo o conteúdo original. Se o GitHub ficar indisponível, o terreno pode não carregar; isso não significa que o mapa foi testado.
- Os testes locais de colisão utilizaram arquivos oficiais simulados, não os arquivos reais baixados de toda Hoenn. Não foi possível testar visualmente o navegador neste ambiente. Nenhuma garantia de zero erros para os centenas de mapas reais.

Ver `CORRECOES_V33.md`, `CORRECOES_V32.md`, `TESTES_V31.md` e `README_MAPAS_OFICIAIS.md`.

## Apresentação da Versão 2

- Identificação pública do site: **Versão 2 (V2)**.
- Tela de créditos redesenhada com a imagem fornecida pelo criador (`assets/creditos-red-pikachu.jpg`).
- Nenhum arquivo de lógica de batalha, progressão ou simulação foi alterado nesta atualização visual.


## Correção de ginásios e nomes — V2
- Corrigidos os nomes oficiais dos oito ginásios, incluindo os dois níveis de Lavaridge e Sootopolis.
- O mapa só é carregado a partir do identificador confirmado em `data/maps/map_groups.json`.
- Missões e recuperações aguardam a chegada real ao local; não finalizam no instante da troca de destino.
- Para os gráficos reais é necessária conexão à fonte `pret/pokeemerald` do GitHub.
- Modos de transporte, HM Surf/Dive, cutscenes e puzzles de alguns ginásios seguem pendentes: alguns trajetos poderão aguardar implementação específica, em vez de teleportar.
- Colisões, eventos e funcionamento integral dos arquivos remotos NÃO foram testados em Cloudflare publicado.
- Títulos e créditos públicos continuam como Versão 2; não apague o armazenamento do navegador se quiser preservar saves.

## Correção de IAs paradas nas portas — V2

Atualização do cálculo de acesso aos `warp_events` oficiais para que uma porta com célula de colisão não deixe os treinadores parados na calçada. A transição só é ativada quando o bot alcança o limiar da entrada por um caminho caminhável. Veja `CORRECAO_PORTAS_E_TRAVAMENTOS_V2.md`.

**Verificação:** o teste isolado de porta bloqueada reproduziu o defeito na versão anterior e passou na nova. Também passaram os testes de saída da casa, ida à Rota 101, bloqueio de paredes e direção dos sprites. A validação visual completa no Android/Cloudflare ainda é necessária.
