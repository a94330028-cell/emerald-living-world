# Emerald Living World — V2, campanha e batalhas

## Novidades

- **Minha campanha / Jogar:** 8 capítulos narrativos, com 126 etapas: eventos, encontros, treinadores de rotas, 8 ginásios e 5 confrontos da Liga. As equipes dos adversários seguem o roteiro que o autor forneceu.
- **Batalhas do jogador:** escolha de golpes por turno, troca do Pokémon ativo, itens, captura de selvagens, narração, PP e HP. Um botão de desafio agora posiciona o combate na tela do celular.
- **Transmissão de IAs:** na aba *IAs ao vivo*, use **📺 Assistir batalhas** para escolher um duelo, acompanhar turnos, HP, Pokémon e últimas ações. Até 40 combates recentes são mantidos **na sessão atual**.
- **Caminhos das IAs:** a missão só é marcada após o personagem caminhar dentro do mapa até um ponto de evento, quando os dados oficiais permitem navegar. O trajeto de Mr. Briney é tratado como viagem marítima após a missão correspondente.
- **Mapa mais legível:** a câmera desenha até 7 IAs em interiores e 16 ao ar livre, mas o motor segue simulando o restante dos treinadores.
- **Créditos e versão pública:** permanecem V2 e Dezin, com a imagem do Red e do Pichu.

## Como publicar no Cloudflare Pages

1. Faça backup do progresso em **Jogar → Exportar campanha (.json)**. Salve também um backup do simulador se houver a opção no painel.
2. Abra **Cloudflare → Workers & Pages → seu projeto → Create deployment** e envie o ZIP deste pacote, com `index.html` na raiz.
3. Recarregue a página. Se aparecer uma versão antiga, force recarga no navegador Android ou teste em aba privativa antes de mexer no save.
4. Use **Jogar** para sua campanha e **IAs ao vivo → 📺 Assistir batalhas** para observar o mundo.

## Importante: limites da versão

- Este site **não é um emulador da ROM Pokémon Emerald**. As batalhas têm regras simplificadas; alguns treinadores e equipes são baseados no guia do autor, e não foram confrontados um por um com os dados de treinador do jogo original. A batalha de Tate e Liza, por exemplo, não reproduz todos os detalhes de batalha dupla da terceira geração.
- **Campanha do jogador**: deslocamentos entre eventos são narrados/automatizados; o jogador controla as batalhas e seu time. **Campanha das IAs**: utiliza colisões oficiais, portas e conexões quando disponíveis, mas viagens de Surf/Dive, quebra-cabeças, scripts especiais e toda a história ainda não são fiéis à ROM.
- Os mapas e algumas imagens são carregados do repositório `pret/pokeemerald` em tempo de execução. Se não houver conexão ou um caminho remoto mudar, certos mapas podem não abrir. Não avance uma missão se o mapa necessário não carregar.
- Saves são guardados no navegador por origem. Mudar o domínio ou apagar os dados do navegador pode fazer um save parecer perdido. A importação/exportação da campanha humana está no menu Jogar.
- O histórico das batalhas das IAs é temporário. Ele não é um servidor de transmissão 24 horas por dia; as IAs só simulam enquanto a página está rodando.

## Testes feitos nesta entrega

- `node --check` para todos os scripts, incluindo o roteiro.
- Navegação simulada com colisões: interior da casa, porta oficial, saída, Route 101 e bloqueio de parede comum.
- Teste no navegador: oito capítulos, 126 etapas, escolha de inicial e início de combate com golpes.
- Teste no navegador: abertura/fechamento da área de transmissão com uma IA em batalha.
- **Não houve teste de ponta a ponta de todos os 126 eventos com mapas oficiais em um deploy público no Cloudflare.**
