# Testes da correção de direção V2

Verificado com Node.js:
- Sintaxe de js/official-runtime.js, js/world.js e js/engine.js: OK.
- Sprites de Brendan/May (9 quadros): idle nas quatro direções e quadros de caminhada: OK.
- Permanecer olhando à esquerda depois de parar, mesmo que código externo altere walkDir para frente: OK.
- Permanecer olhando para cima após a parada e depois de carregar outro mapa: OK.
- Movimentação ortogonal em 40x e saída para Rota 101 em mapa simulado: OK.
- Interiores: sem caminhada circular repetida durante a espera por um evento em mapa simulado: OK.

Limites:
- O ambiente bloqueou a abertura do site pelo Chromium e a obtenção dos gráficos oficiais. Não foi possível validar visualmente no Cloudflare ou em cada mapa real.
- As outras limitações da campanha (regras de puzzles/eventos especiais) permanecem.
