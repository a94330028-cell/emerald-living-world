# Emerald Living V2 — direção de caminhada e deslocamento

- Os sprites oficiais continuam sendo carregados do repositório pret/pokeemerald.
- Brendan e May conservam a orientação do último passo ao parar, entrar em batalha, esperar por evento ou aguardar dados de mapa.
- O renderizador só vira o avatar quando há movimento real de exatamente uma célula.
- Corrigidos os quadros de caminhar com 9 frames originais (incluindo a alternância do pé na caminhada para baixo).
- A missão escolhe um ponto próximo e caminhável, reduzindo a tendência de ficar circulando em torno dos mesmos objetos.
- Saves antigos continuam válidos. O site continua identificado como V2.

Os mapas oficiais são carregados da rede, portanto uma falha de conexão ainda pode paralisar a caminhada; sem os dados, o motor não inventa atravessamentos.
