/* Emerald Living World 2.9 — bordas sem espelhos nem sprites inventados.
 * A paisagem extra é SOMENTE visual, nunca entra no mapa, save ou colisão.
 * Para terra, usar apenas uma mancha validada de COPAS DO tileset oficial
 * já renderizado (Route101), repetida na grade original de 16px.
 * Enquanto o gráfico não estiver disponível, usar uma cor lisa: jamais
 * copiar caminhos, edifícios, flores ou outros objetos da borda.
 */
(function(root,factory){
 'use strict';const api=factory();
 if(typeof module==='object'&&module.exports)module.exports=api;
 if(root)root.EmeraldEdgeScenery=api;
})(typeof window==='object'?window:undefined,function(){
 'use strict';
 const TILE=16,PATCH=64;
 const SEA_ROUTES=new Set([105,106,107,108,109,124,125,126,127,128,129,130,131,132,133,134]);
 const ROCK_AREAS=new Set(['SootopolisCity','JaggedPass','MtChimney','LavaridgeTown','Route111','Route112','Route113','Route114','Route115']);
 const SEA_TOWNS=new Set(['DewfordTown','MossdeepCity','PacifidlogTown','EverGrandeCity']);
 const colors={forest:'#397e59',sea:'#2878a4',rocky:'#777461'};
 const sourceName='Route101';
 let forestPatch=null,forestSource=null,lastCheck=0;
 const mod=(a,n)=>((a%n)+n)%n;
 function biomeForName(name){
  const n=String(name||''),m=/^Route(\d+)$/.exec(n);
  return ROCK_AREAS.has(n)?'rocky':SEA_TOWNS.has(n)||(m&&SEA_ROUTES.has(Number(m[1])))?'sea':'forest';
 }
 const inside=(x,y,r)=>x>=r.x&&y>=r.y&&x<r.x+r.width&&y<r.y+r.height;
 function nearestRect(x,y,rects){
  let best=null,distance=Infinity;
  for(const r of rects){
   const dx=x<r.x?r.x-x:x>=r.x+r.width?x-(r.x+r.width-1):0;
   const dy=y<r.y?r.y-y:y>=r.y+r.height?y-(r.y+r.height-1):0;
   const d=dx*dx+dy*dy;
   if(d<distance){distance=d;best=r}
  }
  return best;
 }
 function nearestBiome(x,y,rects){return biomeForName(nearestRect(x/TILE,y/TILE,rects||[])?.name)}
 // Verificar que a amostra é majoritariamente verde, texturizada, bloqueada
 // e sem superfícies claras de casas, caminhos ou construções.
 function patchScore(data,width,sx,sy,nav,cx,cy,official){
  let greenery=0,dark=0,light=0,grey=0,n=0,blocked=0;
  for(let ty=0;ty<4;ty++)for(let tx=0;tx<4;tx++){
   if(official?.walkable&&nav&&!official.walkable(nav,cx*16+sx/16+tx,cy*16+sy/16+ty))blocked++;
  }
  if(official?.walkable&&nav&&blocked<12)return -1;
  for(let y=sy;y<sy+PATCH;y+=4)for(let x=sx;x<sx+PATCH;x+=4){
   const at=(y*width+x)*4,r=data[at],g=data[at+1],b=data[at+2],a=data[at+3];
   if(a<200)return -1;
   n++;
   const green=g>r+11&&g>b+6&&g>44;
   if(green)greenery++;
   const l=(r+g+b)/3;
   if(green&&l<75)dark++;
   if(green&&l>104)light++;
   if(Math.abs(r-g)<15&&Math.abs(g-b)<15&&l>100)grey++;
  }
  if(greenery/n<.73||dark/n<.07||light/n<.1||grey/n>.13)return -1;
  return greenery/n*5+dark/n+light/n+blocked/16;
 }
 function extractForest(official){
  if(forestPatch||typeof document==='undefined'||!official?.ensureChunk)return;
  const now=Date.now();if(now-lastCheck<1300)return;lastCheck=now;
  const nav=official.cache?.get(sourceName)?.value;
  if(!nav||nav.fallback)return;
  let chosen=null,best=-1;
  // Não buscar uma Hoenn inteira por causa da decoração: no máximo três chunks.
  for(const [cx,cy] of [[0,0],[0,1],[1,0]]){
   if(cx*16>=nav.width||cy*16>=nav.height)continue;
   const tile=official.ensureChunk(sourceName,cx,cy)?.value;
   if(!tile?.base||tile.adapted)continue;
   const source=document.createElement('canvas');source.width=tile.base.width;source.height=tile.base.height;
   const c=source.getContext('2d',{willReadFrequently:true});c.imageSmoothingEnabled=false;
   c.drawImage(tile.base,0,0);if(tile.foreground)c.drawImage(tile.foreground,0,0);
   if(source.width<PATCH||source.height<PATCH)continue;
   let pixels;try{pixels=c.getImageData(0,0,source.width,source.height).data}catch{continue}
   for(let y=0;y<=source.height-PATCH;y+=16)for(let x=0;x<=source.width-PATCH;x+=16){
    const score=patchScore(pixels,source.width,x,y,nav,cx,cy,official);
    if(score>best){best=score;chosen={source,x,y,cx,cy}}
   }
  }
  if(chosen){forestPatch=document.createElement('canvas');forestPatch.width=forestPatch.height=PATCH;
   const c=forestPatch.getContext('2d');c.imageSmoothingEnabled=false;
   c.drawImage(chosen.source,chosen.x,chosen.y,PATCH,PATCH,0,0,PATCH,PATCH);
   forestSource={map:sourceName,chunk:[chosen.cx,chosen.cy],tile:[chosen.x/16,chosen.y/16]};
  }
 }
 function draw(ctx,camera,rectangles,{width=640,height=416,scale=2,official=null}={}){
  const stats={cells:0,trees:0,officialTiles:0,placeholders:0,sea:0,rocks:0};
  if(!ctx||!camera||!Array.isArray(rectangles)||!rectangles.length)return stats;
  extractForest(official);
  const left=Math.floor(camera.x/TILE),top=Math.floor(camera.y/TILE);
  const right=Math.ceil((camera.x+width/scale)/TILE),bottom=Math.ceil((camera.y+height/scale)/TILE);
  ctx.save();ctx.imageSmoothingEnabled=false;
  for(let gy=top;gy<=bottom;gy++)for(let gx=left;gx<=right;gx++){
   if(rectangles.some(r=>inside(gx,gy,r)))continue;
   const region=nearestRect(gx,gy,rectangles);if(!region)continue;
   const biome=biomeForName(region.name),dx=Math.round((gx*TILE-camera.x)*scale),dy=Math.round((gy*TILE-camera.y)*scale);
   stats.cells++;
   if(biome==='sea')stats.sea++;
   if(biome==='rocky')stats.rocks++;
   if(biome==='forest'&&forestPatch){
    ctx.drawImage(forestPatch,mod(gx-region.x,4)*TILE,mod(gy-region.y,4)*TILE,TILE,TILE,dx,dy,TILE*scale,TILE*scale);
    stats.officialTiles++;stats.trees++;continue;
   }
   // Fallback limpo até os tiles oficiais chegarem: jamais espelhar mapa.
   ctx.fillStyle=colors[biome];ctx.fillRect(dx,dy,TILE*scale+1,TILE*scale+1);stats.placeholders++;
  }
  ctx.restore();return stats;
 }
 return Object.freeze({TILE,PATCH,SEA_ROUTES,SEA_TOWNS,ROCK_AREAS,biomeForName,nearestBiome,nearestRect,inside,patchScore,draw,source:()=>forestSource});
});
