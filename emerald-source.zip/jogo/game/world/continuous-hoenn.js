/* Emerald Living World — mundo lógico externo contínuo.
 * A geometria vem EXCLUSIVAMENTE de connections / direction / offset do
 * map.json oficial. Warps, cavernas, florestas e mergulho NÃO são costurados.
 * UMD para testes Node e execução no navegador, sem rede antecipada.
 */
(function(root,factory){
 'use strict';
 const api=factory();
 if(typeof module==='object'&&module.exports)module.exports=api;
 if(root)root.EmeraldContinuousHoenn=api;
})(typeof window==='object'?window:undefined,function(){
 'use strict';
 const outdoorNames=[
  'LittlerootTown','Route101','OldaleTown','Route103','Route102','PetalburgCity',
  'Route104','RustboroCity','Route105','Route106','DewfordTown','Route107',
  'Route108','Route109','SlateportCity','Route110','MauvilleCity','Route117',
  'VerdanturfTown','Route116','Route118','Route111','Route112','Route113',
  'FallarborTown','Route114','Route115','LavaridgeTown','JaggedPass','MtChimney',
  'Route119','FortreeCity','Route120','Route121','LilycoveCity','Route122',
  'Route123','Route124','Route125','MossdeepCity','Route126','Route127',
  'Route128','Route129','Route130','Route131','PacifidlogTown','Route132',
  'Route133','Route134','EverGrandeCity','SootopolisCity'];
 const OUTDOORS=new Set(outdoorNames);
 const DOORS=new Set(['PetalburgWoods','RusturfTunnel','GraniteCave_1F','FieryPath',
  'MeteorFalls_1F_1R','VictoryRoad_1F','MtPyre_1F','SeafloorCavern_Entrance']);
 const CARDINAL=new Set(['up','down','left','right']);
 const CHUNK_TILES=16;
 const isOutdoorName=name=>OUTDOORS.has(name);
 const isOutdoorMap=map=>!!map&&OUTDOORS.has(map.name)&&
  !['MAP_TYPE_INDOOR','MAP_TYPE_UNDERWATER','MAP_TYPE_UNDERGROUND'].includes(map.meta?.map_type);
 const targetFor=(from,edge,to)=>{
  if(!from||!to||!edge||!CARDINAL.has(edge.direction))return null;
  const offset=Number(edge.offset);
  if(!Number.isInteger(offset))return null;
  switch(edge.direction){
   case 'up':return {x:from.x+offset,y:from.y-to.height};
   case 'down':return {x:from.x+offset,y:from.y+from.height};
   case 'left':return {x:from.x-to.width,y:from.y+offset};
   case 'right':return {x:from.x+from.width,y:from.y+offset};
  }
  return null;
 };
 function createWorld(official,{maxConcurrent=2}={}){
  const positions=new Map(),pending=new Set(),queue=[],inflight=new Set();
  let component=0,activeComponent=0,rejected=0;
  const resolve=key=>official.mapName(key);
  const loaded=name=>official.cache.get(name)?.value||null;
  function place(name,x,y,group){
   const map=loaded(name);if(!isOutdoorMap(map)||positions.has(name))return false;
   positions.set(name,{name,x,y,width:map.width,height:map.height,component:group});
   return true;
  }
  function seed(name){
   name=official.resolve(name);const map=loaded(name);
   if(!isOutdoorMap(map))return null;
   if(!positions.has(name)){component++;place(name,0,0,component)}
   activeComponent=positions.get(name).component;
   recalculate();return positions.get(name);
  }
  // Descoberta em largura: jamais inferir um atalho por proximidade do nome
  // das rotas. Apenas conexões EXTERNAS do mapa oficial criam costura.
  function recalculate(){
   const todo=[...positions.keys()];
   for(let i=0;i<todo.length&&i<200;i++){
    const name=todo[i],source=loaded(name),origin=positions.get(name);
    if(!source||!origin)continue;
    for(const edge of source.meta?.connections||[]){
     if(!CARDINAL.has(edge.direction))continue;
     const neighbor=resolve(edge.map),dest=loaded(neighbor);
     if(!isOutdoorMap(dest))continue;
     const next=targetFor(origin,edge,dest);
     if(!next)continue;
     const old=positions.get(neighbor);
     if(old){
      if(old.component!==origin.component){
       // Componentes descobertos separadamente passam a compartilhar as
       // mesmas coordenadas quando uma borda oficial prova sua ligacao.
       const oldComponent=old.component,dx=next.x-old.x,dy=next.y-old.y;
       for(const p of positions.values())if(p.component===oldComponent){
        p.x+=dx;p.y+=dy;p.component=origin.component;
       }
       if(activeComponent===oldComponent)activeComponent=origin.component;
      }else if(old.x!==next.x||old.y!==next.y)rejected++;
      continue;
     }
     if(place(neighbor,next.x,next.y,origin.component))todo.push(neighbor);
    }
   }
  }
  function position(name){return positions.get(official.resolve(name))||null}
  function schedule(name){
   name=official.resolve(name);
   if(!OUTDOORS.has(name)||loaded(name)||pending.has(name))return false;
   pending.add(name);queue.push(name);pump();return true;
  }
  function pump(){
   while(inflight.size<maxConcurrent&&queue.length){
    const name=queue.shift();inflight.add(name);
    Promise.resolve().then(()=>official.ensureNav(name)).then(()=>recalculate())
     .catch(()=>{}).finally(()=>{pending.delete(name);inflight.delete(name);pump()});
   }
  }
  function prefetchNear(name,x,y,radius=34){
   name=official.resolve(name);const map=loaded(name);
   if(!isOutdoorMap(map))return;
   for(const edge of map.meta?.connections||[]){
    if(!CARDINAL.has(edge.direction))continue;
    const n=resolve(edge.map);
    if(!OUTDOORS.has(n))continue;
    const offset=Number(edge.offset)||0;
    // Só carregar mapas cuja borda conectada pode entrar na câmera ou
    // no próximo trecho; não requisitar todas as rotas de Hoenn.
    const distance=edge.direction==='up'?y:edge.direction==='down'?map.height-1-y:
     edge.direction==='left'?x:map.width-1-x;
    const orth=edge.direction==='up'||edge.direction==='down'?x-offset:y-offset;
    if(distance<=radius&&orth>=-radius&&orth<=(edge.direction==='up'||edge.direction==='down'?map.width:map.height)+radius)
     schedule(n);
   }
   recalculate();
  }
  function visible(camera,margin=0){
   const {x,y,width,height}=camera;
   return [...positions.values()].filter(o=>o.component===activeComponent&&loaded(o.name)&&
    o.x*16<(x+width+margin)&&o.y*16<(y+height+margin)&&
    (o.x+o.width)*16>x-margin&&(o.y+o.height)*16>y-margin);
  }
  function chunks(rect,camera,margin=0){
   const left=Math.max(0,Math.floor((camera.x-margin-rect.x*16)/(CHUNK_TILES*16)));
   const top=Math.max(0,Math.floor((camera.y-margin-rect.y*16)/(CHUNK_TILES*16)));
   const right=Math.min(Math.ceil(rect.width/CHUNK_TILES)-1,Math.floor((camera.x+camera.width+margin-rect.x*16)/(CHUNK_TILES*16)));
   const bottom=Math.min(Math.ceil(rect.height/CHUNK_TILES)-1,Math.floor((camera.y+camera.height+margin-rect.y*16)/(CHUNK_TILES*16)));
   const result=[];
   for(let cy=top;cy<=bottom;cy++)for(let cx=left;cx<=right;cx++)result.push({name:rect.name,cx,cy,
    x:(rect.x+cx*CHUNK_TILES)*16,y:(rect.y+cy*CHUNK_TILES)*16});
   return result;
  }
  const metrics=()=>({located:positions.size,activeComponent,pending:pending.size,inflight:inflight.size,
   inconsistentConnections:rejected,chunkTiles:CHUNK_TILES,outdoorCount:OUTDOORS.size});
  return {seed,position,loaded,prefetchNear,visible,chunks,recalculate,metrics,allPositions:()=>[...positions.values()]};
 }
 return Object.freeze({outdoorNames,OUTDOORS,DOORS,CARDINAL,CHUNK_TILES,isOutdoorName,isOutdoorMap,targetFor,createWorld});
});
