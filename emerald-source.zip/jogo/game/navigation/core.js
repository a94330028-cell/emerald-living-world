/* Emerald Living World | Navigation core v5
 * Pure, DOM-free tile navigation, reused by the official map runtime.
 * Only tiles with a verified collision flag are traversable. Special scripts,
 * badge-locked obstacles and NPC movement are not reconstructed here.
 */
(function(root){
 'use strict';
 const SEA=new Set([0x10,0x11,0x12,0x13,0x14,0x15,0x1a,0x1b,0x19,0x22]);
 const LEDGE_DIR={0x38:[1,0],0x39:[-1,0],0x3a:[0,-1],0x3b:[0,1],
   0x3c:[1,-1],0x3d:[-1,-1],0x3e:[1,1],0x3f:[-1,1]};
 const BLOCKED_DIR={0x30:[1,0],0x31:[-1,0],0x32:[0,-1],0x33:[0,1],
   0x34:[1,-1],0x35:[-1,-1],0x36:[1,1],0x37:[-1,1]};
 function infoAt(m,x,y){
   if(!m||!Number.isInteger(x)||!Number.isInteger(y)||x<0||y<0||x>=m.width||y>=m.height)return null;
   const v=m.blocks.getUint16(2*(y*m.width+x),true),id=v&1023;
   const attrs=id>=512?m.secondaryAttrs:m.primaryAttrs,idx=(id>=512?id-512:id)*2;
   const attribute=attrs&&idx+2<=attrs.byteLength?attrs.getUint16(idx,true):0;
   return {id,collision:(v>>10)&3,elevation:v>>12,behavior:attribute&255,layerType:(attribute>>>12)&15};
 }
 function walkable(m,x,y,mode='walk'){
   const b=infoAt(m,x,y);
   if(!b||b.collision!==0)return false;
   // Initial NPC / scripted obstacle cells are solid, even when their
   // ground metatile itself is walkable. Keys use x:y format.
   if(m.solidObjects?.has(x+':'+y))return false;
   if(m.layout?.primary_tileset==='gTileset_General'&&[0x10,0x11,0x12].includes(b.id))return false;
   if(mode==='walk'&&SEA.has(b.behavior))return false;
   return true;
 }
 function canStep(m,from,to,mode='walk'){
   if(!from||!to)return false;
   const dx=to.x-from.x,dy=to.y-from.y;
   if(Math.abs(dx)+Math.abs(dy)!==1)return false;
   if(!walkable(m,from.x,from.y,mode)||!walkable(m,to.x,to.y,mode))return false;
   const a=infoAt(m,from.x,from.y),b=infoAt(m,to.x,to.y);
   // Compare direction as a PAIR: independent axis matches turn a one-way
   // restriction into a wall blocking unrelated directions.
   const matches=(direction)=>direction&&direction[0]===dx&&direction[1]===dy;
   if(matches(BLOCKED_DIR[a.behavior])||matches(BLOCKED_DIR[b.behavior]))return false;
   if(LEDGE_DIR[a.behavior]&&!matches(LEDGE_DIR[a.behavior]))return false;
   if(LEDGE_DIR[b.behavior]&&!matches(LEDGE_DIR[b.behavior]))return false;
   if(a.elevation&&b.elevation&&a.elevation!==b.elevation&&!LEDGE_DIR[a.behavior]&&!LEDGE_DIR[b.behavior])return false;
   return true;
 }
 function nearest(m,p,mode='walk',maxRadius=Infinity){
   if(!m)return null;
   const x=Math.max(0,Math.min(m.width-1,Math.round(p?.x??m.width/2)));
   const y=Math.max(0,Math.min(m.height-1,Math.round(p?.y??m.height/2)));
   if(walkable(m,x,y,mode))return {x,y};
   const limit=Math.min(m.width+m.height,maxRadius);
   for(let r=1;r<=limit;r++)for(let dy=-r;dy<=r;dy++){
     const dx=r-Math.abs(dy);
     for(const nx of dx===0?[x]:[x-dx,x+dx])if(walkable(m,nx,y+dy,mode))return {x:nx,y:y+dy};
   }
   return null;
 }
 function findPath(m,start,end,mode='walk'){
   if(!m||!start||!end||!walkable(m,start.x,start.y,mode)||!walkable(m,end.x,end.y,mode))return [];
   const width=m.width,total=width*m.height,begin=start.y*width+start.x,goal=end.y*width+end.x;
   if(begin===goal)return [];
   const parent=new Int32Array(total);parent.fill(-1);
   const queue=new Int32Array(total);let front=0,back=0;
   parent[begin]=begin;queue[back++]=begin;
   const offsets=[[0,-1],[1,0],[0,1],[-1,0]];
   while(front<back&&parent[goal]===-1){
     const cur=queue[front++],x=cur%width,y=Math.floor(cur/width);
     for(const [dx,dy] of offsets){
       const nx=x+dx,ny=y+dy;
       if(nx<0||ny<0||nx>=m.width||ny>=m.height)continue;
       const n=ny*width+nx;
       if(parent[n]!==-1||!canStep(m,{x,y},{x:nx,y:ny},mode))continue;
       parent[n]=cur;queue[back++]=n;
     }
   }
   if(parent[goal]===-1)return [];
   const path=[];
   for(let cur=goal;cur!==begin;cur=parent[cur])path.push({x:cur%width,y:Math.floor(cur/width)});
   return path.reverse();
 }
 const api=Object.freeze({infoAt,walkable,canStep,nearest,findPath,SEA,LEDGE_DIR,BLOCKED_DIR});
 if(typeof module==='object'&&module.exports)module.exports=api;
 if(root)root.EmeraldNavigation=api;
})(typeof window==='object'?window:undefined);
