/* V9.4: shared starter choices from generations 1 to 9. Existing saves never change starters. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.EmeraldStarters=api;})(typeof window!=='undefined'?window:null,function(){
 'use strict';
 const TRIOS=[
  ['Bulbasaur','Charmander','Squirtle'],['Chikorita','Cyndaquil','Totodile'],
  ['Treecko','Torchic','Mudkip'],['Turtwig','Chimchar','Piplup'],
  ['Snivy','Tepig','Oshawott'],['Chespin','Fennekin','Froakie'],
  ['Rowlet','Litten','Popplio'],['Grookey','Scorbunny','Sobble'],
  ['Sprigatito','Fuecoco','Quaxly']
 ];
 const ALL=TRIOS.flat();const COUNTER=Object.fromEntries(TRIOS.flatMap(trio=>trio.map((s,i)=>[s,trio[(i+1)%3]])));
 const GENERATION=Object.fromEntries(TRIOS.flatMap((trio,i)=>trio.map(s=>[s,i+1])));
 function forTrainer(n){return ALL[((Math.trunc(Number(n)||1)-1)%ALL.length+ALL.length)%ALL.length]}
 function counter(name){return COUNTER[name]||'Treecko'}
 return {TRIOS,ALL,GENERATION,forTrainer,counter,isStarter:name=>ALL.includes(name)};
});
