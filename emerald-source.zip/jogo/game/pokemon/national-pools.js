/* V9.4 — Fixed encounter locations for the simulator, NOT Quetzal ROM encounter tables.
 * All species have stable, individually assigned locations; unknown/safe areas have no
 * national encounters. Never fall back to a random Pokémon from the whole Pokédex.
 */
(function(root,factory){const api=factory(root);if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.EmeraldNationalPools=api;})(typeof window!=='undefined'?window:null,function(root){
 'use strict';
 const HABITATS=(typeof module==='object'&&module.exports)?require('./national-habitats.js'):root?.EmeraldNationalHabitats;
 const TYPE_BIOMES={
  grass:['Grass','Bug','Normal','Flying','Fairy'],forest:['Grass','Bug','Poison','Fairy','Flying'],
  cave:['Rock','Ground','Steel','Dark','Ghost','Psychic'],
  surf:['Water','Flying','Ice','Dragon'],water:['Water','Flying','Ice','Dragon'],
  sand:['Ground','Rock','Fire','Steel'],desert:['Ground','Rock','Fire','Steel'],
  volcano:['Fire','Rock','Ground','Dragon'],ash:['Fire','Rock','Poison','Flying'],
  electric:['Electric','Steel','Normal'],psychic:['Psychic','Ghost','Fairy'],
  mountain:['Rock','Fighting','Ground','Dragon'],urban:['Normal','Electric','Steel','Psychic']
 };
 // Fully explicit encounter-enabled locations. Buildings, cities and arbitrary names
 // are intentionally excluded (except wild grass in the named mapped outdoor areas).
 const AREA_DEFS={
  Route101:['grass',0],Route102:['grass',0],Route103:['grass',0],Route104:['grass',0],
  Route104North:['grass',0],Woods:['forest',0],Route116:['mountain',0],Route106:['water',1],
  GraniteCave:['cave',1],Route110:['electric',2],Route111:['desert',3],Route112:['volcano',3],
  Route113:['ash',3],Route114:['mountain',3],Route115:['mountain',3],Route117:['grass',2],
  Route118:['water',4],Route119:['forest',5],Route120:['forest',5],Route121:['forest',5],
  Route122:['water',5],Route123:['grass',5],Route124:['water',6],Route125:['water',6],
  Route126:['water',6],Route127:['water',6],Route128:['water',6],Route129:['water',6],
  Route130:['water',6],Route131:['water',6],Route132:['water',6],Route133:['water',6],
  Route134:['water',6],RusturfTunnel:['cave',0],FieryPath:['volcano',3],
  MeteorFalls:['cave',3],MtPyre:['psychic',5],NewMauville:['electric',4],
  ShoalCave:['cave',6],SeafloorCavern:['water',7],VictoryRoad:['mountain',8],
  SafariZone:['forest',5],JaggedPass:['volcano',3],PetalburgWoods:['forest',0],
  MtChimney:['volcano',3],MagmaHideout:['cave',5],AquaHideout:['water',6]
 };
 const ALIASES={'Route 101':'Route101','Route 102':'Route102','Route 103':'Route103',
  'Route 104':'Route104','Route 106':'Route106','Route 110':'Route110',
  'Route 111':'Route111','Route 112':'Route112','Route 113':'Route113',
  'Route 114':'Route114','Route 115':'Route115','Route 116':'Route116',
  'Route 117':'Route117','Route 118':'Route118','Route 119':'Route119',
  'Route 120':'Route120','Route 121':'Route121','Route 122':'Route122',
  'Route 123':'Route123','Route 124':'Route124','Route 125':'Route125',
  'Route 126':'Route126','Route 127':'Route127','Route 128':'Route128',
  'Route 129':'Route129','Route 130':'Route130','Route 131':'Route131',
  'Route 132':'Route132','Route 133':'Route133','Route 134':'Route134',
  'Petalburg Woods':'Woods','Granite Cave':'GraniteCave','Rusturf Tunnel':'RusturfTunnel',
  'Meteor Falls':'MeteorFalls','Fiery Path':'FieryPath','Mt. Pyre':'MtPyre',
  'New Mauville':'NewMauville','Shoal Cave':'ShoalCave','Seafloor Cavern':'SeafloorCavern',
  'Victory Road':'VictoryRoad','Safari Zone':'SafariZone','Jagged Pass':'JaggedPass',
  'Mt. Chimney':'MtChimney','Magma Hideout':'MagmaHideout','Aqua Hideout':'AquaHideout'};
 const CLASSIC_AREAS=Object.fromEntries(Object.entries(AREA_DEFS).map(([k,v])=>[k,v[0]]));
 for(const [alias,key] of Object.entries(ALIASES))CLASSIC_AREAS[alias]=AREA_DEFS[key][0];
 const CAPS=[420,450,470,495,520,550,580,620,670];
 // Manually pinned early encounters avoid forcing every species into arbitrary spots.
 const FIXED={Route101:['Zigzagoon','Poochyena','Wurmple','Bidoof','Starly','Sentret'],
 Route102:['Ralts','Lotad','Poochyena','Zigzagoon','Seedot'],
 Woods:['Shroomish','Wurmple','Caterpie','Weedle','Sprigatito','Treecko','Bulbasaur','Oddish'],
 Route104North:['Taillow','Wingull','Lotad','Seedot'],Route106:['Wingull','Tentacool','Magikarp'],
 GraniteCave:['Zubat','Geodude','Aron','Makuhita','Abra'],Route110:['Electrike','Magnemite','Plusle','Minun'],
 Route116:['Whismur','Nincada','Taillow'],Route111:['Trapinch','Sandshrew','Cacnea'],
 Route119:['Tropius','Kecleon','Oddish'],Route124:['Wailmer','Tentacool','Chinchou']};
 function adapt(entry){if(Array.isArray(entry))return {key:entry[0],types:[entry[1],entry[2]].filter(Boolean),base:entry.slice(3,9),catch:entry[9],exp:entry[10],dex:entry[11],kind:entry[12]};return entry;}
 function normalize(location){const s=String(location||'').trim();return ALIASES[s]||s;}
 function biomeFor(location,habitat){const key=normalize(location);return AREA_DEFS[key]?.[0]||'none'}
 function hash(text){let h=2166136261;for(const c of text){h=Math.imul(h^c.charCodeAt(0),16777619)>>>0;}return h>>>0}
 function habitatRecord(entry){
  const e=adapt(entry);
  if(!e?.key||!HABITATS?.ENTRIES)return null;
  const key=(e.kind==='variant')?HABITATS.BY_DEX?.[e.dex]:e.key;
  return HABITATS.ENTRIES[key||e.key]||null;
 }
 function locationsFor(record){
  const h=habitatRecord(record);
  return h?.method==='wild'&&Array.isArray(h.locations)?h.locations.slice():[];
 }
 function encounterInfo(record){
  const e=adapt(record),h=habitatRecord(e);
  return {species:e?.key||'',method:h?.method||'unavailable',locations:locationsFor(e),minBadges:h?.minBadges??null,source:HABITATS?.source||'unavailable'};
 }
 function eligible(record,{badges=0,champion=false,allowForms=false,allowSpecial=false}={}){
  const e=adapt(record);if(!e||!e.key||!Array.isArray(e.base))return false;
  if(e.kind==='experimental'||(e.kind==='variant'&&!allowForms))return false;
  const habitat=habitatRecord(e);if(!habitat)return false;
  if(!champion&&Math.max(0,Math.floor(Number(badges)||0))<habitat.minBadges)return false;
  if(e.kind!=='species'&&e.kind!=='variant')return false;
  const power=e.base.reduce((a,b)=>a+b,0),cap=champion?Infinity:CAPS[Math.max(0,Math.min(8,Math.floor(badges)||0))];
  if(power>cap)return false;
  if(e.catch<10&&!champion&&!allowSpecial)return false;
  return true;
 }
 function hasEncounters(location){return Boolean(AREA_DEFS[normalize(location)])}
 function pool(records,opts={}){
  const loc=normalize(opts.location);if(opts.location&&!hasEncounters(loc))return [];
  const types=TYPE_BIOMES[biomeFor(loc)]||[];
  return records.map(adapt).filter(e=>eligible(e,opts)&&(!opts.location||locationsFor(e).includes(loc))&&(!opts.matchHabitat||e.types.some(t=>types.includes(t))||FIXED[loc]?.includes(e.key)));
 }
 function pick(records,opts={},rand=Math.random){
  const candidates=pool(records,{...opts,matchHabitat:true});if(!candidates.length)return null;
  const owned=new Set(opts.owned||[]);let total=0;
  const weights=candidates.map(e=>{let w=Math.pow(Math.max(1,Number(e.catch)||3)/255,.7);
   if(owned.has(e.key))w*=.55;if(e.kind==='variant')w*=.06;total+=w;return w;});
  let spin=rand()*total;for(let i=0;i<candidates.length;i++){spin-=weights[i];if(spin<=0)return candidates[i];}return candidates.at(-1);
 }
 return {TYPE_BIOMES,CLASSIC_AREAS,AREA_DEFS,FIXED,CAPS,adapt,eligible,pool,pick,biomeFor,hasEncounters,locationsFor,encounterInfo,normalize};
});
