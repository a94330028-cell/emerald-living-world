/* Velocidade da SIMULAÇÃO por eventos; não aumenta velocidade de Pokémon
 * em batalha nem faz personagens atravessarem tiles ou paredes. */
(function(root){'use strict';
 const PRESETS=Object.freeze([1,2,3,5]);
 function normalize(value,allowZero=false){
  const n=Number(value);
  if(allowZero&&n===0)return 0; // Usado somente no diagnóstico do motor.
  return Number.isFinite(n)&&PRESETS.includes(n)?n:1;
 }
 // 1x nesta versão corresponde ao antigo 40x; demais escolhas são proporcionais.
 function effectiveMultiplier(value){return normalize(value)*40;}
 function fromLegacy(value){const n=Number(value);return n>=180?5:n>=110?3:n>=65?2:1;}
 function frameLimit(value){
  const effective=effectiveMultiplier(value);
  return Math.max(2,Math.min(16,Math.ceil(effective/12)+1));
 }
 // Uma atualização não pode monopolizar o thread do Android.
 const CPU_BUDGET_MS=7,MAX_BACKLOG_MS=2400,TICK_MS=600;
 const api=Object.freeze({PRESETS,normalize,fromLegacy,effectiveMultiplier,frameLimit,CPU_BUDGET_MS,MAX_BACKLOG_MS,TICK_MS});
 if(typeof module==='object'&&module.exports)module.exports=api;
 if(root)root.EmeraldSimSpeed=api;
})(typeof window==='object'?window:undefined);
