# Guia de gráficos e mapas — Pokémon Emerald (pret/pokeemerald)

Repositório: https://github.com/pret/pokeemerald

> O jogo atual é um **simulador por eventos**, não um emulador do Pokémon Emerald. O ZIP mantém os sprites que já estavam no projeto do usuário. Os links abaixo servem de referência para uma futura fase de mapas corretos. Arquivos gráficos de Pokémon podem continuar protegidos por direitos autorais: repositório público não equivale a licença de redistribuição.

## 1. Tilesets, edifícios, ruas e terreno

O caminho principal para os **tilesets de mapas** no `pokeemerald` é **`data/tilesets/`**, e não `graphics/tilesets/`.

- https://github.com/pret/pokeemerald/tree/master/data/tilesets
- https://github.com/pret/pokeemerald/tree/master/data/tilesets/primary
- https://github.com/pret/pokeemerald/tree/master/data/tilesets/secondary
- Exemplo de tiles comuns: `data/tilesets/primary/general/tiles.png`
- Exemplo de paletas: `data/tilesets/primary/general/palettes/00.pal`
- Blocos/metatiles: `data/tilesets/primary/general/metatiles.bin`
- Propriedades de cada bloco (comportamento/camadas): `data/tilesets/primary/general/metatile_attributes.bin`

Não basta abrir `tiles.png` como o cenário inteiro. A ROM combina pequenos tiles (8×8) em metatiles e monta o mapa com os dados de layout e palettes.

## 2. Pokémon: frente, costas, ícone e shiny

- https://github.com/pret/pokeemerald/tree/master/graphics/pokemon
- Treecko: https://github.com/pret/pokeemerald/tree/master/graphics/pokemon/treecko
- Sprite parado de frente: `graphics/pokemon/treecko/front.png`
- Sprite de frente com quadros: `graphics/pokemon/treecko/anim_front.png`
- Sprite de costas: `graphics/pokemon/treecko/back.png`
- Ícone do time/PC: `graphics/pokemon/treecko/icon.png`
- Paleta normal: `graphics/pokemon/treecko/normal.pal`
- Paleta shiny: `graphics/pokemon/treecko/shiny.pal`

O mesmo padrão aparece em outras espécies, mas nomes especiais podem ser organizados de outra maneira. **A paleta shiny pode ser aplicada à imagem, não é necessariamente um PNG shiny separado.**

Exemplo para abrir/baixar no Android: https://github.com/pret/pokeemerald/blob/master/graphics/pokemon/treecko/front.png

O site já contém `assets/rom_pokemon/*.png` e `assets/pokemon/*.gif` do ZIP original, portanto não depende da rede para carregar imagens das espécies presentes nessas pastas.

## 3. Brendan, May, NPCs e overworld

- https://github.com/pret/pokeemerald/tree/master/graphics/object_events
- https://github.com/pret/pokeemerald/tree/master/graphics/object_events/pics/people
- Brendan andando: `graphics/object_events/pics/people/brendan/walking.png`
- Brendan correndo: `graphics/object_events/pics/people/brendan/running.png`
- Brendan bicicleta: `graphics/object_events/pics/people/brendan/mach_bike.png`
- Pokémon no mundo: `graphics/object_events/pics/pokemon/`
- Paletas dos personagens: `graphics/object_events/palettes/`

As folhas de animação incluem vários quadros e direções. Para usá-las em Canvas é necessário recortar cada quadro e vinculá-lo às direções do personagem.

## 4. Mapas, scripts, eventos e conexão das rotas

- https://github.com/pret/pokeemerald/tree/master/data/maps
- Exemplo: https://github.com/pret/pokeemerald/blob/master/data/maps/LittlerootTown/map.json
- Outro exemplo: https://github.com/pret/pokeemerald/blob/master/data/maps/Route101/map.json
- Grupos de mapas: `data/maps/map_groups.json`
- Layouts: https://github.com/pret/pokeemerald/tree/master/data/layouts
- Definições dos layouts: `data/layouts/layouts.json`

**`map.json`** descreve identidade, layout referenciado, conexões com rotas, NPCs e suas coordenadas, warps (entradas de interiores), eventos e scripts de interação. **`layouts.json` + dados binários dos layouts** determinam a grade de metatiles. Os atributos dos tilesets especificam comportamentos como grama, água e tipos de terreno. A colisão exigirá traduzir a combinação de layout, metatile e comportamento, não apenas ler um campo booleano de `map.json`.

Os arquivos `header.inc`, `events.inc`, `connections.inc` são **gerados** a partir de `map.json` pelo ferramental do projeto, conforme `map_data_rules.mk`:
https://github.com/pret/pokeemerald/blob/master/map_data_rules.mk

## 5. Próxima etapa: mapas originais começando por Littleroot/Route 101

1. Usar o `map.json` de Littleroot para identificar conexão com Route 101, NPCs e portas.
2. Localizar a entrada do `LAYOUT_LITTLEROOT_TOWN` em `data/layouts/layouts.json`.
3. Decodificar `map.bin`, `border.bin` e os metatiles/atributos do tileset indicados pelo layout, respeitando layers e paletas.
4. Renderizar a grade no Canvas e converter metatiles passáveis/impassáveis em uma grade de colisão.
5. Ligar warps de portas e saídas para os interiores/rotas corretos.
6. Trocar as rotas simplificadas em `js/player.js` por um roteiro derivado dos mapas. O jogador pode continuar movendo automaticamente entre pontos de interesse; as escolhas permanecem só nas batalhas e no PC.

Os mapas atuais em `js/world.js` e `js/engine.js` são **representações próprias** e não cópias exatas do layout/colisão do jogo. Não desative esses mapas enquanto prepara os arquivos de referência.

## 6. Sobre desempenho e hospedagem

O deploy segue sendo **estático** e compatível com **Cloudflare Pages**. O mundo foi ajustado para criar **20 IAs inicialmente**, com seletor para até **100**, e atualizar a interface com menor frequência ao abrir a campanha. As IAs só avançam enquanto a página estiver aberta; hospedagem 24/7 não significa uma simulação 24/7 em segundo plano.

O save da campanha do jogador é separado do save das IAs e fica no `localStorage`. Para trocar de celular, use **Exportar campanha** e **Importar campanha**. Nenhum login ou salvamento compartilhado entre aparelhos foi incluído.
