# 🌿﹒EMERALD LIVING WORLD
-# __**Atualização V2 — Correção das Rotas de Hoenn**__

**🧭﹒NAVEGAÇÃO DAS IAS**
-# ✦ Corrigida a escolha de saídas quando uma rota tem áreas separadas por obstáculos.
-# ✦ As IAs podem buscar uma passagem por Petalburg Woods para chegar a Rustboro.
-# ✦ Ajustado o acesso ao embarque de Mr. Briney a partir da Rota 104.
-# ✦ Reduzidas tentativas repetitivas de encontrar uma saída bloqueada.
-# ✦ Recuperação automática de trajetos travados sem mover o treinador instantaneamente para outra cidade.

**🎮﹒CONTROLES E INTERFACE**
-# ✦ Novo botão **🧭 Recalcular rota** no mapa da transmissão.
-# ✦ Indicador de aviso quando a IA está procurando uma passagem.
-# ✦ Preservadas batalhas, treinadores de rota, campanha e a escolha da quantidade de IAs.

**💾﹒PROGRESSO**
-# ✦ O sistema mantém a estrutura de salvamento da V2.
-# ✦ Não é necessário criar um mundo novo para atualizar, mas recomendamos exportar um backup.

-# __**Emerald Living World · Versão 2**__
-# Projeto criado por André “Dezin”.
