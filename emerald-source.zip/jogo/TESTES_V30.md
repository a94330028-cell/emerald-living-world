# Registro de verificações — versão 30

## Verificado nesta execução
- Sintaxe de todos os scripts JavaScript: `node --check` — passou.
- Leitura de PNG indexado de 4 bits (índices de cor exatos) — passou em arquivo de teste.
- Resolução de nomes de mapas, arquivos de tilesets e constantes `MAP_*` — passou nos casos de teste.
- Busca de caminhos respeitando uma célula marcada como bloqueada — passou em grade simulada.
- Carregamento com respostas simuladas de `pret/pokeemerald` para três mapas de teste (Littleroot Town, Route 101 e laboratório): catálogo, layouts, tilesets, 13 paletas, `map.bin`, NPCs, links de conexão e warps — passou.
- Navegação anterior e cache de recursos no teste de execução — passou.
- Links locais HTML/CSS/JS/imagens em `index.html` e `mapas-oficiais.html` — nenhum arquivo faltante encontrado.
- Arquivo ZIP — integridade verificada.

## Não verificado
- O navegador gráfico de testes deste ambiente bloqueou a navegação com `ERR_BLOCKED_BY_ADMINISTRATOR`, inclusive para arquivos locais. Por isso, não foi possível executar uma bateria visual pelo Chrome nem validar layouts reais usando a rede.
- Não foi feita validação individual de cada mapa e tileset do repositório remoto; situações excepcionais ainda podem mostrar erro de carregamento.
- A rota visualizada no mapa usa somente os flags de colisão de `map.bin`; água, HM, eventos, saltos, elevação e entradas condicionais exigem lógica adicional.
- A campanha e as IAs não usam a grade oficial para navegação: a página `mapas-oficiais.html` é um visualizador independente.

Não há garantia de ausência total de erros até serem realizados testes de uso após a publicação.
