# Validação de navegação — V2

Foram criados testes automatizados com grades sintéticas estruturadas como mapas oficiais (células com colisão, saídas, objetos e warps).

- Rota 104, setor sul -> Petalburg Woods -> Rota 104, setor norte -> Rustboro City: **passou**.
- Rota 104, setor norte -> Petalburg Woods -> Rota 104, setor sul -> travessia de Mr. Briney a Dewford Town: **passou**.
- Scripts JS da aplicação: **análise de sintaxe passou**.
- Empacotamento: index.html na raiz e recursos presentes.

Limitações: estes testes não equivalem a uma partida completa nem verificam todos os mapas reais em um navegador com acesso à rede. Mapas e tilesets do pokeemerald são obtidos sob demanda, e eventos como Surf, puzzles e alguns interiores continuam aproximados.

A correção não move IAs diretamente de um mapa para outro quando uma saída está bloqueada; só usa saídas ou eventos de trânsito previstos na navegação.
