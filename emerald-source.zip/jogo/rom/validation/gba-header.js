/* Reads ONLY a local GBA file header. It does not emulate or extract ROM assets. */
(function(root){'use strict';
 function readGbaHeader(bytes){
  if(!(bytes instanceof Uint8Array)||bytes.length<0xC0)return {valid:false,error:'Cabeçalho GBA ausente ou incompleto.'};
  const ascii=(a,b)=>Array.from(bytes.subarray(a,b)).map(x=>x>=32&&x<=126?String.fromCharCode(x):' ').join('').trim();
  const title=ascii(0xA0,0xAC),gameCode=ascii(0xAC,0xB0),maker=ascii(0xB0,0xB2),revision=bytes[0xBC];
  const magic=bytes[0xB2]===0x96;
  let sum=0;for(let i=0xA0;i<=0xBC;i++)sum=(sum+bytes[i])&255;
  const checksum=((0xE7-sum)&255)===bytes[0xBD];
  const valid=magic&&checksum&&/^[A-Z0-9]{4}$/.test(gameCode);
  const emerald=valid&&/^POKEMON EMER/i.test(title)&&/^BPE[A-Z0-9]$/.test(gameCode);
  const quetzal=valid&&/^PKM QUETZAL/i.test(title)&&gameCode==='BPEE';
  return {valid,emerald,quetzal,emeraldFamily:emerald||quetzal,title,gameCode,maker,revision,checksumOk:checksum,
   error:!magic?'Assinatura GBA inválida.':!checksum?'Checksum do cabeçalho inválido.':!valid?'Código de jogo inválido.':!(emerald||quetzal)?'O arquivo é GBA, mas não foi identificado como Emerald ou Quetzal.':null};
 }
 const api=Object.freeze({readGbaHeader});
 if(typeof module==='object'&&module.exports)module.exports=api;
 if(root)root.EmeraldRomHeader=api;
})(typeof window==='object'?window:undefined);
