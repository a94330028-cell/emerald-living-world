(()=>{'use strict';const $=id=>document.getElementById(id);let rom=null;
const value=s=>{const text=String(s).trim().replace(/^0x/i,'');if(!/^[0-9a-f]+$/i.test(text))throw Error('Offset hexadecimal inválido');return parseInt(text,16)};
$('file').addEventListener('change',async e=>{rom=null;const file=e.target.files?.[0];if(!file)return;
 try{if(!/\.gba$/i.test(file.name)||file.size<192||file.size>64*1024*1024)throw Error('Selecione um arquivo .gba de tamanho compatível');
 const header=new Uint8Array(await file.slice(0,192).arrayBuffer()),identity=window.EmeraldRomHeader.readGbaHeader(header);
 if(!identity.valid)throw Error(identity.error||'ROM inválida');
 rom=new Uint8Array(await file.arrayBuffer());$('summary').textContent=`${identity.title||'GBA'} · ${identity.gameCode} · revisão ${identity.revision} · ${(file.size/1048576).toFixed(1)} MB. ${identity.quetzal?'Quetzal identificado pelo título interno; offsets de gráficos NÃO verificados.':identity.emerald?'Emerald original identificado pelo cabeçalho.':'Outros dados gráficos podem não ser compatíveis.'} Nenhum arquivo é enviado ao servidor.`;
 }catch(err){$('summary').textContent=err.message;}
 });
$('preview').addEventListener('click',()=>{try{if(!rom)throw Error('Selecione uma ROM válida antes.');const offset=value($('tileOffset').value),pal=value($('palOffset').value);const w=Number($('widthTiles').value),h=Number($('heightTiles').value);
 if(!Number.isInteger(w)||!Number.isInteger(h)||w<1||h<1||w>16||h>16)throw Error('Tamanho inválido');
 const engine=window.EmeraldGbaGraphics,palette=engine.palette555(rom,pal,16),source=$('compressed').checked?engine.lz77(rom,offset,1024*1024):rom;
 const tile=engine.decode4bpp(source,palette,{widthTiles:w,heightTiles:h,offset:$('compressed').checked?0:offset});
 const c=$('canvas');c.width=tile.width;c.height=tile.height;const cx=c.getContext('2d');const image=cx.createImageData(tile.width,tile.height);image.data.set(tile.pixels);cx.putImageData(image,0,0);$('result').textContent=`Imagem ${tile.width}×${tile.height} px. Prévia técnica; não representa necessariamente um sprite de Pokémon.`;
 }catch(err){$('result').textContent='Não foi possível decodificar: '+err.message;}});
})();
