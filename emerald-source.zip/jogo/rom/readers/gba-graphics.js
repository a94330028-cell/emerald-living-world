/* Local-only binary GBA tools. No offsets or sprite identities are guessed.
 * 4bpp 8x8 tile pixels, BGR555 palettes and BIOS LZ77 0x10 streams.
 */
(function(root){'use strict';
 function bytesOf(x){if(x instanceof Uint8Array)return x;throw new TypeError('Array de bytes necessário');}
 function palette555(data,offset=0,count=16){bytesOf(data);if(!Number.isInteger(offset)||offset<0||!Number.isInteger(count)||count<1||count>256||offset+count*2>data.length)throw new RangeError('Paleta fora do arquivo');
  const colors=[];for(let i=0;i<count;i++){const v=data[offset+i*2]|(data[offset+i*2+1]<<8);const red=v&31,green=(v>>5)&31,blue=(v>>10)&31;
  colors.push([Math.round(red*255/31),Math.round(green*255/31),Math.round(blue*255/31)]);
  }return colors;
 }
 function lz77(data,offset=0,max=1024*1024){bytesOf(data);if(!Number.isInteger(offset)||offset<0||offset+4>data.length||data[offset]!==0x10)throw new Error('Cabeçalho LZ77 inválido');
  const length=data[offset+1]|(data[offset+2]<<8)|(data[offset+3]<<16);if(!length||length>max)throw new Error('Saída LZ77 grande demais');
  const out=new Uint8Array(length);let at=offset+4,position=0;
  while(position<length){if(at>=data.length)throw new Error('LZ77 truncado');const flags=data[at++];
   for(let bit=7;bit>=0&&position<length;bit--){if(!(flags&(1<<bit))){if(at>=data.length)throw new Error('Literal incompleto');out[position++]=data[at++];}
    else{if(at+1>=data.length)throw new Error('Referência incompleta');const hi=data[at++],lo=data[at++],count=(hi>>4)+3,distance=((hi&15)<<8|lo)+1;
     if(distance>position)throw new Error('Distância LZ77 inválida');
     for(let i=0;i<count&&position<length;i++){out[position]=out[position-distance];position++;}
    }
   }
  }return out;
 }
 function decode4bpp(data,palette,{widthTiles=2,heightTiles=2,transparentZero=true,offset=0}={}){
  bytesOf(data);if(!Array.isArray(palette)||palette.length<16)throw new TypeError('Paleta de 16 cores obrigatória');
  if(!Number.isInteger(widthTiles)||!Number.isInteger(heightTiles)||widthTiles<1||heightTiles<1||widthTiles*heightTiles>4096)throw new RangeError('Dimensões inválidas');
  const tiles=widthTiles*heightTiles;if(!Number.isInteger(offset)||offset<0||offset+tiles*32>data.length)throw new RangeError('Dados gráficos insuficientes');
  const w=widthTiles*8,h=heightTiles*8,out=new Uint8ClampedArray(w*h*4);
  for(let t=0;t<tiles;t++)for(let i=0;i<64;i++){
   const by=data[offset+t*32+(i>>1)],idx=i&1?(by>>4)&15:by&15;
   const x=(t%widthTiles)*8+(i%8),y=Math.floor(t/widthTiles)*8+Math.floor(i/8),at=(y*w+x)*4;
   out.set(palette[idx]||[0,0,0],at);out[at+3]=idx===0&&transparentZero?0:255;
  }return {width:w,height:h,pixels:out};
 }
 const api=Object.freeze({palette555,lz77,decode4bpp});
 if(typeof module==='object'&&module.exports)module.exports=api;
 if(root)root.EmeraldGbaGraphics=api;
})(typeof window==='object'?window:undefined);
