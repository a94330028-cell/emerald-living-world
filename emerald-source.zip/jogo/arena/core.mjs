/* Emerald Living World — Arena 3.6. Regras simplificadas do projeto (não é emulador de torneios oficiais). */
export const FORMATS=[1,3,6];
export const TYPE_CHART={
 Normal:{Rock:.5,Ghost:0,Steel:.5},Fire:{Fire:.5,Water:.5,Grass:2,Ice:2,Bug:2,Rock:.5,Dragon:.5,Steel:2},
 Water:{Fire:2,Water:.5,Grass:.5,Ground:2,Rock:2,Dragon:.5},Electric:{Water:2,Electric:.5,Grass:.5,Ground:0,Flying:2,Dragon:.5},
 Grass:{Fire:.5,Water:2,Grass:.5,Poison:.5,Ground:2,Flying:.5,Bug:.5,Rock:2,Dragon:.5,Steel:.5},
 Ice:{Fire:.5,Water:.5,Grass:2,Ice:.5,Ground:2,Flying:2,Dragon:2,Steel:.5},Fighting:{Normal:2,Ice:2,Poison:.5,Flying:.5,Psychic:.5,Bug:.5,Rock:2,Ghost:0,Dark:2,Steel:2,Fairy:.5},
 Poison:{Grass:2,Poison:.5,Ground:.5,Rock:.5,Ghost:.5,Steel:0,Fairy:2},Ground:{Fire:2,Electric:2,Grass:.5,Poison:2,Flying:0,Bug:.5,Rock:2,Steel:2},
 Flying:{Electric:.5,Grass:2,Fighting:2,Bug:2,Rock:.5,Steel:.5},Psychic:{Fighting:2,Poison:2,Psychic:.5,Dark:0,Steel:.5},
 Bug:{Fire:.5,Grass:2,Fighting:.5,Poison:.5,Flying:.5,Psychic:2,Ghost:.5,Dark:2,Steel:.5,Fairy:.5},
 Rock:{Fire:2,Ice:2,Fighting:.5,Ground:.5,Flying:2,Bug:2,Steel:.5},Ghost:{Normal:0,Psychic:2,Ghost:2,Dark:.5},
 Dragon:{Dragon:2,Steel:.5,Fairy:0},Dark:{Fighting:.5,Psychic:2,Ghost:2,Dark:.5,Fairy:.5},Steel:{Fire:.5,Water:.5,Electric:.5,Ice:2,Rock:2,Steel:.5,Fairy:2},
 Fairy:{Fire:.5,Fighting:2,Poison:.5,Dragon:2,Dark:2,Steel:.5}
};
export const typeMultiplier=(attack,defenses)=>defenses.filter(Boolean).reduce((v,t)=>v*(TYPE_CHART[attack]?.[t]??1),1);
const clamp=(n,min,max)=>Math.min(max,Math.max(min,n));
export function getSpecies(list,id){return list.find(x=>x[0]===id)||null}
export function validTeam(ids,format,list){return FORMATS.includes(format)&&Array.isArray(ids)&&ids.length===format&&new Set(ids).size===ids.length&&ids.every(id=>Number.isInteger(id)&&!!getSpecies(list,id))}
export function makeMember(spec){const [id,name,type1,type2,h,a,d,sa,sd,s]=spec;
 const stat=b=>Math.floor((2*b+31)*.5)+5;const hp=Math.floor((2*h+31)*.5)+60;
 return {id,name,types:[type1,type2].filter(Boolean),maxHp:hp,hp,atk:stat(a),def:stat(d),spa:stat(sa),spd:stat(sd),spe:stat(s)};
}
export function createBattle(a,b,list){if(!Array.isArray(a)||!validTeam(a,a.length,list)||!validTeam(b,a.length,list))throw Error('Equipes inválidas');return {version:1,turn:1,sides:[{team:a.map(id=>makeMember(getSpecies(list,id))),active:0},{team:b.map(id=>makeMember(getSpecies(list,id))),active:0}],winner:null,log:['Batalha iniciada!']};}
export function moves(mon){return [{name:'Investida',type:'Normal',power:48,category:'physical',priority:0},
 {name:'Ataque '+mon.types[0],type:mon.types[0],power:65,category:'special',priority:0},
 {name:mon.types[1]?'Ataque '+mon.types[1]:'Golpe de força',type:mon.types[1]||'Normal',power:mon.types[1]?57:65,category:'physical',priority:0},
 {name:'Ataque Rápido',type:'Normal',power:38,category:'physical',priority:1}];}
export function alive(side){return side.team.some(m=>m.hp>0)}
export function active(side){return side.team[side.active]}
export function validateAction(battle,sideIndex,action){
 if(!battle || battle.winner!==null || ![0,1].includes(sideIndex))return false;
 const side=battle.sides[sideIndex];if(!side)return false;
 if(action?.kind==='switch')return Number.isInteger(action.to)&&action.to>=0&&action.to<side.team.length&&action.to!==side.active&&side.team[action.to].hp>0;
 if(action?.kind==='attack')return Number.isInteger(action.move)&&action.move>=0&&action.move<4&&active(side)?.hp>0;
 return false;
}
export function resolveTurn(battle,first,second){
 if(!validateAction(battle,0,first)||!validateAction(battle,1,second))throw Error('Ação inválida para a rodada atual');
 const state=JSON.parse(JSON.stringify(battle));let lines=[];
 const actions=[first,second];const order=[0,1].sort((a,b)=>{
  const pa=actions[a].kind==='switch'?2:moves(active(state.sides[a]))[actions[a].move].priority;
  const pb=actions[b].kind==='switch'?2:moves(active(state.sides[b]))[actions[b].move].priority;
  if(pa!==pb)return pb-pa;
  const speedA=active(state.sides[a]).spe,speedB=active(state.sides[b]).spe;
  return speedB-speedA||a-b;
 });
 for(const i of order){
  if(state.winner!==null)break;
  const side=state.sides[i],op=state.sides[1-i],action=actions[i];
  if(action.kind==='switch'){
    side.active=action.to;lines.push(`Treinador ${i+1} escolheu ${active(side).name}.`);continue;
  }
  const mon=active(side);if(!mon||mon.hp<=0)continue;
  const defender=active(op),move=moves(mon)[action.move];
  const atk=move.category==='physical'?mon.atk:mon.spa;
  const def=Math.max(1,move.category==='physical'?defender.def:defender.spd);
  const eff=typeMultiplier(move.type,defender.types);const stab=mon.types.includes(move.type)?1.5:1;
  const dmg=eff===0?0:Math.max(1,Math.floor(((22*move.power*atk/def)/50+2)*stab*eff));
  defender.hp=clamp(defender.hp-dmg,0,defender.maxHp);
  lines.push(`${mon.name} usou ${move.name}: ${dmg} de dano${eff>=2?' (super efetivo)':eff<1&&eff>0?' (pouco efetivo)':eff===0?' (sem efeito)':''}.`);
  if(defender.hp===0){lines.push(`${defender.name} foi derrotado!`);
   const next=op.team.findIndex(t=>t.hp>0);
   if(next<0){state.winner=i;lines.push(`Treinador ${i+1} venceu!`);}
   else {op.active=next;lines.push(`${active(op).name} entrou em campo.`);}
  }
 }
 state.turn++;if(state.turn>100&&state.winner===null){const totals=state.sides.map(s=>s.team.reduce((n,m)=>n+m.hp/m.maxHp,0));state.winner=totals[0]===totals[1]?-1:totals[0]>totals[1]?0:1;lines.push('A batalha terminou pelo limite de turnos.');}
 state.log=[...state.log,...lines].slice(-36);return state;
}
export function pickBotAction(battle,index=1,level='normal'){
 const side=battle.sides[index],opp=battle.sides[1-index];
 const mon=active(side);if(!mon||mon.hp<=0){const next=side.team.findIndex(m=>m.hp>0);return {kind:'switch',to:next}}
 const ms=moves(mon),target=active(opp);
 if(level==='easy')return {kind:'attack',move:battle.turn%4};
 let best=0,score=-1;ms.forEach((m,i)=>{
  const atk=m.category==='physical'?mon.atk:mon.spa,def=m.category==='physical'?target.def:target.spd;
  const val=m.power*atk/Math.max(1,def)*(mon.types.includes(m.type)?1.5:1)*typeMultiplier(m.type,target.types)+(m.priority?5:0);
  if(val>score){score=val;best=i}
 });
 if(level==='hard'&&mon.hp<mon.maxHp*.24){
  const next=side.team.findIndex((m,i)=>i!==side.active&&m.hp>m.maxHp*.7);
  if(next!==-1)return {kind:'switch',to:next};
 }
 return {kind:'attack',move:best};
}
export function eloChange(my,other,result,k=24){const expected=1/(1+10**((other-my)/400));return Math.round(k*(result-expected));}
export function division(elo){return elo>=1700?'Mestre':elo>=1450?'Diamante':elo>=1250?'Ouro':elo>=1050?'Prata':'Bronze';}
