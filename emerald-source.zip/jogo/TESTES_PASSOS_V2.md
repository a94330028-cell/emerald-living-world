# Validação da caminhada — Emerald Living V2

## Testes executados
- `node --check` nos três scripts alterados: sem erros sintáticos.
- Motor em velocidade 40× com relógio simulado: passos físicos ortogonais, controle de intervalo e direção coerente com deslocamento — passou.
- Seleção dos oito quadros de Brendan/May: direção parada e caminhada para cima, baixo, esquerda e direita — passou.
- Interior: treinador aguarda missão sem ficar percorrendo células aleatórias — passou.
- Rota de Littleroot a Route 101 pelas conexões do mapa — passou (mapas simulados).
- Entradas por escadas e colisões — passou (mapas simulados).
- Telhados: blocos inferiores bloqueados e sobreposição da camada frontal — passou (dados simulados).

## Limitações
- O teste visual em Chromium no ambiente de desenvolvimento foi bloqueado por restrição de navegação local; **não foi possível verificar no site publicado**.
- Os mapas e sprites oficiais do GitHub são obtidos pela rede. A disponibilidade desses arquivos na hospedagem final depende da conexão.
- Alguns eventos e rotas especiais não foram completamente reproduzidos. Esta atualização é focada em caminhada e orientação; não é uma emulação exata de Pokémon Emerald.
