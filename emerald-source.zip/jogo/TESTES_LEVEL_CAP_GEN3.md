# ✅ Testes executados — motor da atualização

## Testes unitários do JavaScript (Node)

1. Fórmulas Gen III de HP, Atk, SpA e Speed com IV/EV/Nature determinados: passou.
2. Todos os atributos de um Torchic Nv. 20 acima dos mesmos atributos no Nv. 5: passou.
3. Bot com 0 insígnias para no Nv. 15 e descarta EXP excedente: passou.
4. Cap individual ao ganhar 1 insígnia (19), 8 insígnias (58) e virar Campeão (100): passou.
5. Treecko evolui para Grovyle no Nv. 16 após desbloqueio do limite: passou.
6. EVs não passam de 255 por atributo nem 510 no total: passou.
7. Combate do tipo Fogo causa dano variável e usa estatísticas reais: passou.
8. Save contém IV, EV, Nature e EXP: passou.
9. Missão do museu exige duas vitórias antes de avançar: passou.
10. Save antigo é convertido e permanece dentro do cap ao recarregar: passou.
11. Ataque normal contra Pokémon do tipo Fantasma é imune: passou.

## Teste de carregamento da interface (Chromium)

- Script do motor e páginas iniciam sem erros de JavaScript: passou em ambiente isolado.
- 20 treinadores e o teto do primeiro bot carregam: passou.
- Tentar desativar o cap não modifica a regra obrigatória: passou.
- 1.500 passos simulados sem erro de JavaScript: passou. Ao aguardar o tempo de falha no carregamento de mapas externos, o bot volta a caminhar e progride.

**Não testado integralmente:** todos os puzzles e NPCs nos mapas oficiais acessados via rede; uma jornada completa de cada bot até Wallace/Steven; todas as variantes de habilidades, itens, movimentos e tipos. Testar em hospedagem é recomendado.
