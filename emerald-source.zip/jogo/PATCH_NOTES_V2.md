# Emerald Living World — V2 | Atualização Treinadores de Hoenn

## Alterações
- Treinadores estáticos detectados pelo campo `trainer_type` dos mapas oficiais; NPCs comuns não disparam batalhas.
- Visão dos treinadores baseada no raio de visão oficial e nos blocos livres (paredes e objetos interrompem a visão).
- Direções fixas respeitadas; personagens que alternam o olhar usam as direções previstas pelo tipo de movimento.
- Bot que entra na visão de um treinador inicia batalha automaticamente, quando tiver Pokémon disponíveis.
- Vitória registra o treinador como derrotado no save da IA; derrotas permitem revanche depois de uma pausa.
- Monitor de caminhada tenta recalcular trajetos que permanecem bloqueados, sem teletransportar IAs.
- Mapa mostra treinadores com marcador `!` e campo de visão, e `✓` para os já derrotados pelo treinador observado.
- Painéis e cartões com retoques visuais; créditos V2 aprimorados, mantendo a imagem e o nome do criador.
- ZIP estruturado com `index.html` e pastas na raiz, para upload direto no Cloudflare Pages.

## Observações
- Equipes dos treinadores do mapa são simulações baseadas no catálogo regional; quando uma equipe nomeada está registrada no motor, ela é priorizada. Não reproduz todos os scripts e equipes do jogo original.
- Sprites dos treinadores no mapa ainda usam avatares da simulação em vez da arte específica de cada classe de NPC.
- A atualização não foi validada numa partida inteira publicada no Cloudflare; eventos mais complexos podem exigir novos ajustes.
- Saves locais permanecem no navegador; faça um backup pelas configurações antes de atualizar.
