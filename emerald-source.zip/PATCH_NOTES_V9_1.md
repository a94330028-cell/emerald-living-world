# 🌿 Patch Notes — Emerald Living World V9.1

**Tema:** Pokémon Quetzal PT-BR Alpha 9 v1 — Pokédex Nacional integrada.

## Adicionado

- Catálogo local de **1.025 espécies**, **494 formas internas** e **9 entradas experimentais** extraído da ROM fornecida pelo usuário.
- Tipagens, HP/Attack/Defense/Sp. Attack/Sp. Defense/Speed, taxa de captura e base EXP com dados reais de tabelas internas.
- Motor de batalha Node reconhecendo 1.528 registros, com suporte inicial ao tipo Fada.
- Evoluções por nível dos iniciais das nove gerações (regras curadas).
- Nova tela de Pokédex com pesquisa, filtros e paginação para Android e desktop.
- API `GET /api/dex` e `GET /api/dex/{slot}` e contadores em `/api/health`.
- Botão de encontros nacionais EXPERIMENTAIS, com biomas e limites de força para jogadores.
- Sprite de fallback para espécies sem imagem local.

## Preservado

- Simulação offline V9, modo de espectador, bots autônomos até a 3ª insígnia, mundo compartilhado, transições e saves.
- Encontros tradicionais de Hoenn e desafios da campanha dos bots.

## Não concluído

- Todos os sprites, learnsets, métodos de evolução e habilidades por espécie, encontros exatos da ROM, estados reais das formas, região completa e MMO pronto para publicação.
- Não foram incluídos arquivos da ROM ou sprites novos no pacote.

Veja `LEIA_PRIMEIRO_V9_1.md` para instruções e limitações.
