# 🌿 Emerald Living World — Versão 3.0 Beta

**Nova campanha experimental ampliada**
- Oito líderes de ginásio disponíveis através dos mapas de teste conectados.
- Liga Pokémon: Sidney, Phoebe, Glacia, Drake e Wallace, com vitória validada para progredir.
- Hall da Fama e desbloqueio da Battle Frontier oficial experimental após título.
- Os bots podem seguir para novas insígnias; **todos os Pokémon capturáveis e habitats nacionais existentes foram preservados**.
- Nova interface para desafios da Liga e indicadores de progresso.
- Todos os recursos da versão anterior foram incluídos: Arena Competitiva, Frontier LAB, simulação nacional e integração Gen III parcial.

**Beta — limitações**: mapas adaptados, eventos de história intermediários ausentes, Tate e Liza Single provisório, IA e regras Gen III incompletas, autenticação Supabase não implantada.
