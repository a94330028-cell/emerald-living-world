# 🌿 Emerald Living World — 3.0 RC1

- ⚔️ **Tate e Liza agora são uma Double Battle jogável**: dois Pokémon de cada lado, escolha dos dois movimentos, seleção de alvos, prioridade/velocidade e substituições após desmaios.
- 🤖 Bots ajustados para disputar o ginásio duplo e continuar a jornada de Hoenn.
- 📱 Interface de combate com seleção do segundo golpe e dos dois alvos.
- 🌎 Preservados os Pokémon nacionais, encontros, habitats e a Arena Competitiva.
- 🧪 Novos testes de integridade, combate duplo e desbloqueio por vitória.
- 🔍 Comando `npm run audit:release` para avaliar a preparação para publicação.

**Candidata à versão final; ainda não homologada para produção pública.** Permanecem pendentes Supabase Auth, fidelidade integral às regras da ROM, Frontier Brains/símbolos, história original completa e teste visual/de carga.
