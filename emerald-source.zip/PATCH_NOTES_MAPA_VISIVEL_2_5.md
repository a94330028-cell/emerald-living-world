# Emerald Living World — Versão 2.5 — Mapa visível novamente

## Bug corrigido
O mapa `liveWorld` desaparecia ao sair da abertura: `personal-landing.js` tentava colocar o canvas antes do elemento `liveBattleCinema`, mas a interface visual havia movido a transmissão para outro painel. O navegador lançava um erro e não concluía a movimentação do canvas.

## Correções
- `personal-landing.js`: reposiciona o canvas com uma âncora ainda presente no DOM ou acrescenta no final da área de jogo.
- `jogo/index.html`: a janela real do mapa vem **antes** dos controles avançados, mesmo quando algum JavaScript demora a carregar.
- `pokemon-illustrated-ui.js`: não duplica controles e começa com a caixa de ferramentas recolhida.
- `pokemon-illustrated-25.css`: reforça que o mapa tem prioridade visual no Android.
- Identificadores de cache dos scripts afetados foram atualizados.

## Verificações
- `npm test`: 124 testes aprovados.
- Chromium em tela Android: modo Observador com canvas visível e controles recolhidos; modo Só meu bot com o mesmo canvas movido para `myBotMapMount`; sem erros de JavaScript nesses cenários e sem overflow horizontal.
- **Não comprova** que todos os mapas oficiais estejam disponíveis em qualquer conexão, nem valida a campanha completa.

## Instalação
Extraia o ZIP e publique o conteúdo completo. O `index.html` deve estar na raiz, ao lado de `jogo/`, `server/` e das demais pastas. Faça backup do progresso antes de publicar. Para evitar cache antigo, recarregue o navegador após atualizar.
