# 🌿 EMERALD LIVING WORLD — V7 TRUE LIVING WORLD

-# ✦ Marco 1 — Jornada autônoma até Roxanne, com servidor e testes

__**🤖 IAs que realmente jogam**__
Bots escolhem inicial, atravessam as rotas de teste, procuram Pokémon selvagens, capturam, treinam, curam e enfrentam Roxanne. Sem subir de nível simplesmente por andar.

__**⚔️ Batalhas e primeira insígnia**__
Roxanne usa Geodude Nv. 12, Geodude Nv. 12 e Nosepass Nv. 15. A Stone Badge só é concedida após vencer os três. Evolução e EXP são calculadas após combates.

__**🗺️ Caminhos e interiores**__
Navegação com colisões e transições compartilhadas por bots e visitantes. Áreas de teste adicionadas até Rustboro e o ginásio — ainda não são os mapas completos oficiais.

__**👁️ Observatório**__
Acompanhe objetivos, time, vitórias, derrotas, capturas, decisões e ranking. O modo espectador segue qualquer bot no servidor.

__**💾 Simulação persistente**__
Configure de 5 a 100 bots. Eles continuam ativos com o servidor ligado e são restaurados após reiniciar o processo.

__**🧪 Testes**__
34 testes automatizados aprovados. Jornada completa até a primeira insígnia, reinício de servidor, grupos de 20 e 100 bots e visualização Android emulada verificados.

-# ⚠️ Ainda faltam a campanha completa, gráficos oficiais validáveis, regras integrais da Geração III, PvP, contas seguras e multiplayer pronto para produção. Não publique o chat de visitantes sem controles de segurança.
