# Patch Notes — Emerald Living World V3.3

### Imagens e interface
- Top 6 com áreas de sprite maiores e cards proporcionais no Android.
- Foco em imagens de Pokémon mais legíveis nas fichas.
- Preferência de ilustração detalhada ou pixel art clássico nas configurações.
- Alternativa offline usando arquivos de Pokémon previamente existentes.
- Enquadramento dinâmico de sprites locais, com proteção contra falhas de leitura de imagens externas.

### Preservado
- Saves, simulação, 100 IAs, mapas, ranking e chat da versão anterior.

### Observação
A ROM Quetzal foi analisada, mas **seus sprites compactados não foram inseridos**. A opção de arte detalhada usa recursos externos via PokeAPI, não dados extraídos da ROM.
