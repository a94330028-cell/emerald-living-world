# 🌿 Emerald Living World — versão 2.7 (bordas naturais e Discord)

Esta entrega atualiza a versão 2.6 sem remover o simulador, suas 100 IAs, funcionalidades ou o formato de save.

## Bordas de mapa

- Fundos escuros visíveis fora dos limites dos mapas externos recebem **decoração visual de acordo com a região**.
- Florestas e rotas terrestres: árvores estilizadas em pixel art com variações de posição.
- Áreas marítimas: ondas/água decorativas.
- Encostas e áreas vulcânicas: rochas e desníveis decorativos.
- Os efeitos são **somente visuais**: não criam caminhos, teletransportes nem alteram mapas oficiais ou colisões. Não substituem tiles oficiais, quando estiverem disponíveis.

## Comunidade

- Link para o Discord oficial na tela inicial, na página **Sobre o Projeto** e no rodapé.
- Endereço: https://discord.gg/6r9w3kA4sh
- Os links abrem uma nova aba, com `rel="noopener noreferrer"` por segurança.

## Como abrir

1. Descompacte o arquivo mantendo a estrutura de pastas.
2. Abra `jogo/index.html` a partir de um servidor web (ou publique a pasta do ZIP em um host estático).
3. No Android, use um navegador atualizado e confira a tela inicial.

## Validação

- **145 testes automatizados** da lógica do projeto aprovados após a decoração visual, incluindo navegação e progressão das IAs.
- Teste em Chromium emulado como Android: decoração de floresta, mar e vulcão, mapas adjacentes e ausência de rolagem horizontal.
- O teste de jornada que havia falhado na primeira execução passou na repetição (8 de 8).
- Validada separadamente a presença do link do Discord nos 3 pontos da interface e no navegador emulado.

**Limites:** não foi realizado teste com todos os mapas oficiais em um celular Android físico. O primeiro acesso aos recursos do `pokeemerald` ainda depende da disponibilidade da fonte de arquivos oficiais.
