# 🌿 Emerald Living World — Patch Notes 2.6

## 🌍 Mapa externo contínuo (Jogo)
- Costura geográfica dos exteriores com base nas conexões oficiais e offsets das bordas.
- Suporte a todas as rotas externas de Hoenn (101–134), cidades, vilas e áreas externas específicas.
- Travessia visual sem trocar de tela ao mudar entre mapas externos realmente adjacentes.
- Petalburg Woods, Rusturf Tunnel, cavernas, casas, centros, ginásios, Dive e áreas especiais permanecem mapas próprios.
- Nenhuma ligação falsa de Route 126 a Sootopolis por terra ou superfície do mar.

## ⚡ Otimizações
- Renderização progressiva em setores de 16×16 tiles e até 56 setores gráficos em cache.
- Prefetch limitado aos mapas vizinhos do mapa atual.
- Cache local persistente dos dados oficiais carregados com sucesso.
- Sprites extras de personagens carregados sob demanda, com cache.
- 100 IAs mantidas pelo motor da simulação mesmo fora do quadro; renderização só dos treinadores próximos.
- Mapa inteiro em forma de panorama topológico leve, sem reconstruir todo o continente.

## 🧪 Validação
- 138 testes Node aprovados.
- Smoke test de Android/Chromium aprovado.
- Teste de costura com duas áreas externas sintéticas aprovado.
- Cenário de desempenho com 100 treinadores sintéticos registrado em `tests/v26_connected_browser_report.json`.

-# A fidelidade dos mapas externos exige acesso inicial aos dados de `pret/pokeemerald`. Eventos especiais do Emerald original ainda não estão integralmente emulados.
