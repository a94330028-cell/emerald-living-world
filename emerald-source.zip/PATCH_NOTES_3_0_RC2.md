# 🌿 Emerald Living World — Patch Notes 3.0 RC2

**Novidade principal: autenticação do mundo compartilhado.**

- Tela integrada para cadastro e entrada com Supabase Auth.
- Backend verifica o token com o provedor antes de vincular a conta a um treinador.
- Modo `AUTH_MODE=required` para recusar visitantes em servidores públicos.
- Contas diferentes utilizam perfis de jogador diferentes, mesmo no mesmo navegador.
- Logout encerra sessão do servidor e conexão de eventos do jogador.
- Correção de loop de treinamento dos bots antes de Brawly: recuperam Pokémon de apoio desmaiados e limitam preparação improdutiva, sem conceder insígnias sem vitória.
- Testes de regressão preservam os Pokémon nacionais disponíveis para captura pelos bots.
- Mantidos ginásios de Hoenn, Liga, Double de Tate e Liza, Arena e protótipos da Frontier.

**Status:** candidata à versão final, **não** lançamento estável homologado.
