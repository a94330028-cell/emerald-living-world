# 🌿 Emerald Living World — V4 (revisão de progressão)

## Como jogar / publicar

1. Extraia o ZIP ou envie o conteúdo **completo** para a hospedagem estática (Netlify, Vercel ou similar). Há um `index.html` na raiz e a pasta `/jogo` deve ser enviada junto, sem renomear as pastas.
2. O endereço inicial redireciona para `/jogo/index.html`. Também é possível abrir diretamente `/jogo/#jogo`.
3. **Faça backup do save antes de substituir a V3.** O simulador usa armazenamento local do navegador; trocar domínio, limpar dados ou usar outro navegador pode ocultar o save antigo. Exporte o progresso nas opções existentes do jogo antes de atualizar.
4. A publicação não é automática: o ZIP precisa ser enviado à sua hospedagem.

## Correções desta versão

- **Bots deixam de ficar travados tentando os mesmos ginásios com um único Pokémon**: procuram parceiros em habitats, fazem batalhas de captura e montam equipes antes dos líderes.
- **Progressão:** preservados os limites de níveis por insígnia (15 / 19 / 24 / 29 / 31 / 33 / 42 / 46 / 58; campeão até 100). Cada treinador conserva seu progresso e não acumula XP acima do limite.
- **Atributos e combate:** cálculos por valores-base, nível, IV, EV e Nature, além de ajustes de ataques, defesa, críticos, golpes de status, imunidades e efeitos de terreno/clima. Mantida a divisão físico/especial por *tipo* da geração III.
- **Mais espécies catalogadas:** o conjunto de espécies que o motor de simulação conhece foi ampliado para 182, incluindo evoluções e personagens usados na campanha. Evoluções por pedra, amizade e métodos de troca adaptados ao simulador.
- **Liga Pokémon:** compras de Hyper Potion e Revive com dinheiro do treinador; itens consumidos entre os confrontos sem visita a Centro Pokémon, premiações proporcionais ao desafio, evolução de Pokémon por pedras antes de entrar. O uso não é gratuito nem infinito.
- **Pós-jogo:** recuperação após a Liga, encontros dos lendários, Regis e Steven; corrigido erro que interpretava início de combate como falha; melhor acompanhamento de captura/derrota; mapa alternativo quando o mapa oficial não carregar.
- **Saves:** migração de versões anteriores e preservação dos dados individuais de cada Pokémon.
- **Mapa:** mantidas as correções anteriores de portas, passagens e colisões; adicionados nomes alternativos para mapas de pós-jogo.

## Testes executados

- 16 testes automatizados de motor: níveis, crescimento, fórmula de atributos, IV/EV, evolução, imunidades, conservação de saves, história, itens da Liga e pós-jogo.
- Verificação do catálogo e dos alvos de evolução: **182 espécies, sem alvos evolutivos ausentes**.
- Teste de interface no Chromium com scripts completos e **sem erros de JavaScript observados**.
- Simulação de 20 treinadores com **navegação substituída por um simulador de chegada**, para isolar a lógica da campanha: 17 chegaram ao título de Campeão em uma rodada de 14.000 ticks. Esse teste **não confirma** a travessia de todos os tiles, warps e ginásios dos mapas oficiais.
- Teste isolado de pós-jogo: um Campeão chegou aos eventos de lendários e Steven, com captura/batalha e recuperação funcionando.

## Limitações importantes

Esta V4 **é um simulador de fãs no navegador, não a ROM completa do Pokémon Emerald**. Atualmente são 182 espécies no motor, não todas as 386 da Pokédex Nacional. Alguns golpes, habilidades, itens, treinadores opcionais, regras de batalhas duplas, puzzles e desafios da Battle Frontier têm adaptações ou implementações simplificadas. Os mapas oficiais dependem do carregamento remoto do repositório pret/pokeemerald; o modo de recuperação é simplificado. Nem todos os interiores e trajetos físicos puderam ser verificados por testes automatizados neste ambiente. O site publicado continua com sua versão antiga até um novo envio do ZIP.
