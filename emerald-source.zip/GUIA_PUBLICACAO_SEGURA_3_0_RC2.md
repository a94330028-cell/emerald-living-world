# Emerald Living World 3.0 RC2 — autenticação e publicação

## O que foi implementado neste pacote

- Vinculação de perfis do servidor ao `user.id` validado pelo Supabase Auth (`GET /auth/v1/user`).
- O servidor não confia em e-mail, ID ou `user_metadata` enviados pelo navegador.
- Interface de entrar/criar conta no **Mundo Compartilhado**; reutiliza a mesma configuração pública do Supabase da página principal.
- `AUTH_MODE=required` exige conta em todas as rotas de jogo e rejeita visitantes. `AUTH_MODE=guest` permanece para testes locais.
- Cada conta autentica o próprio perfil com progresso persistente no arquivo `world.json` sob `DATA_DIR`, não no navegador. Os perfis antigos de visitantes não são apagados.
- Saída da conta invalida o cookie e encerra as transmissões daquele perfil.
- Limite básico de tentativas de abrir sessão e testes automatizados de isolamento entre contas.
- **Não alterados**: catálogos, habitats, encontros e lógica de captura dos bots; arquivos centrais da Arena.
- Preparação dos bots antes de Brawly corrigida para impedir treinamento sem fim quando o Pokémon de apoio está desmaiado.

## Como ativar o login obrigatório

1. Configure o Supabase Authentication no projeto correspondente a `jogo/js/cloud-config.js` (URL/chave pública). A configuração de confirmação de e-mail é administrativa, não é removida por este ZIP.
2. No ambiente do processo Node, defina `AUTH_MODE=required`, `SUPABASE_URL`, `SUPABASE_ANON_KEY` (ou `SUPABASE_PUBLISHABLE_KEY`). **Nunca use `service_role` ou chave secreta no HTML.**
3. Configure um domínio HTTPS e um **volume persistente** para `DATA_DIR`. Sem o volume, os saves do mundo compartilhado podem desaparecer a cada publicação.
4. Execute `npm test`, `npm run audit:release` e `npm start`.
5. Abra `jogo/online.html`, entre na conta e só então clique em `Entrar no mundo`.
6. Teste cadastro, login, logout, reconexão e persistência em dois navegadores. Use controles de acesso/RLS no banco para as tabelas da parte offline.

O `Dockerfile` incluído executa o servidor Node com usuário não-root e exige login em produção. Configure as variáveis e anexe um volume persistente ao `/data` se optar por container; `VOLUME` sozinho não garante persistência no provedor.

## O que ainda impede chamar de versão final pública

- Supabase real não foi configurado, consultado ou validado ao vivo a partir deste arquivo. O fluxo de login foi testado contra uma API simulada em testes automatizados.
- Os dados de perfil do MMO ainda ficam no arquivo do servidor, não em tabelas de saves Supabase com RLS. Exige backup e volume persistente.
- A Battle Frontier ainda possui protótipos LAB; falta fidelidade completa de Brains, símbolos e regras específicas.
- O motor de batalha e a campanha não reproduzem completamente a ROM de Emerald.
- A interface não teve teste visual automatizado concluído em navegador e não houve teste de carga prolongada com 100 jogadores.

Este pacote é **3.0 RC2**, não uma homologação de produção. O objetivo é avançar de forma verificável sem perder o progresso nem anunciar recursos incompletos.

## Auditoria somente de leitura do Supabase conectado

O projeto Supabase ligado ao Emerald Living World respondeu como ativo. As tabelas públicas verificadas tinham RLS habilitado. A análise de segurança sinalizou tabelas sem políticas (podem estar deliberadamente fechadas), funções de chat `SECURITY DEFINER` que exigem revisão de permissões e proteção contra senhas vazadas desativada. Nenhuma política, função ou definição de Auth foi alterada remotamente nesta revisão. Confirme permissões e configurações antes de publicar.
