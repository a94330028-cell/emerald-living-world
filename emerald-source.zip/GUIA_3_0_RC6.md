# 📗 Instalação — Emerald Living World 3.0 RC6

1. Extraia este ZIP em uma pasta nova. Guarde seu ZIP e seus saves anteriores.
2. Tenha Node.js 20 ou superior.
3. Execute `npm test` para verificar os testes e `npm run audit:release` para confirmar os catálogos protegidos.
4. Inicie `npm start` e abra `http://localhost:8787/jogo/online.html`.
5. Acesse `http://localhost:8787/jogo/frontier.html` para o Frontier Pass LAB e as sete instalações.
6. Para abrir ao público, configure um servidor Node com HTTPS, armazenamento persistente, Supabase Auth verificado e `AUTH_MODE=required`, conforme o guia de publicação segura. **Não use chaves secretas no frontend.**

O Pass LAB é um índice de progresso demonstrativo 0–1000, **não** ranking mundial, Símbolos oficiais ou BP do jogo original.

## Verificações executadas

- `npm test`: 265 aprovados, zero reprovados no pacote RC6.
- `npm run audit:release`: preservação de seis arquivos verificada por hash.
- `npm run audit:production`: continua bloqueando a declaração de lançamento estável por pendências conhecidas.

## O que foi mantido

O mundo compartilhado com 100 bots configuráveis, os oito ginásios e Liga na adaptação online, as sete instalações LAB, a Arena Competitiva separada, o catálogo Quetzal e os Pokémon e habitats capturáveis pelos bots foram preservados.
