# Patch Notes — V9.10

- Corrigido o fallback visual de mapas: casas, caminhos, árvores, flores e decorações em vez do gramado quadriculado.
- Os obstáculos de recuperação agora compartilham colisões verificadas pelo sistema de navegação.
- Modo clássico de carregamento dos mapas oficiais preservado quando os arquivos carregam.
- Barra principal preservada: **Jogo | Pokémon | Rank**.
- Restaurado menu secundário com **17 destinos**, incluindo Créditos, Histórico, Recuperação, Hall da Fama, Mapa, Corrida, Configurações, Editor de Regras e rankings de força.
- Criada página de Recuperação com status do time e backup/importação de save.
- Testes adicionados de geometria e acesso a portas para mapas adaptados.
- Testes: 97/97 aprovados na última rodada e navegador móvel/desktop sem erros observados; um teste histórico de IA permanece intermitente.

**Não são mapas originais offline:** os cenários adaptados são redesenhados; os gráficos oficiais ainda requerem carregamento dos recursos externos.
