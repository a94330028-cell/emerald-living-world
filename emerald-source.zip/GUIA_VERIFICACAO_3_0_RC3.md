# Guia 3.0 RC3 — verificações antes de publicar

Esta build é uma **RC3 de desenvolvimento**, não o lançamento final.

### Como validar
1. Instale Node.js 20 ou superior; extraia o ZIP.
2. Execute `npm test` e `npm run audit:release`.
3. Execute `npm start` e abra `http://localhost:8787/jogo/online.html`.
4. Crie sessão, avance no jogo e teste `jogo/frontier.html`. Em um ambiente separado, simule vitórias perto dos marcos dos Brain challenges.
5. Faça testes de navegador em Android e desktop, da campanha completa à Liga, da Arena e dos 100 bots antes do lançamento público.

### Segurança
- A autenticação do servidor usa Supabase Auth; em produção, configure `AUTH_MODE=required`, `SUPABASE_URL` HTTPS e a chave **publicável**.
- Nunca exponha chave `service_role`/secret no frontend.
- Revisão read-only do Supabase realizada em 07/11/2026: foram reportadas tabelas com RLS sem políticas (podendo ser intencional), funções públicas `SECURITY DEFINER` que precisam de análise, e proteção contra senhas vazadas desativada. Esses pontos **não foram alterados automaticamente** e devem ser avaliados antes de divulgar o projeto.
- Não houve alteração em contas, senhas, usuários ou dados de produção.

### Integridade
- Os arquivos originais de habitats e encontros dos bots foram preservados sem alterações.
- As medalhas LAB não são os Símbolos oficiais.
- `npm run audit:production` permanece bloqueado até os requisitos de release estarem atendidos.
