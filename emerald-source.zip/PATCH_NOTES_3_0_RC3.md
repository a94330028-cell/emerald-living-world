# 🌿 Emerald Living World — Versão 3.0 RC3

Esta atualização **não é a versão 3.0 final estável**. A base é a RC2. Foram implementados confrontos de exibição dos **sete Frontier Brains** no servidor do mundo compartilhado, seus marcos, equipes de espécies da Gen III, registro de vitórias LAB e proteção das recompensas oficiais.

## Conteúdo acrescentado
- **Anabel (Tower)**: confronto de exibição na 35ª e 70ª batalha.
- **Tucker (Dome)**: confronto na 20ª e 40ª batalha do protótipo (aproximação das finais do 5º e 10º torneios).
- **Spenser (Palace)**: 21ª e 42ª batalha.
- **Greta (Arena)**: 28ª e 56ª batalha.
- **Noland (Factory)**: 21ª e 42ª batalha, com equipe aleatória de alugados.
- **Lucy (Pike)**: salas 28 e 140. O marco exige uma batalha real; não pode ser avançado por uma sala vazia.
- **Brandon (Pyramid)**: andares 21 e 70. O marco exige uma batalha real.
- Equipes de espécie e nomes inspirados nos originais de Emerald; os **movesets e itens são adaptações** compatíveis com o motor atual. Eles não são uma cópia exata do jogo de GBA.
- Golpes ofensivos extras da Gen III no subconjunto de combate: Psychic, Thunderbolt, Fire Blast, Ice Beam, Dragon Claw, Shadow Ball, Body Slam, Return (potência máxima simplificada), Flamethrower, Crunch, Sludge Bomb, Aerial Ace, Hydro Pump, três punches elementais, Meteor Mash, Megahorn, Brick Break, Slash, Iron Tail, Ancient Power e Superpower (alguns efeitos secundários permanecem incompletos).
- Página Frontier LAB atualizada: avisos honestos sobre os confrontos, PP de golpes, medidores de pontos e medalhas **LAB**.

## Recompensas honestas e anti-duplicação
- Os confrontos adaptados **nunca concedem Símbolos oficiais de Prata/Ouro nem BP oficial**.
- Vitórias contra Frontier Brains conferem somente `frontier.labSymbols` (medalha de exibição).
- Pontos LAB, recordes LAB e recompensas oficiais são armazenados separadamente.
- O servidor impede pontuação duplicada para o mesmo resultado e aplica regras de banimento de espécies da Frontier original **somente na inscrição**, sem excluir os Pokémon dos habitats.

## Sistemas preservados
Os arquivos de espécies, habitats, encontros nacionais e autonomia dos bots, bem como os módulos centrais da Arena Competitiva, permanecem iguais à RC2. A história, os 100 bots configurados, os oito ginásios, a Liga e a autenticação da RC2 foram mantidos.

## O que ainda impede o anúncio de versão estável
1. As **sete instalações oficiais** ainda não têm seus modos completos de GBA (Pyramid com mapas autênticos, Dome com chave de 16 participantes, Palace com probabilidades completas por natureza, julgamentos Mind/Skill/Body, modo Multi e Battle Tower Double, eventos reais da Pike).
2. Motor Gen III ainda parcial; nem todos os movimentos, habilidades, itens, arredondamentos e efeitos foram reproduzidos e comparados à ROM.
3. História, NPCs, mapas e transições completas da campanha original ainda estão incompletos.
4. Falta um teste de navegador Android real, teste de carga de usuários simultâneos, configuração de domínio/HTTPS, testes de Supabase Auth com contas reais e revisão das políticas de RLS no banco publicado.
5. **Nenhum deploy foi realizado.** Não copie as credenciais de serviço do Supabase para o navegador.

## Executar localmente
Requer Node.js >=20:
```bash
npm test
npm run audit:release
npm start
```
Abrir `http://localhost:8787/jogo/online.html` e visitar a opção `Battle Frontier LAB`.

Em produção, `AUTH_MODE=required` e as configurações de Supabase devem ser feitas apenas no servidor. Ver também `GUIA_PUBLICACAO_SEGURA_3_0_RC2.md`.

Referências do design da Frontier: https://serebii.net/emerald/frontierleader.shtml e https://bulbapedia.bulbagarden.net/wiki/Appendix:Emerald_walkthrough/Section_21
