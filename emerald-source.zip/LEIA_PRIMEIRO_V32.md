# Emerald Living World 3.2 — Seu Treinador + sprites centralizados

Esta é uma atualização **da versão 3.1**, sem recriar o projeto nem mudar o formato dos saves.

## Tela do modo Meu Treinador

Ordem em dispositivos móveis:
1. Mapa animado da jornada (o mesmo canvas do jogo).
2. Equipe atual do treinador (com Pokémon e atributos existentes).
3. **Decisões da jornada:** Seguir história, Treinar, Procurar Pokémon, Explorar ou Desafiar treinador.
4. **Top 6 Pokémon mais fortes** da simulação, incluindo reservas dos treinadores.

O modo **Meu Treinador** não avança a jornada automaticamente quando não há uma decisão de progressão selecionada. Golpes em batalhas permanecem disponíveis para escolha manual. As outras IAs permanecem independentes. Certas ações podem estar indisponíveis devido a localização, Pokébolas, etapa de história e configuração da simulação.

## Velocidade

A escala visível passa a **1×, 2×, 3×, 5×**, mapeando para a solicitação anterior de 40×, 80×, 120× e 200× no acumulador de eventos da simulação. A CPU tem limite de trabalho por quadro para evitar bloqueios de interface, então esses fatores são **alvos lógicos**, não garantia de aceleração real em todos os celulares. Os saves antigos recebem migração automática da preferência de velocidade.

## Centralização das imagens Pokémon

- **432 arquivos locais** normalizados em `jogo/assets/pokemon_fit`: 162 sprites PNG + 270 GIFs animados.
- Todos os arquivos têm quadro transparente 64×64, com figura centralizada em até 52×52 e proporções preservadas.
- Os originais foram mantidos nas pastas antigas para recuperação.
- A interface usa os novos arquivos e regras CSS de enquadramento nos cards, batalhas, Pokédex, equipe, PC e ranking.
- GIFs continuam com seis quadros de animação e mesma duração por quadro.
- Sprites externos à coleção local mantêm enquadramento CSS, mas o conteúdo interno depende da fonte externa.

## Testes e limites

- Testes automatizados do projeto.
- Verificação de todos os arquivos normalizados, dimensões e quadros dos GIFs.
- Teste offline do site no Chromium mobile com mapa, time, ações, Top 6 e velocidade.
- **Não foram testados** 100 IAs em um celular físico durante uma campanha inteira, nem o Supabase em produção.

Para publicação, envie **todo o conteúdo do ZIP**, mantendo a mesma estrutura de pastas. Não exclua o conteúdo de `jogo/`.
