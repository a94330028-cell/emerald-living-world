# Emerald Living World — Versão 2.5 (Esmeralda + Escuro + PC)

## Visual
- Tema esmeralda inspirado no visual Pokémon clássico e alternativa escura pelo botão no cabeçalho (preferência salva no navegador).
- Pokédex vermelha funcional, com consulta ao catálogo existente.
- Cartão do treinador com os Pokémon da equipe ao lado do retrato.
- No PC, equipe ao lado do treinador e reservas abaixo.
- Mapa e botões de navegação mantidos; controles técnicos agrupados em área recolhível.

## Como iniciar
- No modo estático: abra o `index.html` na raiz por uma hospedagem web (não dentro do ZIP).
- Para o modo online, use `npm start` em uma hospedagem Node.js persistente.
- Salve/exporte o progresso antes de atualizar.

## Validação
- 121 testes automatizados aprovados em 2026-11-05 (arquivo `tests` no pacote).
- Prévia visual isolada da página em temas claro/esmeralda e escuro e da Pokédex.
- O teste de ponta a ponta do navegador com conexão local foi bloqueado no ambiente; portanto não há garantia sobre todos os estados e dispositivos.
