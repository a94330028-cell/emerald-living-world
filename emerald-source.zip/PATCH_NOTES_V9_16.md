# V9.16 — Cercas, caminhos e Centros Pokémon

- Removido realinhamento automático de posições isoladas em mapas oficiais.
- NPCs e objetos de evento fixos passam a bloquear a grade de navegação.
- Arquivos de save inválidos não são mais transportados silenciosamente para Littleroot.
- Retrocesso para o Centro Pokémon permitido apenas após derrota total da equipe.
- Cura parcial exige caminhar até um Centro Pokémon; nada de curas instantâneas.
- Novos testes para fences, NPCs, blackouts, saves bloqueados e transições.
- Corrigida a condição do teste de evolução de Treecko para não parar quando outro Pokémon evolui.
- Preservados os sistemas e gráficos da V9.15.
