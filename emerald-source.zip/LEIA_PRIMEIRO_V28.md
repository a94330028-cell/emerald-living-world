# Emerald Living World 2.8 — Bordas oficiais, Mobile e Plataforma

Atualização incremental sobre a versão 2.7: o jogo, os sprites, os saves e os arquivos anteriores foram mantidos.

## O que está no ZIP
- O preenchimento de bordas do mundo externo passa a copiar pixels dos chunks oficiais carregados, alinhados aos tiles, sem adicionar árvores artificiais nem alterar as colisões. O resultado definitivo de cada bioma depende dos gráficos originais disponíveis; quando ainda não estão carregados, existe fallback de cor do bioma.
- Controles de qualidade gráfica (econômica, automática e alta) e ajustes de renderização mobile.
- Páginas públicas Sobre, Atualizações, Privacidade e Estatísticas; metadados para compartilhamento e imagem de apresentação.
- `robots.txt`, `sitemap.xml` e `llms.txt` para o domínio configurado nos arquivos. Confirme o domínio real antes de publicar.
- Estrutura de painel `/admin` com autenticação Supabase e verificação **no servidor** de membro administrador, sem desbloqueio por e-mail apenas no navegador.
- Scripts SQL para analytics, acesso restrito (RLS), funções de estatísticas públicas e administrativas e telemetria consentida.

## O que PRECISA ser configurado para funcionar online
1. Criar ou reutilizar o projeto Supabase e configurar seu endereço e chave **anon/publishable** em `jogo/js/cloud-config.js`. **Nunca** colocar a chave `service_role` no site.
2. No SQL Editor do Supabase, executar `supabase/setup.sql` e depois `supabase/analytics_admin.sql`. Inspecione os scripts antes de executá-los em um banco já em uso.
3. Publicar as Edge Functions em `supabase/functions/`: `telemetry`, `admin-dashboard` e `public-stats`. Configurar origens autorizadas, JWT e os segredos somente no servidor.
4. Registrar a conta administradora, confirmar o e-mail e inserir **seu UUID autenticado** em `public.elw_admins` por operação administrativa no SQL Editor. Há um exemplo comentado ao final de `supabase/analytics_admin.sql`. Não há administrador automático por e-mail.
5. Configurar Auth (SMTP, URLs de redirecionamento, confirmação de e-mail e recuperação de senha). Testar com uma conta comum e uma conta administradora.
6. Publicar em hospedagem compatível com site estático e Supabase externo; verificar o domínio em `robots.txt`, `sitemap.xml`, `llms.txt` e tags canonical/Open Graph.

## Testes e limites
- Suíte Node: 151 testes aprovados na execução de 06/11/2026 (`tests/v28_node_suite.log`).
- Smoke Chromium **offline**: checks de desenho em grade de 16 px com chunks simulados e bloqueio do painel sem configuração (`tests/v28_browser_report.json`).
- **Não foi comprovado** acesso real ao Supabase, contagens de visitantes, envio de eventos, entrega de e-mails, experiência em Android/iPhone reais, 60 FPS ou toda a navegação de Hoenn após deploy. O servidor, os mapas oficiais e as chaves precisam estar disponíveis para os testes de integração.
- Estatísticas começam vazias (não são inventadas) e, no modo configurado, exigem consentimento do visitante. As 100 IAs não contam como usuários humanos.

## Publicação
Enviar o conteúdo do ZIP preservando a estrutura de diretórios. Antes de substituí-lo em produção, fazer backup do projeto e dos saves/usuários. O ZIP não altera a hospedagem sozinho.
