# Emerald Living World 3.6 — Arena Competitiva

## O que já funciona sem depender de servidores

- Abra **jogo/arena.html** (ou o atalho Arena na página inicial).
- Escolha 1×1, 3×3 ou 6×6.
- Monte até seis Pokémon dentre 1.025 espécies, use o sorteio ou um time sugerido.
- Enfrente bots de três dificuldades em batalhas adaptadas por turnos com 4 ataques e trocas, vantagens de tipo e HP.
- Acompanhe Elo e histórico locais de vitórias/derrotas. Não exige explorar Hoenn.
- A Arena não modifica os Pokémon ou o save da campanha.

## Partidas entre pessoas (PvP)

- SQL de `supabase/migrations/20261106_arena_pvp.sql`: tabelas de fila, partidas e ranking de Elo protegidas por RLS. Migração aplicada ao Supabase conectado em 6/11/2026.
- Código do backend em `supabase/functions/arena-online/`.
- No PvP, é preciso entrar com uma conta Supabase e confirmar o e-mail. Somente o servidor pode registrar vitórias e atualizar Elo mundial. Partidas contra bots não contam.
- O frontend usa a função `arena-online` e exibe mensagens de erro quando a função, a sessão ou os serviços online estiverem indisponíveis.
- **A Arena Beta utiliza regras simplificadas**, não reproduz integralmente mecânicas oficiais de batalha (abilities, itens, EVs, PP, status etc.).
- A Edge Function `arena-online` foi implantada no Supabase conectado em 6/11/2026, com `verify_jwt=false` exclusivamente para permitir leitura pública do ranking. Todas as ações de partidas exigem token de usuário válido e e-mail confirmado.
- A função publicada consulta atributos oficiais pela PokeAPI ao iniciar partidas PvP; isso requer disponibilidade da PokeAPI. O código-fonte no ZIP inclui uma implementação alternativa com catálogo local das 1.025 espécies.
- O PvP ainda precisa ser validado com DUAS contas diferentes confirmadas antes do anúncio público.

## Publicação

A hospedagem `fantasticbell.chatgpt.site` não é atualizada pelo ZIP automaticamente. É preciso publicar os arquivos do ZIP. Nunca colocar chaves privadas/service_role no navegador.

## Testes

- `npm run test:arena` — testes unitários de 1×1/3×3/6×6, tipos, dano, swaps, Elo e proteção da campanha.
- `npm run test:browser:arena` — smoke test isolado da Arena em Chromium mobile.
- Para PvP real, testar duas contas confirmadas e validar o ranking e o estado compartilhado.
