# Patch Notes — V3.1

## Interface
- removido o card teaser da Pokédex da tela principal do jogo;
- removido o bloco "Rank e Pokémon" da tela principal do jogo;
- tela principal ficou mais limpa e focada no mapa;
- página "Equipe e batalhas" atualizada para orientar o jogador a usar as abas corretas.

## Preservado
- saves locais;
- simulação das IAs;
- Pokédex;
- ranking;
- navegação por abas.
