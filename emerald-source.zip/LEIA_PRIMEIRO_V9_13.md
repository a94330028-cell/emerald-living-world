# 🌿 Emerald Living World V9.13 — Direção estável dos personagens

## Correções implementadas
- **Online:** a direção mostrada é obtida do passo validado pelo servidor, e não de uma indicação de direção que pode chegar desatualizada no mesmo instante. Quando o personagem fica parado, conserva a direção anterior.
- **Mapa principal:** a interpolação só muda o lado para o qual o personagem olha depois de um deslocamento ortogonal de um tile; pausa e passagem de mapa não provocam giro visual.
- **NPCs do cenário:** NPCs que não possuem movimento animado deixaram de girar automaticamente a cada instante. Apenas instruções explícitas de múltiplas direções podem mudar a direção lentamente.
- **Rotas das IAs:** os desvios opcionais passam a evitar repetições de posições e viradas excessivas; bots comuns priorizam a rota mais direta.
- **Cache:** versões dos scripts atualizadas no HTML para não carregar o código de movimentação antigo.

## Mantido da V9.12
Jogo, Pokémon e Rank, Top 6, mapa oficial com recuperação adaptada, modo solo, modos de simulação, créditos, recuperação, captura, batalha, evoluções, sprites Brendan/May 16×32 e 32×48 e configuração de até 100 IAs.

## Testes executados
- `npm test`: **103/103 testes passaram na execução registrada** (`tests/v9_13_all_tests.log`).
- `python tests/browser-v9-13-facing.py`: passaram testes de interface e direção no Chromium em resolução Android. Um personagem andou à direita mesmo com direção antiga no snapshot; ao parar continuou olhando à direita; outro personagem andou para cima com a direção correta. O render offline manteve a direção ao parar. Relatório: `tests/v9_13_browser_report.json`.
- O teste online de interface **simulou** as mensagens do servidor. Os testes reais do motor e da API são separados e fazem parte da regressão.

## Limites ainda existentes
- Ainda não há reprodução fiel e completa de todos os scripts e movimento dos NPCs da ROM oficial.
- Os mapas oficiais exigem acesso aos recursos externos, com modo de recuperação quando indisponíveis.
- Os testes demonstram correções de direção e prevenção de ciclos nos cenários previstos, mas não validam visualmente todos os mapas, celulares e sprites do projeto.
- O site publicado não se atualiza com o download deste ZIP; o novo pacote precisa ser instalado na hospedagem.

## Instalação
1. Faça backup de seus saves.
2. Substitua os arquivos publicados pela V9.13 (na raiz, com `index.html` e pasta `jogo`).
3. Recarregue a página com atualização de cache ou feche e abra a aba.
4. O modo online continua exigindo servidor Node.js e hospedagem persistente.
