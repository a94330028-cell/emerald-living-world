# 🌿 Patch Notes V9.9 — Jogo · Pokémon · Rank

- ✅ Apenas 3 páginas principais, com navegação responsiva.
- ✅ Pokémon do treinador no topo da jornada solo.
- ✅ Visão da equipe e Pokédex reunidas na página Pokémon.
- ✅ Ranking principal exclusivamente por insígnias.
- ✅ Página secundária de força: times mais fortes, Pokémon mais forte e Top 6 Pokémon.
- ✅ Preservados os mapas da V9.8 e as escolhas da jornada.
- ✅ Preservada a simulação, multiplayer experimental e demais códigos do projeto.
- 🧪 Testes de interface Android e desktop aprovados. Regressão antiga de EXP de IA segue com falha intermitente.
