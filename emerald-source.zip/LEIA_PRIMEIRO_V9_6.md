# 🌿 Emerald Living World V9.6 — Novos sprites centralizados

Esta atualização preserva a V9.5 e substitui os arquivos visuais de Brendan e May pelo material fornecido pelo usuário.

## O que mudou
- `jogo/assets/overworld/brendan_v2.png`, `may_v2.png`: novas folhas compactas 48×128 (16×32 por frame).
- `jogo/assets/overworld/brendan_detailed.png`, `may_detailed.png`: novas folhas detalhadas 96×192 (32×48 por frame).
- `jogo/client/animation/trainer-sprites.js`: atlas centralizado com duas variantes, recortes exatos 3×4 e alinhamento de hitbox à base do personagem.
- `jogo/js/world.js`: usa a arte detalhada na câmera da simulação, com aspecto original e pés ancorados ao tile. Se a arte detalhada não carregar, usa a compacta.
- `jogo/multiplayer/client.js` e `jogo/js/official-maps.js`: usam automaticamente a versão compacta atualizada para preservar a escala de tiles 16×16.
- Referências de scripts atualizadas para evitar o cache antigo no Android.
- `jogo/assets/overworld/PREVIA_SPRITES_NOVOS.png`: prévia fornecida no ZIP.

## O que NÃO foi alterado
- 100 IAs, batalhas, capturas, evolução, ranking, mapas, colisões e saves. O multiplayer ainda requer Node.js em hospedagem persistente.

## Validação
- Testes automáticos de tamanho e coordenadas de frames, alinhamento da hitbox e regressão executados.
- Imagens PNG e transparência verificadas.
- Este pacote não prova que todos os mapas e animações estejam visualmente perfeitos em todos os navegadores; confira a renderização no seu aparelho após publicar.

## Importante
Os sprites fornecidos são uma interpretação redesenhada em pixel art, e não uma extração oficial da ROM. A ROM não é incluída no pacote.

### Instalação
Faça backup do save, substitua os arquivos da hospedagem pelo conteúdo do projeto e limpe o cache do site se a versão antiga continuar aparecendo. Para o modo online, execute `npm start` a partir da pasta principal em uma hospedagem com Node.js.

## Arquivos extras para editar os quadros
- `jogo/assets/overworld/source_frames/compacto_16x32/`: 24 PNGs individuais.
- `jogo/assets/overworld/source_frames/principal_32x48/`: 24 PNGs individuais.
- `jogo/assets/overworld/animacoes.json`: mapa das direções e ordem dos passos.
