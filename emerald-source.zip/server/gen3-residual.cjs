'use strict';
/** Incremental Gen III residual primitives. This is NOT the full Emerald end-turn script.
 * Deliberately supports only a documented subset, with injectable RNG and event logs.
 * Do not invoke on modern Arena battles.
 */
const VALID_STATUSES = new Set(['poison','toxic','burn']);
function check(mon){
 if(!mon || !Number.isInteger(mon.maxHp)||mon.maxHp<1||!Number.isInteger(mon.hp)||mon.hp<0||mon.hp>mon.maxHp)throw Error('Invalid Pokemon HP');
 if(mon.status!=null&&!VALID_STATUSES.has(mon.status))throw Error('Unsupported status for residual subset');
}
function fraction(maxHp,denominator){return Math.max(1,Math.floor(maxHp/denominator));}
function apply(mon,kind,amount,events){
 if(mon.hp===0)return;
 const before=mon.hp;
 mon.hp=Math.max(0,Math.min(mon.maxHp,mon.hp+amount));
 const actual=mon.hp-before;
 if(actual)events.push({kind,delta:actual,hp:mon.hp});
 if(before>0&&mon.hp===0)events.push({kind:'faint',hp:0});
}
/** End-turn subset for one active Pokemon. Weather occurs before per-Pokemon items/status.
 * Leech Seed healing of the opposing slot, abilities, Wish, etc. are NOT implemented.
 * toxicCounter belongs to the active battle state and resets upon switching.
 */
function resolveOne(mon,{weather=null,leftovers=false,seeded=false,weatherImmune=false}={}){
 check(mon);
 const events=[];
 if(mon.hp===0)return {events,hp:0};
 if((weather==='sandstorm'||weather==='hail')&&!weatherImmune)apply(mon,'weather',-fraction(mon.maxHp,16),events);
 if(mon.hp===0)return {events,hp:0};
 if(leftovers&&mon.hp<mon.maxHp)apply(mon,'leftovers',fraction(mon.maxHp,16),events);
 if(seeded)apply(mon,'leech-seed-damage',-fraction(mon.maxHp,8),events);
 if(mon.status==='poison'||mon.status==='burn')apply(mon,mon.status,-fraction(mon.maxHp,8),events);
 if(mon.status==='toxic'&&mon.hp>0){
  const next=Math.min(15,Math.max(0,Number.isInteger(mon.toxicCounter)?mon.toxicCounter:0)+1);
  mon.toxicCounter=next;
  apply(mon,'toxic',-Math.max(1,Math.floor(mon.maxHp*next/16)),events);
 }
 return {events,hp:mon.hp};
}
function resetOnSwitch(mon){if(!mon||typeof mon!=='object')throw Error('Invalid Pokemon');mon.toxicCounter=0;}
module.exports={resolveOne,resetOnSwitch,fraction};
