'use strict';
/** A* (uniform cost) over the shared authoritative collision geometry. The bot
 * never transmits a position: it asks world.step for one cardinal move. */
const {MAPS,walkable,step,portalOpen}=require('./world.cjs');
const DELTAS=[['up',0,-1],['right',1,0],['down',0,1],['left',-1,0]];
function mapRoute(start,goal,profile=null){
 if(!MAPS[start]||!MAPS[goal])return null;
 if(start===goal)return [];
 const todo=[start],seen=new Set([start]),first=new Map();
 for(let i=0;i<todo.length;i++){
  const area=todo[i];
  // Center/Mart are shared interior layouts. Their real exit is the door
  // remembered on this specific traveler; the static map portal is only a fallback.
  const realReturn=(area===start&&['Center','Mart'].includes(area)&&profile?.returnDoor&&MAPS[profile.returnDoor.area]&&walkable(profile.returnDoor.area,profile.returnDoor.x,profile.returnDoor.y))
   ? MAPS[area].portals.map(p=>({...p,to:profile.returnDoor.area,tx:profile.returnDoor.x,ty:profile.returnDoor.y})) : MAPS[area].portals;
  for(const portal of realReturn){
   if(profile&&!portalOpen(profile,portal))continue;
   if(seen.has(portal.to)||((/Gym$|^League/.test(portal.to)||['Center','Mart','Lab','House','StevenChamber'].includes(portal.to))&&portal.to!==goal&&!(goal.startsWith('League')&&portal.to.startsWith('League'))&&!(goal==='HallOfFame'&&portal.to.startsWith('League'))&&!(start.startsWith('League')&&portal.to.startsWith('League'))))continue;
   seen.add(portal.to);first.set(portal.to,{from:area,portal});
   if(portal.to===goal){let cur=goal;const route=[];while(cur!==start){const edge=first.get(cur);route.unshift(edge);cur=edge.from;}return route;}
   todo.push(portal.to);
  }
 }
 return null;
}
function localDirections(area,startX,startY,targetX,targetY,allowPortalTarget=false){
 if(!walkable(area,startX,startY)||!walkable(area,targetX,targetY))return null;
 if(startX===targetX&&startY===targetY)return [];
 const map=MAPS[area],toKey=(x,y)=>`${x}:${y}`,start=toKey(startX,startY),dest=toKey(targetX,targetY);
 const q=[[startX,startY]],prev=new Map([[start,null]]);
 for(let i=0;i<q.length;i++){
  const [x,y]=q[i];
  for(const [dir,dx,dy] of DELTAS){const nx=x+dx,ny=y+dy,k=toKey(nx,ny);
   if(prev.has(k)||!walkable(area,nx,ny))continue;
   // Passing through a warp changes maps. Treat it as a terminal path cell.
   if(map.portals.some(p=>p.x===nx&&p.y===ny)&&(k!==dest||!allowPortalTarget))continue;
   prev.set(k,{x,y,dir});
   if(k===dest){const result=[];let at=k;while(at!==start){const entry=prev.get(at);result.unshift(entry.dir);at=toKey(entry.x,entry.y);}return result;}
   q.push([nx,ny]);
  }
 }
 return null;
}
// A single bot can request the same route dozens of times per minute. Keep
// plans in a WeakMap (never in persisted saves), and replan only if its
// position, goals, permissions, or the actual collision outcome changes.
const plans=new WeakMap();
const STATS={builds:0,hits:0,blocked:0,alternatives:0};
function routeKey(bot,target){
 const flags=Object.entries(bot.story||{}).filter(([,v])=>v===true).map(([k])=>k).sort().join(',');
 const back=bot.returnDoor?`${bot.returnDoor.area}:${bot.returnDoor.x}:${bot.returnDoor.y}`:'';
 return [target.area,target.x,target.y,bot.badges||0,flags,back].join('|');
}
function ingressPortals(bot){
 const m=MAPS[bot.area];if(!m)return [];
 if(['Center','Mart'].includes(bot.area)&&bot.returnDoor&&MAPS[bot.returnDoor.area]&&
   walkable(bot.returnDoor.area,bot.returnDoor.x,bot.returnDoor.y)){
  return m.portals.map(p=>({...p,to:bot.returnDoor.area,tx:bot.returnDoor.x,ty:bot.returnDoor.y}));
 }
 return m.portals;
}
function buildPlan(bot,target){
 STATS.builds++;
 if(bot.area===target.area){
  const onPortal=MAPS[bot.area].portals.some(p=>p.x===target.x&&p.y===target.y);
  const directions=localDirections(bot.area,bot.x,bot.y,target.x,target.y,onPortal);
  return directions===null?{reason:'no-path'}:{directions,arrival:directions.length===0};
 }
 const candidates=[];
 for(const p of ingressPortals(bot)){
  // A shared Center/Mart interior is NOT an intercity shortcut. Its exit uses
  // the visitor's returnDoor; entering it to reach another city loops forever.
  if(!['Center','Mart'].includes(bot.area)&&['Center','Mart'].includes(p.to)&&p.to!==target.area)continue;
  if(!portalOpen(bot,p)||!MAPS[p.to]||!walkable(p.to,p.tx,p.ty))continue;
  let dirs=localDirections(bot.area,bot.x,bot.y,p.x,p.y,true);
  if(dirs===null)continue;
  // A stale save on a warp tile must step out and back through the warp.
  if(!dirs.length){
   for(const [out,dx,dy] of DELTAS){
    const ax=bot.x+dx,ay=bot.y+dy;
    if(!walkable(bot.area,ax,ay)||MAPS[bot.area].portals.some(w=>w.x===ax&&w.y===ay))continue;
    const back=localDirections(bot.area,ax,ay,p.x,p.y,true);
    if(back?.length){dirs=[out,...back];break;}
   }
  }
  if(!dirs.length)continue;
  // Find actual multi-area progress; a shortest graph edge with an
  // unreachable local doorway is never selected.
  const next=p.to===target.area?[]:mapRoute(p.to,target.area,bot);
  if(!next)continue;
  const hops=next.length+1;
  candidates.push({directions:dirs,hops,score:hops*100+dirs.length,portal:p});
 }
 if(!candidates.length)return {reason:'unreachable-door'};
 candidates.sort((a,b)=>a.score-b.score||a.portal.y-b.portal.y||a.portal.x-b.portal.x);
 if(candidates.length>1)STATS.alternatives++;
 return candidates[0];
}
function walkToward(bot,target){
 if(!target||!MAPS[target.area]||!Number.isInteger(target.x)||!Number.isInteger(target.y)||
    !walkable(target.area,target.x,target.y))return {ok:false,reason:'unknown-or-blocked-target'};
 if(!MAPS[bot.area]||!walkable(bot.area,bot.x,bot.y))return {ok:false,reason:'invalid-current-position'};
 if(bot.area===target.area&&bot.x===target.x&&bot.y===target.y)return {ok:true,arrived:true};
 const key=routeKey(bot,target);
 let plan=plans.get(bot);
 if(!plan||plan.key!==key||plan.area!==bot.area||plan.x!==bot.x||plan.y!==bot.y||!plan.directions.length){
  const next=buildPlan(bot,target);
  if(next.reason)return {ok:false,reason:next.reason};
  if(next.arrival)return {ok:true,arrived:true};
  plan={key,area:bot.area,x:bot.x,y:bot.y,directions:next.directions.slice(),portal:next.portal};
  plans.set(bot,plan);
 }else STATS.hits++;
 const dir=plan.directions.shift(),from=bot.area;
 if(!step(bot,dir)){
  plans.delete(bot);STATS.blocked++;
  return {ok:false,reason:'step-blocked',dir};
 }
 if(bot.area!==from){plans.delete(bot);return {ok:true,arrived:false,dir,transition:`${from}->${bot.area}`};}
 plan.x=bot.x;plan.y=bot.y;
 if(!plan.directions.length)plans.delete(bot);
 return {ok:true,arrived:false,dir};
}
function clearRoute(bot){plans.delete(bot);}
function stats(){return {...STATS};}
module.exports={mapRoute,localDirections,walkToward,clearRoute,stats};
