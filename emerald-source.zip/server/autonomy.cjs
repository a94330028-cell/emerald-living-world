'use strict';
/** Real first-badge vertical slice for V7, NOT a full Emerald storyline.
 * No counters for free level-ups, badges or captures. All battles are resolved
 * by the SAME Battle.begin/act functions used for players at /api/battle/*. */
const crypto=require('node:crypto');
const Battle=require('./battle.cjs');
const Nav=require('./navigation.cjs');
const Story=require('./story.cjs');
const Shop=require('./shop.cjs');
const {MAPS,walkable,blackoutRespawn}=require('./world.cjs');
const StartOptions=require('../jogo/game/pokemon/starters.js');
const AVATARS=require('../jogo/assets/overworld/characters/manifest.json').characters.map(c=>c.id);
const STARTERS=[...StartOptions.TRIOS[2],...StartOptions.ALL.filter(x=>!StartOptions.TRIOS[2].includes(x))];
const PHASES={
 starter:'Escolher Pokémon inicial',leave:'Sair de Littleroot pela Rota 101',
 capture:'Enfraquecer e capturar um Pokémon na Rota 101',recruit:'Buscar um Pokémon de Grama em Petalburg Woods',travel:'Atravessar Hoenn rumo a Rustboro',
 prepare:'Treinar a equipe para enfrentar Roxanne',gym:'Entrar no ginásio e desafiar Roxanne',
 post:'Treinar e evoluir após a Stone Badge',
 aqua:'Recuperar Peeko e os produtos Devon no Rusturf Tunnel',boat:'Viajar com Mr. Briney até Dewford',
 steven:'Entregar a carta a Steven em Granite Cave',prepareBrawly:'Montar equipe para enfrentar Brawly',
 gymBrawly:'Vencer os três Pokémon de Brawly em Dewford',slateport:'Viajar de barco até Slateport',
 prepareRival:'Treinar equipe para superar o rival na Rota 110',rival110:'Enfrentar o rival na Route 110',wally:'Enfrentar Wally em Mauville',
 prepareWattson:'Preparar equipe para o desafio de Wattson',gymWattson:'Vencer os quatro Pokémon de Wattson',
 next:'Percorrer os demais ginásios de Hoenn',lateGym:'Treinar e desafiar o próximo líder de Hoenn',league:'Conquistar a Liga Pokémon em batalhas reais',champion:'Campeão de Hoenn: explorar o pós-jogo'
};
function log(bot,type,message,extra={}){
 bot.events??=[];const event={tick:bot.ticks||0,type,message,area:bot.area,...extra};bot.events.push(event);
 if(['starter','capture','evolution','badge','story'].includes(type)){bot.milestones??=[];bot.milestones.push(event);if(bot.milestones.length>200)bot.milestones.shift();}
 if(bot.events.length>80)bot.events.splice(0,bot.events.length-80);
 bot.lastAction=message;
}
function createBot(n){return {id:`bot-${n}`,name:`Red ${String(n).padStart(2,'0')}`,
 avatar:AVATARS[(n-1)%AVATARS.length],starter:STARTERS[(n-1)%STARTERS.length],channel:(n-1)%3+1,
 area:'Littleroot',x:14,y:10,facing:'down',mode:'bot',team:[],bag:{pokeballs:5},money:500,
 badges:0,wins:0,losses:0,steps:0,ticks:0,phase:'starter',objective:PHASES.starter,events:[],
 stateVersion:8,createdAt:Date.now(),nationalEncounters:true,visitedAreas:['Littleroot'],milestones:[]};}
function migrate(bot){
 if(bot.stateVersion>=7&&Array.isArray(bot.events)&&typeof bot.phase==='string'){
  if(bot.badges>=1&&bot.phase==='next'&&bot.badges<3){bot.phase='aqua';bot.objective=PHASES.aqua;}
  bot.stateVersion=8;
  if(!walkable(bot.area,bot.x,bot.y)&&!bot.navigationBlocked){bot.navigationBlocked=true;log(bot,'blocked','Save em posição inválida; nenhuma relocação automática foi feita.');}
  return bot;
 }
 // V6 artificially increased levels; preserve that historic data but do not
 // certify it as EXP earned, and never award a badge during migration.
 const old=Array.isArray(bot.team)?bot.team:[];
 bot.team=old.filter(m=>Battle.SPEC[m.species]).map(m=>{
  if(m.ivs&&m.evs&&Array.isArray(m.moves))return m;
  const fresh=Battle.create(m.species,Math.max(1,Math.min(100,Number(m.level)||5)));
  return {...fresh,legacyUnverifiedLevel:true};
 });
 bot.events??=[];bot.visitedAreas??=[bot.area];bot.milestones??=[];bot.bag??={pokeballs:5};bot.money??=500;bot.badges??=0;
 bot.wins??=0;bot.losses??=0;bot.steps??=0;bot.ticks??=0;
 if(!MAPS[bot.area]||!walkable(bot.area,bot.x,bot.y))bot.navigationBlocked=true;
 if(!bot.team.length)bot.phase='starter';else bot.phase=bot.area==='Route101'?'capture':'travel';
 bot.objective=PHASES[bot.phase];bot.stateVersion=8;
 log(bot,'migration','Equipe histórica V6 preservada; níveis antigos sem comprovação de EXP.');
 return bot;
}
function setPhase(bot,phase){if(bot.phase===phase)return;bot.phase=phase;bot.objective=PHASES[phase];log(bot,'goal',`Novo objetivo: ${bot.objective}`);}
function navigate(bot,target){const from=bot.area;const state=Nav.walkToward(bot,target);
 if(state.ok&&!state.arrived){bot.steps=(bot.steps||0)+1;if(bot.area!==from){bot.visitedAreas??=[];if(!bot.visitedAreas.includes(bot.area))bot.visitedAreas.push(bot.area);log(bot,'map',`Entrou em ${MAPS[bot.area]?.title||bot.area}.`);}}
 else if(!state.ok){bot.stuck=(bot.stuck||0)+1;if(bot.stuck%50===1)log(bot,'blocked',`Sem caminho para ${target.area}: ${state.reason}.`);}
 return state;
}
function shouldHeal(bot){const team=bot.team||[];if(!team.length)return false;
 const grass=Battle.SPEC[bot.starter]?.types.includes('Fire')&&bot.phase==='prepare'?team.find(m=>['Shroomish','Breloom','Lotad'].includes(m.species)):null;
 return !Battle.firstAlive(bot)||team[0].hp<=Math.max(2,Math.floor(team[0].maxHp*.35))||(grass&&grass.hp<=Math.floor(grass.maxHp*.35))||team.every(m=>m.hp<=Math.max(3,Math.floor(m.maxHp*0.3)));
}
function healJourney(bot){
 if(bot.area==='Center'){
  Battle.heal(bot);log(bot,'heal','Equipe recuperada no Centro Pokémon.');
  bot.recovering=false;bot.leavingCenter=true;
 }
 else navigate(bot,{area:'Center',x:14,y:17});
}
function chooseAttack(own,foe){return Battle.availableMoves(own).filter(m=>m==='Struggle'||(Battle.MOVES[m]&&Battle.MOVES[m].power>0))
 .sort((a,b)=>Battle.estimate(own,foe,b)-Battle.estimate(own,foe,a))[0]||own.moves[0]||'Tackle';}
function selectMove(bot){const foe=bot.battle.enemy,own=Battle.firstAlive(bot);if(!own)return null;
 if(bot.battle.format==='double'){
  const a=bot.team.find(m=>m.id===bot.battle.doubleSlots?.A1&&m.hp>0);
  const ally=bot.team.find(m=>m.id===bot.battle.doubleSlots?.A2&&m.hp>0);
  const target=bot.battle.enemy?.hp>0?bot.battle.enemy:bot.battle.enemyPartner;
  const other=bot.battle.enemyPartner?.hp>0?bot.battle.enemyPartner:target;
  if(!target)return null;
  return {type:'move',move:chooseAttack(a||ally,target),partnerMove:ally&&a?chooseAttack(ally,other):undefined,
   target:target===bot.battle.enemy?'B1':'B2',partnerTarget:other===bot.battle.enemy?'B1':'B2'};
 }
 if(bot.battle.type==='wild'&&bot.phase==='prepare'&&Battle.SPEC[bot.starter]?.types.includes('Fire')&&['Shroomish','Breloom','Lotad'].includes(own.species)&&bot.team[0].hp>0&&bot.activeIndex!==0){return {type:'switch',move:0};}
 const current=Battle.estimate(own,foe,chooseAttack(own,foe));
 const switchIndex=(bot.team||[]).findIndex((m,i)=>i!==bot.activeIndex&&m.hp>m.maxHp*0.5&&Battle.estimate(m,foe,chooseAttack(m,foe))>Math.max(6,current*1.8));
 if(bot.battle.type==='gym'&&switchIndex>=0)return {type:'switch',move:switchIndex};
 const nationalWanted=bot.battle.type==='wild'&&bot.battle.nationalEncounter&&
  !bot.team.some(m=>m.species===foe.species)&&bot.bag.pokeballs>0&&
  ((bot.team.length<4)||
   (bot.team.length<6&&bot.team.every(m=>!Battle.SPEC[m.species].types.some(tp=>Battle.SPEC[foe.species].types.includes(tp)))));
 if(bot.battle.type==='wild'&&(nationalWanted||(bot.phase==='capture'&&bot.team.length<2)||(bot.phase==='recruit'&&foe.species==='Shroomish')||
   (bot.phase==='prepareBrawly'&&['Wingull','Taillow'].includes(foe.species)&&!bot.team.some(m=>['Wingull','Taillow','Swellow','Pelipper'].includes(m.species)))||
   (bot.phase==='prepareWattson'&&foe.species==='Geodude'&&!bot.team.some(m=>Battle.SPEC[m.species]?.types.includes('Ground'))))&&bot.bag.pokeballs>0){
  if(foe.hp<=Math.ceil(foe.maxHp*.65)||own.hp<=Math.floor(own.maxHp*.35)||['prepareBrawly','prepareWattson'].includes(bot.phase))return {type:'ball'};
  const damaging=own.moves.filter(m=>Battle.MOVES[m]?.power>0).sort((a,b)=>Battle.estimate(own,foe,a)-Battle.estimate(own,foe,b));
  return {type:'move',move:damaging[0]||chooseAttack(own,foe)};
 }
 return {type:'move',move:chooseAttack(own,foe)};
}
function battleTurn(bot){
 const before=bot.team.map(m=>({id:m.id,species:m.species,level:m.level}));
 const beforeTeam=bot.team.length,beforePC=(bot.pc||[]).length;
 const battleType=bot.battle.type,gymTarget=bot.battle.targetId;
 const beforeBadges=bot.badges,priorWins=bot.wins||0,priorLosses=bot.losses||0,priorStory={...bot.story};
 const action=selectMove(bot);if(!action)return;
 const outcome=Battle.act(bot,action);
 if(bot.team.length>beforeTeam||(bot.pc||[]).length>beforePC){const stored=(bot.pc||[]).length>beforePC;const m=stored?bot.pc.at(-1):bot.team.at(-1);
  bot.captureCount=(bot.captureCount||0)+1;
  log(bot,'capture',`${m.species} Nv. ${m.level} capturado em batalha real${stored?' e enviado ao PC':''}.`,{species:m.species});}
 for(let i=0;i<before.length;i++){
  const m=bot.team.find(x=>x.id===before[i].id);if(!m)continue;
  if(m.level>before[i].level)log(bot,'level',`${m.species} subiu do nível ${before[i].level} para ${m.level}.`);
  if(m.species!==before[i].species)log(bot,'evolution',`${before[i].species} evoluiu para ${m.species}!`);
 }
 if(bot.badges>beforeBadges){const leader={1:'Roxanne (Stone Badge)',2:'Brawly (Knuckle Badge)',3:'Wattson (Dynamo Badge)',4:'Flannery (Heat Badge)',5:'Norman (Balance Badge)',6:'Winona (Feather Badge)',7:'Tate & Liza (Mind Badge)',8:'Juan (Rain Badge)'}[bot.badges]||'Líder';
  log(bot,'badge',`${leader} derrotado em batalha completa. Insígnia ${bot.badges} conquistada.`,{badges:bot.badges});}
 for(const [key,name] of [['peeko','Peeko e produtos Devon recuperados'],['rival110','Rival derrotado na Route 110'],['wally','Wally derrotado em Mauville']]){
  if(!priorStory[key]&&bot.story?.[key])log(bot,'story',name);
 }
 if((bot.wins||0)>priorWins)log(bot,'victory',`Batalha vencida: ${bot.wins} vitória(s).`);
 if((bot.losses||0)>priorLosses){
  log(bot,'defeat',`Batalha perdida. Tentará outra estratégia.`,{losses:bot.losses});
  if(battleType==='trainer'&&bot.phase==='rival110'){
   bot.rivalRetries=(bot.rivalRetries||0)+1;
   if(bot.rivalRetries>=2)setPhase(bot,'prepareRival');
  }
 }
 if(outcome.done){if(bot.phase==='capture'&&(bot.team.length>1||bot.bag.pokeballs<=0))setPhase(bot,'travel');
  if(bot.phase==='recruit'&&(bot.team.some(m=>m.species==='Shroomish')||bot.bag.pokeballs<=0))setPhase(bot,'prepare');
  if(bot.phase==='gym'&&bot.badges>=1)setPhase(bot,'post');
  if(bot.phase==='aqua'&&bot.story?.peeko)setPhase(bot,'boat');
  if(bot.phase==='gymBrawly'&&bot.badges>=2)setPhase(bot,'slateport');
  if(bot.phase==='rival110'&&bot.story?.rival110)setPhase(bot,'wally');
  if(bot.phase==='wally'&&bot.story?.wally)setPhase(bot,'prepareWattson');
  if(bot.phase==='gymWattson'&&bot.badges>=3)setPhase(bot,'next');
  if(bot.phase==='lateGym'&&bot.badges>beforeBadges)setPhase(bot,'lateGym');
  if(bot.phase==='league'&&bot.champion)setPhase(bot,'champion');
  if((bot.losses||0)>priorLosses&&battleType==='gym'){
   bot.gymRetries??={};bot.gymRetries[gymTarget]=(bot.gymRetries[gymTarget]||0)+1;
   const back={roxanne:'prepare',brawly:'prepareBrawly',wattson:'prepareWattson',flannery:'lateGym',norman:'lateGym',winona:'lateGym',tate_liza:'lateGym',juan:'lateGym'}[gymTarget];
   if(back)setPhase(bot,back);
  }}
}
function beginWild(bot){
 // National encounters use the SAME real Battle.begin/Battle.act as players.
 // Preserve curated story-capture phases (Shroomish, Wingull, Geodude).
 const curated=new Set(['recruit','prepareBrawly','prepareWattson']);
 const national=bot.nationalEncounters!==false&&!curated.has(bot.phase)&&(bot.phase==='capture'||(bot.ticks||0)%5===0);
 Battle.begin(bot,{type:'wild',national});
 if(national&&bot.battle)bot.battle.nationalEncounter=true;
 log(bot,'encounter',`Encontro ${national?'nacional ':''}selvagem: ${bot.battle.enemy.species} Nv. ${bot.battle.enemy.level}.`);
}
function startStoryBattle(bot,id){Battle.begin(bot,{type:'trainer',trainerId:id});log(bot,'trainer',`Batalha de história iniciada: ${Battle.STORY_TRAINERS[id]?.name||id}.`);}
function trainFor(bot,{targetLevel,otherLevel,trainingArea,limit,maxEffort=2200}){
 const main=bot.team[0],second=bot.team.find(m=>m!==main&&m.hp>0&&m.level<otherLevel);
 const selected=main.level<targetLevel?main:second;
 if(!selected)return true;
 bot.activeIndex=bot.team.indexOf(selected);
 if(bot.area!==trainingArea){navigate(bot,{area:trainingArea,x:14,y:12});return false;}
 beginWild(bot);return false;
}
function seekSupplies(bot,city,wildArea){
 if(bot.money>=Shop.PRICES.pokeballs){
  if(bot.area!=='Mart'){navigate(bot,{area:'Mart',x:14,y:17});return true;}
  const amount=Math.min(5,Math.floor(bot.money/Shop.PRICES.pokeballs));
  if(amount>0){const bought=Shop.buy(bot,'pokeballs',amount);log(bot,'purchase',`Comprou ${bought.count} Poké Bolas por ₽${bought.cost}.`);bot.leavingMart=true;return true;}
 }
 if(bot.area!==wildArea){navigate(bot,{area:wildArea,x:14,y:12});return true;}
 beginWild(bot);return true;
}
function prepare(bot){
 const grass=bot.team.find(m=>['Shroomish','Breloom','Lotad','Lombre'].includes(m.species));
 if(Battle.SPEC[bot.starter]?.types.includes('Fire')&&!grass){setPhase(bot,'recruit');return;}
 const priority=Battle.SPEC[bot.starter]?.types.includes('Fire')&&grass?grass:bot.team[0];
 const goal=15;
 if(priority.level>=goal){bot.activeIndex=bot.team.indexOf(priority);setPhase(bot,'gym');return;}
 bot.activeIndex=bot.team.indexOf(priority);
 const field=priority.level<8?'Woods':'Route104North';
 if(bot.area!==field){navigate(bot,{area:field,x:14,y:12});return;}
 beginWild(bot);
}
function advance(bot){
 migrate(bot);bot.ticks=(bot.ticks||0)+1;
 if(!bot.battle&&bot.area!=='Center'&&!Battle.firstAlive(bot)&&bot.team?.length){
  if(blackoutRespawn(bot)){
   bot.recovering=true;bot.navigationBlocked=false;
   log(bot,'blackout','Equipe inteira derrotada: voltou ao Centro Pokémon.');
  }else{bot.navigationBlocked=true;log(bot,'blocked','Centro Pokémon inacessível após derrota total.');}
 }
 if(bot.navigationBlocked){bot.lastAction='Posição inválida: sem teletransporte automático';return;}
 if(bot.phase==='starter'){
  // Start Pokémon is chosen and created once; its IVs/EVs remain stable.
  Battle.createProfileStarter(bot);log(bot,'starter',`${bot.name} escolheu ${bot.starter} Nv. 5 em Littleroot.`);
  setPhase(bot,'leave');return;
 }
 if(bot.battle){battleTurn(bot);return;}
 if(bot.leavingMart){
  if(bot.area!=='Mart')bot.leavingMart=false;
  else {navigate(bot,{area:'Mart',x:14,y:19});return;}
 }
 if(bot.leavingCenter){
  if(bot.area!=='Center')bot.leavingCenter=false;
  else {navigate(bot,{area:'Center',x:14,y:19});return;}
 }
 // Optional NPC battle is real and does not mint badges or XP without winning.
 // Story-critical tasks take priority; avoid creating a forced infinite loop.
 if(!bot.battle&&bot.badges>=1&&bot.phase!=='post'&&bot.ticks%5===0&&bot.team?.some(m=>m.hp>0)){
  const npc=Battle.optionalTrainerAt(bot);
  if(npc&&bot.team.some(m=>m.level>=npc.team[0][1])){
   Battle.begin(bot,{type:'npc',trainerId:npc.id});
   log(bot,'trainer',`Desafiou ${npc.name} na rota, com equipe real.`);
   return;
  }
 }
 if(shouldHeal(bot)){bot.recovering=true;}
 if(bot.recovering){healJourney(bot);return;}
 switch(bot.phase){
  case 'leave':
   if(bot.area==='Route101'){setPhase(bot,'capture');return;}
   navigate(bot,{area:'Route101',x:14,y:16});return;
  case 'capture':
   if(bot.team.length>=2||bot.bag.pokeballs<=0){setPhase(bot,'travel');return;}
   if(bot.area!=='Route101'){navigate(bot,{area:'Route101',x:14,y:13});return;}
   beginWild(bot);return;
  case 'recruit':
   if(bot.team.some(m=>['Shroomish','Breloom','Lotad','Lombre'].includes(m.species))){setPhase(bot,'prepare');return;}
   if(bot.bag.pokeballs<=0){seekSupplies(bot,'Rustboro','Woods');return;}
   if(bot.area!=='Woods'){navigate(bot,{area:'Woods',x:14,y:12});return;}
   beginWild(bot);bot.recruitTries=(bot.recruitTries||0)+1;
   if(bot.battle.enemy.species!=='Shroomish'){
    Battle.act(bot,{type:'run'});log(bot,'strategy','Ignorou encontro: procura Shroomish para o ginásio de Pedra.');
   }
   return;
  case 'travel':
   if(bot.area==='Rustboro'){setPhase(bot,'prepare');return;}
   navigate(bot,{area:'Rustboro',x:14,y:11});return;
  case 'prepare':prepare(bot);return;
  case 'gym':
   if(bot.badges>=1){setPhase(bot,'post');return;}
   if(bot.area!=='RustboroGym'||Math.abs(bot.x-14)+Math.abs(bot.y-9)>2){navigate(bot,{area:'RustboroGym',x:14,y:10});return;}
   Battle.begin(bot,{type:'gym'});log(bot,'gym','Desafio real iniciado contra Roxanne: Geodude 12, Geodude 12 e Nosepass 15.');return;
  case 'post':
   if(bot.team.some(m=>m.level>=16)){setPhase(bot,'aqua');return;}
   if(bot.area!=='Route104North'){navigate(bot,{area:'Route104North',x:14,y:12});return;}
   beginWild(bot);return;
  case 'aqua':
   if(bot.story?.peeko){setPhase(bot,'boat');return;}
   if(bot.area!=='RusturfTunnel'||Math.abs(bot.x-14)+Math.abs(bot.y-9)>2){navigate(bot,{area:'RusturfTunnel',x:14,y:10});return;}
   startStoryBattle(bot,'aqua_grunt');return;
  case 'boat':
   if(bot.area==='Dewford'){setPhase(bot,'steven');return;}
   navigate(bot,{area:'Dewford',x:14,y:12});return;
  case 'steven':
   if(bot.story?.steven){setPhase(bot,'prepareBrawly');return;}
   if(bot.area!=='StevenChamber'||Math.abs(bot.x-14)+Math.abs(bot.y-8)>2){navigate(bot,{area:'StevenChamber',x:14,y:9});return;}
   {const event=Story.interact(bot);log(bot,'story',event.description);setPhase(bot,'prepareBrawly');}return;
  case 'prepareBrawly':{
   const flyer=bot.team.find(m=>['Wingull','Taillow','Swellow','Pelipper'].includes(m.species));
   if(!flyer&&bot.team.length<6){
    if(bot.bag.pokeballs<=0){seekSupplies(bot,'Dewford','Route106');return;}
    if(bot.area!=='Route106'){navigate(bot,{area:'Route106',x:14,y:12});return;}
    beginWild(bot);bot.flyerTries=(bot.flyerTries||0)+1;
    if(!['Wingull','Taillow'].includes(bot.battle.enemy.species)){Battle.act(bot,{type:'run'});log(bot,'strategy','Ignorou encontro: procura um Pokémon Voador para Brawly.');}return;
   }
   // Do not grind a fainted Flying supporter forever while a healthy lead
   // collects all the EXP. Try bounded preparation, then challenge Brawly
   // with the genuinely trained team; the badge still requires a real win.
   const retries=bot.gymRetries?.brawly||0;
   const supportGoal=Math.min(19,15+retries*2);
   const supportBudget=Math.min(300,120+retries*40);
   const support=flyer&&flyer.level<supportGoal&&(bot.brawlySupportTraining||0)<supportBudget?flyer:null;
   const main=bot.team[0],mainGoal=Math.min(30,19+retries*2);
   const focus=main.level<mainGoal?main:support;
   if(!focus){setPhase(bot,'gymBrawly');return;}
   if(focus.hp<=0){bot.recovering=true;healJourney(bot);return;}
   bot.activeIndex=bot.team.indexOf(focus);
   if(bot.area!=='Route106'){navigate(bot,{area:'Route106',x:14,y:12});return;}
   beginWild(bot);if(focus===support)bot.brawlySupportTraining=(bot.brawlySupportTraining||0)+1;
   return;
  }
  case 'gymBrawly':
   if(bot.badges>=2){setPhase(bot,'slateport');return;}
   if(bot.area!=='DewfordGym'||Math.abs(bot.x-14)+Math.abs(bot.y-9)>2){navigate(bot,{area:'DewfordGym',x:14,y:10});return;}
   Battle.begin(bot,{type:'gym'});log(bot,'gym','Desafio real iniciado contra Brawly: Machop 16, Meditite 16, Makuhita 19.');return;
  case 'slateport':
   if(bot.area==='Slateport'){setPhase(bot,'rival110');return;}
   navigate(bot,{area:'Slateport',x:14,y:11});return;
  case 'prepareRival':{
   // Never fake a win: the rival can counter a Water starter with Lombre.
   // Train a secondary party member through wild battles, then retry.
   const support=bot.team.filter(m=>m!==bot.team[0]).sort((a,b)=>b.level-a.level)[0];
   const main=bot.team[0];const goal=Math.min(Battle.levelCap(bot),22);
   const selected=support&&support.level<goal?support:main.level<goal?main:null;
   if(!selected){setPhase(bot,'rival110');return;}
   bot.activeIndex=bot.team.indexOf(selected);
   if(bot.area!=='Route106'){navigate(bot,{area:'Route106',x:14,y:12});return;}
   beginWild(bot);return;
  }
  case 'rival110':
   if(bot.story?.rival110){setPhase(bot,'wally');return;}
   if(bot.area!=='Route110'||Math.abs(bot.x-14)+Math.abs(bot.y-11)>2){navigate(bot,{area:'Route110',x:14,y:12});return;}
   startStoryBattle(bot,'rival110');return;
  case 'wally':
   if(bot.story?.wally){setPhase(bot,'prepareWattson');return;}
   if(bot.area!=='Mauville'||Math.abs(bot.x-14)+Math.abs(bot.y-11)>2){navigate(bot,{area:'Mauville',x:14,y:12});return;}
   startStoryBattle(bot,'wally');return;
  case 'prepareWattson':{
   const ground=bot.team.find(m=>Battle.SPEC[m.species]?.types.includes('Ground'));
   if(!ground&&bot.team.length<6){
    if(bot.bag.pokeballs<=0){seekSupplies(bot,'Dewford','GraniteCave');return;}
    if(bot.area!=='GraniteCave'){navigate(bot,{area:'GraniteCave',x:14,y:12});return;}
    beginWild(bot);if(bot.battle.enemy.species!=='Geodude'){
      Battle.act(bot,{type:'run'});log(bot,'strategy','Procura Geodude para enfrentar Pokémon Elétricos.');}return;
   }
   const main=bot.team[0];
   // Ground-type immunity is already useful before Lv.23. Requiring a freshly
   // captured Geodude to grind to 23 made some bots loop for tens of thousands
   // of ticks before Wattson. The lead still needs real training and every
   // gym badge continues to require an actual battle victory.
   const focus=main.level<24?main:ground&&ground.level<18?ground:null;
   if(!focus){setPhase(bot,'gymWattson');return;}
   if(focus.hp<=0){bot.recovering=true;healJourney(bot);return;}
   bot.activeIndex=bot.team.indexOf(focus);
   if(bot.area!=='Route110'){navigate(bot,{area:'Route110',x:14,y:12});return;}
   beginWild(bot);return;
  }
  case 'gymWattson':
   if(bot.badges>=3){setPhase(bot,'next');return;}
   if(bot.area!=='MauvilleGym'||Math.abs(bot.x-14)+Math.abs(bot.y-9)>2){navigate(bot,{area:'MauvilleGym',x:14,y:10});return;}
   Battle.begin(bot,{type:'gym'});log(bot,'gym','Desafio real iniciado contra Wattson: Voltorb 20, Electrike 20, Magneton 22, Manectric 24.');return;
  case 'next':setPhase(bot,'lateGym');return;
  case 'lateGym':{
   if(bot.badges>=8){setPhase(bot,'league');return;}
   const next=Object.values(Battle.GYMS).find(g=>g.badge===bot.badges+1);
   if(!next)return;
   const cap=Battle.levelCap(bot);
   const retries=bot.gymRetries?.[next.id]||0;
   // Emerald level caps are advisory, not an XP prohibition. After genuine
   // defeats the AI trains a little further instead of repeating the same
   // losing matchup forever. No badges or experience are granted for free.
   const goal=Math.min(100,cap+Math.min(18,2*Math.floor(retries/4)));
   const team=bot.team.filter(m=>m.hp>0).sort((a,b)=>b.level-a.level);
   const counter=next.id==='flannery'&&retries>=6?team.find(m=>
     m!==bot.team[0]&&Battle.SPEC[m.species]?.types.some(t=>['Water','Ground','Rock'].includes(t))&&m.level<Math.min(goal,30)):null;
   // Prefer preparing a viable elemental counter when one is already owned.
   // The existing habitat and capture system remains untouched.
   const under=counter||(team[0]?.level<goal?team[0]:null);
   if(under){
    bot.activeIndex=bot.team.indexOf(under);
    // Train and meet wild Pokémon by the same real Battle.begin and Battle.act
    // paths. National encounter tables are unchanged.
    const trainingArea=({4:'Route112',5:'Route118',6:'Route120',7:'Route127',8:'VictoryRoad'})[next.badge]||'Route111';
    const nearby=Battle.AREAS[trainingArea]?trainingArea:'Route111';
    if(bot.area!==nearby){navigate(bot,{area:nearby,x:14,y:12});return;}
    beginWild(bot);return;
   }
   if(bot.area!==next.area||Math.abs(bot.x-14)+Math.abs(bot.y-9)>2){navigate(bot,{area:next.area,x:14,y:10});return;}
   Battle.begin(bot,{type:'gym'});log(bot,'gym',`Desafio real iniciado contra ${next.name}, insígnia ${next.badge}.`);return;
  }
  case 'league':{
   if(bot.champion){setPhase(bot,'champion');return;}
   const next=Battle.LEAGUE.find(e=>!bot.story?.[e.flag]);if(!next){setPhase(bot,'champion');return;}
   if(bot.area!==next.area||Math.abs(bot.x-14)+Math.abs(bot.y-9)>2){navigate(bot,{area:next.area,x:14,y:10});return;}
   Battle.begin(bot,{type:'league'});log(bot,'trainer',`Desafio da Liga iniciado contra ${next.name}.`);return;
  }
  case 'champion':
   if(bot.area!=='HallOfFame')navigate(bot,{area:'HallOfFame',x:14,y:12});return;
  default:bot.phase='travel';bot.objective=PHASES.travel;
 }
}
function view(bot,detail=false){return {id:bot.id,name:bot.name,avatar:bot.avatar,area:bot.area,channel:bot.channel,
 x:bot.x,y:bot.y,facing:bot.facing,starter:bot.starter,phase:bot.phase,objective:bot.objective,
 badges:bot.badges||0,champion:bot.champion===true,leagueWins:bot.leagueWins||0,wins:bot.wins||0,losses:bot.losses||0,steps:bot.steps||0,
 team:(bot.team||[]).map(m=>({species:m.species,level:m.level,hp:m.hp,maxHp:m.maxHp})),
 lastAction:bot.lastAction||'',...(detail?{events:(bot.events||[]).slice(-35),battle:Battle.publicBattle(bot),ticks:bot.ticks,bag:bot.bag,money:bot.money,visitedAreas:bot.visitedAreas||[],milestones:bot.milestones||[],legacyUnverified:bot.team.some(m=>m.legacyUnverifiedLevel)}:{})};}
module.exports={createBot,migrate,advance,view,PHASES};
