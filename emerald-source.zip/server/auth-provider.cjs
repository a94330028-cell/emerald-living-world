'use strict';
/** Server-side identity check. Never trust browser-supplied user IDs or JWT payloads. */
const MODE=process.env.AUTH_MODE==='required'?'required':'guest';
const URL=(process.env.SUPABASE_URL||'').replace(/\/+$/,'');
const KEY=process.env.SUPABASE_ANON_KEY||process.env.SUPABASE_PUBLISHABLE_KEY||'';
const configured=!!(URL&&KEY);
if(process.env.NODE_ENV==='production'&&MODE!=='required')throw Error('Produção exige AUTH_MODE=required para bloquear visitantes.');
if(MODE==='required'&&(!configured||!/^https:\/\//.test(URL)&&process.env.NODE_ENV!=='test')){
 throw Error('AUTH_MODE=required exige SUPABASE_URL HTTPS e SUPABASE_ANON_KEY (ou SUPABASE_PUBLISHABLE_KEY).');
}
const timeout=Number(process.env.AUTH_TIMEOUT_MS)||6000;
async function verifyToken(header){
 if(!configured)throw Object.assign(Error('Supabase Auth não configurado'),{status:503});
 const m=/^Bearer ([A-Za-z0-9._~-]+)$/.exec(String(header||''));
 if(!m||m[1].length<16||m[1].length>8192)throw Object.assign(Error('Token de conta inválido'),{status:401});
 let r;
 try{
  r=await fetch(URL+'/auth/v1/user',{method:'GET',headers:{apikey:KEY,authorization:`Bearer ${m[1]}`},signal:AbortSignal.timeout(timeout)});
 }catch{throw Object.assign(Error('Serviço de autenticação indisponível'),{status:503});}
 if(r.status===401||r.status===403)throw Object.assign(Error('Sessão da conta expirada ou inválida'),{status:401});
 if(!r.ok)throw Object.assign(Error('Serviço de autenticação indisponível'),{status:503});
 let user;try{user=await r.json();}catch{throw Object.assign(Error('Resposta inválida do serviço de autenticação'),{status:503});}
 if(!user||typeof user.id!=='string'||!/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(user.id)||user.is_anonymous===true)
  throw Object.assign(Error('Entre com uma conta cadastrada'),{status:401});
 return {id:user.id}; // Never authorize from user_metadata, email or client-provided role.
}
module.exports={MODE,configured,verifyToken};
