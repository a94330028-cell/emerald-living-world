'use strict';
/** V9: an online guest can challenge the SAME persistent bot Pokémon, not
 * a newly generated copy. An active duel pauses that bot's autonomous loop.
 * No ROM assets or client-provided stats are trusted here. */
const Battle=require('./battle.cjs');
const DUPLEX_MS=5*60*1000;
function cloneTeam(bot){return (bot.team||[]).filter(m=>m?.hp>0&&Battle.SPEC[m.species]).map(m=>structuredClone(m));}
function locked(bot,at=Date.now()){return Boolean(bot?.duelWith&&at-Number(bot.duelTouchedAt||0)<DUPLEX_MS);}
function release(bot){if(!bot)return;delete bot.duelWith;delete bot.duelTouchedAt;}
function begin(player,bot,at=Date.now()){
 if(!bot)throw Error('Treinador não encontrado');
 if(locked(bot,at))throw Error('Este treinador já está em uma batalha.');
 if(bot.battle)throw Error('O bot está enfrentando outro Pokémon.');
 const team=cloneTeam(bot);if(!team.length)throw Error('Este bot precisa curar sua equipe.');
 // Use Battle.begin for authoritative range/channel checks and the standard
 // player-side rules, then replace only the enemy Pokémon with persistent data.
 Battle.begin(player,{type:'bot',bot});
 player.battle.enemy=team.shift();player.battle.remaining=team;
 player.battle.trainerName=bot.name;
 player.battle.history=[`${bot.name} enviou ${player.battle.enemy.species} Nv. ${player.battle.enemy.level}.`];
 bot.duelWith=player.id;bot.duelTouchedAt=at;
 bot.lastAction=`Batalhando contra ${player.name||'visitante'}`;
 return Battle.publicBattle(player);
}
function sync(bot,battle){
 if(!bot||!battle)return;
 const candidates=[battle.enemy,...(battle.remaining||[])];
 for(const enemy of candidates){
  const actual=bot.team.find(m=>m.id===enemy.id);
  if(actual){actual.hp=Math.max(0,Math.min(actual.maxHp,enemy.hp));actual.status=enemy.status||null;actual.pp=structuredClone(enemy.pp||{});actual.toxicCounter=enemy.toxicCounter||0;actual.item=enemy.item??null;}
 }
}
function action(player,bot,body,at=Date.now()){
 const battle=player.battle;
 if(!battle||battle.type!=='bot')throw Error('Não há duelo com bot');
 if(!bot||!locked(bot,at)||bot.duelWith!==player.id||battle.targetId!==bot.id)throw Error('O duelo não está ativo');
 const beforeEnemy=battle.enemy;
 const result=Battle.act(player,body);
 // After KO Battle.act swaps to the next Pokémon or ends the match.
 // The old opponent must be committed even if it is no longer b.enemy.
 if(beforeEnemy){const actual=bot.team.find(m=>m.id===beforeEnemy.id);if(actual){actual.hp=Math.max(0,Math.min(actual.maxHp,beforeEnemy.hp));actual.status=beforeEnemy.status||null;actual.pp=structuredClone(beforeEnemy.pp||{});actual.toxicCounter=beforeEnemy.toxicCounter||0;actual.item=beforeEnemy.item??null;}}
 if(player.battle)sync(bot,player.battle);
 bot.duelTouchedAt=at;
 if(result.done){
  if(result.victory===true){bot.losses=(bot.losses||0)+1;bot.lastAction=`Perdeu um desafio contra ${player.name||'visitante'}`;}
  else if(result.victory===false){bot.wins=(bot.wins||0)+1;bot.lastAction=`Venceu um desafio contra ${player.name||'visitante'}`;}
  release(bot);
 }
 return result;
}
function expire(players,bots,at=Date.now()){
 const cleaned=[];
 for(const bot of bots){
  if(!bot.duelWith)continue;
  const player=players.get(bot.duelWith);
  if(!locked(bot,at)||!player||!player.battle||player.battle.type!=='bot'||player.battle.targetId!==bot.id){
   // Invalid or abandoned duel: never invent a victory/badge/XP.
   if(player?.battle?.type==='bot'&&player.battle.targetId===bot.id)player.battle=null;
   release(bot);bot.lastAction='Retomou a própria jornada';cleaned.push(bot.id);
  }
 }
 return cleaned;
}
module.exports={begin,action,expire,release,locked,cloneTeam,DUPLEX_MS};
