'use strict';
/** Live Double gym adapter (Emerald rules subset) for the original campaign.
 * Resolve four queued commands in one turn; preserve individual party ownership.
 * Known limits are documented in RELEASE_CANDIDATE_3_0.md.
 */
const Target=require('./gen3-doubles.cjs');
const Turn=require('./gen3-turn.cjs');
const STATUS_DAMAGE=new Set(['poison','burn','toxic']);
const clamp=(n,min,max)=>Math.max(min,Math.min(max,n));
function selected(profile,battle){
 const a=profile.team.find(m=>m.id===battle.doubleSlots?.A1&&m.hp>0)||null;
 const b=profile.team.find(m=>m.id===battle.doubleSlots?.A2&&m.hp>0)||null;
 return [a,b];
}
function chooseReplacement(profile,used){return (profile.team||[]).find(m=>m.hp>0&&!used.has(m.id))||null;}
function fillParty(profile,b,Gen3,history){
 b.doubleSlots??={};let [a,ally]=selected(profile,b);
 if(a&&ally&&a.id===ally.id)ally=null;
 const used=new Set([a?.id,ally?.id].filter(Boolean));
 if(!a){a=chooseReplacement(profile,used);if(a){used.add(a.id);b.doubleSlots.A1=a.id;Gen3.onEntry(a,[b.enemy,b.enemyPartner].filter(m=>m?.hp>0),history);history.push(`Você enviou ${a.species}.`);}}
 if(!ally){ally=chooseReplacement(profile,used);if(ally){used.add(ally.id);b.doubleSlots.A2=ally.id;Gen3.onEntry(ally,[b.enemy,b.enemyPartner].filter(m=>m?.hp>0),history);history.push(`Você enviou ${ally.species} como parceiro.`);}}
 if(!a)b.doubleSlots.A1=null;
 if(!ally)b.doubleSlots.A2=null;
 if(a)profile.activeIndex=profile.team.findIndex(m=>m.id===a.id);
 return [a,ally];
}
function fillOpponents(b,Gen3,history,allies){
 for(const slot of ['enemy','enemyPartner'])if(!b[slot]||b[slot].hp<=0){
  const replacement=b.remaining?.shift()||null;b[slot]=replacement;
  if(replacement){Gen3.initialize(replacement);Gen3.onEntry(replacement,allies.filter(m=>m?.hp>0),history);history.push(`Tate & Liza enviaram ${replacement.species} Nv. ${replacement.level}.`);}
 }
}
function checkFaints(profile,b,api){
 const {Gen3,grantExp,history}=api;
 for(const slot of ['enemy','enemyPartner']){
  const mon=b[slot];if(mon?.hp===0&&!b.defeatedFoeIds.includes(mon.id)){
   b.defeatedFoeIds.push(mon.id);
   const eligible=(profile.team||[]).filter(m=>m.hp>0&&b.participants.includes(m.id));
   if(eligible.length)for(const member of eligible)grantExp(member,mon,profile,history,eligible.length);
   history.push(`${mon.species} desmaiou.`);
  }
 }
 const allies=fillParty(profile,b,Gen3,history);
 fillOpponents(b,Gen3,history,allies);
 return allies;
}
function orderedActions(actions,Gen3,stat,weather,rng){
 for(const a of actions){a.priority=Turn.priority(a.move);a.effectiveSpeed=Gen3.speed(a.mon,stat,weather);a.quick=a.mon.item==='QuickClaw'&&rng()<.2;a.tie=rng();}
 return actions.sort((a,b)=>b.priority-a.priority||Number(b.quick)-Number(a.quick)||b.effectiveSpeed-a.effectiveSpeed||a.tie-b.tie);
}
function cleanupTurn(b,profile,api){
 const {Gen3,stat,types,history,rng}=api;
 b.turn++;
 const members=[...selected(profile,b),b.enemy,b.enemyPartner].filter(m=>m?.hp>0);
 const weather=b.weather;
 // Wish resolves before weather. This subset stores one timer per side.
 if(b.wishes)for(const [side,entry] of Object.entries(b.wishes)){
  entry.turns--;if(entry.turns<=0){const mon=side==='own'?members.find(m=>profile.team.includes(m)):members.find(m=>!profile.team.includes(m));
   if(mon?.hp>0){const healed=Math.min(Math.max(0,mon.maxHp-mon.hp),entry.heal);mon.hp+=healed;if(healed)history.push(`Wish recuperou ${healed} HP de ${mon.species}.`);}delete b.wishes[side];}
 }
 if(['sandstorm','hail'].includes(weather))for(const mon of members){
  if(mon.hp<=0||Gen3.weatherImmune(mon,weather,types(mon.species,b.ruleset)))continue;
  const damage=Math.max(1,Math.floor(mon.maxHp/16));mon.hp=Math.max(0,mon.hp-damage);
  history.push(`${mon.species} sofreu ${damage} HP pelo clima.`);
 }
 members.sort((a,z)=>Gen3.speed(z,stat,weather)-Gen3.speed(a,stat,weather));
 for(const mon of members){
  if(mon.hp<=0)continue;
  if(mon.ability==='ShedSkin'&&mon.status&&rng()<1/3){mon.status=null;mon.toxicCounter=0;history.push(`${mon.species} curou seu status com Shed Skin.`);}
  if(mon.ability==='RainDish'&&weather==='rain')heal(mon,Math.floor(mon.maxHp/16),'Rain Dish',history);
  if(mon.item==='Leftovers')heal(mon,Math.floor(mon.maxHp/16),'Leftovers',history);
  if(mon.leechSeeded&&mon.hp>0){const dmg=Math.min(mon.hp,Math.max(1,Math.floor(mon.maxHp/8)));mon.hp-=dmg;
   const opposite=profile.team.includes(mon)?[b.enemy,b.enemyPartner]:selected(profile,b);
   const receiver=opposite.find(m=>m?.hp>0);if(receiver&&receiver.ability!=='LiquidOoze')heal(receiver,dmg,'Leech Seed',history);
   history.push(`${mon.species} perdeu ${dmg} HP por Leech Seed.`);
  }
  if(mon.hp>0&&STATUS_DAMAGE.has(mon.status)){
   const damage=mon.status==='toxic'?Math.max(1,Math.floor(mon.maxHp*clamp(++mon.toxicCounter,1,15)/16)):Math.max(1,Math.floor(mon.maxHp/8));
   mon.hp=Math.max(0,mon.hp-damage);history.push(`${mon.species} perdeu ${damage} HP por ${mon.status}.`);
  }
  if(mon.hp>0&&mon.ability==='SpeedBoost'&&mon.turnsActive>0){mon.stages.spe=clamp((mon.stages.spe||0)+1,-6,6);}
 }
 for(const mon of [...selected(profile,b),b.enemy,b.enemyPartner].filter(Boolean)){
  mon.protected=false;mon.flinched=false;
  if(mon.hp>0)mon.turnsActive=(mon.turnsActive||0)+1;
 }
 if(b.weatherTurns!=null&&--b.weatherTurns<=0){b.weather=null;delete b.weatherTurns;history.push('O clima voltou ao normal.');}
}
function heal(mon,amount,label,history){if(mon.hp<=0)return;const value=Math.min(mon.maxHp-mon.hp,Math.max(1,amount));if(value>0){mon.hp+=value;history.push(`${mon.species} recuperou ${value} HP com ${label}.`);}}
function run(profile,action,api){
 const {Gen3,stat,history,rng,availableMoves,chooseFoeMove,attempt,types,grantExp,publicBattle}=api;
 const b=profile.battle;
 if(!b||b.format!=='double')throw Error('Batalha Double indisponível');
 if(action.type==='ball')throw Error('Não é permitido capturar Pokémon de outro treinador');
 if(action.type!=='move')throw Error('Na Double Battle, escolha os movimentos da equipe');
 const [own,ally]=selected(profile,b);
 if(!own&&!ally)throw Error('Nenhum Pokémon apto a agir');
 const userCommands=[...(own?[{mon:own,slot:'A1',side:'A',move:action.move,target:action.target}]:[]), ...(ally?[{mon:ally,slot:'A2',side:'A',move:own?(action.partnerMove??availableMoves(ally)[0]):action.move,target:action.partnerTarget||action.target}]:[])];
 for(const command of userCommands){if(!availableMoves(command.mon).includes(command.move))throw Error(`Movimento indisponível para ${command.mon.species}`);}
 const enemyCommands=[['B1',b.enemy],['B2',b.enemyPartner]].filter(([,mon])=>mon?.hp>0).map(([slot,mon])=>{
  const selectedTarget=[own,ally].filter(x=>x?.hp>0).sort((a,z)=>z.hp-a.hp)[0];
  return {mon,slot,side:'B',move:chooseFoeMove(mon,selectedTarget),target:selectedTarget===ally?'A2':'A1'};
 });
 const actions=orderedActions([...userCommands,...enemyCommands],Gen3,stat,b.weather,rng);
 const followMe={A:null,B:null},helpingHand=new Set(),acted=new Set();
 const slotMonster=slot=>slot==='A1'?selected(profile,b)[0]:slot==='A2'?selected(profile,b)[1]:slot==='B1'?b.enemy:b.enemyPartner;
 for(const command of actions){
  const mon=slotMonster(command.slot);
  if(!mon||mon.hp<=0||mon.id!==command.mon.id)continue;
  const board={A1:slotMonster('A1'),A2:slotMonster('A2'),B1:b.enemy,B2:b.enemyPartner};
  const kind=Target.targetClass(command.move);
  const mateSlot=Target.partner(command.slot);
  const mate=slotMonster(mateSlot);
  if(command.move==='HelpingHand'||command.move==='FollowMe'){
   if(!Gen3.beforeMove(mon,command.move,history,rng,{target:mate}))continue;
   if(command.move==='HelpingHand'){
    if(mate?.hp>0&&!acted.has(mate.id)){helpingHand.add(mate.id);history.push(`${mon.species} apoiou ${mate.species} com Helping Hand!`);}
    else history.push('Helping Hand não teve efeito.');
   }else{followMe[command.side]=command.slot;history.push(`${mon.species} usou Follow Me.`);}
   acted.add(mon.id);continue;
  }
  const targets=Target.resolveTargets(board,command.slot,command.move,command.target,{followMe:followMe[command.side==='A'?'B':'A']});
  if(kind==='field'){attempt(mon,mon,command.move,history,b);acted.add(mon.id);continue;}
  if(!targets.length){history.push(`${mon.species} não encontrou alvo para ${command.move}.`);acted.add(mon.id);continue;}
  const spread=Target.spreadMultiplier(command.move,targets);
  for(const [index,targetSlot] of targets.entries()){
   const defender=slotMonster(targetSlot);
   if(!defender?.hp)continue;
   attempt(mon,defender,command.move,history,b,{skipBeforeMove:index>0,spread,helpingHand:helpingHand.has(mon.id)});
  }
  acted.add(mon.id);helpingHand.delete(mon.id);
  checkFaints(profile,b,{Gen3,grantExp,history});
  if(!selected(profile,b).some(m=>m?.hp>0)||![b.enemy,b.enemyPartner,...b.remaining].some(m=>m?.hp>0))break;
 }
 cleanupTurn(b,profile,{Gen3,stat,types,history,rng});
 checkFaints(profile,b,{Gen3,grantExp,history});
 if(!selected(profile,b).some(mon=>mon?.hp>0)){
  profile.losses=(profile.losses||0)+1;profile.battle=null;
  return {done:true,victory:false,log:history.slice(-10)};
 }
 if(![b.enemy,b.enemyPartner,...b.remaining].some(m=>m?.hp>0)){
  profile.wins=(profile.wins||0)+1;
  profile.story??={};profile.story.tate_liza=true;
  if(profile.badges===6)profile.badges=7;
  profile.money=(profile.money||0)+4200;profile.battle=null;
  history.push('🏅 Tate & Liza derrotados em Double Battle: insígnia 7 conquistada!');
  return {done:true,victory:true,log:history.slice(-10)};
 }
 return {done:false,battle:publicBattle(profile),log:history.slice(-10)};
}
module.exports={run,selected,fillParty,fillOpponents,orderedActions,cleanupTurn};
