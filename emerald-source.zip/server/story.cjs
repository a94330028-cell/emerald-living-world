'use strict';
/** Location-based story triggers shared by visitors and bots. Not badge rewards. */
function nearby(profile){
 if(profile.area==='StevenChamber'&&Math.abs(profile.x-14)+Math.abs(profile.y-8)<=2&&Number(profile.badges||0)>=1&&!profile.story?.steven){
  return {id:'steven',label:'Entregar carta a Steven',description:'Steven recebe a carta da Devon Corporation.'};
 }
 return null;
}
function interact(profile){
 if(profile.frontier?.active)throw Error('Eventos externos bloqueados durante a Frontier');
 const event=nearby(profile);
 if(!event)throw Error('Nenhum evento da história disponível aqui');
 profile.story??={};profile.story[event.id]=true;
 return event;
}
module.exports={nearby,interact};
