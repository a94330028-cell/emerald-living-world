'use strict';
/**
 * Emerald Frontier Brain exhibition lineups (Gen III species and encounter milestones).
 * Opponent moves/items are adapted to the current subset battle engine, NOT the complete
 * official ROM move/item/nature/EV sets. This module must not award official Symbols.
 * Based on Emerald Frontier Brain rosters; Factory Head Noland uses random rentals.
 */
const BRAINS=Object.freeze({
 tower:{name:'Anabel',symbol:'Ability',triggers:[35,70],
   silver:['Alakazam','Entei','Snorlax'],gold:['Raikou','Snorlax','Latios']},
 dome:{name:'Tucker',symbol:'Tactics',triggers:[20,40],
   silver:['Swampert','Salamence','Charizard'],gold:['Swampert','Latias','Metagross']},
 palace:{name:'Spenser',symbol:'Spirits',triggers:[21,42],
   silver:['Crobat','Slaking','Lapras'],gold:['Arcanine','Slaking','Suicune']},
 arena:{name:'Greta',symbol:'Guts',triggers:[28,56],
   silver:['Heracross','Umbreon','Shedinja'],gold:['Umbreon','Gengar','Breloom']},
 factory:{name:'Noland',symbol:'Knowledge',triggers:[21,42],
   silver:null,gold:null},
 pike:{name:'Lucy',symbol:'Luck',triggers:[28,140],
   silver:['Seviper','Milotic','Shuckle'],gold:['Seviper','Gyarados','Steelix']},
 pyramid:{name:'Brandon',symbol:'Brave',triggers:[21,70],
   silver:['Regirock','Regice','Registeel'],gold:['Articuno','Zapdos','Moltres']}
});
const MOVESETS=Object.freeze({
 Alakazam:['Psychic','FirePunch','IcePunch','ThunderPunch'],
 Entei:['FireBlast','Flamethrower','Return','CalmMind'],
 Snorlax:['BodySlam','ShadowBall','Return','Earthquake'],
 Raikou:['Thunderbolt','CalmMind','Bite','QuickAttack'],
 Latios:['Psychic','DragonClaw','Recover','Thunderbolt'],
 Salamence:['DragonClaw','AerialAce','Flamethrower','Earthquake'],
 Charizard:['Flamethrower','AerialAce','DragonClaw','Earthquake'],
 Latias:['Psychic','DragonClaw','Recover','Thunderbolt'],
 Metagross:['MeteorMash','Psychic','Earthquake','ShadowBall'],
 Crobat:['SludgeBomb','AerialAce','Bite','Confusion'],
 Slaking:['Return','Earthquake','ShadowBall','BodySlam'],
 Lapras:['Surf','IceBeam','Thunderbolt','BodySlam'],
 Arcanine:['Flamethrower','ExtremeSpeed','Bite','FireBlast'],
 Suicune:['Surf','IceBeam','CalmMind','Bite'],
 Heracross:['Megahorn','BrickBreak','Earthquake','RockSlide'],
 Umbreon:['Bite','ShadowBall','QuickAttack','Toxic'],
 Shedinja:['ShadowBall','AerialAce','Slash','Protect'],
 Gengar:['ShadowBall','Psychic','Thunderbolt','SludgeBomb'],
 Breloom:['MachPunch','MegaDrain','LeechSeed','Headbutt'],
 Seviper:['SludgeBomb','Crunch','Flamethrower','Earthquake'],
 Milotic:['Surf','IceBeam','Recover','Toxic'],
 Shuckle:['Toxic','RockSlide','Protect','BodySlam'],
 Gyarados:['Surf','Earthquake','DragonBreath','Bite'],
 Steelix:['Earthquake','RockSlide','IronTail','DoubleKick'],
 Regirock:['RockSlide','Earthquake','Superpower','BrickBreak'],
 Regice:['IceBeam','Thunderbolt','AncientPower','Amnesia'],
 Registeel:['MetalClaw','Earthquake','AncientPower','Superpower'],
 Articuno:['IceBeam','AerialAce','AncientPower','WaterPulse'],
 Zapdos:['Thunderbolt','AerialAce','AncientPower','RockSlide'],
 Moltres:['Flamethrower','FireBlast','AerialAce','AncientPower'],
 Swampert:['Surf','Earthquake','IceBeam','WaterPulse']
});
const ITEMS=Object.freeze({Alakazam:'BrightPowder',Entei:'LumBerry',Snorlax:'QuickClaw',
 Raikou:'LumBerry',Latios:'BrightPowder',Latias:'LumBerry',Metagross:'ChoiceBand',
 Salamence:'LumBerry',Charizard:'BrightPowder'});
function tierAt(facility,winNumber){
 const conf=BRAINS[facility];
 if(!conf||!Number.isInteger(winNumber))return null;
 return winNumber===conf.triggers[0]?'silver':winNumber===conf.triggers[1]?'gold':null;
}
function lineup(facility,tier,level,randomRentals){
 const conf=BRAINS[facility];
 if(!conf||!['silver','gold'].includes(tier))throw Error('Frontier Brain inválido');
 const Battle=require('./battle.cjs');
 const species=facility==='factory'?randomRentals(3):conf[tier];
 const chosen=facility==='dome'?species.slice(0,2):species;
 return chosen.map(name=>{
  const mon=Battle.create(name,level);
  const moves=(MOVESETS[name]||[]).filter(move=>Battle.MOVES[move]);
  if(moves.length)mon.moves=moves.slice(0,4);
  const Gen3=require('./gen3-mechanics.cjs');
  mon.pp={};
  mon.item=ITEMS[name]||null;
  Gen3.initialize(mon);
  return mon;
 });
}
module.exports={BRAINS,MOVESETS,ITEMS,tierAt,lineup};
