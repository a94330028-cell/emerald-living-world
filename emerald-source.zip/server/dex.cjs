'use strict';
// ROM-derived factual fields only. No ROM binary, graphics, scripts or text are served.
const DATA=require('../jogo/data/quetzal-catalog.json');
const POKEMON=Object.freeze(DATA.pokemon);
const META=Object.freeze(DATA.metadata);
const BY_KEY=new Map(POKEMON.map(x=>[x.key,x]));
const BY_ID=new Map(POKEMON.map(x=>[x.id,x]));
const PRIMARY=Object.freeze(POKEMON.filter(x=>x.kind==='species'));
const normalize=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('pt-BR');
function query({search='',type='',kind='species',generation='',limit=40,offset=0}={}){
 const text=normalize(search),tp=String(type),classification=String(kind);
 const gen=Number(generation);
 const genRanges=[[1,151],[152,251],[252,386],[387,493],[494,649],[650,721],[722,809],[810,905],[906,1025]];
 let entries=POKEMON;
 if(classification==='species')entries=PRIMARY;
 else if(['variant','experimental'].includes(classification))entries=POKEMON.filter(x=>x.kind===classification);
 if(text)entries=entries.filter(x=>normalize(x.name).includes(text)||String(x.dex||'')===text);
 if(tp)entries=entries.filter(x=>x.types.includes(tp));
 if(gen>=1&&gen<=9){const [start,end]=genRanges[gen-1];entries=entries.filter(x=>x.dex>=start&&x.dex<=end);}
 const safeLimit=Math.max(1,Math.min(80,Number(limit)||40));
 const safeOffset=Math.max(0,Math.min(1528,Number(offset)||0));
 return {metadata:META,total:entries.length,offset:safeOffset,limit:safeLimit,results:entries.slice(safeOffset,safeOffset+safeLimit)};
}
module.exports={DATA,POKEMON,META,BY_KEY,BY_ID,PRIMARY,query};
