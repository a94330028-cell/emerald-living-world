'use strict';
/** Focused Gen III damage pipeline for supported direct-damage moves.
 * The integer order matches the main Emerald modifiers (burn, screen, spread,
 * weather BEFORE +2; critical, Helping Hand, STAB, typing, random AFTER +2).
 * This is NOT a full emulator for every species-specific ability/move script.
 */
const {isPhysical}=require('./gen3-turn.cjs');
const stageMult=n=>n>=0?(2+n)/2:2/(2-n);
const floorMult=(n,m)=>Math.floor(n*m);
function calculate({attacker,defender,move,stat,typeMultiplier,typesOf,critical=false,randomRoll=100,weather=null,spread=1,helpingHand=false,screen=1}){
 if(!move||!Number.isFinite(move.power)||move.power<=0)throw Error('Movimento ofensivo inválido');
 if(!Number.isInteger(randomRoll)||randomRoll<85||randomRoll>100)throw Error('Variação de dano fora de 85–100');
 const physical=isPhysical(move.type),aStat=physical?'atk':'spa',dStat=physical?'def':'spd';
 const attackStage=Math.min(6,Math.max(-6,Number(attacker.stages?.[aStat])||0));
 const defenseStage=Math.min(6,Math.max(-6,Number(defender.stages?.[dStat])||0));
 let attack=Math.max(1,Math.floor(stat(attacker,aStat)*stageMult(critical&&attackStage<0?0:attackStage)));
 let defense=Math.max(1,Math.floor(stat(defender,dStat)*stageMult(critical&&defenseStage>0?0:defenseStage)));
 if(physical&&attacker.item==='ChoiceBand')attack=Math.max(1,floorMult(attack,1.5));
 if(physical&&['HugePower','PurePower'].includes(attacker.ability))attack*=2;
 if(physical&&attacker.ability==='Guts'&&attacker.status)attack=Math.max(1,floorMult(attack,1.5));
 if(defender.ability==='ThickFat'&&['Fire','Ice'].includes(move.type))attack=Math.max(1,Math.floor(attack/2));
 if(move.id==='Explosion'||move.id==='Selfdestruct')defense=Math.max(1,Math.floor(defense/2));
 const l=Math.max(1,Math.min(100,Math.floor(attacker.level)||1));
 let damage=Math.floor(Math.floor((Math.floor(2*l/5)+2)*move.power*attack/defense)/50);
 if(physical&&attacker.status==='burn'&&attacker.ability!=='Guts')damage=floorMult(damage,.5);
 if(!critical&&screen!==1)damage=floorMult(damage,screen);
 if(spread!==1)damage=floorMult(damage,spread);
 if(damage===0&&physical)damage=1;
 if((weather==='rain'&&move.type==='Water')||(weather==='sun'&&move.type==='Fire'))damage=floorMult(damage,1.5);
 if((weather==='rain'&&move.type==='Fire')||(weather==='sun'&&move.type==='Water'))damage=floorMult(damage,.5);
 if(attacker.flashFireBoosted&&move.type==='Fire')damage=floorMult(damage,1.5);
 damage+=2;
 if(critical)damage*=2;
 if(helpingHand)damage=floorMult(damage,1.5);
 if(typesOf(attacker.species).includes(move.type))damage+=Math.floor(damage/2);
 // Type1 and Type2 have separate integer rounding, rather than multiplying
 // by an overall 4x/0.25x modifier after the fact.
 for(const targetType of typesOf(defender.species)){
  const factor=typeMultiplier(move.type,targetType);
  if(factor===0)return 0;
  damage=floorMult(damage,factor);
 }
 if(!damage)return 0;
 damage=Math.floor(damage*randomRoll/100);
 return Math.max(1,damage);
}
module.exports={calculate};
