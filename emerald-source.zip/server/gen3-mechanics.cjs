'use strict';
/** Classic/extended-DEX Gen-III-compatible battle primitives.
 * Only verified mechanics are enabled; unverified modern species remain in the
 * existing encounter catalogue and are never removed by this module.
 * This is not a bit-identical recreation of pokeemerald's battle scripts.
 */
const Turn=require('./gen3-turn.cjs');
const PP=Object.freeze({Tackle:35,Pound:35,Scratch:35,Peck:35,QuickAttack:30,Absorb:25,Ember:25,
 WaterGun:25,MudSlap:10,Bite:25,VineWhip:10,Leer:30,Growl:40,RockThrow:15,MegaDrain:10,
 TailWhip:30,StringShot:40,Howl:40,KarateChop:25,LowKick:20,DoubleKick:30,Confusion:25,
 ThunderShock:30,Spark:20,MetalClaw:35,Gust:35,RockTomb:10,Headbutt:15,WaterPulse:20,
 PoisonSting:35,BugBite:20,Lick:30,FairyWind:30,DragonBreath:20,PowderSnow:25,
 SandAttack:15,FurySwipes:15,DoubleSlap:10,PinMissile:20,Protect:10,LeechSeed:10,Toxic:10,ThunderWave:20,WillOWisp:15,
 SleepPowder:15,Recover:20,SwordsDance:30,CalmMind:20,RainDance:5,SunnyDay:5,
 Sandstorm:10,Hail:10,Explosion:5,Selfdestruct:5,Wish:10,SeismicToss:20,NightShade:15,DragonRage:10,
 SonicBoom:20,SuperFang:10,Endeavor:5,ExtremeSpeed:5,FakeOut:10,HelpingHand:20,
 FollowMe:20,Earthquake:10,Surf:15,RockSlide:10,Explosion:5,Selfdestruct:5,
 Psychic:10,Thunderbolt:15,FireBlast:5,IceBeam:10,DragonClaw:15,
 ShadowBall:15,BodySlam:15,Return:20,Flamethrower:15,Crunch:15,
 SludgeBomb:10,AerialAce:20,HydroPump:5,FirePunch:15,IcePunch:15,
 ThunderPunch:15,MeteorMash:10,Megahorn:10,BrickBreak:15,Slash:20,
 IronTail:15,AncientPower:5,Superpower:5});
const ABILITIES=Object.freeze({Treecko:'Overgrow',Grovyle:'Overgrow',Sceptile:'Overgrow',
 Torchic:'Blaze',Combusken:'Blaze',Blaziken:'Blaze',Mudkip:'Torrent',Marshtomp:'Torrent',Swampert:'Torrent',
 Zigzagoon:'Pickup',Poochyena:'RunAway',Mightyena:'Intimidate',Wurmple:'ShieldDust',
 Taillow:'Guts',Swellow:'Guts',Lotad:'SwiftSwim',Lombre:'SwiftSwim',Wingull:'KeenEye',
 Pelipper:'KeenEye',Shroomish:'EffectSpore',Breloom:'EffectSpore',Geodude:'RockHead',
 Nosepass:'Sturdy',Machop:'Guts',Meditite:'PurePower',Makuhita:'ThickFat',
 Zubat:'InnerFocus',Abra:'Synchronize',Slugma:'MagmaArmor',Ralts:'Synchronize',
 Voltorb:'Soundproof',Electrike:'Static',Manectric:'Static',Magnemite:'MagnetPull',
 Magneton:'MagnetPull',Shedinja:'WonderGuard'});
const CONTACT=new Set(['Tackle','Pound','Scratch','Peck','QuickAttack','Bite','VineWhip','DoubleKick','Headbutt','KarateChop','LowKick','Spark','MetalClaw','Lick','ExtremeSpeed']);
const SECONDARY=Object.freeze({Ember:{status:'burn',chance:.1},ThunderShock:{status:'paralysis',chance:.1},
 Spark:{status:'paralysis',chance:.3},Lick:{status:'paralysis',chance:.3},
 PoisonSting:{status:'poison',chance:.3},PowderSnow:{status:'freeze',chance:.1},
 Headbutt:{status:'flinch',chance:.3},Bite:{status:'flinch',chance:.3},FakeOut:{status:'flinch',chance:1},
 Confusion:{status:'confusion',chance:.1},MetalClaw:{stat:'atk',chance:.1},
 RockTomb:{stat:'spe',delta:-1,chance:1}});
const STATUS_NAMES=new Set(['poison','toxic','burn','paralysis','sleep','freeze']);
const clamp=(n,min,max)=>Math.max(min,Math.min(max,n));
function initialize(mon){
 if(!mon||typeof mon!=='object'||!Array.isArray(mon.moves))throw Error('Pokémon inválido');
 mon.pp??={};for(const move of mon.moves){if(!Number.isInteger(mon.pp[move]))mon.pp[move]=PP[move]??20;else mon.pp[move]=clamp(mon.pp[move],0,PP[move]??20);}
 if(mon.ability===undefined)mon.ability=ABILITIES[mon.species]||null;
 if(mon.item===undefined)mon.item=null;
 if(mon.status===undefined)mon.status=null;
 if(mon.toxicCounter===undefined)mon.toxicCounter=0;
 mon.stages??={};return mon;
}
function stageMult(n){n=clamp(Number(n)||0,-6,6);return n>=0?(2+n)/2:2/(2-n);}
function speed(mon,stat,weather=null){initialize(mon);
 let n=Math.max(1,Math.floor(stat(mon,'spe')*stageMult(mon.stages.spe||0)));
 if(mon.status==='paralysis')n=Math.max(1,Math.floor(n/4));
 if((mon.ability==='SwiftSwim'&&weather==='rain')||(mon.ability==='Chlorophyll'&&weather==='sun'))n*=2;
 return n;
}
function order(a,b,rng=Math.random){
 const pa=Turn.priority(a.move),pb=Turn.priority(b.move);if(pa!==pb)return pa>pb;
 const qa=a.mon?.item==='QuickClaw'&&rng()<.2,qb=b.mon?.item==='QuickClaw'&&rng()<.2;
 if(qa!==qb)return qa;
 if(a.speed!==b.speed)return a.speed>b.speed;
 return rng()<.5;
}
function canStatus(mon,status,types=[]){initialize(mon);
 if(!STATUS_NAMES.has(status)||mon.hp===0||mon.status)return false;
 if((status==='poison'||status==='toxic')&&(types.includes('Poison')||types.includes('Steel')))return false;
 if(status==='burn'&&types.includes('Fire'))return false;
 if(status==='freeze'&&types.includes('Ice'))return false;
 if(status==='paralysis'&&mon.ability==='Limber')return false;
 if(status==='sleep'&&['Insomnia','VitalSpirit'].includes(mon.ability))return false;
 return true;
}
function setStatus(mon,status,types=[],history=[]){
 if(!canStatus(mon,status,types))return false;
 mon.status=status;mon.toxicCounter=0;
 if(status==='sleep')mon.sleepTurns=1+Math.floor(Math.random()*4);
 history.push(`${mon.species} recebeu o status ${status}.`);
 if(mon.item==='LumBerry'){mon.status=null;mon.sleepTurns=0;mon.item=null;history.push(`${mon.species} usou Lum Berry para curar o status.`);}
 return true;
}
function beforeMove(mon,move,history,rng=Math.random,{target=null}={}){initialize(mon);
 if(move!=='Struggle'){
  if(!mon.moves.includes(move))throw Error('Movimento não aprendido');
  if((mon.pp[move]??0)<=0){history.push(`${mon.species} está sem PP para ${move}.`);return false;}
  if(mon.item==='ChoiceBand'&&mon.choiceLock&&mon.choiceLock!==move)throw Error('Choice Band impede escolher outro golpe antes de trocar');
  if(move!=='Protect')mon.protectStreak=0;
 }
 if(mon.flinched){history.push(`${mon.species} hesitou e não agiu.`);return false;}
 if(mon.status==='sleep'){
  mon.sleepTurns=Math.max(0,(Number(mon.sleepTurns)||1)-1);
  if(mon.sleepTurns){history.push(`${mon.species} está dormindo.`);return false;}
  mon.status=null;history.push(`${mon.species} acordou!`);
 }
 if(mon.status==='freeze'){
  if(rng()>=.2){history.push(`${mon.species} está congelado.`);return false;}
  mon.status=null;history.push(`${mon.species} descongelou!`);
 }
 if(mon.status==='paralysis'&&rng()<.25){history.push(`${mon.species} está paralisado e não conseguiu agir.`);return false;}
 if(mon.confusionTurns>0){mon.confusionTurns--;
  if(rng()<.5){const damage=Math.max(1,Math.floor(mon.maxHp/12));mon.hp=Math.max(0,mon.hp-damage);history.push(`${mon.species} se feriu na confusão (${damage} HP).`);return false;}
 }
 if(move!=='Struggle'){
  // PP is consumed only if the Pokémon reaches execution. A failed Fake Out
  // still uses PP; sleep, freeze, paralysis, confusion and flinch do not.
  const selfOrField=new Set(['Protect','Recover','SwordsDance','CalmMind','Wish','RainDance','SunnyDay','Sandstorm','Hail','HelpingHand','FollowMe','Howl']);
  const cost=target?.ability==='Pressure'&&!selfOrField.has(move)?2:1;
  mon.pp[move]=Math.max(0,mon.pp[move]-cost);
  if(mon.item==='ChoiceBand'&&!mon.choiceLock)mon.choiceLock=move;
 }
 if(move==='FakeOut'&&(mon.turnsActive||0)>0){history.push(`${mon.species} não pode usar Fake Out após o primeiro turno em campo.`);return false;}
 return true;
}
function afterHit(attacker,defender,move,damage,defenderTypes,attackerTypes,history,rng=Math.random){
 initialize(attacker);initialize(defender);
 if(damage<=0)return;
 const effect=SECONDARY[move];
 if(effect&&rng()<effect.chance){
  if(effect.status==='flinch'&&!['InnerFocus','ShieldDust'].includes(defender.ability))defender.flinched=true;
  else if(effect.status==='confusion'&&defender.confusionTurns==null)defender.confusionTurns=2+Math.floor(rng()*3);
  else if(effect.status)setStatus(defender,effect.status,defenderTypes,history);
  else if(effect.stat){const mon=effect.delta===-1?defender:attacker;
   mon.stages[effect.stat]=clamp((mon.stages[effect.stat]||0)+(effect.delta||1),-6,6);}
 }
 if(CONTACT.has(move)&&attacker.hp>0){
  if(defender.ability==='RoughSkin'){
   const lost=Math.max(1,Math.floor(attacker.maxHp/16));attacker.hp=Math.max(0,attacker.hp-lost);history.push(`Rough Skin causou ${lost} de dano a ${attacker.species}.`);
  }else if(defender.ability==='Static'&&rng()<.3)setStatus(attacker,'paralysis',attackerTypes,history);
  else if(defender.ability==='FlameBody'&&rng()<.3)setStatus(attacker,'burn',attackerTypes,history);
 }
 triggerBerry(defender,history);
}
function triggerBerry(mon,history){initialize(mon);if(mon.hp<=0)return;
 if(mon.item==='LumBerry'&&(mon.status||mon.confusionTurns>0)){mon.status=null;mon.confusionTurns=0;mon.toxicCounter=0;mon.item=null;history.push(`${mon.species} usou Lum Berry.`);return;}
 if(mon.hp<=Math.floor(mon.maxHp/2)&&['OranBerry','SitrusBerry'].includes(mon.item)){
  const amount=mon.item==='OranBerry'?10:30;
  const healed=Math.min(amount,mon.maxHp-mon.hp);
  if(healed>0){history.push(`${mon.species} recuperou ${healed} HP com ${mon.item}.`);mon.hp+=healed;mon.item=null;}
 }
}
function switchOut(mon){initialize(mon);mon.stages={};mon.toxicCounter=0;mon.confusionTurns=0;mon.flinched=false;mon.choiceLock=null;
 mon.leechSeeded=false;if(mon.ability==='NaturalCure')mon.status=null;
}
function onEntry(mon,opponents,history){initialize(mon);mon.turnsActive=0;
 if(mon.ability==='Intimidate')for(const foe of opponents){if(foe?.hp>0){initialize(foe);foe.stages.atk=clamp((foe.stages.atk||0)-1,-6,6);history.push(`Intimidate de ${mon.species} reduziu o Attack de ${foe.species}.`);}}
 return mon;
}
function weatherImmune(mon,weather,types){if(weather==='sandstorm')return types.some(t=>['Rock','Ground','Steel'].includes(t))||mon.ability==='SandVeil';
 if(weather==='hail')return types.includes('Ice')||mon.ability==='IceBody';return true;}
function damageWithModifiers(damage,attacker,move,type,weather){
 if(damage<=0)return 0;
 const physical=Turn.isPhysical(type);
 if(physical&&attacker.status==='burn'&&attacker.ability!=='Guts')damage=Math.max(1,Math.floor(damage*.5));
 if(attacker.hp>0&&attacker.hp<=Math.floor(attacker.maxHp/3)&&({Overgrow:'Grass',Blaze:'Fire',Torrent:'Water',Swarm:'Bug'})[attacker.ability]===type)damage=Math.max(1,Math.floor(damage*1.5));
 if(weather==='rain'&&type==='Water'||weather==='sun'&&type==='Fire')damage=Math.max(1,Math.floor(damage*1.5));
 if(weather==='rain'&&type==='Fire'||weather==='sun'&&type==='Water')damage=Math.max(1,Math.floor(damage*.5));
 return damage;
}
/** Intentional partial implementation: supports singles with weather/berry/status/seed.
 * For exact doubles and all Gen-III end-turn exceptions, use a validated event script. */
function endTurn(own,foe,battle,typesOf,statFn,history,rng=Math.random){
 if(battle.wishes)for(const [side,entry] of Object.entries(battle.wishes)){
  entry.turns--;if(entry.turns<=0){const target=side==='own'?own:foe;
   if(target?.hp>0)healResidual(target,'Wish',entry.heal,history);delete battle.wishes[side];}
 }
 const all=[own,foe].filter(m=>m?.hp>0);
 for(const mon of all)initialize(mon);
 const weather=battle.weather||null;
 if(weather==='sandstorm'||weather==='hail')for(const mon of all){
  if(mon.hp<=0||weatherImmune(mon,weather,typesOf(mon.species)))continue;
  const dmg=Math.max(1,Math.floor(mon.maxHp/16));mon.hp=Math.max(0,mon.hp-dmg);
  history.push(`${mon.species} sofreu ${dmg} de dano pelo clima.`);
 }
 all.sort((a,b)=>speed(b,statFn,weather)-speed(a,statFn,weather));
 for(const mon of all){
  if(mon.hp<=0)continue;
  if(mon.ability==='ShedSkin'&&mon.status&&rng()<1/3){mon.status=null;mon.toxicCounter=0;history.push(`${mon.species} se curou com Shed Skin.`);}
  if(mon.ability==='RainDish'&&weather==='rain')healResidual(mon,'Rain Dish',Math.max(1,Math.floor(mon.maxHp/16)),history);
  if(mon.item==='Leftovers')healResidual(mon,'Leftovers',Math.max(1,Math.floor(mon.maxHp/16)),history);
  if(mon.leechSeeded&&mon.hp>0){const dmg=Math.min(mon.hp,Math.max(1,Math.floor(mon.maxHp/8)));mon.hp-=dmg;
   const other=mon===own?foe:own;
   if(other?.hp>0&&other.ability!=='LiquidOoze')healResidual(other,'Leech Seed',dmg,history);
   history.push(`${mon.species} perdeu ${dmg} HP por Leech Seed.`);
  }
  if(mon.hp>0){let dmg=0;
   if(mon.status==='poison'||mon.status==='burn')dmg=Math.max(1,Math.floor(mon.maxHp/8));
   if(mon.status==='toxic'){mon.toxicCounter=clamp((mon.toxicCounter||0)+1,1,15);dmg=Math.max(1,Math.floor(mon.maxHp*mon.toxicCounter/16));}
   if(dmg){mon.hp=Math.max(0,mon.hp-dmg);history.push(`${mon.species} sofreu ${dmg} de dano por ${mon.status}.`);}
  }
  if(mon.hp>0&&mon.ability==='SpeedBoost'&&battle.turn>0){mon.stages.spe=clamp((mon.stages.spe||0)+1,-6,6);history.push(`${mon.species} ganhou Speed Boost.`);}
  mon.flinched=false;
 }
 for(const mon of [own,foe])if(mon){mon.flinched=false;mon.protected=false;if(mon.hp>0)mon.turnsActive=(mon.turnsActive||0)+1;}
 if(battle.weatherTurns!=null&&--battle.weatherTurns<=0){battle.weather=null;delete battle.weatherTurns;history.push('O clima voltou ao normal.');}
}
function healResidual(mon,label,amount,history){if(mon.hp<=0||mon.hp>=mon.maxHp)return;const healed=Math.min(amount,mon.maxHp-mon.hp);mon.hp+=healed;history.push(`${mon.species} recuperou ${healed} HP com ${label}.`);}

function accuracyChance(moveAccuracy,attackStage=0,defenseStage=0){
 const stage=clamp((Number(attackStage)||0)-(Number(defenseStage)||0),-6,6);
 const ratio=stage>=0?(3+stage)/3:3/(3-stage);
 return clamp((Number(moveAccuracy)||0)*ratio/100,0,1);
}
function multiHitCount(move,rng=Math.random){
 if(move==='DoubleKick')return 2;
 if(!['FurySwipes','DoubleSlap','PinMissile'].includes(move))return 1;
 const roll=rng();return roll<.375?2:roll<.75?3:roll<.875?4:5;
}
module.exports={accuracyChance,multiHitCount,PP,ABILITIES,CONTACT,SECONDARY,initialize,speed,order,canStatus,setStatus,beforeMove,afterHit,triggerBerry,switchOut,onEntry,weatherImmune,damageWithModifiers,endTurn,stageMult};
