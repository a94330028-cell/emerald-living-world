'use strict';
/** Emerald Living World 3.0 local server. Node 20+, no external packages.
 * Shared world with authoritative battles/movement; not a full ROM-equivalent MMO.
 * For an internet deployment use HTTPS, a persistent volume and reverse-proxy timeout >= 60s.
 */
const http=require('node:http');
const fs=require('node:fs');
const fsp=fs.promises;
const path=require('node:path');
const crypto=require('node:crypto');
const {MAPS,step,walkable,publicMap,validateWorld,blackoutRespawn}=require('./world.cjs');
const Battle=require('./battle.cjs');
const Auth=require('./auth-provider.cjs');
const Frontier=require('./frontier.cjs');
const StartOptions=require('../jogo/game/pokemon/starters.js');
const Dex=require('./dex.cjs');
const NationalPools=require('../jogo/game/pokemon/national-pools.js');
const BotAI=require('./autonomy.cjs');
const Story=require('./story.cjs');
const Shop=require('./shop.cjs');
const Duel=require('./shared-duel.cjs');
const Nav=require('./navigation.cjs');
if(validateWorld().length)throw Error('World graph broken: '+validateWorld().join(', '));
const HOST=process.env.HOST||'127.0.0.1', PORT=Number(process.env.PORT)||8787;
const ROOT=path.resolve(__dirname,'..'),DATA_DIR=path.resolve(process.env.DATA_DIR||path.join(__dirname,'data'));
const FILE=path.join(DATA_DIR,'world.json'),BACKUP_FILE=FILE+'.bak';
const CHANNELS=[1,2,3];
// Supabase access is reverified when this short-lived game session expires.
// Cookies are never a substitute for permanent identity or a live Auth token.
const ACCOUNT_SESSION_TTL_MS=60*60*1000;
const BOT_COUNT=Math.max(5,Math.min(100,Number(process.env.BOT_COUNT)||100));
const BOT_STEPS_PER_TICK=Math.max(1,Math.min(100,Number(process.env.BOT_STEPS_PER_TICK)||20));
const BOT_TICK_MS=Math.max(100,Math.min(60000,Number(process.env.BOT_TICK_MS)||650));
let simTick=0;
const sessions=new Map(),profiles=new Map(),streams=new Set(),chat=[];
const onlineBots=[];
const authAttempts=new Map();
function authRateLimited(req){
 const key=req.socket.remoteAddress||'unknown',time=Date.now(),previous=authAttempts.get(key);
 const next=!previous||time-previous.started>60000?{started:time,count:1}:{started:previous.started,count:previous.count+1};
 authAttempts.set(key,next);if(authAttempts.size>5000)authAttempts.clear();return next.count>20;
}
function newCookie(secret,req){
 const secure=!!(req.socket.encrypted||(process.env.TRUST_PROXY==='true'&&req.headers['x-forwarded-proto']==='https'));
 return `elw_sid=${secret}; Path=/; Max-Age=${Auth.MODE==='required'?Math.floor(ACCOUNT_SESSION_TTL_MS/1000):604800}; HttpOnly; SameSite=Strict${secure?'; Secure':''}`;
}
function createSessionProfile(body){
 const p={id:id(),name:safeText(body.name)||'Treinador',starter:StartOptions.isStarter(body.starter)?body.starter:'Mudkip',avatar:AVATARS.includes(body.avatar)?body.avatar:'brendan',channel:CHANNELS.includes(Number(body.channel))?Number(body.channel):1,area:'Littleroot',x:14,y:10,facing:'down',mode:'online',badges:0,team:[]};
 Battle.createProfileStarter(p);profiles.set(p.id,p);return p;
}
function rotateSession(p,req){
 if(p.secretHash)sessions.delete(p.secretHash);
 const secret=crypto.randomBytes(32).toString('hex');p.secretHash=sha(secret);sessions.set(p.secretHash,p.id);return newCookie(secret,req);
}

const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const safeText=(s,max=24)=>String(s||'').replace(/[\x00-\x1f\x7f<>]/g,'').trim().slice(0,max);
const id=()=>crypto.randomUUID();
const now=()=>Date.now();
const AVATARS=require('../jogo/assets/overworld/characters/manifest.json').characters.map(p=>p.id);
const clientView=(p,own=false)=>({id:p.id,name:p.name,starter:p.starter,avatar:p.avatar,
 channel:p.channel,area:p.area,x:p.x,y:p.y,facing:p.facing||'down',mode:p.mode||'online',badges:p.badges||0,champion:p.champion===true,leagueWins:p.leagueWins||0,objective:p.objective||null,wins:p.wins||0,losses:p.losses||0,
 team:(p.team||[]).map(m=>({species:m.species,level:m.level,hp:m.hp,maxHp:m.maxHp,...(own?{id:m.id,moves:m.moves||[],pp:m.pp||{},status:m.status||null,ability:m.ability||null,nature:m.nature,item:m.item||null}:{})})),
 ...(own?{money:p.money||0,bag:p.bag||{pokeballs:0},battle:Battle.publicBattle(p),hallOfFame:p.hallOfFame||[],story:p.story||{},frontier:Frontier.info(p)}:{})});
let dirty=false,server,primaryCorrupted=false;
function persist(){fs.mkdirSync(DATA_DIR,{recursive:true,mode:0o700});const tmp=FILE+'.tmp';const data={schema:2,simTick,profiles:[...profiles.values()],bots:onlineBots};
 // Trainer saves contain account identifiers and salted session hashes.
 // Never leave new files readable by other local users of a shared host.
 fs.writeFileSync(tmp,JSON.stringify(data),{mode:0o600});
 if(process.platform!=='win32')fs.chmodSync(tmp,0o600);
 // Keep one last-known-good snapshot so an interrupted save does not erase
 // all trainer sessions and bot journeys. Never overwrite it with corrupt data.
 if(!primaryCorrupted&&fs.existsSync(FILE)){fs.copyFileSync(FILE,BACKUP_FILE);if(process.platform!=='win32')fs.chmodSync(BACKUP_FILE,0o600);}
 fs.renameSync(tmp,FILE);if(process.platform!=='win32')fs.chmodSync(FILE,0o600);primaryCorrupted=false;dirty=false;
}
function recover(){try{let data;try{data=JSON.parse(fs.readFileSync(FILE,'utf8'));}
 catch(error){if(!fs.existsSync(BACKUP_FILE))throw error;
  data=JSON.parse(fs.readFileSync(BACKUP_FILE,'utf8'));
  primaryCorrupted=true;console.warn('[world] primary save failed; recovered backup');}
for(const p of data.profiles||[]){if(!p.id||!p.secretHash||!MAPS[p.area])continue;
 if(!walkable(p.area,p.x,p.y))p.navigationBlocked=true;
 if(!CHANNELS.includes(p.channel))p.channel=1;
 // Migrate the lightweight V6 guest Pokémon to the new combat schema.
 p.team=(p.team||[]).filter(m=>Battle.SPEC[m.species]).map(m=>Number.isFinite(m.hp)&&Array.isArray(m.moves)?m:Battle.create(m.species,Math.max(1,Math.min(100,Number(m.level)||5))));
 if(p.battle?.type==='bot')p.battle=null; // Abandoned guest duel must not retain a lock after restart.
 if(!p.team.length)Battle.createProfileStarter(p);
 p.bag??={pokeballs:5};p.money??=500;p.pc??=[];
 profiles.set(p.id,p);sessions.set(p.secretHash,p.id);
 }
 for(const b of data.bots||[])if(b.id){BotAI.migrate(b);Duel.release(b);onlineBots.push(b);}
 simTick=Number.isSafeInteger(data.simTick)?data.simTick:0;
 }catch(e){if(e.code!=='ENOENT')console.warn('[world] failed to restore:',e.message);}
}
recover();
// Never discard a saved bot when lowering the active simulation count.
// They remain in storage and can be resumed by increasing BOT_COUNT.
for(let i=onlineBots.length+1;i<=BOT_COUNT;i++)onlineBots.push(BotAI.createBot(i));
const active=new Map();
function sessionFrom(req){const pair=String(req.headers.cookie||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('elw_sid='));if(!pair)return null;
 const raw=pair.slice(8);if(!/^[a-f0-9]{64}$/.test(raw))return null;const who=sessions.get(sha(raw));const p=who?profiles.get(who)||null:null;if(Auth.MODE==='required'&&(!p?.accountId||!Number.isFinite(p.accountAuthUntil)||p.accountAuthUntil<=now()))return null;return p;}
function response(res,status,data,extra={}){res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff',...extra});res.end(JSON.stringify(data));}
function fail(res,status,message){response(res,status,{error:message});}
function readBody(req,max=4096){return new Promise((ok,err)=>{let size=0,buf='';req.setEncoding('utf8');req.on('data',s=>{size+=Buffer.byteLength(s);if(size>max){err(Error('too large'));req.destroy();return;}buf+=s;});req.on('end',()=>{try{ok(JSON.parse(buf||'{}'))}catch(e){err(e)}});req.on('error',err);});}
function safeOrigin(req){const origin=req.headers.origin;const host=req.headers.host;
 if(!host||/[\x00-\x20]/.test(host))return false;
 if(origin){try{const u=new URL(origin);if(u.host!==host||!['http:','https:'].includes(u.protocol))return false;}catch{return false;}}
 return !req.headers['sec-fetch-site']||['same-origin','none'].includes(req.headers['sec-fetch-site']);
}
function publicPlayers(p){return [...active.keys()].map(id=>profiles.get(id)).filter(q=>q&&q.channel===p.channel&&q.area===p.area).map(clientView);}
function publicBots(p){return onlineBots.slice(0,BOT_COUNT).filter(b=>b.channel===p.channel&&b.area===p.area).map(b=>({...clientView(b),...BotAI.view(b)}));}
function snapshot(p){
 const follow=p.mode==='spectator'&&p.followBot?onlineBots.slice(0,BOT_COUNT).find(x=>x.id===p.followBot):null;
 const camera=follow?BotAI.view(follow):null;
 const focus=follow?{area:follow.area,channel:follow.channel}:p;
 return {self:clientView(p,true),map:publicMap(focus.area),players:publicPlayers(focus),bots:publicBots(focus),
  camera,chat:chat.filter(c=>c.channel===focus.channel&&c.area===focus.area).slice(-25),online:active.size,
  interactions:{gym:Battle.gymAt(p)?.name||null,league:Battle.leagueAt(p)?.name||null,trainer:Battle.storyTrainerAt(p)?.id||null,npc:Battle.optionalTrainerAt(p)?.id||null,story:Story.nearby(p)},
  simulation:{tick:simTick,bots:BOT_COUNT,running:!!botTimer}};
}
function push(res,data,event='snapshot'){try{res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);}catch{streams.delete(res);}}
function notify(){for(const c of streams){const p=profiles.get(c.id);if(Auth.MODE==='required'&&(!p?.accountId||!Number.isFinite(p.accountAuthUntil)||p.accountAuthUntil<=now())){c.res.end();streams.delete(c);continue;}if(p)push(c.res,snapshot(p));}}
const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.png':'image/png','.gif':'image/gif','.svg':'image/svg+xml','.ico':'image/x-icon','.json':'application/json; charset=utf-8','.md':'text/plain; charset=utf-8'};
async function staticFile(req,res,url){const pathname=decodeURIComponent(url.pathname);const file=path.resolve(ROOT,'.'+(pathname==='/'?'/index.html':pathname));
 if(!file.startsWith(ROOT+path.sep)||file.includes(`${path.sep}server${path.sep}`)||file.includes(`${path.sep}tests${path.sep}`)||file.includes(`${path.sep}.`))return fail(res,404,'Não encontrado');
 try{const stat=await fsp.stat(file);if(!stat.isFile())return fail(res,404,'Não encontrado');const ext=path.extname(file).toLowerCase();if(!mime[ext])return fail(res,404,'Não encontrado');
 res.writeHead(200,{'content-type':mime[ext],'content-length':stat.size,'x-content-type-options':'nosniff','cross-origin-resource-policy':'same-origin','cache-control':'no-cache'});fs.createReadStream(file).pipe(res);
 }catch{return fail(res,404,'Arquivo não encontrado');}}
async function handler(req,res){let u;try{u=new URL(req.url,'http://local');}catch{return fail(res,400,'URL inválida');}
 if(u.pathname.startsWith('/api/')&&req.method==='POST'&&!safeOrigin(req))return fail(res,403,'Origem bloqueada');
 if(u.pathname==='/api/auth-config'&&req.method==='GET')return response(res,200,{required:Auth.MODE==='required',enabled:Auth.configured,provider:'supabase'});
 if(u.pathname==='/api/logout'&&req.method==='POST'){
  const p=sessionFrom(req);if(p){
   sessions.delete(p.secretHash);p.secretHash=sha(crypto.randomBytes(32).toString('hex'));dirty=true;
   for(const c of [...streams])if(c.id===p.id){streams.delete(c);try{c.res.end()}catch{}}
   active.delete(p.id);
  }
  return response(res,200,{ok:true},{'set-cookie':'elw_sid=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict'});
 }
 if(u.pathname==='/api/campaign'&&req.method==='GET'){
  const p=sessionFrom(req);if(!p)return fail(res,401,'Crie sua sessão antes de consultar a jornada');
  const gyms=Object.values(Battle.GYMS).sort((a,b)=>a.badge-b.badge).map(g=>({name:g.name,area:g.area,badge:g.badge,complete:Number(p.badges||0)>=g.badge,unlocked:Number(p.badges||0)===g.badge-1,team:g.team.map(([species,level])=>({species,level})),betaFormat:g.format||'single'}));
  const league=Battle.LEAGUE.map((l,i)=>({name:l.name,area:l.area,number:i+1,complete:p.story?.[l.flag]===true,unlocked:Number(p.badges||0)===8&&Battle.LEAGUE.slice(0,i).every(x=>p.story?.[x.flag]===true),team:l.team.map(([species,level])=>({species,level}))}));
  return response(res,200,{title:'Jornada Hoenn — V3.0.1',badges:p.badges||0,leagueWins:p.leagueWins||0,champion:p.champion===true,frontierUnlocked:p.champion===true,gyms,league,hallOfFame:p.hallOfFame||[],notes:'Mapas adaptados; Tate & Liza utilizam Double jogável com motor Gen III parcial.'});
 }
 if(u.pathname==='/api/dex'&&req.method==='GET'){
  return response(res,200,Dex.query(Object.fromEntries(u.searchParams)));
 }
 if(/^\/api\/dex\/\d{1,4}$/.test(u.pathname)&&req.method==='GET'){
  const p=Dex.BY_ID.get(Number(u.pathname.split('/').at(-1)));
  return p?response(res,200,p):fail(res,404,'Espécie não encontrada');
 }
 if(u.pathname==='/api/encounters'&&req.method==='GET'){
  const p=sessionFrom(req);if(!p)return fail(res,401,'Crie seu perfil primeiro');
  const allowed=NationalPools.hasEncounters(p.area)&&!['Littleroot','Oldale','Petalburg','Rustboro','Dewford','Slateport','Mauville','Center','Mart'].includes(p.area);
  const names=allowed?NationalPools.pool(Dex.PRIMARY,{location:p.area,badges:p.badges,champion:p.champion===true,matchHabitat:true}).map(e=>e.key):[];
  return response(res,200,{area:p.area,badges:p.badges,total:names.length,sample:names.slice(0,12),source:'adapted-simulator-not-quetzal'});
 }
 if(/^\/api\/habitats\/\d{1,4}$/.test(u.pathname)&&req.method==='GET'){
  const entry=Dex.PRIMARY.find(r=>r.dex===Number(u.pathname.split('/').at(-1)));
  return entry?response(res,200,NationalPools.encounterInfo(entry)):fail(res,404,'Espécie não encontrada');
 }
 if(u.pathname==='/api/health')return response(res,200,{ok:true,authRequired:Auth.MODE==='required',version:require('../package.json').version,pokemonSpecies:Dex.META.nationalSpecies,pokemonRecords:Dex.META.records,players:active.size,bots:BOT_COUNT,maps:Object.keys(MAPS).length,simulationTick:simTick,uptimeSeconds:Math.floor(process.uptime())});
 if(/^\/api\/route\/bot-\d+$/.test(u.pathname)&&req.method==='GET'){
  const p=sessionFrom(req);if(!p)return fail(res,401,'Crie seu perfil primeiro');
  if(p.mode==='spectator')return fail(res,403,'Rotas são para exploradores');
  const bot=onlineBots.slice(0,BOT_COUNT).find(b=>'/api/route/'+b.id===u.pathname);
  if(!bot)return fail(res,404,'IA não encontrada');
  if(bot.channel!==p.channel)return response(res,200,{ok:false,reason:'different-channel',message:'O bot está em outro canal.',channel:bot.channel});
  let dirs=[],destination=null;
  if(p.area===bot.area){dirs=Nav.localDirections(p.area,p.x,p.y,bot.x,bot.y,false);
    destination={area:bot.area,x:bot.x,y:bot.y};
  }else{
    const edges=Nav.mapRoute(p.area,bot.area,p);
    if(!edges?.length)return response(res,200,{ok:false,reason:'locked-or-unreachable',message:'O caminho exige uma passagem ou evento ainda indisponível.'});
    const door=edges[0].portal;
    dirs=Nav.localDirections(p.area,p.x,p.y,door.x,door.y,true);
    destination={area:p.area,x:door.x,y:door.y,to:door.to};
  }
  if(!dirs)return response(res,200,{ok:false,reason:'no-path',message:'Não foi encontrado caminho livre até a próxima passagem.'});
  const delta={up:[0,-1],down:[0,1],left:[-1,0],right:[1,0]};
  let x=p.x,y=p.y;const trail=[];for(const dir of dirs.slice(0,120)){x+=delta[dir][0];y+=delta[dir][1];trail.push({x,y});}
  return response(res,200,{ok:true,target:bot.id,botArea:bot.area,destination,nextDirection:dirs[0]||null,steps:dirs.length,trail,arrived:p.area===bot.area&&dirs.length<=1});
 }
 if(u.pathname==='/api/bots'&&req.method==='GET'){
  const p=sessionFrom(req);if(!p)return fail(res,401,'Faça login como visitante primeiro');
  return response(res,200,{tick:simTick,total:BOT_COUNT,bots:onlineBots.slice(0,BOT_COUNT).map(b=>BotAI.view(b))});
 }
 if(/^\/api\/bots\/bot-\d+$/.test(u.pathname)&&req.method==='GET'){
  const p=sessionFrom(req);if(!p)return fail(res,401,'Faça login como visitante primeiro');
  const b=onlineBots.find(x=>'/api/bots/'+x.id===u.pathname);
  if(!b)return fail(res,404,'Treinador não encontrado');
  return response(res,200,{tick:simTick,bot:BotAI.view(b,true)});
 }
 if(u.pathname==='/api/top-pokemon'&&req.method==='GET'){
  const p=sessionFrom(req);if(!p)return fail(res,401,'Crie seu perfil primeiro');
  const owners=[...onlineBots.slice(0,BOT_COUNT),...profiles.values()];
  const top=owners.flatMap(owner=>(owner.team||[]).concat(owner.pc||[])
    .filter(mon=>mon&&Battle.SPEC[mon.species])
    .map(mon=>({species:mon.species,level:mon.level,owner:owner.name,
      power:['hp','atk','def','spa','spd','spe'].reduce((sum,stat)=>sum+Battle.stat(mon,stat),0)})))
   .sort((a,b)=>b.power-a.power||b.level-a.level).slice(0,6);
  return response(res,200,{tick:simTick,top});
 }
 if(u.pathname==='/api/frontier'&&req.method==='GET'){
  const p=sessionFrom(req);if(!p)return fail(res,401,'Faça login antes de acessar a Frontier');
  return response(res,200,Frontier.info(p));
 }
 if(['/api/frontier/start','/api/frontier/next','/api/frontier/swap','/api/frontier/use-item','/api/frontier/select-lineup','/api/frontier/explore','/api/frontier/retire'].includes(u.pathname)&&req.method==='POST'){
  const p=sessionFrom(req);if(!p)return fail(res,401,'Faça login antes de acessar a Frontier');
  if(p.mode==='spectator')return fail(res,403,'Espectadores não participam da Frontier');
  if(!active.has(p.id))return fail(res,409,'Conecte a transmissão antes de jogar');
  let body;try{body=await readBody(req);}catch{return fail(res,400,'Dados inválidos');}
  try{
   const result=u.pathname.endsWith('/start')?Frontier.start(p,body):u.pathname.endsWith('/next')?Frontier.next(p,body):u.pathname.endsWith('/explore')?Frontier.explore(p,body):u.pathname.endsWith('/swap')?Frontier.swap(p,body):u.pathname.endsWith('/use-item')?Frontier.useBattleBag(p,body):u.pathname.endsWith('/select-lineup')?Frontier.selectLineup(p,body):Frontier.retire(p);
   dirty=true;notify();return response(res,200,{result,frontier:Frontier.info(p),self:clientView(p,true)});
  }catch(e){return fail(res,422,String(e.message||'Ação da Frontier inválida'));}
 }
 if(u.pathname==='/api/ranking'&&req.method==='GET'){
  const p=sessionFrom(req);if(!p)return fail(res,401,'Faça login como visitante primeiro');
  const rank=onlineBots.slice(0,BOT_COUNT).map(b=>BotAI.view(b)).sort((a,b)=>b.badges-a.badges||b.wins-a.wins||b.team.reduce((n,m)=>n+m.level,0)-a.team.reduce((n,m)=>n+m.level,0));
  return response(res,200,{tick:simTick,ranking:rank,hallOfFame:rank.filter(b=>b.champion===true)});
 }
 if(u.pathname==='/api/session'&&req.method==='POST'){
  if(authRateLimited(req))return fail(res,429,'Muitas tentativas de login. Tente novamente em um minuto.');
  let body;try{body=await readBody(req);if(!body||typeof body!=='object'||Array.isArray(body))throw Error('body');}catch{return fail(res,400,'Dados inválidos');}
  let p=sessionFrom(req);let cookie;
  if(req.headers.authorization){
   let user;try{user=await Auth.verifyToken(req.headers.authorization)}catch(e){return fail(res,e.status||401,e.message)}
   if(!p||p.accountId!==user.id){p=[...profiles.values()].find(x=>x.accountId===user.id)||createSessionProfile(body);p.accountId=user.id;cookie=rotateSession(p,req);}
   p.accountAuthUntil=now()+ACCOUNT_SESSION_TTL_MS;
  }else if(Auth.MODE==='required')return fail(res,401,'Entre com sua conta para acessar o mundo compartilhado');
  else if(!p){p=createSessionProfile(body);cookie=rotateSession(p,req);}
  if(!cookie&&p){
   if(body.name)p.name=safeText(body.name)||p.name;
   if(!p.battle&&!p.frontier?.active&&CHANNELS.includes(Number(body.channel)))p.channel=Number(body.channel);
   if(AVATARS.includes(body.avatar))p.avatar=body.avatar;
  }
  if(p.frontier?.active&&body.mode==='spectator')return fail(res,409,'Abandone o desafio Frontier antes de mudar para Espectador');
  if(['online','spectator'].includes(body.mode))p.mode=body.mode;
  p.lastSeen=now();dirty=true;const result={profile:clientView(p,true),guest:!p.accountId,online:active.size};response(res,200,result,cookie?{'set-cookie':cookie}:{});notify();return;
 }
 if(u.pathname==='/api/stream'&&req.method==='GET'){
  const p=sessionFrom(req);if(!p)return fail(res,401,'Crie seu perfil primeiro');
  res.writeHead(200,{'content-type':'text/event-stream; charset=utf-8','cache-control':'no-store, no-transform','connection':'keep-alive','x-accel-buffering':'no','x-content-type-options':'nosniff'});
  res.write(': connected\n\n');const c={id:p.id,res};streams.add(c);active.set(p.id, (active.get(p.id)||0)+1);push(res,snapshot(p));notify();
  let closed=false;req.on('close',()=>{if(closed)return;closed=true;streams.delete(c);const count=active.get(p.id)||0;if(count<2)active.delete(p.id);else active.set(p.id,count-1);notify()});return;
 }
 if(['/api/battle/start','/api/battle/action','/api/battle/heal','/api/story/interact','/api/shop/buy'].includes(u.pathname)&&req.method==='POST'){
  const p=sessionFrom(req);if(!p)return fail(res,401,'Perfil não encontrado');
  if(!active.has(p.id))return fail(res,409,'Conecte a transmissão antes de batalhar');
  if(p.mode==='spectator')return fail(res,403,'Espectadores não participam de batalhas');
  if(p.frontier?.active&&u.pathname!=='/api/battle/action')return fail(res,409,'Desafio Frontier em andamento: use apenas as ações da Frontier e sua batalha');
  let body;try{body=await readBody(req);if(!body||typeof body!=='object'||Array.isArray(body))throw Error('body');}catch{return fail(res,400,'Dados inválidos');}
  try{
   let result;
   if(u.pathname==='/api/story/interact'){
    result=Story.interact(p);
   }else if(u.pathname==='/api/shop/buy'){
    result=Shop.buy(p,body.item,body.count);
   }else if(u.pathname==='/api/battle/start'){
    const b=body.type==='bot'?onlineBots.find(x=>x.id===body.botId):null;
    result=body.type==='bot'?Duel.begin(p,b):Battle.begin(p,{type:['gym','trainer','npc','league'].includes(body.type)?body.type:'wild',trainerId:body.trainerId,national:body.national===true});
   }else if(u.pathname==='/api/battle/action'){
    if(now()-(p.lastBattleAt||0)<300)return fail(res,429,'Aguarde seu turno antes de agir');
    if(p.battle?.type==='bot'){
     const b=onlineBots.find(x=>x.id===p.battle.targetId);
     result=Duel.action(p,b,{type:body.type,move:body.move});
    }else result=Battle.act(p,{type:body.type,move:body.move,partnerMove:body.partnerMove,target:body.target,partnerTarget:body.partnerTarget});p.lastBattleAt=now();
   }else result={healed:Battle.heal(p).length};
   if(!p.battle&&!Battle.firstAlive(p)&&p.team?.length){if(blackoutRespawn(p)){p.navigationBlocked=false;result.blackout=true;}}
   p.lastSeen=now();dirty=true;notify();return response(res,200,{result,self:clientView(p,true)});
  }catch(err){return fail(res,422,String(err.message||'Batalha inválida'));}
 }
 if(['/api/move','/api/chat','/api/channel','/api/spectate'].includes(u.pathname)&&req.method==='POST'){
  const p=sessionFrom(req);if(!p)return fail(res,401,'Perfil não encontrado');let body;try{body=await readBody(req);if(!body||typeof body!=='object'||Array.isArray(body))throw Error('body');}catch{return fail(res,400,'Dados inválidos');}
  if(u.pathname==='/api/spectate'){
   if(p.mode!=='spectator')return fail(res,403,'Entre no modo Espectador para seguir um bot.');
   if(body.botId===null){p.followBot=null;dirty=true;notify();return response(res,200,{ok:true});}
   if(!onlineBots.slice(0,BOT_COUNT).some(b=>b.id===body.botId))return fail(res,404,'Bot não encontrado');
   p.followBot=body.botId;dirty=true;notify();return response(res,200,{ok:true});
  }
  if(u.pathname==='/api/move'){
   if(p.frontier?.active)return fail(res,409,'Finalize ou abandone o desafio da Frontier antes de caminhar');
   if(!active.has(p.id))return fail(res,409,'Conecte a transmissão antes de andar');
   if(p.mode==='spectator')return fail(res,403,'Espectadores não podem mover o personagem');
   if(p.battle)return fail(res,409,'Finalize a batalha antes de caminhar');
   if(now()-(p.lastMove||0)<110)return fail(res,429,'Movimento rápido demais');
   if(p.navigationBlocked||!step(p,body.dir))return fail(res,422,'Passo bloqueado');p.lastMove=now();p.lastSeen=now();dirty=true;notify();return response(res,200,{self:clientView(p)});
  }
  if(u.pathname==='/api/chat'){
   if(!active.has(p.id))return fail(res,409,'Conecte a transmissão antes de conversar');
   if(now()-(p.lastChat||0)<1400)return fail(res,429,'Aguarde antes da próxima mensagem');
   const message=safeText(body.message,180);if(!message)return fail(res,422,'Mensagem vazia');
   if(/(?:https?:\/\/|www\.|discord\.gg\/)/i.test(message))return fail(res,422,'Links desativados no chat de visitantes');
   p.lastChat=now();chat.push({id:id(),author:p.name,area:p.area,channel:p.channel,message,time:now()});if(chat.length>300)chat.splice(0,chat.length-300);notify();return response(res,200,{ok:true});
  }
  if(u.pathname==='/api/channel'){
   if(p.frontier?.active)return fail(res,409,'Não é possível mudar de canal durante um desafio Frontier');
   const ch=Number(body.channel);if(!CHANNELS.includes(ch))return fail(res,422,'Canal inválido');if(p.battle)return fail(res,409,'Não mude de canal durante uma batalha');p.channel=ch;p.lastSeen=now();dirty=true;notify();return response(res,200,{self:clientView(p)});
  }
 }
 if(u.pathname.startsWith('/api/'))return fail(res,404,'Rota não encontrada');
 if(req.method!=='GET'&&req.method!=='HEAD')return fail(res,405,'Método inválido');return staticFile(req,res,u);
}
function advanceBots(){
 simTick++;
 if(Duel.expire(profiles,onlineBots).length)dirty=true;
 const batch=Math.min(BOT_COUNT,BOT_STEPS_PER_TICK);
 for(let stepIndex=0;stepIndex<batch;stepIndex++){
  const b=onlineBots[((simTick-1)*batch+stepIndex)%BOT_COUNT];
  if(Duel.locked(b))continue;
  try{BotAI.advance(b)}catch(e){b.errors=(b.errors||0)+1;if(b.errors<=3)console.error('[AI]',b.id,e.message)}
 }
 dirty=true;if(simTick%2===0)notify();
}
let heartbeat,botTimer,saveTimer;
function start(port=PORT,host=HOST){server=http.createServer((req,res)=>{handler(req,res).catch(e=>{console.error(e);if(!res.headersSent)fail(res,500,'Erro do servidor');else res.end()});});
 heartbeat=setInterval(()=>{for(const c of streams)try{c.res.write(': heartbeat\n\n')}catch{}},20000);
 botTimer=setInterval(advanceBots,BOT_TICK_MS);saveTimer=setInterval(()=>{if(dirty)persist()},5000);
 return new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,host,()=>resolve(server))});}
async function stop(){clearInterval(heartbeat);clearInterval(botTimer);clearInterval(saveTimer);if(dirty)persist();for(const c of streams)c.res.end();streams.clear();active.clear();await new Promise(ok=>server?.close(ok)||ok());}
if(require.main===module){start().then(()=>console.log(`Emerald Living World 3.0 server: http://${HOST}:${server.address().port}/jogo/online.html`)).catch(e=>{console.error(e);process.exitCode=1});for(const sig of ['SIGTERM','SIGINT'])process.on(sig,()=>{stop().then(()=>process.exit(0))});}
module.exports={start,stop,getServer:()=>server,snapshot,profiles,onlineBots,persist,advanceBots,simulation:()=>({tick:simTick,count:BOT_COUNT})};
