'use strict';
/** Transactional purchase in the authoritative room: no free inventory. */
const PRICES=Object.freeze({pokeballs:200});
function buy(profile,item,count=1){
 if(profile.frontier?.active)throw Error('Compras externas bloqueadas durante a Frontier');
 if(profile.area!=='Mart'||profile.battle)throw Error('Visite o Poké Mart fora de uma batalha.');
 if(!Object.hasOwn(PRICES,item)||!Number.isSafeInteger(count)||count<1||count>20)throw Error('Compra inválida');
 const cost=PRICES[item]*count;
 if(!Number.isSafeInteger(profile.money)||profile.money<cost)throw Error('Dinheiro insuficiente');
 profile.money-=cost;profile.bag??={};profile.bag[item]=(profile.bag[item]||0)+count;
 return {item,count,cost,balance:profile.money,pokeballs:profile.bag.pokeballs};
}
module.exports={buy,PRICES};
