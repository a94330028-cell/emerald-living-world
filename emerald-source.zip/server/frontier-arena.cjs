'use strict';
/** Arena Mind/Skill/Body judge. Logs are sampled because this beta battle
 * engine does not yet emit ROM-level per-move result events. */
const MIND_NEUTRAL=new Set(['Counter','MirrorCoat','Bide']);
const MIND_MINUS=new Set(['FakeOut','Protect','Detect','Endure']);
function mindPoints(move,moves){return MIND_MINUS.has(move)?-1:MIND_NEUTRAL.has(move)?0:moves[move]?.power>0?1:0;}
function skillPoints(actor,move,lines,effectiveness=1){
 const line=lines.join(' ');
 if(/se protegeu|Fake Out.*flinch/i.test(line))return 0;
 if(/errou|não conseguiu agir|está dormindo|está congelado|sem efeito|não afetou|evitou|não tem PP|incapaz|hesitou|protegido/i.test(line))return -2;
 if(!line.includes(`${actor.species} usou ${move}`))return -2;
 if(effectiveness>1)return 2;
 if(effectiveness>0&&effectiveness<1)return -1;
 return 1;
}
function init(own,foe){return {ownId:own.id,foeId:foe.id,rounds:0,
 startOwnHp:own.hp,startFoeHp:foe.hp,own:{mind:0,skill:0},foe:{mind:0,skill:0}};}
function record(state,side,mon,move,moves,lines,effectiveness=1){if(!state||!['own','foe'].includes(side))return;
 state[side].mind+=mindPoints(move,moves);state[side].skill+=skillPoints(mon,move,lines,effectiveness);
}
function judge(state,own,foe){
 const categories={
  mind:[state.own.mind,state.foe.mind],
  skill:[state.own.skill,state.foe.skill],
  body:[state.startOwnHp?own.hp/state.startOwnHp:0,state.startFoeHp?foe.hp/state.startFoeHp:0]
 };
 let ownPoints=0,foePoints=0;const detail={};
 for(const [name,[a,b]] of Object.entries(categories)){
  if(a>b)ownPoints+=2;else if(b>a)foePoints+=2;else{ownPoints++;foePoints++;}
  detail[name]={own:a,foe:b,winner:a===b?'tie':a>b?'own':'foe'};
 }
 return {winner:ownPoints===foePoints?'tie':ownPoints>foePoints?'own':'foe',ownPoints,foePoints,detail};
}
module.exports={mindPoints,skillPoints,init,record,judge};
