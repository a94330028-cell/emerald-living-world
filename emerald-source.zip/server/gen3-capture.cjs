'use strict';
/** Poké Ball approximation of Emerald's four-shake Gen III capture mechanics.
 * Standard Poké Ball only. Other ball multipliers can be added separately.
 * The encounter/capture catalog is deliberately NOT modified here.
 */
const statusModifier=status=>['sleep','freeze'].includes(status)?2:['paralysis','poison','toxic','burn'].includes(status)?1.5:1;
function modifiedRate({maxHp,hp,rate,status=null,ballModifier=1}){
 if(!Number.isInteger(maxHp)||maxHp<=0||!Number.isFinite(hp)||hp<0||hp>maxHp||!Number.isFinite(rate)||rate<1||rate>255)throw Error('Dados inválidos para captura');
 if(!Number.isFinite(ballModifier)||ballModifier<=0)throw Error('Poké Bola inválida');
 const adjusted=Math.floor((3*maxHp-2*hp)*rate*ballModifier*statusModifier(status)/(3*maxHp));
 return Math.max(1,Math.min(255,adjusted));
}
function shakeThreshold(modified){
 if(modified>=255)return 65536;
 if(!Number.isInteger(modified)||modified<1)throw Error('Taxa de captura inválida');
 return Math.floor(65536*Math.pow(modified/255,0.25));
}
function throwBall(mon,catchRate,rng=Math.random){
 const rate=modifiedRate({maxHp:mon.maxHp,hp:mon.hp,rate:catchRate,status:mon.status});
 const threshold=shakeThreshold(rate);
 if(rate>=255)return {success:true,shakes:4,modifiedRate:rate};
 let shakes=0;
 for(let i=0;i<4;i++){
  const roll=rng();if(!(roll>=0&&roll<1))throw Error('RNG inválido');
  if(Math.floor(roll*65536)>=threshold)return {success:false,shakes,modifiedRate:rate};
  shakes++;
 }
 return {success:true,shakes:4,modifiedRate:rate};
}
module.exports={statusModifier,modifiedRate,shakeThreshold,throwBall};
