'use strict';
/** Emerald Living World Frontier LAB: seven distinct playable prototype controllers.
 * The classic challenge is unlocked by champion status. Practice mode is explicitly
 * unranked and awards no BP, symbols or permanent records. No facility is currently
 * claimed to be a frame-perfect recreation of the original Emerald Frontier.
 * Modern National encounter pools / bot capture mechanics are never modified here.
 */
const crypto=require('node:crypto');
const Brains=require('./frontier-brains.cjs');
const Adventures=require('./frontier-adventures.cjs');
const FrontierPass=require('./frontier-pass-lab.cjs');
const FACILITIES=Object.freeze({
 tower:{id:'tower',name:'Battle Tower',block:7,register:3,active:3,brain:[35,70],status:'playable-beta'},
 dome:{id:'dome',name:'Battle Dome',block:4,register:3,active:2,brain:[5,10],status:'playable-beta'},
 palace:{id:'palace',name:'Battle Palace',block:7,register:3,active:3,brain:[21,42],status:'playable-beta'},
 arena:{id:'arena',name:'Battle Arena',block:7,register:3,active:3,brain:[28,56],status:'playable-beta'},
 factory:{id:'factory',name:'Battle Factory',block:7,register:0,active:3,brain:[21,42],status:'playable-beta'},
 pike:{id:'pike',name:'Battle Pike',block:14,register:3,active:3,brain:[28,140],status:'playable-beta'},
 pyramid:{id:'pyramid',name:'Battle Pyramid',block:7,register:3,active:3,brain:[21,70],status:'playable-beta'}
});
const CLASSIC_POOL=Object.freeze(['Swampert','Sceptile','Blaziken','Machop','Breloom','Mightyena','Manectric','Magneton','Pelipper','Swellow','Nosepass','Geodude','Ralts','Abra','Makuhita','Zubat','Lotad','Shroomish']);
const ROOM_EVENTS=Object.freeze({pike:['battle','quiet','heal','status','battle','quiet','battle'],pyramid:['battle','battle','quiet','heal','battle','quiet','battle']});
function state(profile){
 profile.frontier??={bp:0,records:{},symbols:{},active:null};
 profile.frontier.labBP??=0;
 profile.frontier.labRecords??={};
 profile.frontier.labSymbols??={};
 return profile.frontier;
}
function info(profile){const f=state(profile),r=f.active;return {unlocked:profile.champion===true,practiceAvailable:true,bp:f.bp,records:f.records,symbols:f.symbols,
 labBP:f.labBP,labRecords:f.labRecords,labSymbols:f.labSymbols,labPass:FrontierPass.calculate(f),
 brainRosterStatus:'equipes adaptadas: não são batalhas 100% fiéis à ROM',
 brains:Object.fromEntries(Object.entries(Brains.BRAINS).map(([id,b])=>[id,{name:b.name,symbol:b.symbol,triggers:b.triggers}])),
 active:r?{id:r.id,facility:r.facility,streak:r.streak,levelRule:r.levelRule,mode:r.mode,practice:r.practice,inBattle:!!profile.battle,
  selectedTeamIds:r.teamIds.slice(),registeredTeamIds:r.registeredIds?.slice()||[],lineupLocked:!!r.lineupLocked,
  block:r.block,room:r.room||0,events:r.events?.slice(-8)||[],rentals:r.facility==='factory'?r.rentals.map(m=>({id:m.id,species:m.species,hp:m.hp,maxHp:m.maxHp,level:m.level,moves:m.moves,pp:m.pp})):undefined,
  swaps:r.swaps||[],battleBag:r.battleBag||null,
  pikeDoors:r.facility==='pike'&&r.pikeDoors?{doors:r.pikeDoors.doors.map(d=>({index:d.index})),hint:r.pikeDoors.hint}:null,
  domeBracket:r.facility==='dome'&&r.domeBracket?{number:r.domeBracket.number,format:r.domeBracket.format,entrants:r.domeBracket.entrants.map(e=>({id:e.id,name:e.name})),rounds:r.domeBracket.rounds.map(row=>({...row})),matches:(r.domeBracket.matches||[]).map(group=>group.map(row=>({round:row.round,match:row.match,firstId:row.firstId,secondId:row.secondId,winnerId:row.winnerId,completed:row.completed})))}:null,
  pyramidFloor:r.facility==='pyramid'?Adventures.exposedPyramidFloor(r.pyramidFloor):null,
 nextBrain:Brains.tierAt(r.facility,r.streak+1),
 tournament:r.facility==='dome'?Math.floor(r.streak/4)+1:undefined}:null,
 facilities:Object.values(FACILITIES)};}
function roster(profile){const r=state(profile).active;return r?.facility==='factory'?r.rentals:profile.team||[];}
function selectTeam(profile,teamIds,levelRule,requireHealthy=true,facility='tower'){
 const Battle=require('./battle.cjs'),count=FACILITIES[facility]?.register??3;
 if(!Array.isArray(teamIds)||teamIds.length!==count||new Set(teamIds).size!==count)throw Error(`Selecione ${count} Pokémon diferentes`);
 const members=teamIds.map(id=>profile.team?.find(mon=>mon.id===id));
 if(members.some(m=>!m||(requireHealthy&&m.hp<=0)))throw Error('Pokémon inválido ou sem HP');
 if(members.some(m=>(Battle.SPEC[m.species]?.dex||99999)>386))throw Error('Frontier clássica utiliza Pokémon das três primeiras gerações; as espécies modernas permanecem capturáveis fora dela');
  const banned=new Set(['Mewtwo','Mew','Lugia','Ho-Oh','Celebi','Kyogre','Groudon','Rayquaza','Jirachi','Deoxys']);
  if(members.some(m=>banned.has(m.species)))throw Error('Pokémon lendário ou mítico proibido no regulamento da Frontier original');
 if(facility==='pyramid'&&members.some(m=>!!m.item))throw Error('A Battle Pyramid não permite itens equipados');
 if(levelRule==='level50'&&members.some(m=>m.level>50))throw Error('No modo Level 50, não utilize Pokémon de nível maior que 50');
 const held=members.map(m=>m.item).filter(Boolean);
 if(new Set(held).size!==held.length)throw Error('Itens equipados repetidos não são permitidos');
 if(new Set(members.map(m=>m.species)).size!==members.length)throw Error('Espécies repetidas não são permitidas');
 return members;
}
function makeRentals(level,count=6){const Battle=require('./battle.cjs');const candidates=[...CLASSIC_POOL];
 for(let i=candidates.length-1;i>0;i--){const j=crypto.randomInt(i+1);[candidates[i],candidates[j]]=[candidates[j],candidates[i]];}
 return candidates.slice(0,count).map(name=>Battle.create(name,level));}
function start(profile,{facility='tower',mode='single',levelRule='level50',teamIds=[],practice=false}={}){
 if(!FACILITIES[facility])throw Error('Instalação inválida');
 if(profile.battle)throw Error('Termine sua batalha atual');
 if(!practice&&profile.champion!==true)throw Error('A Battle Frontier oficial é desbloqueada após vencer a Liga Pokémon; utilize o laboratório de treino sem recompensas');
 if(!['level50','open'].includes(levelRule))throw Error('Categoria de nível inválida');
 if(mode!=='single')throw Error('A implementação de Double/Multi ainda não está liberada como formato jogável');
 const f=state(profile);if(f.active)throw Error('Finalize ou abandone sua sequência atual');
 const members=facility==='factory'?[]:selectTeam(profile,teamIds,levelRule,true,facility);
 const level=levelRule==='level50'?50:Math.max(60,...members.map(m=>m.level),60);
 const rentals=facility==='factory'?makeRentals(level):[];
 const ids=facility==='factory'?rentals.slice(0,3).map(m=>m.id):members.slice(0,facility==='dome'?2:3).map(m=>m.id);
 f.active={id:crypto.randomUUID(),facility,mode,levelRule,practice:!!practice,teamIds:ids,registeredIds:members.map(m=>m.id),battleBag:facility==='pyramid'?{potions:3}:null,streak:0,block:0,room:0,level,rentals,lineupLocked:false,
  savedActiveIndex:profile.activeIndex||0,startedAt:Date.now(),events:[],swaps:[],lastOpponent:[],
  pikeDoors:facility==='pike'?Adventures.makePikeDoors():null,
  domeBracket:facility==='dome'?Adventures.createDomeTournament(1,level,CLASSIC_POOL):null,
  pyramidFloor:null,initialized:false};
 if(facility==='factory')profile.activeIndex=0;
 return info(profile);
}
/** Dome: pick two of three registered Pokemon before each match.
 * Factory: choose three of six rentals once, before entering the first match.
 * Does not affect wild encounters, AI capture species or classic team slots.
 */
function selectLineup(profile,{teamIds=[]}={}){
 const r=state(profile).active;
 if(!r||!['factory','dome'].includes(r.facility))throw Error('Seleção disponível somente no Dome ou Factory');
 if(profile.battle||r.pendingEncounter)throw Error('Finalize o confronto atual antes de alterar a equipe');
 if(r.facility==='factory'&&(r.lineupLocked||r.streak>0))throw Error('O time de aluguéis só pode ser escolhido antes da primeira batalha');
 const count=r.facility==='factory'?3:2;
 if(!Array.isArray(teamIds)||teamIds.length!==count||new Set(teamIds).size!==count)throw Error(`Selecione exatamente ${count} Pokémon diferentes`);
 const eligible=r.facility==='factory'?r.rentals.filter(mon=>mon.hp>0):profile.team.filter(mon=>r.registeredIds.includes(mon.id)&&mon.hp>0);
 if(teamIds.some(id=>typeof id!=='string'||!eligible.some(mon=>mon.id===id)))throw Error('Equipe contém Pokémon não registrado, indisponível ou desmaiado');
 r.teamIds=[...teamIds];
 const first=eligible.find(mon=>mon.id===teamIds[0]);
 if(first){const team=r.facility==='factory'?r.rentals:profile.team;profile.activeIndex=team.findIndex(mon=>mon.id===first.id);}
 append(r,`${r.facility==='factory'?'Factory':'Dome'}: equipe de ${count} Pokémon escolhida.`);
 return info(profile);
}
function refresh(members){const Battle=require('./battle.cjs'),Gen3=require('./gen3-mechanics.cjs');
 for(const mon of members){mon.hp=mon.maxHp;mon.status=null;mon.toxicCounter=0;mon.stages={};mon.choiceLock=null;
  Battle.availableMoves(mon);for(const move of mon.moves)mon.pp[move]=Gen3.PP[move]??20;}
}
function append(run,text){run.events.push(text);if(run.events.length>20)run.events.splice(0,run.events.length-20);}
function awardBlock(profile,run){
 run.block++;
 const f=state(profile);
 if(!run.practice){
  const key=`${run.facility}:${run.levelRule}:${run.mode}`;
  f.labRecords[key]=Math.max(f.labRecords[key]||0,run.streak);
  const reward=run.facility==='dome'?3:2;
  f.labBP+=reward;
  append(run,`Bloco ${run.block} finalizado: +${reward} pontos LAB (não oficiais).`);
 }else append(run,`Bloco ${run.block} concluído (treino: sem recompensas).`);
}
function progress(profile,run){run.streak++;if(run.streak%FACILITIES[run.facility].block===0)awardBlock(profile,run);}
function nextPikeDoors(run){run.pikeDoors=Adventures.makePikeDoors();}
function domeTournament(run){
 const number=Math.floor(run.streak/4)+1;
 if(run.domeBracket?.number!==number){
  const finalBrain=Brains.tierAt('dome',number*4);
  run.domeBracket=Adventures.createDomeTournament(number,run.level,CLASSIC_POOL,finalBrain?{name:Brains.BRAINS.dome.name,team:Brains.BRAINS.dome[finalBrain]}:null);
 }
 return run.domeBracket;
}
function next(profile,{door=0}={}){
 const Battle=require('./battle.cjs'),f=state(profile),r=f.active;
 if(!r)throw Error('Nenhuma sequência Frontier ativa');
 if(profile.battle)throw Error('A batalha atual ainda não terminou');
 if(r.pendingEncounter)throw Error('Encontro pendente sem resultado. Recupere a batalha salva ou abandone a sequência; não é permitido pular um confronto.');
 const members=r.facility==='factory'?r.rentals.filter(m=>r.teamIds.includes(m.id)):
  selectTeam(profile,r.registeredIds||r.teamIds,r.levelRule,false,r.facility).filter(m=>r.teamIds.includes(m.id));
 if(!members.some(m=>m.hp>0))throw Error('Equipe sem Pokémon disponíveis; abandone a sequência');
 if(!['pike','pyramid'].includes(r.facility)||!r.initialized){refresh(members);r.initialized=true;}
 if(r.facility==='factory')profile.activeIndex=r.rentals.findIndex(m=>m.id===members[0].id);
 else profile.activeIndex=profile.team.findIndex(m=>m.id===members[0].id);
 if(r.facility==='factory')r.lineupLocked=true;
 const challengeNumber=r.streak+1;
 const brainTier=Brains.tierAt(r.facility,challengeNumber);
 // The Brain checkpoints cannot be skipped by a room event or a maze exit.
 if(r.facility==='pyramid'&&!brainTier){
  if(!r.pyramidFloor){r.pyramidFloor=Adventures.createPyramidFloor(challengeNumber);r.room=challengeNumber;
   append(r,`Pyramid: andar ${r.room} aberto. Explore o mapa até a saída azul.`);}
  return {event:'explore',frontier:info(profile)};
 }
 if(r.facility==='pike'){
  r.room=challengeNumber;
  if(!brainTier){
   if(!r.pikeDoors)r.pikeDoors=Adventures.makePikeDoors();
   if(!Number.isInteger(door)||door<0||door>2)throw Error('Selecione uma das três portas da Pike');
   const event=r.pikeDoors.doors[door].event;
   r.pikeDoors=null; // once resolved, the same door cannot be replayed
   append(r,`Pike: você escolheu a porta ${door+1} na sala ${r.room}.`);
   if(event==='quiet'){append(r,`Sala ${r.room}: passagem tranquila.`);progress(profile,r);nextPikeDoors(r);return {event,frontier:info(profile)};}
   if(event==='heal'){refresh(members);append(r,`Sala ${r.room}: equipe recuperada.`);progress(profile,r);nextPikeDoors(r);return {event,frontier:info(profile)};}
   if(event==='status'){const target=members.find(m=>m.hp>0&&!m.status);
    if(target){target.status='poison';append(r,`Sala ${r.room}: ${target.species} foi envenenado.`);}else append(r,`Sala ${r.room}: ninguém sofreu novo status.`);
    progress(profile,r);nextPikeDoors(r);return {event,frontier:info(profile)};
   }
  }else r.pikeDoors=null;
 }
 let opponent;
 if(brainTier){
  const mons=Brains.lineup(r.facility,brainTier,r.level,n=>makeRentals(r.level,n).map(m=>m.species));
  opponent=mons.map(mon=>[mon.species,mon.level,mon.moves,mon.item]);
  append(r,`Desafio especial LAB: ${Brains.BRAINS[r.facility].name} (${brainTier==='silver'?'Prata':'Ouro'}).`);
 }else{
  const candidates=[...CLASSIC_POOL];for(let i=candidates.length-1;i>0;i--){
   const j=crypto.randomInt(i+1);[candidates[i],candidates[j]]=[candidates[j],candidates[i]];
  }
  const count=r.facility==='dome'?2:r.facility==='pike'||r.facility==='pyramid'?1:3;
  if(r.facility==='dome'){
   const round=(r.streak%4),match=domeTournament(r).rounds[round];
   const registered=match.registered.length?match.registered:Adventures.sampleDistinct(CLASSIC_POOL,3);
   opponent=registered.slice(0,2).map(species=>[species,r.level]);
   append(r,`Dome: torneio ${r.domeBracket.number}, rodada ${round+1}/4 contra ${match.opponent}.`);
  }else opponent=candidates.slice(0,count).map(species=>[species,r.level]);
  if(r.facility!=='dome')append(r,`${FACILITIES[r.facility].name}: encontro ${challengeNumber}.`);
 }
 r.lastOpponent=opponent.map(row=>row[0]);
 const result=Battle.begin(profile,{type:'frontier',frontierId:r.id,frontierOpponent:opponent,frontierFacility:r.facility});
 const battle=profile.battle;
 r.pendingEncounter=crypto.randomUUID();
 battle.frontierResultId=r.pendingEncounter;
 battle.frontierChallengeNumber=challengeNumber;
 if(brainTier){
  battle.frontierBrain={name:Brains.BRAINS[r.facility].name,tier:brainTier};
  battle.trainerName=`${Brains.BRAINS[r.facility].name} — Frontier Brain LAB`;
  battle.history.unshift(`${battle.trainerName} desafia seu time!`);
  result.trainerName=battle.trainerName;
  result.frontierBrain=battle.frontierBrain;
 }
 return result;
}
function recordResult(profile,battle,won){
 const f=state(profile),r=f.active;
 if(!r||!battle||battle.type!=='frontier'||r.id!==battle.frontierRunId)return;
 // Every result must belong to one authoritative, pending encounter. No
 // duplicated response or fabricated result may grant streaks/medals.
 if(!r.pendingEncounter||!battle.frontierResultId||r.pendingEncounter!==battle.frontierResultId)return;
 if(battle.frontierChallengeNumber!==r.streak+1)return;
 r.pendingEncounter=null;
 if(won){
  if(battle.frontierFloorEncounter){
   append(r,`Pyramid: combate de exploração vencido no andar ${r.room}. A saída ainda precisa ser alcançada.`);
   return;
  }
  progress(profile,r);
  if(r.facility==='pike')nextPikeDoors(r);
  if(r.facility==='dome'&&r.domeBracket){
   const round=(battle.frontierChallengeNumber-1)%4;
   if(r.domeBracket.rounds[round])r.domeBracket.rounds[round].completed=true;
   const playerMatch=r.domeBracket.matches?.[round]?.find(match=>match.firstId==='player'||match.secondId==='player');
   if(playerMatch){playerMatch.winnerId='player';playerMatch.completed=true;}
   if(r.streak%4===0)r.domeBracket.completed=true;
  }
  append(r,`Vitória ${r.streak} em ${FACILITIES[r.facility].name}.`);
  if(battle.frontierBrain){
   const previous=f.labSymbols[r.facility];
   const tier=battle.frontierBrain.tier;
   if(!previous||tier==='gold')f.labSymbols[r.facility]=tier;
   append(r,`Medalha de exibição ${tier==='gold'?'Ouro':'Prata'}: ${battle.frontierBrain.name}. Não é um Símbolo oficial.`);
  }
  if(r.facility==='factory')r.swaps=r.lastOpponent.slice(0,3);
 }else{
  append(r,`Sequência encerrada após ${r.streak} vitórias.`);
  profile.activeIndex=r.savedActiveIndex;f.active=null;
 }
 // Real Symbols/BP are never granted by simplified LAB battles.
}
/** Advance by one orthogonal tile in the Pyramid. Each floor requires
 * finding the actual exit, rather than receiving a free floor on /next.
 */
function explore(profile,{direction}={}){
 const f=state(profile),r=f.active;
 if(!r||r.facility!=='pyramid'||!r.pyramidFloor)throw Error('Abra primeiro o andar da Pyramid');
 if(profile.battle||r.pendingEncounter)throw Error('Termine o combate atual antes de explorar');
 const step=Adventures.movePyramid(r.pyramidFloor,direction);
 if(step.exit){
  append(r,`Pyramid: saída do andar ${r.room} encontrada!`);
  r.pyramidFloor=null;progress(profile,r);
  return {event:'floor-complete',frontier:info(profile)};
 }
 const members=roster(profile).filter(m=>r.teamIds.includes(m.id));
 if(step.kind==='item'){
  r.battleBag??={potions:0};r.battleBag.potions=Math.min(20,(r.battleBag.potions||0)+1);
  r.pyramidFloor.items++;append(r,'Pyramid: encontrou uma Potion para a Battle Bag.');
 }else if(step.kind==='status'){
  const target=members.find(m=>m.hp>0&&!m.status);
  if(target){target.status='poison';append(r,`Pyramid: ${target.species} sofreu envenenamento.`);}
 }else if(step.kind==='trainer'||step.kind==='wild'){
  const species=Adventures.sampleDistinct(CLASSIC_POOL,1)[0];
  const Battle=require('./battle.cjs');
  const result=Battle.begin(profile,{type:'frontier',frontierId:r.id,frontierOpponent:[[species,r.level]],frontierFacility:'pyramid'});
  const battle=profile.battle;
  battle.frontierFloorEncounter=true;
  r.pendingEncounter=crypto.randomUUID();battle.frontierResultId=r.pendingEncounter;
  battle.frontierChallengeNumber=r.streak+1;
  r.pyramidFloor.encounters++;
  append(r,`Pyramid: encontro ${step.kind==='trainer'?'de treinador':'selvagem'} no andar ${r.room}.`);
  return {event:'battle',battle:result,frontier:info(profile)};
 }
 return {event:step.kind,frontier:info(profile)};
}
function swap(profile,{oldId,newSpecies}={}){const r=state(profile).active;
 if(!r||r.facility!=='factory'||profile.battle||r.pendingEncounter)throw Error('Troca disponível apenas entre batalhas resolvidas do Factory');
 if(!r.swaps.includes(newSpecies))throw Error('Pokémon não disponível para troca');
 const i=r.rentals.findIndex(m=>m.id===oldId&&r.teamIds.includes(m.id));if(i<0)throw Error('Aluguel não selecionado');
 const Battle=require('./battle.cjs');const replacement=Battle.create(newSpecies,r.level);
 if(r.rentals.some((mon,index)=>index!==i&&r.teamIds.includes(mon.id)&&mon.species===replacement.species))throw Error('Espécie já presente no time');
 r.teamIds=r.teamIds.map(id=>id===oldId?replacement.id:id);r.rentals[i]=replacement;r.swaps=[];
 append(r,`Troca Factory: ${replacement.species} entrou nos alugados.`);return info(profile);
}
function useBattleBag(profile,{item='potion',pokemonId}={}){const r=state(profile).active;
 if(!r||r.facility!=='pyramid'||profile.battle||r.pendingEncounter)throw Error('Battle Bag disponível apenas fora de encontros pendentes da Pyramid');
 if(item!=='potion'||!r.battleBag||r.battleBag.potions<=0)throw Error('Item indisponível na Battle Bag');
 const mon=profile.team?.find(m=>m.id===pokemonId&&r.teamIds.includes(m.id));
 if(!mon||mon.hp<=0||mon.hp>=mon.maxHp)throw Error('Escolha um Pokémon ferido e disponível');
 const recovered=Math.min(20,mon.maxHp-mon.hp);mon.hp+=recovered;r.battleBag.potions--;
 append(r,`Battle Bag: Potion recuperou ${recovered} HP de ${mon.species}.`);return info(profile);
}
function retire(profile){if(profile.battle)throw Error('Finalize a batalha antes de abandonar a sequência');const f=state(profile);
 if(f.active)profile.activeIndex=f.active.savedActiveIndex;f.active=null;return info(profile);}
module.exports={FACILITIES,CLASSIC_POOL,ROOM_EVENTS,state,info,roster,selectTeam,selectLineup,makeRentals,start,next,explore,recordResult,swap,useBattleBag,retire};
