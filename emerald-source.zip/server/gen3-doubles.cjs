'use strict';
/** Gen III Double/Multi targeting and support primitives.
 * This is a tested adapter, not an online Double Battle matchmaking mode.
 */
const Turn=require('./gen3-turn.cjs');
const SLOTS=Object.freeze(['A1','A2','B1','B2']);
const TARGET_CLASSES=Object.freeze({
 Surf:'both-opponents',RockSlide:'both-opponents',IcyWind:'both-opponents',
 Earthquake:'all-other',Magnitude:'all-other',Explosion:'all-other',Selfdestruct:'all-other',
 HelpingHand:'partner',FollowMe:'self',Protect:'self',Detect:'self',
 Recover:'self',SwordsDance:'self',CalmMind:'self',Wish:'self',Howl:'self',
 RainDance:'field',SunnyDay:'field',Sandstorm:'field',Hail:'field'
});
const VALID_CLASSES=new Set(['single-opponent','both-opponents','all-other','partner','self','field']);
function side(slot){if(!SLOTS.includes(slot))throw Error('Slot inválido');return slot[0];}
function partner(slot){return slot[0]+(slot[1]==='1'?'2':'1');}
function active(board,slot){return !!board[slot]&&Number(board[slot].hp)>0;}
function normalizeBoard(board){if(!board||typeof board!=='object')throw Error('Campo inválido');
 for(const slot of SLOTS)if(board[slot]&&(!Number.isFinite(board[slot].hp)||board[slot].hp<0))throw Error('HP inválido');
 return board;
}
function targetClass(move){return TARGET_CLASSES[move]||'single-opponent';}
function resolveTargets(board,source,move,selected=null,{followMe=null}={}){
 normalizeBoard(board);if(!active(board,source))throw Error('Atacante não está ativo');
 const kind=targetClass(move);if(!VALID_CLASSES.has(kind))throw Error('Classe de alvo inválida');
 if(kind==='field')return [];
 if(kind==='self')return [source];
 const ally=partner(source),foes=SLOTS.filter(slot=>side(slot)!==side(source)&&active(board,slot));
 if(kind==='partner')return active(board,ally)?[ally]:[];
 if(kind==='both-opponents')return foes;
 if(kind==='all-other')return SLOTS.filter(slot=>slot!==source&&active(board,slot));
 if(!foes.length)return [];
 if(followMe&&foes.includes(followMe))return [followMe];
 if(selected&&foes.includes(selected))return [selected];
 // A departed or fainted selected target cannot receive damage; the attack
 // may retarget an available foe rather than targeting a stale Pokemon ID.
 return [foes[0]];
}
function spreadMultiplier(move,targets){return Turn.gen3SpreadMultiplier(targetClass(move),targets.filter(s=>!!s).length);}
function helpingHand(board,source,acted=new Set()){
 const ally=partner(source);if(!active(board,source)||!active(board,ally)||acted.has(ally))return {ok:false,reason:'Sem parceiro elegível'};
 return {ok:true,target:ally,multiplier:1.5,priority:5};
}
function validSwitch(board,source,replacement,owner){
 normalizeBoard(board);if(!SLOTS.includes(source))throw Error('Slot inválido');
 if(!replacement||replacement.hp<=0)return false;
 if(board[source]?.trainerId!==owner||replacement.trainerId!==owner)return false;
 return !SLOTS.some(slot=>slot!==source&&board[slot]?.id===replacement.id&&active(board,slot));
}
function replaceFainted(board,source,replacement,owner){
 if(active(board,source))throw Error('O Pokémon ainda não desmaiou');
 if(!validSwitch(board,source,replacement,owner))throw Error('Substituição inválida');
 board[source]=replacement;return board;
}
module.exports={SLOTS,TARGET_CLASSES,side,partner,active,targetClass,resolveTargets,spreadMultiplier,helpingHand,validSwitch,replaceFainted};
