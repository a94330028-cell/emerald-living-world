'use strict';
/** Emerald Gen III: initial turn-order primitives. Not a complete battle engine. */
const MOVE_PRIORITY=Object.freeze({HelpingHand:5,MagicCoat:4,Snatch:4,Protect:3,Detect:3,Endure:3,FollowMe:3,ExtremeSpeed:1,FakeOut:1,MachPunch:1,QuickAttack:1,VitalThrow:-1,FocusPunch:-3,Revenge:-4,Counter:-5,MirrorCoat:-5,Roar:-6,Whirlwind:-6});
const PHYSICAL_TYPES=new Set(['Normal','Fighting','Flying','Poison','Ground','Rock','Bug','Ghost','Steel']);
function priority(move){return MOVE_PRIORITY[move]??0;}
function isPhysical(type){return PHYSICAL_TYPES.has(type);}
function speedWithParalysis(speed,paralyzed){if(!Number.isFinite(speed)||speed<0)throw Error('Invalid speed');return paralyzed?Math.floor(speed/4):Math.floor(speed);}
/** Caller supplies RNG as float in [0,1). This is a generic priority/speed comparator,
 * NOT the full Emerald switching/Quick Claw/Pursuit action scheduler. */
function moveGoesFirst(a,b,rng=Math.random){const pa=priority(a.move),pb=priority(b.move);if(pa!==pb)return pa>pb;
 const sa=speedWithParalysis(a.speed,!!a.paralyzed),sb=speedWithParalysis(b.speed,!!b.paralyzed);
 if(sa!==sb)return sa>sb;const roll=rng();if(!(roll>=0&&roll<1))throw Error('Invalid RNG');return roll<.5;}
function fixedDamage(move,level,currentTargetHp){if(!Number.isInteger(level)||level<1||level>100)throw Error('Invalid level');
 if(move==='SeismicToss'||move==='NightShade')return level;
 if(move==='DragonRage')return 40;
 if(move==='SonicBoom')return 20;
 if(move==='SuperFang')return Math.max(1,Math.floor(currentTargetHp/2));
 return null;}
function gen3SpreadMultiplier(targetClass,eligibleOpponentCount){return targetClass==='both-opponents'&&eligibleOpponentCount>=2?.5:1;}
module.exports={MOVE_PRIORITY,PHYSICAL_TYPES,priority,isPhysical,speedWithParalysis,moveGoesFirst,fixedDamage,gen3SpreadMultiplier};
