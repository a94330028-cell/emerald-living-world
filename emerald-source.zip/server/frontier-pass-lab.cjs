'use strict';
/** Read-only experimental Frontier Pass. There are no official Emerald Symbols,
 * BP or international rankings in this adapter. Scores summarize only LAB
 * performances and never grant in-game rewards.
 *
 * The 0-1000 scale is the Emerald Living World design from Studies 01.36-01.48,
 * not a scoring formula supplied by Game Freak.
 */
const GOLD_TARGET=Object.freeze({tower:70,dome:40,palace:42,arena:56,factory:42,pike:140,pyramid:70});
const IDS=Object.keys(GOLD_TARGET);
function recordFor(facility,records){
 const a=['level50','open'].map(level=>records[`${facility}:${level}:single`]??0);
 return Math.max(0,...a.map(v=>Number.isFinite(v)?Math.max(0,Math.floor(v)):0));
}
function calculate(frontier={}){
 const records=frontier.labRecords||{},symbols=frontier.labSymbols||{};
 const facilities=IDS.map(id=>{
  const symbol=['silver','gold'].includes(symbols[id])?symbols[id]:null;
  const best=recordFor(id,records);
  const target=GOLD_TARGET[id];
  const symbolPoints=symbol==='gold'?85:symbol==='silver'?30:0;
  const performanceFraction=Math.min(1,best/target);
  return {id,symbol,best,goal:target,metric:id==='dome'?'partidas':'desafios',symbolPoints,performanceFraction};
 });
 const goldCount=facilities.filter(f=>f.symbol==='gold').length;
 const symbolScore=facilities.reduce((n,f)=>n+f.symbolPoints,0)+(goldCount===7?5:0);
 const performanceScore=400/7*facilities.reduce((n,f)=>n+f.performanceFraction,0);
 return {kind:'experimental-lab',official:false,
  value:Math.min(1000,Math.round((symbolScore+performanceScore)*100)/100),
  symbolScore,performanceScore:Math.round(performanceScore*100)/100,goldCount,
  facilities};
}
module.exports={GOLD_TARGET,IDS,recordFor,calculate};
