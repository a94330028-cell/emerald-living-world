'use strict';
/** Independently testable exploration and tournament state for Frontier challenges.
 * No access to the national encounter tables, captures, player PC, or Arena.
 * These are original browser adaptations, not ROM-derived map geometry.
 */
const crypto=require('node:crypto');
const random=n=>crypto.randomInt(n);
const PIKE_EVENTS=['battle','battle','quiet','heal','status','quiet','heal','battle','quiet','status','battle','heal'];
const PIKE_HINTS=Object.freeze({battle:'A funcionária percebeu presença de treinadores nesta passagem.',quiet:'Há vozes tranquilas vindo desta passagem.',heal:'Um aroma agradável e acolhedor vem desta passagem.',status:'Um arrepio estranho vem desta passagem.'});
function makePikeDoors(){
 const shuffled=[...PIKE_EVENTS];for(let i=shuffled.length-1;i>0;i--){const j=random(i+1);[shuffled[i],shuffled[j]]=[shuffled[j],shuffled[i]];}
 const doors=shuffled.slice(0,3).map((event,index)=>({index,event}));
 const hintedDoor=random(3);
 return {doors,hint:{door:hintedDoor,text:PIKE_HINTS[doors[hintedDoor].event]}};
}
const TRAINER_NAMES=['Ariel','Breno','Cora','Dante','Elisa','Fábio','Gabi','Heitor','Iris','Jonas','Kira','Lucas','Maya','Nina','Otto','Pietra','Ravi','Sara','Teo','Yara'];
function sampleDistinct(pool,count){const values=[...pool];for(let i=values.length-1;i>0;i--){const j=random(i+1);[values[i],values[j]]=[values[j],values[i]];}return values.slice(0,count);}
function createDomeTournament(number,level,pool,brainFinal=null){
 if(!Number.isInteger(number)||number<1||!Array.isArray(pool)||pool.length<3)throw Error('Torneio inválido');
 const entrants=[{id:'player',name:'Você',team:[]}];
 for(let i=1;i<16;i++)entrants.push({id:`opponent-${i}`,name:`Treinador ${TRAINER_NAMES[(i+number)%TRAINER_NAMES.length]}`,team:sampleDistinct(pool,3)});
 // Tucker must occupy a genuine slot of the 16-person bracket, not a
 // seventeenth participant inserted directly into the finals.
 if(brainFinal)entrants[15]={id:'frontier-brain',name:typeof brainFinal==='string'?brainFinal:brainFinal.name,team:Array.isArray(brainFinal.team)?brainFinal.team.slice(0,3):[]};
 const byId=new Map(entrants.map(entry=>[entry.id,entry]));
 let participants=entrants.map(entry=>entry.id);
 const matches=[];
 for(let round=1;round<=4;round++){
  const fixtures=[],winners=[];
  for(let i=0;i<participants.length;i+=2){
   const firstId=participants[i],secondId=participants[i+1];
   const playerMatch=firstId==='player'||secondId==='player';
   const predictedWinnerId=playerMatch?'player':firstId==='frontier-brain'||secondId==='frontier-brain'?'frontier-brain':(random(2)?firstId:secondId);
   const row={round,match:i/2+1,firstId,secondId,
    winnerId:playerMatch?null:predictedWinnerId,projectedWinnerId:predictedWinnerId,
    completed:!playerMatch};
   fixtures.push(row);winners.push(predictedWinnerId);
  }
  matches.push(fixtures);participants=winners;
 }
 // The player's four opponents follow from the bracket simulation. All
 // NPC wins are tracked explicitly, while the player's win is NOT recorded
 // until the authoritative battle result is accepted by frontier.recordResult.
 const rounds=matches.map((fixtures,index)=>{
  const match=fixtures.find(row=>row.firstId==='player'||row.secondId==='player');
  const id=match.firstId==='player'?match.secondId:match.firstId;
  const opponent=byId.get(id);
  return {round:index+1,opponentId:id,opponent:opponent.name,registered:[...opponent.team],completed:false};
 });
 return {number,entrants,rounds,matches,completed:false,format:'16-single-elimination'};
}
/** A 5x5 connected floor: a guaranteed winding route, with additional open
 * cells and optional encounters. No wild catches in the Pyramid.
 */
function createPyramidFloor(floor){
 const size=5, passable=new Set(['0,0']);let x=0,y=0;
 while(x<size-1||y<size-1){if(x===size-1)y++;else if(y===size-1)x++;else if(random(2))x++;else y++;passable.add(`${x},${y}`);}
 for(let cy=0;cy<size;cy++)for(let cx=0;cx<size;cx++)if(random(100)<73)passable.add(`${cx},${cy}`);
 const tiles=[];for(let cy=0;cy<size;cy++)for(let cx=0;cx<size;cx++){
  const key=`${cx},${cy}`;let kind='wall';
  if(passable.has(key))kind='empty';
  if(kind==='empty'&&key!=='0,0'&&key!=='4,4'){
   const roll=random(100);kind=roll<12?'trainer':roll<22?'wild':roll<30?'item':roll<34?'status':'empty';
  }
  if(key==='0,0')kind='start';if(key==='4,4')kind='exit';
  tiles.push({x:cx,y:cy,kind,visited:key==='0,0'});
 }
 return {floor,size,position:{x:0,y:0},tiles,encounters:0,items:0};
}
function exposedPyramidFloor(floor){if(!floor)return null;const {x,y}=floor.position;
 return {floor:floor.floor,size:floor.size,position:{x,y},encounters:floor.encounters,items:floor.items,
  cells:floor.tiles.map(tile=>({x:tile.x,y:tile.y,kind:tile.visited||Math.abs(tile.x-x)+Math.abs(tile.y-y)<=1?tile.kind:'unknown',visited:tile.visited}))};
}
function movePyramid(floor,direction){
 const offsets={north:[0,-1],south:[0,1],west:[-1,0],east:[1,0]};
 if(!Object.prototype.hasOwnProperty.call(offsets,direction))throw Error('Direção inválida');
 const [dx,dy]=offsets[direction],x=floor.position.x+dx,y=floor.position.y+dy;
 const tile=floor.tiles.find(tile=>tile.x===x&&tile.y===y);
 if(!tile||tile.kind==='wall')throw Error('Existe uma parede nesse caminho');
 floor.position={x,y};const first=!tile.visited;tile.visited=true;
 return {kind:first?tile.kind:'empty',x,y,exit:tile.kind==='exit',first};
}
module.exports={PIKE_EVENTS,PIKE_HINTS,makePikeDoors,sampleDistinct,createDomeTournament,createPyramidFloor,exposedPyramidFloor,movePyramid};
