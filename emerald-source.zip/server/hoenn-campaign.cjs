'use strict';
/** Emerald story rosters; battle turn handling is still a Gen III subset.
 * These arenas/rooms are original connected test maps, not cartridge assets.
 * Tate & Liza now use a playable server-side Double subset.
 */
const LATE_GYMS=Object.freeze({
 LavaridgeGym:{id:'flannery',name:'Flannery',badge:4,area:'LavaridgeGym',prize:2900,team:[['Numel',24],['Slugma',24],['Camerupt',26],['Torkoal',29]]},
 Gym:{id:'norman',name:'Norman',badge:5,area:'Gym',prize:3100,team:[['Spinda',27],['Vigoroth',27],['Linoone',29],['Slaking',31]]},
 FortreeGym:{id:'winona',name:'Winona',badge:6,area:'FortreeGym',prize:3300,team:[['Swablu',29],['Tropius',29],['Pelipper',30],['Skarmory',31],['Altaria',33]]},
 MossdeepGym:{id:'tate_liza',name:'Tate & Liza',badge:7,area:'MossdeepGym',prize:4200,format:'double',team:[['Claydol',41],['Xatu',41],['Lunatone',42],['Solrock',42]]},
 SootopolisGym:{id:'juan',name:'Juan',badge:8,area:'SootopolisGym',prize:4600,team:[['Luvdisc',41],['Whiscash',41],['Sealeo',43],['Crawdaunt',43],['Kingdra',46]]}
});
const LEAGUE=Object.freeze([
 {id:'sidney',name:'Sidney',area:'LeagueSidney',requiresBadges:8,flag:'league_sidney',team:[['Mightyena',46],['Shiftry',48],['Cacturne',46],['Crawdaunt',48],['Absol',49]]},
 {id:'phoebe',name:'Phoebe',area:'LeaguePhoebe',requiresBadges:8,flag:'league_phoebe',team:[['Dusclops',48],['Banette',49],['Banette',49],['Sableye',50],['Dusclops',51]]},
 {id:'glacia',name:'Glacia',area:'LeagueGlacia',requiresBadges:8,flag:'league_glacia',team:[['Sealeo',50],['Glalie',50],['Sealeo',52],['Glalie',52],['Walrein',53]]},
 {id:'drake',name:'Drake',area:'LeagueDrake',requiresBadges:8,flag:'league_drake',team:[['Shelgon',52],['Altaria',54],['Flygon',53],['Flygon',53],['Salamence',55]]},
 {id:'wallace',name:'Wallace',area:'LeagueWallace',requiresBadges:8,flag:'league_wallace',team:[['Wailord',57],['Tentacruel',55],['Ludicolo',56],['Whiscash',56],['Gyarados',56],['Milotic',58]]}
]);
function leagueAt(profile){const current=LEAGUE.findIndex(x=>!profile.story?.[x.flag]);if(current<0||Number(profile.badges||0)<8)return null;const boss=LEAGUE[current];return profile.area===boss.area&&Math.abs(profile.x-14)+Math.abs(profile.y-9)<=2?boss:null;}
module.exports={LATE_GYMS,LEAGUE,leagueAt};
