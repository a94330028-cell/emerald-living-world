'use strict';
/** Emerald Palace nature-driven move categories. Percentages sourced from
 * pret/pokeemerald/src/battle_script_commands.c (PALACE_STYLE table).
 * This module does not reproduce the ROM's complete move-target scripts/AI.
 */
const NATURE_WEIGHTS=Object.freeze({
 Hardy:[61,7,61,7],Lonely:[20,25,84,8],Brave:[70,15,32,60],Adamant:[38,31,70,15],Naughty:[20,70,70,22],
 Bold:[30,20,32,58],Docile:[56,22,56,22],Relaxed:[25,15,75,15],Impish:[69,6,28,55],Lax:[35,10,29,6],
 Timid:[62,10,30,20],Hasty:[58,37,88,6],Serious:[34,11,29,11],Jolly:[35,5,35,60],Naive:[56,22,56,22],
 Modest:[35,45,34,60],Mild:[44,50,34,6],Quiet:[56,22,56,22],Bashful:[30,58,30,58],Rash:[30,13,27,6],
 Calm:[40,50,25,62],Gentle:[18,70,90,5],Sassy:[88,6,22,20],Careful:[42,50,42,5],Quirky:[56,22,56,22]
});
const SELF_MOVES=new Set(['Protect','Detect','Endure','Recover','SwordsDance','CalmMind','Wish','Howl','FollowMe']);
function classify(move,data){if(data?.power>0)return 'attack';if(SELF_MOVES.has(move))return 'defense';return 'support';}
function roll(rng){const x=rng();if(!(x>=0&&x<1))throw Error('RNG inválido');return x;}
function weights(nature,lowHp){const [atk,def,atkLow,defLow]=NATURE_WEIGHTS[nature]||NATURE_WEIGHTS.Hardy;return lowHp?[atkLow,defLow,100-atkLow-defLow]:[atk,def,100-atk-def];}
function choose(mon,eligible,moves,rng=Math.random){
 if(!Array.isArray(eligible)||eligible.length===0)return {move:'Struggle',category:'attack',incapable:false};
 if(eligible.length===1&&eligible[0]==='Struggle')return {move:'Struggle',category:'attack',incapable:false};
 const lowHp=mon.hp*2<mon.maxHp;const w=weights(mon.nature,lowHp);const pick=roll(rng)*100;
 const category=pick<w[0]?'attack':pick<w[0]+w[1]?'defense':'support';
 let pool=eligible.filter(m=>classify(m,moves[m])===category);
 if(!pool.length){if(roll(rng)<.5)return {move:null,category,incapable:true};pool=eligible;}
 return {move:pool[Math.floor(roll(rng)*pool.length)],category,incapable:false};
}
module.exports={NATURE_WEIGHTS,SELF_MOVES,classify,weights,choose};
