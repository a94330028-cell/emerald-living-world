'use strict';
/** Independent demo-area data. NOT Emerald cartridge maps. */
const W=28,H=20;
const rect=(x,y,w,h)=>({x,y,w,h});
const MAPS={
 Littleroot:{title:'Littleroot · praça de teste',seed:1,walls:[rect(3,3,6,5),rect(19,3,6,5),rect(4,12,7,5),rect(17,11,6,5)],portals:[{x:14,y:0,to:'Route101',tx:14,ty:18},{x:12,y:13,to:'Lab',tx:14,ty:17},{x:21,y:8,to:'House',tx:14,ty:17}]},
 Route101:{title:'Rota 101 · campo de teste',seed:2,walls:[rect(3,3,4,5),rect(20,9,5,5),rect(9,11,3,4)],portals:[{x:14,y:19,to:'Littleroot',tx:14,ty:1},{x:14,y:0,to:'Oldale',tx:14,ty:18}]},
 Oldale:{title:'Oldale · praça de teste',seed:3,walls:[rect(3,3,5,5),rect(19,3,6,6),rect(5,13,5,3),rect(20,13,4,4)],portals:[{x:14,y:19,to:'Route101',tx:14,ty:1},{x:0,y:10,to:'Route102',tx:26,ty:10},{x:27,y:10,to:'Route103',tx:1,ty:10},{x:20,y:9,to:'Center',tx:14,ty:17}]},
 Route103:{title:'Rota 103 · campo de teste',seed:28,walls:[rect(4,4,6,5),rect(18,3,6,5),rect(7,13,4,4)],portals:[{x:0,y:10,to:'Oldale',tx:26,ty:10}]},
 Route102:{title:'Rota 102 · campo de teste',seed:4,walls:[rect(6,2,6,3),rect(15,5,4,5),rect(6,14,7,3)],portals:[{x:27,y:10,to:'Oldale',tx:1,ty:10},{x:0,y:10,to:'Petalburg',tx:26,ty:10}]},
 Petalburg:{title:'Petalburg · praça de teste',seed:5,walls:[rect(3,3,5,5),rect(18,3,6,6),rect(2,12,6,5),rect(18,13,5,3)],portals:[{x:27,y:10,to:'Route102',tx:1,ty:10},{x:13,y:12,to:'Gym',tx:14,ty:17},{x:20,y:9,to:'Center',tx:14,ty:17},{x:14,y:0,to:'Route104',tx:14,ty:18}]},
 Lab:{title:'Laboratório · sala de teste',seed:6,walls:[rect(5,3,5,4),rect(17,3,5,4),rect(4,10,3,4)],portals:[{x:14,y:19,to:'Littleroot',tx:12,ty:14}]},
 House:{title:'Casa · interior de teste',seed:7,walls:[rect(4,3,5,4),rect(17,3,5,4)],portals:[{x:14,y:19,to:'Littleroot',tx:21,ty:9}]},
 Center:{title:'Centro Pokémon · interior de teste',seed:8,walls:[rect(4,3,6,4),rect(18,3,5,4)],portals:[{x:14,y:19,to:'Oldale',tx:20,ty:10}]},
 Gym:{title:'Ginásio · sala de teste',seed:9,walls:[rect(4,4,4,3),rect(20,4,4,3),rect(7,12,4,3),rect(17,12,4,3)],portals:[{x:14,y:19,to:'Petalburg',tx:13,ty:13}]},
 // The following are ORIGINAL test-fixture layouts, not ripped Emerald maps.
 // They make the first badge a physically traversable integration slice.
 Route104:{title:'Rota 104 sul · mapa de teste',seed:10,walls:[rect(3,4,5,4),rect(19,8,4,5)],portals:[{x:14,y:19,to:'Petalburg',tx:14,ty:1},{x:14,y:0,to:'Woods',tx:14,ty:18},{x:24,y:10,to:'BrineyHouse',tx:14,ty:17}]},
 Woods:{title:'Petalburg Woods · mapa de teste',seed:11,walls:[rect(1,3,6,7),rect(21,8,6,7),rect(9,9,3,4)],portals:[{x:14,y:19,to:'Route104',tx:14,ty:1},{x:14,y:0,to:'Route104North',tx:14,ty:18}]},
 Route104North:{title:'Rota 104 norte · mapa de teste',seed:12,walls:[rect(2,4,6,6),rect(19,4,6,6)],portals:[{x:14,y:19,to:'Woods',tx:14,ty:1},{x:14,y:0,to:'Rustboro',tx:14,ty:18}]},
 Rustboro:{title:'Rustboro · mapa de teste',seed:13,walls:[rect(2,3,7,5),rect(19,3,7,5),rect(2,13,6,4),rect(19,13,5,4)],portals:[{x:14,y:19,to:'Route104North',tx:14,ty:1},{x:14,y:8,to:'RustboroGym',tx:14,ty:17},{x:18,y:10,to:'Center',tx:14,ty:17},{x:10,y:10,to:'Mart',tx:14,ty:17},{x:27,y:10,to:'Route116',tx:1,ty:10}]},
 RustboroGym:{title:'Ginásio Roxanne · mapa de teste',seed:14,walls:[rect(4,5,5,4),rect(19,5,5,4)],portals:[{x:14,y:19,to:'Rustboro',tx:14,ty:9}]},
 // Chapter 2/3: interconnected original layouts, NOT cartridge map assets.
 Route116:{title:'Route 116 · área adaptada',seed:15,walls:[rect(3,3,4,5),rect(19,12,5,4)],portals:[{x:0,y:10,to:'Rustboro',tx:26,ty:10},{x:27,y:10,to:'RusturfTunnel',tx:1,ty:10}]},
 RusturfTunnel:{title:'Rusturf Tunnel · caverna adaptada',seed:16,walls:[rect(5,2,6,5),rect(18,13,6,4)],portals:[{x:0,y:10,to:'Route116',tx:26,ty:10}]},
 BrineyHouse:{title:'Casa de Mr. Briney · interior adaptado',seed:17,walls:[rect(4,3,5,4),rect(18,3,5,4)],portals:[{x:14,y:19,to:'Route104',tx:24,ty:11},{x:14,y:3,to:'Dewford',tx:14,ty:18,requiresStory:'peeko'},{x:11,y:4,to:'Slateport',tx:14,ty:18,requiresBadges:2,requiresStory:'steven'}]},
 Dewford:{title:'Dewford Town · área adaptada',seed:18,walls:[rect(2,3,7,5),rect(20,3,6,6),rect(2,13,5,5),rect(20,13,6,4)],portals:[{x:14,y:19,to:'BrineyHouse',tx:14,ty:6},{x:14,y:7,to:'DewfordGym',tx:14,ty:17},{x:0,y:10,to:'GraniteCave',tx:26,ty:10},{x:27,y:10,to:'Route106',tx:1,ty:10},{x:19,y:10,to:'Center',tx:14,ty:17},{x:11,y:10,to:'Mart',tx:14,ty:17}]},
 DewfordGym:{title:'Ginásio Brawly · interior adaptado',seed:19,walls:[rect(4,4,6,5),rect(19,5,5,5)],portals:[{x:14,y:19,to:'Dewford',tx:14,ty:8}]},
 GraniteCave:{title:'Granite Cave · área adaptada',seed:20,walls:[rect(4,3,7,7),rect(18,10,6,6)],portals:[{x:27,y:10,to:'Dewford',tx:1,ty:10},{x:14,y:3,to:'StevenChamber',tx:14,ty:17}]},
 StevenChamber:{title:'Câmara de Steven · interior adaptado',seed:21,walls:[rect(3,3,7,5),rect(20,3,5,5)],portals:[{x:14,y:19,to:'GraniteCave',tx:14,ty:4}]},
 Route106:{title:'Route 106 · costa adaptada',seed:22,walls:[rect(6,4,6,5),rect(19,12,5,4)],portals:[{x:0,y:10,to:'Dewford',tx:26,ty:10}]},
 Slateport:{title:'Slateport City · área adaptada',seed:23,walls:[rect(3,4,6,5),rect(19,4,6,5),rect(3,13,7,4)],portals:[{x:14,y:19,to:'BrineyHouse',tx:11,ty:5},{x:14,y:0,to:'Route110',tx:14,ty:18},{x:19,y:10,to:'Center',tx:14,ty:17}]},
 Route110:{title:'Route 110 · área adaptada',seed:24,walls:[rect(2,4,6,6),rect(19,10,6,6)],portals:[{x:14,y:19,to:'Slateport',tx:14,ty:1},{x:14,y:0,to:'Mauville',tx:14,ty:18}]},
 Mauville:{title:'Mauville City · área adaptada',seed:25,walls:[rect(3,3,6,5),rect(19,3,5,6),rect(3,13,6,4),rect(19,13,5,4)],portals:[{x:14,y:19,to:'Route110',tx:14,ty:1},{x:14,y:8,to:'MauvilleGym',tx:14,ty:17,requiresStory:'wally'},{x:18,y:10,to:'Center',tx:14,ty:17},{x:10,y:10,to:'Mart',tx:14,ty:17},{x:27,y:10,to:'Route111',tx:1,ty:10,requiresBadges:3}]},
 MauvilleGym:{title:'Ginásio Wattson · interior adaptado',seed:26,walls:[rect(4,4,5,4),rect(19,4,5,4),rect(7,13,4,3),rect(17,13,4,3)],portals:[{x:14,y:19,to:'Mauville',tx:14,ty:9}]},

 // V3.0 extended Hoenn route fixtures: original navigable demo layouts, never ROM maps.
 Route111:{title:'Route 111 · deserto adaptado',seed:31,walls:[rect(3,4,5,5),rect(20,12,4,4)],portals:[{x:0,y:10,to:'Mauville',tx:26,ty:10},{x:14,y:0,to:'FieryPath',tx:14,ty:18},{x:27,y:10,to:'Route118',tx:1,ty:10}]},
 FieryPath:{title:'Fiery Path · caverna adaptada',seed:32,walls:[rect(4,4,5,5),rect(19,11,5,4)],portals:[{x:14,y:19,to:'Route111',tx:14,ty:1},{x:14,y:0,to:'Route112',tx:14,ty:18}]},
 Route112:{title:'Route 112 · montanha adaptada',seed:33,walls:[rect(3,3,6,5),rect(19,13,5,4)],portals:[{x:14,y:19,to:'FieryPath',tx:14,ty:1},{x:14,y:0,to:'Lavaridge',tx:14,ty:18}]},
 Lavaridge:{title:'Lavaridge Town · área adaptada',seed:34,walls:[rect(3,3,6,5),rect(20,3,4,6)],portals:[{x:14,y:19,to:'Route112',tx:14,ty:1},{x:14,y:8,to:'LavaridgeGym',tx:14,ty:17},{x:18,y:10,to:'Center',tx:14,ty:17},{x:10,y:10,to:'Mart',tx:14,ty:17}]},
 LavaridgeGym:{title:'Ginásio de Flannery · interior adaptado',seed:35,walls:[rect(4,5,5,4),rect(20,10,4,4)],portals:[{x:14,y:19,to:'Lavaridge',tx:14,ty:9}]},
 Route118:{title:'Route 118 · área adaptada',seed:36,walls:[rect(3,3,6,5),rect(20,12,5,4)],portals:[{x:0,y:10,to:'Route111',tx:26,ty:10},{x:14,y:0,to:'Route119',tx:14,ty:18}]},
 Route119:{title:'Route 119 · área adaptada',seed:37,walls:[rect(4,3,5,5),rect(19,12,5,5)],portals:[{x:14,y:19,to:'Route118',tx:14,ty:1},{x:14,y:0,to:'Fortree',tx:14,ty:18}]},
 Fortree:{title:'Fortree City · área adaptada',seed:38,walls:[rect(3,3,6,5),rect(19,3,6,5)],portals:[{x:14,y:19,to:'Route119',tx:14,ty:1},{x:14,y:8,to:'FortreeGym',tx:14,ty:17},{x:27,y:10,to:'Route120',tx:1,ty:10},{x:18,y:10,to:'Center',tx:14,ty:17}]},
 FortreeGym:{title:'Ginásio de Winona · interior adaptado',seed:39,walls:[rect(4,5,5,4),rect(20,12,4,4)],portals:[{x:14,y:19,to:'Fortree',tx:14,ty:9}]},
 Route120:{title:'Route 120 · área adaptada',seed:40,walls:[rect(3,4,5,5),rect(20,11,5,5)],portals:[{x:0,y:10,to:'Fortree',tx:26,ty:10},{x:27,y:10,to:'Lilycove',tx:1,ty:10}]},
 Lilycove:{title:'Lilycove City · área adaptada',seed:41,walls:[rect(4,4,5,4),rect(20,4,5,4)],portals:[{x:0,y:10,to:'Route120',tx:26,ty:10},{x:27,y:10,to:'Route124',tx:1,ty:10},{x:18,y:10,to:'Center',tx:14,ty:17}]},
 Route124:{title:'Route 124 · travessia adaptada',seed:42,walls:[rect(4,4,5,5),rect(19,12,5,4)],portals:[{x:0,y:10,to:'Lilycove',tx:26,ty:10},{x:27,y:10,to:'Mossdeep',tx:1,ty:10}]},
 Mossdeep:{title:'Mossdeep City · área adaptada',seed:43,walls:[rect(3,3,6,5),rect(19,3,6,5)],portals:[{x:0,y:10,to:'Route124',tx:26,ty:10},{x:14,y:8,to:'MossdeepGym',tx:14,ty:17},{x:27,y:10,to:'Route127',tx:1,ty:10},{x:18,y:10,to:'Center',tx:14,ty:17}]},
 MossdeepGym:{title:'Ginásio Tate e Liza · interior adaptado (batalha Single de teste)',seed:44,walls:[rect(4,5,5,4),rect(20,12,4,4)],portals:[{x:14,y:19,to:'Mossdeep',tx:14,ty:9}]},
 Route127:{title:'Route 127 · travessia adaptada',seed:45,walls:[rect(3,4,6,5),rect(20,12,4,4)],portals:[{x:0,y:10,to:'Mossdeep',tx:26,ty:10},{x:27,y:10,to:'Route126',tx:1,ty:10}]},
 Route126:{title:'Route 126 · travessia adaptada',seed:46,walls:[rect(3,4,6,5),rect(20,12,4,4)],portals:[{x:0,y:10,to:'Route127',tx:26,ty:10},{x:27,y:10,to:'Sootopolis',tx:1,ty:10}]},
 Sootopolis:{title:'Sootopolis City · área adaptada',seed:47,walls:[rect(3,3,6,5),rect(19,3,6,5)],portals:[{x:0,y:10,to:'Route126',tx:26,ty:10},{x:14,y:8,to:'SootopolisGym',tx:14,ty:17},{x:27,y:10,to:'Route128',tx:1,ty:10},{x:18,y:10,to:'Center',tx:14,ty:17}]},
 SootopolisGym:{title:'Ginásio de Juan · interior adaptado',seed:48,walls:[rect(4,5,5,4),rect(20,12,4,4)],portals:[{x:14,y:19,to:'Sootopolis',tx:14,ty:9}]},
 Route128:{title:'Route 128 · travessia adaptada',seed:49,walls:[rect(4,4,5,4),rect(19,12,5,4)],portals:[{x:0,y:10,to:'Sootopolis',tx:26,ty:10},{x:27,y:10,to:'EverGrande',tx:1,ty:10,requiresBadges:8}]},
 EverGrande:{title:'Ever Grande City · área adaptada',seed:50,walls:[rect(4,4,5,4),rect(19,12,5,4)],portals:[{x:0,y:10,to:'Route128',tx:26,ty:10},{x:14,y:0,to:'VictoryRoad',tx:14,ty:18},{x:18,y:10,to:'Center',tx:14,ty:17}]},
 VictoryRoad:{title:'Victory Road · caverna adaptada',seed:51,walls:[rect(3,3,6,5),rect(19,12,5,4)],portals:[{x:14,y:19,to:'EverGrande',tx:14,ty:1},{x:14,y:0,to:'LeagueLobby',tx:14,ty:18,requiresBadges:8}]},
 LeagueLobby:{title:'Liga Pokémon · entrada',seed:52,walls:[rect(4,3,5,4),rect(20,3,4,4)],portals:[{x:14,y:19,to:'VictoryRoad',tx:14,ty:1},{x:14,y:3,to:'LeagueSidney',tx:14,ty:17,requiresBadges:8}]},
 LeagueSidney:{title:'Liga Pokémon · Sidney',seed:53,walls:[rect(4,4,5,4),rect(20,13,4,4)],portals:[{x:14,y:19,to:'LeagueLobby',tx:14,ty:12},{x:14,y:2,to:'LeaguePhoebe',tx:14,ty:17,requiresStory:'league_sidney'}]},
 LeaguePhoebe:{title:'Liga Pokémon · Phoebe',seed:54,walls:[rect(4,4,5,4),rect(20,13,4,4)],portals:[{x:14,y:19,to:'LeagueSidney',tx:14,ty:12},{x:14,y:2,to:'LeagueGlacia',tx:14,ty:17,requiresStory:'league_phoebe'}]},
 LeagueGlacia:{title:'Liga Pokémon · Glacia',seed:55,walls:[rect(4,4,5,4),rect(20,13,4,4)],portals:[{x:14,y:19,to:'LeaguePhoebe',tx:14,ty:12},{x:14,y:2,to:'LeagueDrake',tx:14,ty:17,requiresStory:'league_glacia'}]},
 LeagueDrake:{title:'Liga Pokémon · Drake',seed:56,walls:[rect(4,4,5,4),rect(20,13,4,4)],portals:[{x:14,y:19,to:'LeagueGlacia',tx:14,ty:12},{x:14,y:2,to:'LeagueWallace',tx:14,ty:17,requiresStory:'league_drake'}]},
 LeagueWallace:{title:'Liga Pokémon · Wallace (Campeão)',seed:57,walls:[rect(4,4,5,4),rect(20,13,4,4)],portals:[{x:14,y:19,to:'LeagueDrake',tx:14,ty:12},{x:14,y:2,to:'HallOfFame',tx:14,ty:17,requiresStory:'league_wallace'}]},
 HallOfFame:{title:'Hall da Fama · sala adaptada',seed:58,walls:[rect(4,4,5,4),rect(20,12,5,4)],portals:[{x:14,y:19,to:'EverGrande',tx:14,ty:1}]},
 Mart:{title:'Poké Mart · balcão de teste',seed:27,walls:[rect(4,4,5,4),rect(19,4,5,4)],portals:[{x:14,y:19,to:'Rustboro',tx:10,ty:11}]}
};
// Optional route trainers for this adapted test world. Teams are fought via
// the exact battle engine used by visitors and bots; the same NPC is not
// automatically defeated or granted a badge by walking past them.
const OPTIONAL_TRAINERS=Object.freeze({
 Route101:[{id:'calvin101',name:'Youngster Calvin',x:12,y:11,avatar:'red',team:[['Poochyena',5]]}],
 Route102:[{id:'tiana102',name:'Lass Tiana',x:12,y:11,avatar:'leaf',team:[['Zigzagoon',4],['Shroomish',4]]}],
 Route103:[{id:'rival103train',name:'Treinador da Rota 103',x:12,y:11,avatar:'brendan',team:[['Wingull',5]]}],
 Route104:[{id:'billy104',name:'Youngster Billy',x:12,y:11,avatar:'ethan',team:[['Zigzagoon',5],['Seedot',7]]}],
 Woods:[{id:'rickwoods',name:'Bug Catcher Rick',x:12,y:11,avatar:'hilbert',team:[['Wurmple',5],['Wurmple',5]]}],
 Route104North:[{id:'cindy104',name:'Lady Cindy',x:12,y:11,avatar:'serena',team:[['Zigzagoon',7]]}],
 Route116:[{id:'hiker116',name:'Hiker Clint',x:12,y:11,avatar:'lucas',team:[['Geodude',11]]}],
 Route106:[{id:'sailor106',name:'Sailor Brenden',x:12,y:11,avatar:'nate',team:[['Machop',13]]}],
 GraniteCave:[{id:'hikergranite',name:'Hiker Marcos',x:12,y:11,avatar:'victor',team:[['Geodude',12],['Zubat',12]]}],
 Route110:[{id:'joseph110',name:'Guitarist Joseph',x:12,y:11,avatar:'calem',team:[['Electrike',14],['Voltorb',14]]}]
});
// Story actors are original fixture markers, NOT verified ROM NPC coordinates.
// They occupy their own tiles so no visitor/bot may walk through them.
const ACTORS={
 RustboroGym:[{x:14,y:8,name:'Roxanne'}],
 DewfordGym:[{x:14,y:8,name:'Brawly'}],
 MauvilleGym:[{x:14,y:8,name:'Wattson'}],
 Gym:[{x:14,y:8,name:'Norman'}],
 LavaridgeGym:[{x:14,y:8,name:'Flannery'}],
 FortreeGym:[{x:14,y:8,name:'Winona'}],
 MossdeepGym:[{x:14,y:8,name:'Tate e Liza'}],
 SootopolisGym:[{x:14,y:8,name:'Juan'}],
 LeagueSidney:[{x:14,y:8,name:'Sidney'}],
 LeaguePhoebe:[{x:14,y:8,name:'Phoebe'}],
 LeagueGlacia:[{x:14,y:8,name:'Glacia'}],
 LeagueDrake:[{x:14,y:8,name:'Drake'}],
 LeagueWallace:[{x:14,y:8,name:'Wallace'}],
 RusturfTunnel:[{x:14,y:9,name:'Recruta Aqua'}],
 Route110:[{x:14,y:11,name:'Rival'}],
 Mauville:[{x:14,y:11,name:'Wally'}],
 StevenChamber:[{x:14,y:8,name:'Steven'}]
};
const inBounds=(map,x,y)=>Number.isInteger(x)&&Number.isInteger(y)&&x>=0&&y>=0&&x<W&&y<H;
const key=(x,y)=>`${x}:${y}`;
for(const [name,m] of Object.entries(MAPS)){
 m.name=name;m.width=W;m.height=H;
 const walls=new Set();for(const a of m.walls)for(let y=a.y;y<a.y+a.h;y++)for(let x=a.x;x<a.x+a.w;x++)walls.add(key(x,y));
 m.npcs=[...(ACTORS[name]||[]).map(n=>({...n})),...(OPTIONAL_TRAINERS[name]||[]).map(n=>({id:n.id,name:n.name,avatar:n.avatar,x:n.x,y:n.y,challenge:true}))];
 m._walls=walls; m._npcWalls=new Set(m.npcs.map(n=>key(n.x,n.y)));
 m.portals=m.portals.map(p=>({...p}));
}
function walkable(area,x,y){const m=MAPS[area];return !!m&&inBounds(m,x,y)&&!m._walls.has(key(x,y))&&!m._npcWalls.has(key(x,y));}
function portalOpen(profile,portal){return (!portal.requiresBadges||Number(profile?.badges||0)>=portal.requiresBadges)&&(!portal.requiresStory||profile?.story?.[portal.requiresStory]===true);}
function step(profile,dir){const m=MAPS[profile.area];if(!m)return false;const d={up:[0,-1],right:[1,0],down:[0,1],left:[-1,0]}[dir];if(!d)return false;
 const x=profile.x+d[0],y=profile.y+d[1];if(!walkable(profile.area,x,y))return false;
 const portal=m.portals.find(p=>p.x===x&&p.y===y);
 if(portal){
  if(!portalOpen(profile,portal))return false;
  // The same Center interior serves multiple cities. Its exit must return to
  // the specific entrance used, not teleport everyone to Oldale.
  if(['Center','Mart'].includes(profile.area)&&profile.returnDoor&&walkable(profile.returnDoor.area,profile.returnDoor.x,profile.returnDoor.y)){
   const target=profile.returnDoor;profile.area=target.area;profile.x=target.x;profile.y=target.y;delete profile.returnDoor;
  }else{
   if(!walkable(portal.to,portal.tx,portal.ty))return false;
   if(['Center','Mart'].includes(portal.to)&&!['Center','Mart'].includes(profile.area)){
    const landingY=walkable(profile.area,x,y+1)?y+1:profile.y;
    profile.returnDoor={area:profile.area,x,y:landingY};
   }
   profile.area=portal.to;profile.x=portal.tx;profile.y=portal.ty;
  }
 }
 else {profile.x=x;profile.y=y;}
 profile.facing=dir;return true;
}
// The only non-door relocation accepted by the world: full team blackout.
// A normal blocked path MUST remain blocked and never call this routine.
function blackoutRespawn(profile){
 if(!Array.isArray(profile?.team)||!profile.team.length||profile.area==='Center'||profile.team.some(m=>Number(m.hp)>0)||profile.battle)return false;
 const queue=[profile.area],seen=new Set(queue);let destination=null;
 for(let i=0;i<queue.length;i++){
  const m=MAPS[queue[i]];if(!m)continue;
  const door=m.portals.find(p=>p.to==='Center'&&portalOpen(profile,p));
  if(door){destination={area:m.name,door};break;}
  for(const edge of m.portals){if(!seen.has(edge.to)&&portalOpen(profile,edge)){seen.add(edge.to);queue.push(edge.to);}}
 }
 const safe=destination||{area:'Oldale',door:MAPS.Oldale.portals.find(p=>p.to==='Center')};
 if(!safe?.door||!walkable('Center',14,17))return false;
 const {area,door}=safe;
 // Leaving the Center uses its real door in this city, NEVER the old wild position.
 const adjacent=[[door.x,door.y+1],[door.x+1,door.y],[door.x-1,door.y],[door.x,door.y-1]]
   .find(([x,y])=>walkable(area,x,y));
 if(!adjacent)return false;
 profile.returnDoor={area,x:adjacent[0],y:adjacent[1]};
 profile.area='Center';profile.x=14;profile.y=17;profile.facing='up';
 profile.blackouts=(profile.blackouts||0)+1;
 return true;
}
function publicMap(area){const m=MAPS[area];return m?{name:m.name,title:m.title,seed:m.seed,width:W,height:H,walls:m.walls,portals:m.portals,npcs:m.npcs}:null;}
function validateWorld(){const issues=[];for(const m of Object.values(MAPS))for(const p of m.portals){if(!walkable(m.name,p.x,p.y))issues.push(`${m.name}: portal blocked`);if(!walkable(p.to,p.tx,p.ty))issues.push(`${m.name}->${p.to}: landing blocked`);}return issues;}
module.exports={MAPS,OPTIONAL_TRAINERS,step,walkable,publicMap,validateWorld,portalOpen,blackoutRespawn};
