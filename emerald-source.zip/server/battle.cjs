'use strict';
/* Server-authoritative, intentionally small Gen-III-style battle subset for the online beta.
 * Pokémon and stats used here are independent of the larger legacy offline engine.
 * Not a complete Gen III implementation; Tate/Liza Double is a tested subset.
 */
const crypto=require('node:crypto');
const Gen3Turn=require('./gen3-turn.cjs');
const Gen3=require('./gen3-mechanics.cjs');
const Gen3Damage=require('./gen3-damage.cjs');
const Gen3Capture=require('./gen3-capture.cjs');
const DoubleRuntime=require('./gen3-double-runtime.cjs');
const Palace=require('./frontier-palace.cjs');
const ArenaJudge=require('./frontier-arena.cjs');
const {LATE_GYMS,LEAGUE,leagueAt}=require('./hoenn-campaign.cjs');
const STATS=['hp','atk','def','spa','spd','spe'];
const PHYSICAL=new Set(['Normal','Fighting','Flying','Poison','Ground','Rock','Bug','Ghost','Steel']);
const MOVES={
 Tackle:{type:'Normal',power:40,accuracy:95},Pound:{type:'Normal',power:40,accuracy:100},Scratch:{type:'Normal',power:40,accuracy:100},
 Peck:{type:'Flying',power:35,accuracy:100},QuickAttack:{type:'Normal',power:40,accuracy:100,priority:1},
 Absorb:{type:'Grass',power:20,accuracy:100,drain:0.5},Ember:{type:'Fire',power:40,accuracy:100},
 WaterGun:{type:'Water',power:40,accuracy:100},MudSlap:{type:'Ground',power:20,accuracy:100},
 Bite:{type:'Dark',power:60,accuracy:100},VineWhip:{type:'Grass',power:35,accuracy:100},
 Leer:{type:'Normal',power:0,accuracy:100,stage:'def'},Growl:{type:'Normal',power:0,accuracy:100,stage:'atk'},
 RockThrow:{type:'Rock',power:50,accuracy:90},MegaDrain:{type:'Grass',power:40,accuracy:100,drain:0.5},
 TailWhip:{type:'Normal',power:0,accuracy:100,stage:'def'},StringShot:{type:'Bug',power:0,accuracy:95,stage:'spe'},Howl:{type:'Normal',power:0,accuracy:100,boost:'atk'},
 KarateChop:{type:'Fighting',power:50,accuracy:100},LowKick:{type:'Fighting',power:50,accuracy:100},DoubleKick:{type:'Fighting',power:30,accuracy:100},
 Confusion:{type:'Psychic',power:50,accuracy:100},ThunderShock:{type:'Electric',power:40,accuracy:100},Spark:{type:'Electric',power:65,accuracy:100},
 MetalClaw:{type:'Steel',power:50,accuracy:95},Gust:{type:'Flying',power:40,accuracy:100},RockTomb:{type:'Rock',power:50,accuracy:80},Headbutt:{type:'Normal',power:70,accuracy:100},WaterPulse:{type:'Water',power:60,accuracy:100}
};
// Classic Gen III moves are available to the server engine without changing any
// existing species, bot capture table, or Quetzal learnset fallback.
Object.assign(MOVES,{
 Protect:{type:'Normal',power:0,accuracy:100,effect:'protect'},
 LeechSeed:{type:'Grass',power:0,accuracy:90,effect:'seed'},
 Toxic:{type:'Poison',power:0,accuracy:85,effect:'toxic'},
 ThunderWave:{type:'Electric',power:0,accuracy:100,effect:'paralysis'},
 WillOWisp:{type:'Fire',power:0,accuracy:75,effect:'burn'},
 SleepPowder:{type:'Grass',power:0,accuracy:75,effect:'sleep'},
 Recover:{type:'Normal',power:0,accuracy:100,effect:'recover'},
 SwordsDance:{type:'Normal',power:0,accuracy:100,effect:'swordsdance'},
 CalmMind:{type:'Psychic',power:0,accuracy:100,effect:'calmmind'},
 Wish:{type:'Normal',power:0,accuracy:100,effect:'wish'},
 RainDance:{type:'Water',power:0,accuracy:100,effect:'rain'},
 SunnyDay:{type:'Fire',power:0,accuracy:100,effect:'sun'},
 Sandstorm:{type:'Rock',power:0,accuracy:100,effect:'sandstorm'},
 Hail:{type:'Ice',power:0,accuracy:100,effect:'hail'},
 SeismicToss:{type:'Fighting',power:1,accuracy:100,effect:'fixed'},
 NightShade:{type:'Ghost',power:1,accuracy:100,effect:'fixed'},
 DragonRage:{type:'Dragon',power:1,accuracy:100,effect:'fixed'},
 SonicBoom:{type:'Normal',power:1,accuracy:90,effect:'fixed'},
 SuperFang:{type:'Normal',power:1,accuracy:90,effect:'fixed'},
 Earthquake:{type:'Ground',power:100,accuracy:100},
 Surf:{type:'Water',power:95,accuracy:100},
 RockSlide:{type:'Rock',power:75,accuracy:90},
 ExtremeSpeed:{type:'Normal',power:80,accuracy:100,priority:1},
 FakeOut:{type:'Normal',power:40,accuracy:100,priority:1},
 Explosion:{type:'Normal',power:250,accuracy:100},Selfdestruct:{type:'Normal',power:200,accuracy:100},
 FurySwipes:{type:'Normal',power:18,accuracy:80},DoubleSlap:{type:'Normal',power:15,accuracy:85},PinMissile:{type:'Bug',power:14,accuracy:85},
 HelpingHand:{type:'Normal',power:0,accuracy:100,effect:'helpinghand'},
 FollowMe:{type:'Normal',power:0,accuracy:100,effect:'followme'},
 Psychic:{type:'Psychic',power:90,accuracy:100},
 Thunderbolt:{type:'Electric',power:95,accuracy:100},
 FireBlast:{type:'Fire',power:120,accuracy:85},
 IceBeam:{type:'Ice',power:95,accuracy:100},
 DragonClaw:{type:'Dragon',power:80,accuracy:100},
 ShadowBall:{type:'Ghost',power:80,accuracy:100},
 BodySlam:{type:'Normal',power:85,accuracy:100},
 Return:{type:'Normal',power:102,accuracy:100}, // simplified: max friendship
 Flamethrower:{type:'Fire',power:95,accuracy:100},
 Crunch:{type:'Dark',power:80,accuracy:100},
 SludgeBomb:{type:'Poison',power:90,accuracy:100},
 AerialAce:{type:'Flying',power:60,accuracy:100,alwaysHit:true},
 HydroPump:{type:'Water',power:120,accuracy:80},
 FirePunch:{type:'Fire',power:75,accuracy:100},
 IcePunch:{type:'Ice',power:75,accuracy:100},
 ThunderPunch:{type:'Electric',power:75,accuracy:100},
 MeteorMash:{type:'Steel',power:100,accuracy:85},
 Megahorn:{type:'Bug',power:120,accuracy:85},
 BrickBreak:{type:'Fighting',power:75,accuracy:100},
 Slash:{type:'Normal',power:70,accuracy:100},
 IronTail:{type:'Steel',power:100,accuracy:75},
 AncientPower:{type:'Rock',power:60,accuracy:100},
 Superpower:{type:'Fighting',power:120,accuracy:100}
});
const SPEC={
 Treecko:{types:['Grass'],base:[40,45,35,65,55,70],exp:65,catch:45,moves:['Pound','Leer','Absorb','QuickAttack'],evolve:[16,'Grovyle']},
 Grovyle:{types:['Grass'],base:[50,65,45,85,65,95],exp:141,catch:45,moves:['Pound','Absorb','QuickAttack','VineWhip'],evolve:[36,'Sceptile']},
 Sceptile:{types:['Grass'],base:[70,85,65,105,85,120],exp:208,catch:45,moves:['QuickAttack','VineWhip','Absorb','Pound']},
 Torchic:{types:['Fire'],base:[45,60,40,70,50,45],exp:65,catch:45,moves:['Scratch','Growl','Ember','Peck'],evolve:[16,'Combusken']},
 Combusken:{types:['Fire','Fighting'],base:[60,85,60,85,60,55],exp:142,catch:45,moves:['Scratch','Growl','Ember','Peck'],evolve:[36,'Blaziken']},
 Blaziken:{types:['Fire','Fighting'],base:[80,120,70,110,70,80],exp:209,catch:45,moves:['Scratch','Ember','Peck','QuickAttack']},
 Mudkip:{types:['Water'],base:[50,70,50,50,50,40],exp:65,catch:45,moves:['Tackle','Growl','WaterGun','MudSlap'],evolve:[16,'Marshtomp']},
 Marshtomp:{types:['Water','Ground'],base:[70,85,70,60,70,50],exp:143,catch:45,moves:['Tackle','MudSlap','WaterGun','Growl'],evolve:[36,'Swampert']},
 Swampert:{types:['Water','Ground'],base:[100,110,90,85,90,60],exp:210,catch:45,moves:['Tackle','MudSlap','WaterGun','Growl']},
 Zigzagoon:{types:['Normal'],base:[38,30,41,30,41,60],exp:60,catch:255,moves:['Tackle','Growl','TailWhip','QuickAttack']},
 Poochyena:{types:['Dark'],base:[35,55,35,30,30,35],exp:55,catch:255,moves:['Tackle','Howl','Bite'],evolve:[18,'Mightyena']},
 Wurmple:{types:['Bug'],base:[45,45,35,20,30,20],exp:54,catch:255,moves:['Tackle','StringShot']},
 Taillow:{types:['Normal','Flying'],base:[40,55,30,30,30,85],exp:59,catch:200,moves:['Peck','QuickAttack','Growl'],evolve:[22,'Swellow']},
 Lotad:{types:['Water','Grass'],base:[40,30,30,40,50,30],exp:74,catch:255,moves:['Absorb','Growl']},
 Wingull:{types:['Water','Flying'],base:[40,30,30,55,30,85],exp:64,catch:190,moves:['WaterGun','Growl','QuickAttack']},
 Shroomish:{types:['Grass'],base:[60,40,60,40,60,35],exp:65,catch:255,moves:['Tackle','Absorb','MegaDrain'],evolve:[23,'Breloom']},
 Breloom:{types:['Grass','Fighting'],base:[60,130,80,60,60,70],exp:165,catch:90,moves:['Tackle','Absorb','MegaDrain']},
 Geodude:{types:['Rock','Ground'],base:[40,80,100,30,30,20],exp:73,catch:255,moves:['Tackle','RockThrow','MudSlap']},
 Nosepass:{types:['Rock'],base:[30,45,135,45,90,30],exp:108,catch:255,moves:['Tackle','RockThrow']},
 Mightyena:{types:['Dark'],base:[70,90,70,60,60,70],exp:128,catch:127,moves:['Tackle','Bite','Howl']},
 Swellow:{types:['Normal','Flying'],base:[60,85,60,50,50,125],exp:162,catch:45,moves:['Peck','QuickAttack','Growl']},
 Machop:{types:['Fighting'],base:[70,80,50,35,35,35],exp:75,catch:180,moves:['KarateChop','LowKick','Leer']},
 Meditite:{types:['Fighting','Psychic'],base:[30,40,55,40,55,60],exp:91,catch:180,moves:['Confusion','KarateChop','Leer']},
 Makuhita:{types:['Fighting'],base:[72,60,30,20,30,25],exp:87,catch:180,moves:['KarateChop','Tackle','Howl']},
 Zubat:{types:['Poison','Flying'],base:[40,45,35,30,40,55],exp:54,catch:255,moves:['Gust','Bite']},
 Abra:{types:['Psychic'],base:[25,20,15,105,55,90],exp:73,catch:200,moves:['Confusion']},
 Slugma:{types:['Fire'],base:[40,40,40,70,40,20],exp:78,catch:190,moves:['Ember','RockThrow']},
 Pelipper:{types:['Water','Flying'],base:[60,50,100,85,70,65],exp:164,catch:45,moves:['WaterGun','Gust','QuickAttack']},
 Lombre:{types:['Water','Grass'],base:[60,50,50,60,70,50],exp:141,catch:120,moves:['Absorb','WaterGun','Growl']},
 Ralts:{types:['Psychic'],base:[28,25,25,45,35,40],exp:70,catch:235,moves:['Confusion','Growl']},
 Voltorb:{types:['Electric'],base:[40,30,50,55,55,100],exp:103,catch:190,moves:['ThunderShock','Tackle']},
 Electrike:{types:['Electric'],base:[40,45,40,65,40,65],exp:104,catch:120,moves:['ThunderShock','QuickAttack','Howl']},
 Magneton:{types:['Electric','Steel'],base:[50,60,95,120,70,70],exp:161,catch:60,moves:['ThunderShock','MetalClaw','Spark']},
 Manectric:{types:['Electric'],base:[70,75,60,105,60,105],exp:168,catch:45,moves:['Spark','ThunderShock','QuickAttack']},
 Magnemite:{types:['Electric','Steel'],base:[25,35,70,95,55,45],exp:89,catch:190,moves:['ThunderShock','MetalClaw'],evolve:[30,'Magneton']}
};
// Quetzal Alpha 9 v1: 1,025 base species, 494 internal variant slots and
// 9 experimental Gen-10 starter slots. Stats/types/EXP/catch are ROM-derived;
// generic move choices are NOT extracted Quetzal learnsets.
const DEX=require('./dex.cjs');
const NationalPools=require('../jogo/game/pokemon/national-pools.js');
Object.assign(MOVES,{
 PoisonSting:{type:'Poison',power:15,accuracy:100},
 BugBite:{type:'Bug',power:60,accuracy:100},
 Lick:{type:'Ghost',power:30,accuracy:100},
 FairyWind:{type:'Fairy',power:40,accuracy:100},
 DragonBreath:{type:'Dragon',power:60,accuracy:100},
 PowderSnow:{type:'Ice',power:40,accuracy:100},
 SandAttack:{type:'Ground',power:0,accuracy:100,stage:'accuracy'},
});
const TYPE_START_MOVES={Normal:'Tackle',Fighting:'KarateChop',Flying:'Peck',Poison:'PoisonSting',
 Ground:'MudSlap',Rock:'RockThrow',Bug:'BugBite',Ghost:'Lick',Steel:'MetalClaw',
 Fire:'Ember',Water:'WaterGun',Grass:'Absorb',Electric:'ThunderShock',Psychic:'Confusion',
 Ice:'PowderSnow',Dragon:'DragonBreath',Dark:'Bite',Fairy:'FairyWind'};
const ROM_LEVEL_EVOLUTIONS={
 Bulbasaur:[16,'Ivysaur'],Ivysaur:[32,'Venusaur'],Charmander:[16,'Charmeleon'],Charmeleon:[36,'Charizard'],
 Squirtle:[16,'Wartortle'],Wartortle:[36,'Blastoise'],Caterpie:[7,'Metapod'],Metapod:[10,'Butterfree'],
 Weedle:[7,'Kakuna'],Kakuna:[10,'Beedrill'],Pidgey:[18,'Pidgeotto'],Pidgeotto:[36,'Pidgeot'],
 Chikorita:[16,'Bayleef'],Bayleef:[32,'Meganium'],Cyndaquil:[14,'Quilava'],Quilava:[36,'Typhlosion'],
 Totodile:[18,'Croconaw'],Croconaw:[30,'Feraligatr'],Turtwig:[18,'Grotle'],Grotle:[32,'Torterra'],
 Chimchar:[14,'Monferno'],Monferno:[36,'Infernape'],Piplup:[16,'Prinplup'],Prinplup:[36,'Empoleon'],
 Snivy:[17,'Servine'],Servine:[36,'Serperior'],Tepig:[17,'Pignite'],Pignite:[36,'Emboar'],
 Oshawott:[17,'Dewott'],Dewott:[36,'Samurott'],Chespin:[16,'Quilladin'],Quilladin:[36,'Chesnaught'],
 Fennekin:[16,'Braixen'],Braixen:[36,'Delphox'],Froakie:[16,'Frogadier'],Frogadier:[36,'Greninja'],
 Rowlet:[17,'Dartrix'],Dartrix:[34,'Decidueye'],Litten:[17,'Torracat'],Torracat:[34,'Incineroar'],
 Popplio:[17,'Brionne'],Brionne:[34,'Primarina'],Grookey:[16,'Thwackey'],Thwackey:[35,'Rillaboom'],
 Scorbunny:[16,'Raboot'],Raboot:[35,'Cinderace'],Sobble:[16,'Drizzile'],Drizzile:[35,'Inteleon'],
 Sprigatito:[16,'Floragato'],Floragato:[36,'Meowscarada'],Fuecoco:[16,'Crocalor'],Crocalor:[36,'Skeledirge'],
 Quaxly:[16,'Quaxwell'],Quaxwell:[36,'Quaquaval'],
};
// Several Gen I–III species received Fairy typing only in Gen VI.
// The ROM catalogue keeps their modern types for the extended national mode,
// while classic Emerald battles use their historical Gen III types.
const LEGACY_GEN3_TYPES=Object.freeze({
 Clefairy:['Normal'],Clefable:['Normal'],Jigglypuff:['Normal'],Wigglytuff:['Normal'],
 Togepi:['Normal'],Togetic:['Normal','Flying'],Snubbull:['Normal'],Granbull:['Normal'],
 Marill:['Water'],Azumarill:['Water'],Ralts:['Psychic'],Kirlia:['Psychic'],
 Gardevoir:['Psychic'],Mawile:['Steel']
});
for(const entry of DEX.POKEMON){
 const old=SPEC[entry.key];
 const learnTypes=entry.dex<=386?(LEGACY_GEN3_TYPES[entry.key]||entry.types):entry.types;
 const generic=[...new Set(['Tackle',...learnTypes.map(t=>TYPE_START_MOVES[t]).filter(Boolean),'Growl'])].filter(n=>MOVES[n]);
 const curated=old?.moves?.filter(n=>MOVES[n]);
 SPEC[entry.key]={...(old||{}),types:entry.types,base:entry.base,exp:entry.exp,catch:entry.catch,
  moves:curated?.length?curated.slice(0,4):generic.slice(0,4),
  ...(old?.evolve?{}:ROM_LEVEL_EVOLUTIONS[entry.key]?{evolve:ROM_LEVEL_EVOLUTIONS[entry.key]}:{}),
  romSlot:entry.id,dex:entry.dex,romKind:entry.kind,movesVerified:Boolean(curated?.length)};
}
const NATURES={Hardy:null,Lonely:['atk','def'],Brave:['atk','spe'],Adamant:['atk','spa'],Naughty:['atk','spd'],Bold:['def','atk'],Docile:null,Relaxed:['def','spe'],Impish:['def','spa'],Lax:['def','spd'],Timid:['spe','atk'],Hasty:['spe','def'],Serious:null,Jolly:['spe','spa'],Naive:['spe','spd'],Modest:['spa','atk'],Mild:['spa','def'],Quiet:['spa','spe'],Bashful:null,Rash:['spa','spd'],Calm:['spd','atk'],Gentle:['spd','def'],Sassy:['spd','spe'],Careful:['spd','spa'],Quirky:null};
const ADV={Normal:{Rock:.5,Ghost:0,Steel:.5},Fire:{Fire:.5,Water:.5,Grass:2,Ice:2,Bug:2,Rock:.5,Dragon:.5,Steel:2},Water:{Fire:2,Water:.5,Grass:.5,Ground:2,Rock:2,Dragon:.5},Grass:{Fire:.5,Water:2,Grass:.5,Poison:.5,Ground:2,Flying:.5,Bug:.5,Rock:2,Dragon:.5,Steel:.5},Electric:{Water:2,Electric:.5,Grass:.5,Ground:0,Flying:2,Dragon:.5},Ice:{Fire:.5,Water:.5,Grass:2,Ice:.5,Ground:2,Flying:2,Dragon:2,Steel:.5},Fighting:{Normal:2,Ice:2,Poison:.5,Flying:.5,Psychic:.5,Bug:.5,Rock:2,Ghost:0,Dark:2,Steel:2},Poison:{Grass:2,Poison:.5,Ground:.5,Rock:.5,Ghost:.5,Steel:0},Ground:{Fire:2,Electric:2,Grass:.5,Poison:2,Flying:0,Bug:.5,Rock:2,Steel:2},Flying:{Electric:.5,Grass:2,Fighting:2,Bug:2,Rock:.5,Steel:.5},Psychic:{Fighting:2,Poison:2,Psychic:.5,Dark:0,Steel:.5},Bug:{Fire:.5,Grass:2,Fighting:.5,Poison:.5,Flying:.5,Psychic:2,Ghost:.5,Dark:2,Steel:.5},Rock:{Fire:2,Ice:2,Fighting:.5,Ground:.5,Flying:2,Bug:2,Steel:.5},Ghost:{Normal:0,Psychic:2,Ghost:2,Dark:.5,Steel:.5},Dragon:{Dragon:2,Steel:.5},Dark:{Fighting:.5,Psychic:2,Ghost:2,Dark:.5,Steel:.5},Steel:{Fire:.5,Water:.5,Electric:.5,Ice:2,Rock:2,Steel:.5}};
// Modern Fairy interactions used only by the simplified online V9 battle engine.
ADV.Fairy={Fighting:2,Dragon:2,Dark:2,Fire:.5,Poison:.5,Steel:.5};
for(const [attack,mult] of Object.entries({Fighting:.5,Bug:.5,Dark:.5,Dragon:0}))ADV[attack].Fairy=mult;
ADV.Poison.Fairy=2;ADV.Steel.Fairy=2;
const R=()=>Math.random();
const max=(v,a,b)=>Math.max(a,Math.min(b,v));
function types(species,ruleset='gen3_extended'){return (ruleset==='gen3_emerald'&&LEGACY_GEN3_TYPES[species])||SPEC[species]?.types||['Normal'];}
function effective(type,target,ruleset='gen3_extended'){return types(target.species,ruleset).reduce((n,t)=>n*(ADV[type]?.[t]??1),1);}
function normNature(nature,stat){const adj=NATURES[nature];if(!adj||stat==='hp')return 1;return stat===adj[0]?1.1:stat===adj[1]?0.9:1;}
function create(species,level=5){if(!SPEC[species])throw Error('Pokémon indisponível no modo online');const ivs={},evs={};for(const s of STATS){ivs[s]=crypto.randomInt(0,32);evs[s]=0;}
 const nature=Object.keys(NATURES)[crypto.randomInt(Object.keys(NATURES).length)];const m={id:crypto.randomUUID(),species,level:max(level,1,100),ivs,evs,nature,moves:SPEC[species].moves.slice(0,4),exp:Math.pow(level,3),stages:{},status:null};m.maxHp=stat(m,'hp');m.hp=m.maxHp;return Gen3.initialize(m);}
function stat(mon,s){if(mon.species==='Shedinja'&&s==='hp')return 1;const species=SPEC[mon.species];if(!species)return s==='hp'?20:10;const base=species.base[STATS.indexOf(s)],iv=max(mon.ivs?.[s]??0,0,31),ev=max(mon.evs?.[s]??0,0,255),level=max(mon.level||1,1,100);const raw=Math.floor((2*base+iv+Math.floor(ev/4))*level/100);
 return s==='hp'?raw+level+10:Math.floor((raw+5)*normNature(mon.nature,s));}
function stageMultiplier(n){return n>=0?(2+n)/2:2/(2-n);}
function strength(mon,s){return Math.max(1,Math.floor(stat(mon,s)*stageMultiplier(max(mon.stages?.[s]||0,-6,6))));}
function estimate(attacker,defender,move){const m=MOVES[move];if(!m||m.power===0)return 0;const physical=PHYSICAL.has(m.type);let atk=strength(attacker,physical?'atk':'spa');let def=strength(defender,physical?'def':'spd');
 if(physical&&attacker.item==='ChoiceBand')atk=Math.max(1,Math.floor(atk*1.5));
 if(physical&&['PurePower','HugePower'].includes(attacker.ability))atk*=2;
 if(physical&&attacker.ability==='Guts'&&attacker.status)atk=Math.max(1,Math.floor(atk*1.5));
 if(['Explosion','Selfdestruct'].includes(move))def=Math.max(1,Math.floor(def/2));
 const core=Math.floor(Math.floor((Math.floor(2*attacker.level/5)+2)*m.power*atk/def)/50)+2;
 const mult=(types(attacker.species).includes(m.type)?1.5:1)*effective(m.type,defender);return Math.floor(core*mult);}
/** Integrated online single-battle subset. Keep Arena in its independent module. */
// Moves that affect their own user or the field are not blocked by the
// opponent's Protect, and do not roll against the opponent's evasion.
// Keep this scoped to the supported online Gen III moves, not the modern Arena.
const SELF_OR_FIELD_MOVES=new Set([
 'Protect','Recover','SwordsDance','CalmMind','Wish','RainDance',
 'SunnyDay','Sandstorm','Hail','Howl','FollowMe'
]);
function targetsOpponent(move){return !SELF_OR_FIELD_MOVES.has(move)&&move!=='HelpingHand';}
function attempt(attacker,defender,move,history,battle=null,modifiers={}){
 const info=MOVES[move];if(!info&&move!=='Struggle')throw Error('Movimento não disponível');
 Gen3.initialize(attacker);Gen3.initialize(defender);
 if(!modifiers.skipBeforeMove&&!Gen3.beforeMove(attacker,move,history,R,{target:defender}))return 0;
 if(defender.protected&&targetsOpponent(move)){
  history.push(`${defender.species} se protegeu de ${move}.`);
  if(['Explosion','Selfdestruct'].includes(move))attacker.hp=0;
  return 0;
 }
 if(info&&!info.alwaysHit&&targetsOpponent(move)&&R()>=Gen3.accuracyChance(info.accuracy,attacker.stages.accuracy,defender.stages.evasion)){history.push(`${attacker.species} errou ${move}.`);
  if(['Explosion','Selfdestruct'].includes(move))attacker.hp=0;return 0;}
 if(info?.effect){
  let changed=false;
  switch(info.effect){
   case 'protect':{const chain=Math.max(0,attacker.protectStreak||0);
    changed=R()<1/Math.pow(2,Math.min(8,chain));attacker.protected=changed;attacker.protectStreak=chain+1;break;}
   case 'seed': if(!types(defender.species,battle?.ruleset).includes('Grass')&&!defender.leechSeeded){defender.leechSeeded=true;changed=true;}break;
   case 'toxic':case 'paralysis':case 'burn':case 'sleep':
    changed=!(info.effect==='paralysis'&&effective('Electric',defender,battle?.ruleset)===0)&&
     Gen3.setStatus(defender,info.effect,types(defender.species,battle?.ruleset),history);break;
   case 'wish':if(battle){battle.wishes??={};const side=(attacker===battle.enemy||attacker===battle.enemyPartner)?'foe':'own';
    if(!battle.wishes[side]){battle.wishes[side]={turns:2,heal:Math.max(1,Math.floor(attacker.maxHp/2))};changed=true;}}break;
   case 'recover': if(attacker.hp<attacker.maxHp){attacker.hp=Math.min(attacker.maxHp,attacker.hp+Math.max(1,Math.floor(attacker.maxHp/2)));changed=true;}break;
   case 'swordsdance':attacker.stages.atk=max((attacker.stages.atk||0)+2,-6,6);changed=true;break;
   case 'calmmind':for(const key of ['spa','spd'])attacker.stages[key]=max((attacker.stages[key]||0)+1,-6,6);changed=true;break;
   case 'rain':case 'sun':case 'sandstorm':case 'hail':
    if(battle){battle.weather=info.effect; battle.weatherTurns=5;changed=true;}break;
   case 'fixed':break;
   default:history.push(`${move} ainda não está habilitado neste formato.`);return 0;
  }
  if(info.effect!=='fixed'){
   history.push(`${attacker.species} usou ${move}${changed?'!':' sem efeito.'}`);
   return 0;
  }
 }
 if(info?.stage||info?.boost){const target=info.stage?defender:attacker,s=info.stage||info.boost,delta=info.stage?-1:1;
  target.stages[s]=max((target.stages[s]||0)+delta,-6,6);
  history.push(`${attacker.species} usou ${move}; ${s} ${delta<0?'caiu':'subiu'}.`);return 0;
 }
 if(move==='Struggle'){
  if(R()>=Gen3.accuracyChance(100,attacker.stages.accuracy,defender.stages.evasion)){
   history.push(`${attacker.species} errou Struggle.`);return 0;
  }
  // Generation III Struggle is a typeless 50-power physical attack. It is not
  // immune against Ghost types, and recoil is 1/4 of actual HP removed.
  const calculated=Gen3Damage.calculate({attacker,defender,
   move:{id:'Struggle',type:'Normal',power:50},stat,
   typesOf:()=>[],typeMultiplier:()=>1,randomRoll:85+Math.floor(R()*16),weather:battle?.weather});
  const dealt=Math.max(0,Math.min(defender.hp,calculated));
  defender.hp=Math.max(0,defender.hp-dealt);
  const recoil=Math.max(1,Math.floor(dealt/4));attacker.hp=Math.max(0,attacker.hp-recoil);
  history.push(`${attacker.species} usou Struggle: ${dealt} de dano e ${recoil} de recuo.`);
  return dealt;
 }
 const effectiveness=effective(info.type,defender,battle?.ruleset);
 if(effectiveness===0){history.push(`${move} não afetou ${defender.species}.`);if(['Explosion','Selfdestruct'].includes(move))attacker.hp=0;return 0;}
 if(defender.ability==='Levitate'&&info.type==='Ground'){
  history.push(`${defender.species} evitou ${move} com Levitate.`);if(['Explosion','Selfdestruct'].includes(move))attacker.hp=0;return 0;
 }
 if(defender.ability==='WonderGuard'&&effectiveness<=1){history.push(`Wonder Guard protegeu ${defender.species}.`);if(['Explosion','Selfdestruct'].includes(move))attacker.hp=0;return 0;}
 if(info.effect==='fixed'){
  const dmg=Gen3Turn.fixedDamage(move,attacker.level,defender.hp);
  defender.hp=Math.max(0,defender.hp-dmg);history.push(`${attacker.species} usou ${move}: ${dmg} de dano fixo.`);
  Gen3.triggerBerry(defender,history);return dmg;
 }
 const hits=Gen3.multiHitCount(move,R);let total=0;let realHits=0;
 for(let hit=0;hit<hits&&defender.hp>0;hit++){
  const critical=!['BattleArmor','ShellArmor'].includes(defender.ability)&&R()<1/16;
  // The supported Gen III damage calculation now applies burn/weather before +2,
  // then critical/STAB/type modifiers and an integer 85..100 roll after +2.
  // Extended-DEX species remain catchable and use the same compatible subset.
  let dmg=Gen3Damage.calculate({attacker,defender,move:{...info,id:move},stat,typesOf:s=>types(s,battle?.ruleset),
   typeMultiplier:(attackType,targetType)=>ADV[attackType]?.[targetType]??1,
   critical,randomRoll:85+Math.floor(R()*16),weather:battle?.weather,spread:modifiers.spread??1,helpingHand:!!modifiers.helpingHand});
  if(defender.item==='FocusBand'&&dmg>=defender.hp&&R()<.1)dmg=Math.max(0,defender.hp-1);
  const dealt=Math.max(0,Math.min(defender.hp,dmg));defender.hp=Math.max(0,defender.hp-dmg);total+=dealt;realHits++;
  history.push(`${attacker.species} usou ${move}: acerto ${realHits}, ${dealt} HP${critical?' (crítico)':''}.`);
  Gen3.afterHit(attacker,defender,move,dealt,types(defender.species,battle?.ruleset),types(attacker.species,battle?.ruleset),history,R);
 }
 if(info.drain&&total)attacker.hp=Math.min(attacker.maxHp,attacker.hp+Math.max(1,Math.floor(total*info.drain)));
 if(attacker.item==='ShellBell'&&total&&attacker.hp>0)attacker.hp=Math.min(attacker.maxHp,attacker.hp+Math.max(1,Math.floor(total/8)));
 if(['Explosion','Selfdestruct'].includes(move)){attacker.hp=0;history.push(`${attacker.species} desmaiou após ${move}.`);}
 return total;
}
function availableMoves(mon){Gen3.initialize(mon);
 const list=mon.moves.filter(m=>MOVES[m]&&(mon.pp[m]??0)>0&&(!mon.choiceLock||mon.choiceLock===m));
 return list.length?list:['Struggle'];
}
function chooseFoeMove(foe,target){return availableMoves(foe).sort((a,z)=>estimate(foe,target,z)-estimate(foe,target,a))[0]||'Struggle';}
function finishTurn(profile,own,foe,history){
 const b=profile.battle;if(!b)return;
 b.turn++;
 Gen3.endTurn(own,foe,b,s=>types(s,b.ruleset),stat,history,R);
}
function levelCap(profile){return profile.badges>=8?(profile.champion?100:58):[15,19,24,29,31,33,42,46][max(profile.badges||0,0,7)];}
function grantExp(mon,opponent,profile,history,participants=1){
 // Gym-level advice is NOT an experience hard cap in the original Emerald.
 // Keep levelCap() for AI training goals, but let earned EXP grow to level 100.
 // This online beta still uses simplified EXP gains / cubic growth.
 const base=SPEC[opponent.species]?.exp||50,gain=Math.max(1,Math.floor(base*opponent.level/(7*participants)));
 mon.exp=Math.min(1000000,mon.exp+gain);let leveled=false;
 while(mon.level<100&&mon.exp>=Math.pow(mon.level+1,3)){
  const previousMax=mon.maxHp;mon.level++;const evolved=SPEC[mon.species]?.evolve;
  if(evolved&&mon.level>=evolved[0]){const old=mon.species;mon.species=evolved[1];mon.moves=SPEC[mon.species].moves.slice(0,4);mon.pp={};Gen3.initialize(mon);history.push(`✨ ${old} evoluiu para ${evolved[1]}! Novos atributos-base aplicados.`)}
  mon.maxHp=stat(mon,'hp');mon.hp=Math.min(mon.maxHp,mon.hp+mon.maxHp-previousMax);leveled=true;
 }
 history.push(`${mon.species} recebeu ${gain} EXP.${leveled?' Subiu ao nível '+mon.level+'!':''}`);
}
const AREAS={Route101:['Zigzagoon','Poochyena','Wurmple'],Route102:['Zigzagoon','Poochyena','Lotad'],Route103:['Poochyena','Zigzagoon','Wingull'],Route104:['Taillow','Zigzagoon','Lotad'],Woods:['Shroomish','Wurmple','Poochyena'],Route104North:['Shroomish','Taillow','Lotad','Wingull'],Route116:['Zigzagoon','Poochyena','Taillow'],
 Route106:['Wingull','Taillow','Makuhita'],GraniteCave:['Zubat','Geodude','Makuhita','Abra'],
 Route110:['Electrike','Wingull','Zigzagoon','Magnemite'],
 Route111:['Numel','Machop','Sandshrew'],FieryPath:['Slugma','Numel','Zubat'],Route112:['Numel','Machop','Slugma'],
 Route118:['Electrike','Zigzagoon','Wingull'],Route119:['Tropius','Oddish','Wingull'],Route120:['Oddish','Swablu','Mightyena'],
 Route124:['Wingull','Tentacool','Wailmer'],Route127:['Tentacool','Wailmer','Wingull'],Route126:['Tentacool','Wingull','Wailmer'],
 Route128:['Tentacool','Wailmer','Wingull'],VictoryRoad:['Golbat','Hariyama','Lairon']};
const GYM_ROXANNE=Object.freeze({id:'roxanne',name:'Roxanne',badge:1,area:'RustboroGym',prize:1500,team:[['Geodude',12],['Geodude',12],['Nosepass',15]]});
const GYMS=Object.freeze({
 RustboroGym:GYM_ROXANNE,
 DewfordGym:{id:'brawly',name:'Brawly',badge:2,area:'DewfordGym',prize:1900,team:[['Machop',16],['Meditite',16],['Makuhita',19]]},
 MauvilleGym:{id:'wattson',name:'Wattson',badge:3,area:'MauvilleGym',prize:2400,team:[['Voltorb',20],['Electrike',20],['Magneton',22],['Manectric',24]]},
 ...LATE_GYMS
});
const {OPTIONAL_TRAINERS}=require('./world.cjs');
const STORY_TRAINERS=Object.freeze({
 aqua_grunt:{id:'aqua_grunt',name:'Recruta Aqua',area:'RusturfTunnel',x:14,y:9,requiresBadges:1,flag:'peeko',team:[['Poochyena',11]]},
 rival110:{id:'rival110',name:'May / Brendan',area:'Route110',x:14,y:11,requiresBadges:2,flag:'rival110',teamByStarter:{Treecko:[['Wingull',18],['Lombre',18],['Combusken',20]],Torchic:[['Lombre',18],['Slugma',18],['Marshtomp',20]],Mudkip:[['Wingull',18],['Slugma',18],['Grovyle',20]]}},
 wally:{id:'wally',name:'Wally',area:'Mauville',x:14,y:11,requiresBadges:2,requiresStory:'rival110',flag:'wally',team:[['Ralts',16]]}
});
function gymAt(profile){const gym=GYMS[profile.area];return gym&&profile.badges===gym.badge-1&&Math.abs(profile.x-14)+Math.abs(profile.y-9)<=2?gym:null;}
function storyTrainerAt(profile,id=null){return Object.values(STORY_TRAINERS).find(t=>(!id||id===t.id)&&t.area===profile.area&&Math.abs(profile.x-t.x)+Math.abs(profile.y-t.y)<=2&&Number(profile.badges||0)>=(t.requiresBadges||0)&&(!t.requiresStory||profile.story?.[t.requiresStory])&&!profile.story?.[t.flag])||null;}
function optionalTrainerAt(profile,id=null){
 return (OPTIONAL_TRAINERS[profile.area]||[]).find(t=>(!id||id===t.id)&&
  !profile.npcDefeated?.[t.id]&&Math.abs(profile.x-t.x)+Math.abs(profile.y-t.y)<=2)||null;
}
function encounterTeam(profile,t){const roster=t.teamByStarter?.[profile.starter]||t.team||[['Wingull',18],['Slugma',18],[require('../jogo/game/pokemon/starters.js').counter(profile.starter),20]];return roster.map(([species,lv])=>create(species,lv));}
function firstAlive(profile){
 const team=profile.battle?.type==='frontier'&&profile.frontier?.active?.facility==='factory'?profile.frontier.active.rentals:profile.team;
 const allowed=profile.battle?.type==='frontier'?new Set(profile.battle.selectedTeamIds||[]):null;
 const permitted=m=>!allowed||allowed.has(m.id);
 const a=team?.[profile.activeIndex];if(a&&a.hp>0&&permitted(a))return a;
 const i=(team||[]).findIndex(p=>p.hp>0&&permitted(p));
 if(i>=0)profile.activeIndex=i;return i>=0?team[i]:null;
}
function publicBattle(profile){if(!profile.battle)return null;const b=profile.battle;const double=b.format==='double';return {type:b.type,format:b.format||'single',turn:b.turn,ruleset:b.ruleset,weather:b.weather||null,enemy:b.enemy,enemyPartner:double?b.enemyPartner:null,ally:double&&profile.team.some(m=>m.id===b.doubleSlots?.A1&&m.hp>0)?profile.team.find(m=>m.id===b.doubleSlots?.A2&&m.hp>0)||null:null,log:b.history.slice(-12),targetId:b.targetId,remaining:(b.remaining||[]).length,trainerName:b.trainerName||null,frontierFacility:b.frontierFacility||null,arenaRound:b.arenaJudgement?.rounds||0,selectedTeamIds:b.selectedTeamIds||null,activePokemonId:double?(profile.team.some(m=>m.id===b.doubleSlots?.A1&&m.hp>0)?b.doubleSlots.A1:b.doubleSlots?.A2||null):firstAlive(profile)?.id||null};}
function prepareBattle(profile){
 const b=profile.battle,own=firstAlive(profile);
 Gen3.initialize(own);Gen3.initialize(b.enemy);
 // Modern Quetzal species remain catchable; the classic ruleset is used
 // only when both battlers belong to Emerald's original national range.
 const oldDex=mon=>(SPEC[mon.species]?.dex||9999)<=386;
 b.ruleset=oldDex(own)&&oldDex(b.enemy)?'gen3_emerald':'gen3_extended';
 Gen3.onEntry(own,[b.enemy],b.history);
 Gen3.onEntry(b.enemy,[own],b.history);
}
function begin(profile,{type='wild',bot=null,trainerId=null,national=false,frontierId=null,frontierOpponent=null,frontierFacility='tower'}={}){if(profile.frontier?.active&&type!=='frontier')throw Error('Finalize ou abandone seu desafio da Frontier antes de iniciar outra batalha');if(profile.battle)throw Error('Uma batalha já está em andamento');if(!firstAlive(profile))throw Error('Equipe sem HP. Cure seu Pokémon no Centro Pokémon.');
 let foe,mode=type;
 if(mode==='wild'){const pool=AREAS[profile.area];if(!pool)throw Error('Pokémon selvagens indisponíveis nesta área');const levels={Route104North:[6,11],Woods:[5,10],Route116:[7,12],Route106:[8,15],GraniteCave:[10,16],Route110:[12,18],Slateport:[10,15],Mauville:[12,19],Route111:[20,27],FieryPath:[20,27],Route112:[23,29],Route118:[26,31],Route119:[28,33],Route120:[29,35],Route124:[36,41],Route127:[39,44],Route126:[40,45],Route128:[43,49],VictoryRoad:[43,51]};const [lo,hi]=levels[profile.area]||[3,6];let candidates=pool;
  if(national){
   // Fixed per-species locations from the adapted habitat catalogue, NEVER global random.
   const regional=NationalPools.pool(DEX.PRIMARY,{location:profile.area,badges:profile.badges,
     champion:profile.champion===true,matchHabitat:true});
   const beginner=profile.phase==='capture'&&Number(profile.badges||0)===0&&(profile.team||[]).length<2;
   candidates=(beginner?regional.filter(p=>p.catch>=150&&p.base.reduce((a,b)=>a+b,0)<=380):regional).map(p=>p.key);
   if(!candidates.length)candidates=pool; // only this area's curated Hoenn encounters
  }
  foe=create(candidates[crypto.randomInt(candidates.length)],lo+crypto.randomInt(hi-lo+1));}
 else if(mode==='frontier'){
  const run=profile.frontier?.active;
  if(!run||run.id!==frontierId||!Array.isArray(frontierOpponent))throw Error('Sequência Frontier não autorizada');
  const opponents=frontierOpponent;
  if(opponents.length<1||opponents.length>3||opponents.some(([species,lv])=>!SPEC[species]||!Number.isInteger(lv)||lv<1||lv>100))throw Error('Equipe Frontier inválida');
  const lineup=opponents.map(([species,lv,moves,item])=>{
   const mon=create(species,lv);
   if(Array.isArray(moves)&&moves.length>0&&moves.length<=4&&moves.every(move=>typeof move==='string'&&MOVES[move])){
    mon.moves=[...moves];mon.pp={};Gen3.initialize(mon);
   }
   if(typeof item==='string'&&item.length<=40)mon.item=item;
   return mon;
  });foe=lineup.shift();
  profile.battle={type:'frontier',frontierRunId:run.id,frontierFacility,selectedTeamIds:run.teamIds.slice(),trainerName:require('./frontier.cjs').FACILITIES[frontierFacility]?.name||'Battle Frontier',
   remaining:lineup,participants:[firstAlive(profile).id],turn:0,enemy:foe,history:[`${require('./frontier.cjs').FACILITIES[frontierFacility]?.name||'Battle Frontier'}: ${foe.species} Nv. ${foe.level} apareceu!`]};
  prepareBattle(profile);return publicBattle(profile);
 }
 else if(mode==='bot'){
  if(!bot||bot.area!==profile.area||bot.channel!==profile.channel||Math.abs(bot.x-profile.x)+Math.abs(bot.y-profile.y)>3)throw Error('O bot não está perto de você');
  const m=bot.team?.[0];if(!m||!SPEC[m.species])throw Error('Bot sem Pokémon compatível');foe=create(m.species,m.level);
 }else if(mode==='gym'){
  const gym=gymAt(profile);
  if(!gym)throw Error('Aproxime-se do líder e conquiste as insígnias anteriores para desafiá-lo');
  const lineup=encounterTeam(profile,gym);foe=lineup.shift();
  if(gym.format==='double'){
   const starters=(profile.team||[]).filter(m=>m.hp>0).slice(0,2);
   if(starters.length<2)throw Error('A batalha Double de Tate & Liza exige dois Pokémon saudáveis na equipe');
   profile.activeIndex=profile.team.findIndex(m=>m.id===starters[0].id);
   const second=lineup.shift();
   profile.battle={type:'gym',format:'double',trainerName:gym.name,targetId:gym.id,
    remaining:lineup,participants:starters.map(m=>m.id),doubleSlots:{A1:starters[0].id,A2:starters[1].id},
    defeatedFoeIds:[],turn:0,enemy:foe,enemyPartner:second,history:[`Tate & Liza enviaram ${foe.species} e ${second.species}!`]};
   const b=profile.battle;prepareBattle(profile);
   Gen3.initialize(starters[1]);Gen3.initialize(second);
   Gen3.onEntry(starters[1],[foe,second],b.history);Gen3.onEntry(second,starters,b.history);
   return publicBattle(profile);
  }
  profile.battle={type:'gym',trainerName:gym.name,targetId:gym.id,remaining:lineup,participants:[firstAlive(profile).id],turn:0,enemy:foe,history:[`${gym.name} enviou ${foe.species} Nv. ${foe.level}.`]};prepareBattle(profile);return publicBattle(profile);
 }else if(mode==='league'){
  const boss=leagueAt(profile);
  if(!boss)throw Error('Para desafiar a Liga, vença os oito ginásios e os membros anteriores');
  const lineup=encounterTeam(profile,boss);foe=lineup.shift();
  profile.battle={type:'league',trainerName:boss.name,targetId:boss.id,remaining:lineup,participants:[firstAlive(profile).id],turn:0,enemy:foe,history:[`Liga Pokémon: ${boss.name} enviou ${foe.species} Nv. ${foe.level}.`]};prepareBattle(profile);return publicBattle(profile);
 }else if(mode==='npc'){
  const npc=optionalTrainerAt(profile,trainerId);
  if(!npc)throw Error('NPC não encontrado, já derrotado ou distante demais');
  const lineup=encounterTeam(profile,npc);foe=lineup.shift();
  profile.battle={type:'npc',trainerName:npc.name,targetId:npc.id,remaining:lineup,
   participants:[firstAlive(profile).id],turn:0,enemy:foe,
   history:[`${npc.name} enviou ${foe.species} Nv. ${foe.level}.`]};
  prepareBattle(profile);return publicBattle(profile);
 }else if(mode==='trainer'){
  const trainer=storyTrainerAt(profile,trainerId);
  if(!trainer)throw Error('Treinador da história indisponível nesta posição');
  const lineup=encounterTeam(profile,trainer);foe=lineup.shift();
  profile.battle={type:'trainer',trainerName:trainer.name,targetId:trainer.id,remaining:lineup,participants:[firstAlive(profile).id],turn:0,enemy:foe,history:[`${trainer.name} enviou ${foe.species} Nv. ${foe.level}.`]};prepareBattle(profile);return publicBattle(profile);
 }else throw Error('Modo de batalha inválido');
 profile.battle={type:mode,targetId:mode==='bot'?bot.id:null,participants:[firstAlive(profile).id],turn:0,enemy:foe,history:[mode==='wild'?`Um ${foe.species} selvagem apareceu!`:`${bot.name} enviou ${foe.species}!`]};prepareBattle(profile);return publicBattle(profile);
}
function capture(profile,history){const b=profile.battle;if(b.type!=='wild')throw Error('Não é permitido capturar Pokémon de outro treinador');profile.bag??={pokeballs:5};if(profile.bag.pokeballs<=0)throw Error('Você não tem Poké Bolas');profile.bag.pokeballs--;
 const foe=b.enemy;
 // Standard ball: Gen III adjusted catch rate + four shake checks. Sleep,
 // freeze, paralysis, poison and burn affect capture; no encounters changed.
 const outcome=Gen3Capture.throwBall(foe,SPEC[foe.species]?.catch||100,R);
 if(outcome.success){Gen3.switchOut(foe);foe.exp=Math.pow(foe.level,3);profile.team??=[];profile.pc??=[];if(profile.team.length<6)profile.team.push(foe);else profile.pc.push(foe);
  profile.battle=null;history.push(`✅ ${foe.species} foi capturado!`);return true;
 }history.push(`${foe.species} escapou da Poké Bola! (${outcome.shakes} balanço${outcome.shakes===1?'':'s'})`);return false;
}
function act(profile,{type='move',move=null,partnerMove=null,target=null,partnerTarget=null}={}){
 const b=profile.battle;if(!b)throw Error('Não há batalha ativa');
 if(b.format==='double')return DoubleRuntime.run(profile,{type,move,partnerMove,target,partnerTarget},{Gen3,stat,types,history:b.history,rng:R,availableMoves,chooseFoeMove,attempt,grantExp,publicBattle});
 const own=firstAlive(profile);if(!own)throw Error('Equipe sem HP');b.participants??=[own.id];if(!b.participants.includes(own.id))b.participants.push(own.id);const history=b.history;let captured=false;
 if(type==='run'){if(b.type!=='wild')throw Error('Não é permitido fugir de treinador');profile.battle=null;return {done:true,log:['Você fugiu da batalha.']};}
 if(type==='switch'){
  const team=b.type==='frontier'&&b.frontierFacility==='factory'?profile.frontier.active.rentals:profile.team;
  const index=Number(move);if(b.type==='frontier'&&b.frontierFacility==='arena')throw Error('Trocas voluntárias são proibidas na Battle Arena');
  if(!Number.isInteger(index)||index<0||index>=team.length||team[index].hp<=0||index===profile.activeIndex||(b.type==='frontier'&&!b.selectedTeamIds.includes(team[index].id)))throw Error('Troca inválida');
  profile.activeIndex=index;const next=firstAlive(profile);const foe=b.enemy;if(!b.participants.includes(next.id))b.participants.push(next.id);
  Gen3.switchOut(own);Gen3.onEntry(next,[foe],history);
  const retaliation=chooseFoeMove(foe,next);
  attempt(foe,next,retaliation,history,b);finishTurn(profile,next,foe,history);
  if(!firstAlive(profile)){if(b.type==='frontier')require('./frontier.cjs').recordResult(profile,b,false);else profile.losses=(profile.losses||0)+1;profile.battle=null;return {done:true,victory:false,log:history.slice(-5)};}
  return {done:false,battle:publicBattle(profile),log:history.slice(-4)};
 }
 if(type==='ball'){
  captured=capture(profile,history);
  if(captured)return {done:true,log:history.slice(-4)};
 }else if(type!=='move'||(b.type==='frontier'&&b.frontierFacility==='palace'?false:
  (move==='Struggle'&&!availableMoves(own).includes('Struggle'))||(move!=='Struggle'&&(!MOVES[move]||!own.moves.includes(move)))))throw Error('Ação ou movimento inválido');
 const foe=b.enemy;
 let best=chooseFoeMove(foe,own);
 const palace=b.type==='frontier'&&b.frontierFacility==='palace';
 if(type==='move'&&palace){
  // In Palace the chosen command is ignored: nature decides for BOTH sides.
  const mine=Palace.choose(own,availableMoves(own),MOVES,R);
  const enemy=Palace.choose(foe,availableMoves(foe),MOVES,R);
  move=mine.move;best=enemy.move;
  history.push(mine.incapable?`${own.species} parece incapaz de usar seu poder.`:`Battle Palace escolheu ${move} para ${own.species} (natureza).`);
  if(enemy.incapable)history.push(`${foe.species} parece incapaz de usar seu poder.`);
 }
 const inArena=b.type==='frontier'&&b.frontierFacility==='arena';
 if(inArena&&(!b.arenaJudgement||b.arenaJudgement.ownId!==own.id||b.arenaJudgement.foeId!==foe.id)){
  b.arenaJudgement=ArenaJudge.init(own,foe);
 }
 function perform(actor,defender,chosen,side){
  if(!chosen)return 0;
  const start=history.length;
  const result=attempt(actor,defender,chosen,history,b);
  if(inArena)ArenaJudge.record(b.arenaJudgement,side,actor,chosen,MOVES,history.slice(start),effective(MOVES[chosen]?.type,defender,b.ruleset));
  return result;
 }
 if(!captured){
  const playerFirst=(type==='move')&&Gen3.order({mon:own,move,speed:Gen3.speed(own,stat,b.weather)},
   {mon:foe,move:best,speed:Gen3.speed(foe,stat,b.weather)},R);
  if(playerFirst){perform(own,foe,move,'own');if(foe.hp>0)perform(foe,own,best,'foe');}
  else{perform(foe,own,best,'foe');if(own.hp>0&&type==='move')perform(own,foe,move,'own');}
 }
 finishTurn(profile,own,foe,history);
 if(inArena&&own.hp>0&&foe.hp>0){
  b.arenaJudgement.rounds++;
  if(b.arenaJudgement.rounds===3){
   const result=ArenaJudge.judge(b.arenaJudgement,own,foe);
   history.push(`Battle Arena — Mind ${result.detail.mind.winner}, Skill ${result.detail.skill.winner}, Body ${result.detail.body.winner}; placar ${result.ownPoints} × ${result.foePoints}.`);
   if(result.winner==='own')foe.hp=0;
   else if(result.winner==='foe')own.hp=0;
   else{own.hp=0;foe.hp=0;history.push('Empate na avaliação: ambos os Pokémon desmaiaram.');}
  }
 }
 if(foe.hp<=0){
  // Frontier does not award a win when the last eligible team member also
  // faints on the same turn (e.g. Explosion or shared residual damage).
  if(b.type==='frontier'&&!firstAlive(profile)){
   require('./frontier.cjs').recordResult(profile,b,false);profile.battle=null;
   return {done:true,victory:false,frontier:true,log:[...history.slice(-6),'Equipe derrotada: a sequência Frontier terminou.']};
  }
  if(inArena&&own.hp<=0&&!b.remaining?.length&&!firstAlive(profile)){
   require('./frontier.cjs').recordResult(profile,b,false);profile.battle=null;
   return {done:true,victory:false,frontier:true,log:[...history.slice(-6),'Empate final na Battle Arena: sequência encerrada.']};
  }
  if(b.type==='league'&&!firstAlive(profile)){profile.losses=(profile.losses||0)+1;profile.battle=null;return {done:true,victory:false,log:[...history.slice(-4),'Sua equipe foi derrotada antes de concluir o desafio.']};}
  const eligible=(b.type==='frontier'&&b.frontierFacility==='factory'?profile.frontier.active.rentals:profile.team||[]).filter(m=>m.hp>0&&b.participants.includes(m.id));
  if(b.type!=='frontier')for(const m of eligible)grantExp(m,foe,profile,history,eligible.length);
  if(b.remaining?.length){b.arenaTurns=0;b.arenaJudgement=null;b.enemy=b.remaining.shift();Gen3.initialize(b.enemy);Gen3.onEntry(b.enemy,[firstAlive(profile)],history);b.participants=[firstAlive(profile)?.id].filter(Boolean);history.push(`${b.trainerName||'Treinador'} enviou ${b.enemy.species} Nv. ${b.enemy.level}.`);return {done:false,battle:publicBattle(profile),log:history.slice(-5)};}
  if(b.type==='frontier'){require('./frontier.cjs').recordResult(profile,b,true);profile.battle=null;return {done:true,victory:true,frontier:true,log:history.slice(-7)};}
  profile.wins=(profile.wins||0)+1;profile.money=(profile.money||0)+(b.type==='gym'?(Object.values(GYMS).find(g=>g.id===b.targetId)?.prize||1000):Math.max(10,foe.level*5));
  profile.story??={};
  if(b.type==='gym'){
   const gym=Object.values(GYMS).find(g=>g.id===b.targetId);
   if(gym&&profile.badges===gym.badge-1){profile.badges=gym.badge;profile.story[gym.id]=true;history.push(`🏅 ${gym.name} derrotado: insígnia ${gym.badge} conquistada após vencer toda a equipe!`);}
  }
  if(b.type==='league'){
   const boss=LEAGUE.find(x=>x.id===b.targetId);
   if(boss&&!profile.story[boss.flag]){
    profile.story[boss.flag]=true;profile.leagueWins=(profile.leagueWins||0)+1;
    history.push(`🏆 Liga Pokémon: ${boss.name} derrotado em batalha completa (${profile.leagueWins}/5).`);
    if(boss.id==='wallace'){profile.champion=true;profile.hallOfFame??=[];
     profile.hallOfFame.push({earnedAt:Date.now(),team:(profile.team||[]).map(m=>({species:m.species,level:m.level})),trainer:profile.name||'Treinador'});
     history.push('👑 Campeão de Hoenn! Entrada salva no Hall da Fama. Battle Frontier oficial desbloqueada.');
    }
   }
  }
  if(b.type==='trainer'){
   const trainer=STORY_TRAINERS[b.targetId];if(trainer){profile.story[trainer.flag]=true;history.push(`✅ Evento da história concluído: ${trainer.name}.`);}
  }
  if(b.type==='npc'){
   profile.npcDefeated??={};profile.npcDefeated[b.targetId]=true;
   history.push(`✅ Treinador ${b.trainerName} derrotado numa batalha completa.`);
  }
  profile.battle=null;return {done:true,victory:true,log:history.slice(-7)};
 }
 if(!firstAlive(profile)){if(b.type==='frontier'){require('./frontier.cjs').recordResult(profile,b,false);profile.battle=null;return {done:true,victory:false,frontier:true,log:history.slice(-6)};}profile.losses=(profile.losses||0)+1;profile.battle=null;return {done:true,victory:false,log:[...history.slice(-4),'Sua equipe precisa de cuidados.']};}
 return {done:false,battle:publicBattle(profile),log:history.slice(-4)};
}
function heal(profile){if(profile.frontier?.active)throw Error('A cura externa é bloqueada durante o desafio da Frontier');if(profile.area!=='Center')throw Error('Vá até um Centro Pokémon para curar sua equipe.');if(profile.battle)throw Error('Termine a batalha antes de curar.');for(const m of profile.team||[]){m.maxHp=stat(m,'hp');m.hp=m.maxHp;m.stages={};m.status=null;m.toxicCounter=0;m.confusionTurns=0;m.choiceLock=null;Gen3.initialize(m);for(const key of Object.keys(m.pp))m.pp[key]=Gen3.PP[key]??20;}return profile.team;}
function createProfileStarter(profile){const chosen=SPEC[profile.starter]?profile.starter:'Mudkip';profile.team=[create(chosen,5)];profile.bag={pokeballs:5};profile.money=500;profile.pc=[];}
module.exports={DEX,SPEC,MOVES,NATURES,AREAS,GYM_ROXANNE,GYMS,LEAGUE,leagueAt,STORY_TRAINERS,gymAt,storyTrainerAt,optionalTrainerAt,create,stat,estimate,effective,levelCap,grantExp,begin,act,heal,publicBattle,createProfileStarter,firstAlive,availableMoves};
