# 🌿 Início rápido — Emerald Living World 3.0.1

**1.** Descompacte todo o ZIP (não execute código de dentro do ZIP compactado). **2.** Instale Node.js 20+ no computador/servidor. **3.** Rode `npm run verify:local`. **4.** Rode `npm start`. **5.** Abra `http://127.0.0.1:8787/jogo/online.html` no navegador.

**No Android:** para jogar o modo online, o servidor Node precisa estar publicado em uma hospedagem compatível. O ZIP isolado é o código do projeto e não um APK.

**Saves:** mantenha backup do diretório de dados original antes de atualizar. A versão não reescreve o banco Supabase, nem remove as espécies dos habitats nacionais.

**Ambiente local leve:** copie `.env.local.example` para `.env` e rode `npm run start:env` para começar com 12 bots. Para produção, veja `.env.example`, mas não publique arquivos `.env` ou chaves secretas.

**Páginas:** `jogo/index.html` (portal), `jogo/online.html` (mundo), `jogo/campanha.html` (jornada), `jogo/frontier.html` (Frontier LAB), `jogo/arena.html` (Arena).

**Limitações:** o jogo tem uma campanha adaptada, um motor Gen III parcial e uma Frontier LAB; ainda não é uma reprodução completa da ROM nem um MMO público homologado. As medalhas LAB não são Símbolos oficiais.
