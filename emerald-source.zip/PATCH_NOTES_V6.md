## 🌿・EMERALD LIVING WORLD — V6
-# ✦ Atualização experimental: estabilidade, caminhada, multiplayer e ROM local

__**🗺️ Navegação e mapas**__
- Modo experimental para caminhar com Brendan ou May nos mapas do visualizador.
- Portas verificam destino, entrada de retorno e posição segura.
- Mantidas as correções de colisão da V5.

__**🌐 Mundo Online Beta**__
- Servidor Node com três canais e nove áreas de teste.
- Perfis de visitante, chat básico, controles para Android e modo espectador.
- Posições validadas pelo servidor, transições seguras e progresso salvo em disco.
- Sprites interpolados visualmente conforme a direção autorizada pelo servidor.
- Doze bots experimentais continuam caminhando enquanto o servidor estiver ativo.
- Batalhas de teste: encontros selvagens, desafios de bots próximos, golpes, EXP, evolução,
  captura de Pokémon e cura no Centro Pokémon. Inventário e resultados validados no servidor.

__**🧬 Laboratório ROM**__
- Validação local de arquivos `.gba`.
- Leitura experimental de paletas, tiles e compactação LZ77.
- Nenhum arquivo ROM enviado para o servidor.

__**🛠️ Testes**__
- 28 verificações automáticas aprovadas.
- Interface mobile testada em Chromium com Android emulado.
- Testes de dois visitantes, canais, chat e recuperação de save.

-# ⚠️ Esta V6 ainda não é um MMO completo. As batalhas online são um subconjunto experimental contra Pokémon selvagens e bots; não há PvP nem regras Gen III integrais. A campanha e a IA avançada seguem locais. Contas verificadas, mapas completos, moderação de chat e sprites automáticos da ROM dependem de implementação e testes.
