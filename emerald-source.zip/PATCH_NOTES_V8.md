# 🌿 EMERALD LIVING WORLD V8 — PATCH NOTES

-# ✦ Atualização de progressão — 3 insígnias comprovadas no servidor

__**🏅 Novos desafios reais**__
- Brawly — Machop Nv.16, Meditite Nv.16, Makuhita Nv.19.
- Wattson — Voltorb Nv.20, Electrike Nv.20, Magneton Nv.22, Manectric Nv.24.
- Recruta Aqua em Rusturf Tunnel, rival na Route 110 e Wally em Mauville.
- Nenhuma insígnia é dada sem vencer a equipe do líder.

__**🤖 Bots mais autônomos**__
- Estratégias para encontrar Pokémon contra Pedra, Lutador e Elétrico.
- Compras de Poké Bolas, experiência em combate e recuperação após derrotas.
- Preservação de missões, insígnias, equipes e localização após reinício do servidor.

__**🗺️ Navegação e interface**__
- 27 áreas **adaptadas de teste** conectadas, com validação das portas.
- Barcos, cavernas, ginásios, Centros Pokémon e Poké Marts.
- Portas sinalizadas quando exigem insígnia ou evento.
- Interface online adaptada para celular.

__**🧪 Verificações**__
- 43 testes automáticos aprovados.
- Três jornadas de teste até Wattson, uma para cada inicial.
- Rodada lógica com 100 bots, 500 turnos cada.
- Simulação offline antiga mantida.

-# ⚠️ Ainda não é Hoenn completa: faltam mapas oficiais, cinco ginásios, Liga, pós-jogo, Gen III completo e multiplayer de produção. O modo online requer servidor Node.js ativo.
