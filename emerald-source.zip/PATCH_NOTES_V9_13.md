# 🌿 Patch Notes — V9.13

- Direção visual estável durante a caminhada, baseada no deslocamento real.
- Removida rotação artificial de NPCs que não possuem movimento implementado.
- Removidos loops de ida-e-volta em desvios opcionais das rotas.
- Atualizado cache dos scripts de movimentação nas páginas Jogo e Online.
- Preservados todos os sistemas da V9.12.
- 103/103 testes automáticos e teste visual de direção Android aprovados no cenário verificado.
