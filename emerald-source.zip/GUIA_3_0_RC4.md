# 🌿 Guia de verificação — Emerald Living World 3.0 RC4

Esta build **ainda é uma candidata de lançamento**, não um MMO certificado como estável.

## Rodar localmente

Requer Node.js 20 ou superior. Descompacte, abra um terminal dentro da pasta e execute:

```bash
npm test
npm run audit:release
npm start
```

Abra `http://localhost:8787/jogo/online.html` e, após criar sua sessão, `http://localhost:8787/jogo/frontier.html`.

- Factory: comece o desafio, escolha três dos seis aluguéis antes da primeira luta e confirme.
- Dome: após registrar três Pokémon, escolha dois antes de uma batalha e confirme; pode mudar a dupla entre confrontos.
- Palace: o botão "Avançar turno" deixa o servidor escolher os movimentos conforme a natureza.
- Arena: após três turnos sem nocaute, verifique o registro de Mind, Skill e Body.
- Modo de treino não concede símbolos oficiais nem BP oficial.

## Para hospedagem pública

Configure `AUTH_MODE=required`, `SUPABASE_URL=https://...` e `SUPABASE_PUBLISHABLE_KEY` no **servidor Node**, com HTTPS, persistência real para `DATA_DIR`, backups e monitoramento. Nunca coloque uma chave `service_role`/secret no código público. Os tokens Supabase são verificados ao abrir/renovar a sessão, que expira no servidor em uma hora; isso **não equivale** a validação contínua da revogação de tokens em todos os pedidos.

A auditoria Supabase consultada anteriormente apontou controles e políticas que ainda precisam de revisão: RLS em tabelas sem políticas específicas, funções `SECURITY DEFINER` expostas para usuários autenticados e proteção contra senhas vazadas desativada. Isso não foi modificado. Avalie esses pontos no painel antes de publicar.

`npm run audit:production` ainda deve falhar intencionalmente até a homologação completa; não tente ocultar essas pendências mudando a flag do auditor.

## Dados preservados

O relatório de auditoria valida seis arquivos de encontro/habitats e da Arena por SHA-256; nenhuma das tabelas de Pokémon capturáveis pelos bots foi alterada.
