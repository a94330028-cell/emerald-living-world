# 🌿 Patch Notes 3.2 — Meu Treinador

- 🗺️ Mapa em primeiro lugar na tela principal do jogador.
- 🎒 Time do jogador em destaque logo abaixo do mapa.
- 🧭 Decisão manual da próxima ação na jornada.
- 🏆 Lista compacta apenas dos 6 Pokémon mais fortes na interface principal.
- ⚡ Escala de velocidade renovada para 1×–5× (equivalente lógica de 40×–200× anterior), com orçamento de CPU por quadro.
- 🌙 Refinamento do tema escuro nos painéis do jogador.
- 🖼️ Centralização de 432 sprites locais de Pokémon em caixas iguais sem esticar a arte; GIFs mantêm animação.
- 💾 Saves, mapas e IA dos outros treinadores mantidos.

**Avisos:** o tempo real por evento pode variar conforme o dispositivo; para chat online e painel administrativo de produção é necessário configurar Supabase.
