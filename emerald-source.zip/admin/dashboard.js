(()=>{'use strict';
const $=id=>document.getElementById(id),cfg=window.EMERALD_CLOUD_CONFIG||{};
const base=String(cfg.supabaseUrl||'').replace(/\/+$/,''),apikey=String(cfg.supabaseAnonKey||'');
const ready=/^https:\/\/[^/]+\.supabase\.co$/.test(base)&&apikey.length>15;
const SESSION='elw_cloud_session_v1';let data=null;
const asNum=n=>Number(n||0).toLocaleString('pt-BR');
function gate(message){$('adminContent').hidden=true;$('adminGate').hidden=false;$('adminGate').textContent=message;$('csv').disabled=true}
async function getSession(){let s=null;try{s=JSON.parse(localStorage.getItem(SESSION)||'null')}catch{}if(!s?.access_token)return null;
 if(Number(s.expires_at)*1000>Date.now()+60000)return s.access_token;
 if(!s.refresh_token)return null;
 const res=await fetch(base+'/auth/v1/token?grant_type=refresh_token',{method:'POST',headers:{apikey,'Content-Type':'application/json'},body:JSON.stringify({refresh_token:s.refresh_token})});
 if(!res.ok)return null;const r=await res.json();s={...s,...r,user:r.user||s.user};localStorage.setItem(SESSION,JSON.stringify(s));return s.access_token;
}
const addLine=(node,title,value)=>{const row=document.createElement('div');row.className='line';const a=document.createElement('span'),b=document.createElement('b');a.textContent=title;b.textContent=String(value);row.append(a,b);node.append(row)};
function lines(id,list,name,val){const el=$(id);el.replaceChildren();if(!list?.length){el.textContent='Nenhum dado neste período.';return}
 for(const r of list)addLine(el,String(r[name]||'—'),asNum(r[val]));}
function chart(items){const canvas=$('dailyChart'),ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height;
 ctx.clearRect(0,0,w,h);ctx.fillStyle='#0e2c20';ctx.fillRect(0,0,w,h);
 if(!items?.length){ctx.fillStyle='#b6d3c2';ctx.font='17px system-ui';ctx.fillText('Ainda não há visitas registradas.',28,125);return}
 const max=Math.max(1,...items.map(x=>Number(x.visits)||0)),gap=5,plot=items.length,bar=Math.max(4,(w-60)/plot-gap);
 items.forEach((v,i)=>{const bh=Math.round((Number(v.visits)||0)/max*(h-75)),x=35+i*((w-60)/plot),y=h-37-bh;
  ctx.fillStyle='#55c985';ctx.fillRect(x,y,bar,bh);if(i===0||i===items.length-1||i%Math.ceil(items.length/6)===0){ctx.fillStyle='#c7e9d2';ctx.font='10px system-ui';ctx.fillText(String(v.day).slice(5),x,h-15)}});
 ctx.fillStyle='#91b6a1';ctx.font='11px system-ui';ctx.fillText('Máximo '+asNum(max)+' visitas/dia',10,18);
}
function show(d){data=d;$('metrics').replaceChildren();
 const cards=[['Visitantes únicos',d.uniqueVisitors],['Visitas no período',d.visits],['Jogadores ativos agora',d.activePlayers],['Contas registradas',d.registeredAccounts],['Campanhas iniciadas',d.campaignStarts],['Campanhas concluídas',d.campaignFinishes],['Duração média (min)',d.averageMinutes],['Erros relatados',d.errors]];
 for(const [label,value] of cards){const el=document.createElement('div');el.className='metric';const strong=document.createElement('strong'),span=document.createElement('span');strong.textContent=asNum(value);span.textContent=label;el.append(strong,span);$('metrics').append(el)}
 lines('events',d.events,'event_type','total');lines('pages',d.pages,'page','visits');lines('starters',d.starters,'starter','total');lines('gyms',d.gymDefeats,'gym','defeats');chart(d.daily);
 $('adminGate').hidden=true;$('adminContent').hidden=false;$('csv').disabled=false;
}
async function refresh(){if(!ready){gate('Supabase não configurado. Veja CONFIGURAR_V28.md no ZIP.');return}
 gate('Validando conta e permissão administrativa no servidor…');
 try{const token=await getSession();if(!token){gate('Entre na sua conta pelo jogo, confirme o e-mail e retorne a /admin.');return}
  const resp=await fetch(base+'/functions/v1/admin-dashboard?days='+encodeURIComponent($('days').value),{headers:{apikey,Authorization:'Bearer '+token},cache:'no-store'});
  let result={};try{result=await resp.json()}catch{}if(!resp.ok)throw Error(resp.status===403?'Esta conta não tem permissão de administrador.':resp.status===401?'Faça login e confirme seu e-mail.':result.error||'Falha no painel.');
  show(result);
 }catch(err){gate(err.message||'Erro de conexão com o painel.')} }
$('reload').addEventListener('click',refresh);$('days').addEventListener('change',refresh);
$('csv').addEventListener('click',()=>{if(!data)return;const rows=[['data','visitas','visitantes']].concat((data.daily||[]).map(x=>[x.day,x.visits,x.visitors]));
 const csv='\uFEFF'+rows.map(line=>line.map(s=>'"'+String(s??'').replaceAll('"','""')+'"').join(';')).join('\r\n');
 const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='elw-estatisticas-'+$('days').value+'dias.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)});
refresh();
})();
