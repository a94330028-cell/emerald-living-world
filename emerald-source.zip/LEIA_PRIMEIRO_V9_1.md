# 🌿 Emerald Living World V9.1 — Pokédex Nacional Quetzal (BETA)

## Resumo da entrega

Esta versão preserva o simulador V9, os saves anteriores, o servidor Node, as 27 áreas adaptadas e a campanha online até a terceira insígnia. O objetivo **desta atualização** é adicionar ao catálogo do projeto os Pokémon identificados na ROM `PokemonQuetzalPtBrAlpha9v1.gba` fornecida pelo usuário.

| Componente | Estado |
|---|---|
| Catálogo de espécies nacionais #1–1025 | ✅ extraído e conferido |
| 494 registros internos de formas alternativas | ✅ tipos e atributos; identidade nominal da forma ainda pendente |
| 9 registros experimentais do Quetzal | ✅ dados-base extraídos; nomes provisórios na própria ROM |
| Atributos, dois tipos, taxa de captura e EXP-base | ✅ valores obtidos da ROM (sem preencher números fictícios) |
| Motor Node reconhecendo todos os 1.528 registros | ✅ testes de instanciação/atributos, incluindo Fairy |
| Modo **Encontro Nacional (teste)** | ✅ encontros aleatórios por bioma e limite de poder, apenas formas básicas capturáveis |
| Pokédex pesquisável por geração e tipo | ✅ offline e acessível também pelo servidor |
| Evoluções dos iniciais das gerações I–IX | ✅ regras por nível curadas e verificadas no módulo online |
| Todos os aprendizados de golpes, habilidades e métodos de evolução | ❌ não extraídos; golpes genéricos dos tipos permanecem simplificados |
| Sprites das 1.528 entradas | ❌ não extraídos; o cliente mostra um placeholder quando não existe sprite autorizado |
| Distribuição de Pokémon idêntica à do Quetzal | ❌ não disponível: encontros nacionais têm tabela experimental, não a distribuição da ROM |
| Motor offline com todos os Pokémon habilitados | ❌ o simulador antigo permanece com seu catálogo anterior para evitar regressão |
| Todas as insígnias, mapa completo, online de produção | ❌ fora do escopo desta atualização |

## Fonte dos dados

- Entrada: **ROM do usuário**, 32 MiB, cabeçalho `PKM QUETZAL`, código GBA `BPEE`, Alpha 9 v1.
- O script `tools/extract_quetzal_catalog.py` localiza e valida duas tabelas da ROM (nomes e atributos) e gera apenas dados factuais em `jogo/data/quetzal-catalog.json`.
- A tabela contém **1.025 espécies nacionais** (até Pecharunt), **494 registros extras de formas internas** e **9 registros experimentais** (linhas Browt, Pombon e Gecqua), totalizando **1.528 registros**.
- O `id` é o slot interno da ROM, *não* o número nacional quando a entrada é uma forma. Os registros de forma preservam o mesmo nome-base e recebem chave única (`@` + slot), sem inventar identificação Mega/regional/Gmax.
- **O pacote NÃO contém a ROM**, gráficos, mapas ou sprites dela. Não existe upload da ROM pelo jogo.

## Como abrir

**Somente Pokédex:** publique a pasta `jogo` em hospedagem estática e abra `quetzal-pokedex.html`. Na página principal antiga (`jogo/index.html`), a seção Pokédex ganhou um link direto para a lista completa.

**Mundo online experimental (Node.js 20+):**

```bash
npm test
npm start
```

Depois abra `http://127.0.0.1:8787/jogo/online.html` no próprio servidor. Se preferir os novos Pokémon em combates, visite uma rota com encontros e use **🌎 Encontro Nacional (teste)**. O botão não garante encontrar uma espécie específica. O servidor escolhe um Pokémon elegível pelo bioma e insígnias, para evitar Pokémon poderosos no início. Os bots continuam usando o conjunto anterior de encontros de Hoenn.

Para navegar e pesquisar sem o servidor, `http://127.0.0.1:8787/jogo/quetzal-pokedex.html` ou o equivalente em hospedagem estática. Essa lista possui filtros, paginação e fichas com os seis atributos, tipos, taxa de captura e experiência-base.

Para **regerar os dados com outra ROM que você tenha direito de usar**:

```bash
python tools/extract_quetzal_catalog.py /caminho/para/sua.gba jogo/data/quetzal-catalog.json
```

O script **falha com mensagem explícita** se o cabeçalho, layout ou as tabelas não forem compatíveis; não tenta interpretar versões desconhecidas como se fossem idênticas. O arquivo `.gba` não precisa ser enviado a nenhum servidor.

## Segurança e compatibilidade

Faça uma cópia da pasta `server/data/` e exporte o save local antes da substituição. Os saves antigos preservam o nome textual das espécies; a migração permite manter os Pokémon anteriores. A Pokédex não altera automaticamente seus times. As evoluções por pedra, amizade, itens ou troca exigem uma implementação posterior; não são acionadas por um nível inventado.

As batalhas ainda simplificam habilidades, PP, golpes e outros detalhes da geração correspondente. A tipagem e atributos provêm do Quetzal, mas **não** significa que as batalhas reproduzam todas as regras de Quetzal. Os nove registros experimentais não têm identidades nacionais oficiais verificadas.

## Testes reproduzíveis

- `npm test`: testes Node, incluindo 1.528 entradas, atributos, evolução curada, encontros e persistência básica.
- `python tests/browser-v9-1.py`: verifica busca, filtragem, exibição de detalhes e largura Android/desktop com a aplicação real e o JSON local **carregado em memória**. O Chromium deste ambiente bloqueia endereços locais; o teste não é uma conexão real a um servidor.
- `tests/v9_1_full_node_test_log.txt`, `tests/v9_1_browser_report.json` e capturas `tests/v9_1_pokedex_*.png` preservam evidências.

Esta versão NÃO é uma cópia completa da ROM nem afirma que todos os Pokémon já tenham sprites, movesets, habilidades e locais de captura oficiais.
