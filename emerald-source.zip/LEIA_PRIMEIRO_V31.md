# Emerald Living World 3.1 — Tela principal mais limpa

Esta versão remove da tela principal do jogo os blocos visuais que estavam poluindo a navegação no celular:

- teaser da Pokédex;
- resumo "Rank e Pokémon".

Agora a tela principal fica focada no mapa e na jornada.

## Onde ver cada coisa agora

- **Pokédex / equipe:** aba `Pokédex`
- **Ranking / força:** aba `Rank`
- **Mapa e jornada:** aba `Jogo`

## Objetivo da mudança

Evitar rolagem desnecessária no mobile e deixar a visualização principal mais agradável para o jogador.

## Observação

Nenhum save foi removido e a lógica do jogo não foi alterada.
