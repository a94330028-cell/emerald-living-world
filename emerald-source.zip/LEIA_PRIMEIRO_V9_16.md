# 🌿 EMERALD LIVING WORLD V9.16 — Caminhos seguros

## O que mudou

- **Cercas e paredes:** passos e caminhos calculados respeitam a colisão dos metatiles oficiais carregados. Os mapas do modo adaptado usam a malha local de colisão.
- **NPCs e eventos fixos:** as coordenadas identificadas de personagens no mapa oficial passam a ser tratadas como células bloqueadas; o visualizador manual também aplica essa regra.
- **Fim do teletransporte para fugir de bloqueios:** se uma rota não existe, a IA tenta alternativas válidas, mas nunca troca de coordenada para contornar a cerca.
- **Save com personagem preso em célula inválida:** a posição é preservada e o erro é mostrado; não há deslocamento escondido. Guarde um backup antes de atualizar.
- **Retorno ao Centro Pokémon:** a realocação automática de posição só é permitida quando todos os Pokémon da equipe estão com 0 HP. O Centro precisa ter uma entrada segura confirmada. Após recuperar a equipe, a saída usa uma porta real.
- **Cura com Pokémon ainda vivos:** exige caminhar até um Centro Pokémon, sem cura instantânea em qualquer lugar, mesmo quando a opção de visitas automáticas está desativada.
- **Sem dados de mapa:** o motor não inventa viagens entre cenas. O avatar aguarda o carregamento ou registra o bloqueio.
- **Preservado:** 20 personagens com sprites 32×48, níveis, encontros, rankings, escolhas, modos de jogo e velocidade até 200×.

## Testes e evidências

- **115/115 testes automatizados aprovados** na última execução (`npm test`).
- Cercas, barreiras, NPCs, mapas inacessíveis, transições e saves presos cobertos por testes novos.
- Teste de derrota total (0 HP em todos os Pokémon) provoca retorno ao Centro; equipe com Pokémon vivos não pode ser teletransportada.
- Testes antigos de batalha, 100 IAs até Rustboro, persistência, NPCs e multiplayer passaram.
- Teste de interface Android Chromium (390×844) passou; sem erros JavaScript observados nem rolagem horizontal.
- Os mapas oficiais **não foram todos percorridos visualmente** e dependem dos arquivos de pret/pokeemerald acessíveis. Algumas cercas com metatiles ou scripts especiais ainda podem precisar de regras individuais.

## Limitações importantes

**O modo online atualmente só implementa a campanha até a terceira insígnia.** Não é possível prometer que as 100 IAs já terminem a história até Wallace; faltam ginásios, eventos e puzzles oficiais no servidor. A simulação offline tem mais etapas de história, mas uma campanha completa caminhando por todos os mapas oficiais ainda não foi validada.

Se um save anterior deixou uma IA dentro de um tile bloqueado, o jogo não a teletransportará para um lugar arbitrário. Ela ficará parada e avisará o bloqueio. Apenas derrota total permite o retorno automático ao Centro Pokémon.

## Executar

- **Offline:** abra `jogo/index.html` em um navegador/servidor estático.
- **Online experimental:** Node.js 20+; execute `npm start`. A hospedagem precisa manter o processo e o volume de saves.
- **Testes:** `npm test`; interface Android: `python tests/browser-v9-15.py` (Chromium/Playwright instalado).

Este ZIP não contém ROM de Pokémon Emerald/Quetzal. Antes de atualizar, exporte os saves pelo jogo.
