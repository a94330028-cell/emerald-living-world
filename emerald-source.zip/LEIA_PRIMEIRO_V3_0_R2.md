# 🌿 Emerald Living World — 3.0 Beta · Revisão 2

## O que mudou nesta revisão

Partindo do ZIP **Emerald Living World 3.0 Beta — Hoenn/Liga/Frontier**, apliquei uma série de melhorias concretas no **servidor de batalhas da campanha e do mundo compartilhado**, sem substituir a Arena Competitiva:

- **Cálculo de dano Gen III:** novo módulo `server/gen3-damage.cjs`. Corrige a sequência geral dos multiplicadores, com estágios de atributos, tratamento de críticos, arredondamentos inteiros, 85–100 de sorte, clima, STAB, tipos, queimadura e itens suportados. Explosion/Selfdestruct usa a regra de metade da Defense. Esse módulo foi ligado às batalhas reais do servidor. **Não é um emulador completo de todas as exceções da ROM.**
- **Captura:** novo `server/gen3-capture.cjs`, integrado às Poké Bolas padrão: vida atual, taxa de captura por espécie, bônus de sono/congelamento/envenenamento/paralisia/queimadura e quatro verificações de captura da Gen III. O servidor registra o resultado e preserva os Pokémon capturados na equipe ou no PC.
- **Tipagem da terceira geração:** Gardevoir, Clefairy, Ralts, Marill, Mawile e outros Pokémon originalmente sem o tipo Fada usam o tipo histórico em combates `gen3_emerald`. O catálogo nacional conserva a tipagem moderna no modo estendido; **nenhuma espécie foi retirada**.
- **Bots:** preparação para Wattson ajustada para não insistir em treinos excessivos do Geodude recém-capturado. As insígnias ainda exigem vitórias reais.
- **Interface de batalha:** mostra o PP restante, desabilita golpes sem PP, oferece Struggle quando aplicável, mostra status e usa o Pokémon ativo correto no painel. Os botões receberam tamanho adequado para toque no Android.
- **Saves:** o servidor preserva um snapshot de reserva `world.json.bak` antes de substituir o save principal e tenta recuperar a reserva se o arquivo principal estiver corrompido. A recuperação de backup não garante restauração de absolutamente todos os eventos recentes.
- **Observabilidade:** o endpoint `/api/health` já existente continua compatível e agora informa também a revisão e o tempo de atividade.
- **Testes de regressão:** testes novos verificam dano, críticos, tipos antigos, captura, preservação dos habitats e Arena. Um manifesto SHA-256 no pacote permite conferir os arquivos preservados depois de extrair.

## Capturas dos bots: preservação obrigatória

**Não excluí Pokémon de nenhuma geração, nem reescrevi os habitats ou as listas de encontros.** Os arquivos a seguir permaneceram idênticos aos da versão 3.0 original:

- `jogo/game/pokemon/national-pools.js`
- `jogo/game/pokemon/national-habitats.js`
- `jogo/game/pokemon/national-catalog.js`
- `jogo/data/quetzal-catalog.json`

A Arena Competitiva também manteve `jogo/arena/core.mjs` e `jogo/arena/species.mjs` sem alterações. Suas verificações estão em `tests/fixtures/preserved-v3-content.sha256.json`.

## Como testar

Requer **Node.js 20 ou superior**. Na pasta extraída:

```bash
npm test
npm start
```

Abra `http://localhost:8787/jogo/online.html`. Para verificar o servidor use `http://localhost:8787/api/health`. Um servidor Node.js precisa estar em execução; publicação exclusivamente estática não executa as APIs de batalhas.

## O que ainda não é completo

Esta é uma revisão da **Beta 3.0**, não uma entrega final do escopo completo dos 54 estudos. As áreas novas de Hoenn continuam adaptadas, os eventos intermediários da história original estão incompletos, Tate & Liza ainda utilizam Single experimental, as sete instalações da Frontier continuam protótipos LAB e o motor Gen III ainda não cobre todas as habilidades, condições, movesets e situações Double/Multi.

Os 100 bots estão configurados para simulação, mas seu comportamento e progressão precisam de testes de carga prolongados em produção. O servidor utiliza contas de visitante, e **não há autenticação Supabase completa**. Não publique como MMO público seguro sem revisar autorização, banco, autenticação, testes com usuários reais e implantação.

**Nenhum deploy foi realizado. Nenhum projeto Supabase remoto foi alterado.**
