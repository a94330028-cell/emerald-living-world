# Emerald Living World — Versão 2.5 (início manual e fichas de combate)

## Como começar

Ao abrir o site, a simulação permanece **pausada**. Nenhum turno avança até você escolher uma ação na abertura.

- **Continuar Jornada** aparece quando existe um save local. Retoma os mesmos treinadores, suas equipes, os turnos e as insígnias preservados.
- **Nova Jornada** abre as opções do mundo. Se existir progresso salvo, recomeçar exige confirmação.
- **Só meu bot** inicia o modo pessoal (ou muda para esse modo quando existe save) após um clique explícito.
- **Observar as IAs** inicia a simulação das IAs após um clique explícito.

A atualização não muda as chaves de armazenamento dos saves. Mesmo assim, faça backup em **Recuperação > Exportar save** antes de atualizar.

## Dados dos Pokémon

- Na página **Pokédex > Meu time**, cada Pokémon mostra os seis atributos (HP máximo, Ataque, Defesa, Ataque Especial, Defesa Especial e Velocidade), HP atual, natureza, EXP e golpes conhecidos, com tipo, poder, precisão e PP quando os dados constam do motor.
- Em **Só meu bot**, abra **Atributos e ataques** na ficha do parceiro.
- Na página de configurações, o **PC** tem fichas expansíveis de atributos e golpes dos Pokémon armazenados.
- Na Pokédex Nacional, as fichas mostram atributos-base das 1.025 espécies e golpes cadastrados na simulação. As listas de golpes e evoluções do Quetzal **não estão todas completas**; os dados ausentes não são inventados.

## Verificação

- `node --check` dos módulos alterados: sem erros de sintaxe.
- `npm test`: 128/128 testes aprovados na última execução antes do empacotamento.
- Teste visual completo via HTTP local: **não concluído**. O Chromium do ambiente bloqueou o endereço localhost com `ERR_BLOCKED_BY_ADMINISTRATOR`. Os testes unitários dos componentes passaram.

## Limitações existentes

- As anomalias de tiles na renderização de certos mapas oficiais, como marcas vermelhas/brancas em Oldale, **não foram solucionadas por esta atualização**. Exigem revisão e conferência dos tilesets/camadas reais.
- Mapas oficiais ainda dependem de recursos externos. O sistema pode usar cenário adaptado se esses recursos não carregarem.
- Algumas mecânicas de Pokémon de gerações recentes e suas tabelas completas de golpes/evoluções ainda não estão integradas.

## Instalação

Extraia todo o ZIP, mantenha o `index.html` da raiz junto da pasta `jogo` e publique o conjunto completo. O jogo local está em `jogo/index.html`. Para alguns recursos de navegador, abra por um servidor HTTP, não diretamente pelo gerenciador de arquivos.
