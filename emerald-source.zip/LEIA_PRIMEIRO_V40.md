# 🌿 Emerald Living World 4.0 Beta — Integração ampliada

## Abra este arquivo antes de publicar

Esta atualização foi criada em cima de `Emerald_Living_World_3_9_Gen3_Bots_Frontier.zip`. **Não é a implementação completa dos 54 estudos.** O pacote acrescenta recursos executáveis aos sistemas já existentes e mantém sem alterações os dados dos encontros Pokémon e a Arena Competitiva.

### Requisito importante atendido: capturas dos bots

Comparação binária (mesmo conteúdo) com o ZIP 3.9, para:
- `jogo/game/pokemon/national-pools.js`
- `jogo/game/pokemon/national-habitats.js`
- `jogo/game/pokemon/national-catalog.js`
- `jogo/data/quetzal-catalog.json`
- `server/autonomy.cjs`

Todos foram preservados **byte por byte**. Isto inclui espécies de outras gerações, localizações adaptadas por habitat e o comportamento de escolha/captura da IA já existente. Também não foi modificado `jogo/arena/core.mjs` nem `jogo/arena/species.mjs`.

### O que foi realmente integrado

- **Battle Frontier LAB**: nova interface `jogo/frontier.html` adaptada a celular, ligada às APIs autenticadas do servidor e ao fluxo de batalhas. É necessário criar primeiro uma sessão em `jogo/online.html` e manter o servidor Node ativo.
- **Sete instalações com protótipos jogáveis**: Tower (sequência de 7); Dome (bloco de 4, 2 participantes em batalha); Palace (seleção automática simplificada por natureza); Arena (sem trocas voluntárias, julgamento simplificado em 3 turnos); Factory (6 alugados, 3 selecionados, troca após vitória); Pike (eventos de sala); Pyramid (andares, HP persistente e Battle Bag de Potions limitada).
- **Laboratório de treino não ranqueado** acessível sem campeão; o modo oficial permanece bloqueado antes de vencer a Liga. O treino não fornece BP, recordes ou símbolos.
- **Motor Gen III incremental**: novas funções de acurácia por estágios, consumo adicional de PP contra Pressure, golpes multi-hit, dano especial de Explosion/Selfdestruct, Fake Out com restrição inicial, itens Shell Bell/Focus Band, habilidades Guts/Pure Power/Huge Power/Thick Fat, bônus de Overgrow/Blaze/Torrent/Swarm, e o estado de Pokémon ativo exposto para a interface.
- **Troca Factory sem alterar equipe do jogador**: Pokémon de aluguel ficam em `frontier.active.rentals`, separados de `profile.team` e de `profile.pc`.
- **Pyramid**: itens de Battle Bag consumíveis via API própria, disponíveis entre as batalhas. Sem inventário infinito.
- **Servidor** continua com até 100 bots por padrão, quando executado com Node. Sem mudança nas tabelas de habitats.
- `jogo/index.html`, `jogo/online.html` e `atualizacoes.html` têm acesso às novidades e identificam a Frontier como **beta**.

### O que NÃO está pronto

1. **Campanha completa de Hoenn**: o servidor ainda oferece os capítulos e três ginásios pré-existentes (Roxanne, Brawly, Wattson). Os demais cinco ginásios, Liga e pós-jogo ainda não estão implementados como jornada acessível completa.
2. **Fidelidade integral à ROM Emerald**: cálculos de dano, arredondamentos, IA, alvos Double/Multi, golpes e efeitos especiais ainda têm aproximações. Os protótipos da Frontier usam oponentes gerados, sem equipes fiéis de Frontier Brains. A Arena LAB usa julgamento simplificado por HP, e o Palace LAB usa classificação simplificada de golpes; **não são regras oficiais fiéis**.
3. **Double e Multi jogáveis**: somente os helpers e testes parciais existentes, sem interface e resolução integral.
4. **Símbolos reais, Frontier Pass definitivo e FWS/leaderboards oficiais**: não são concedidos por oponentes genéricos. O BP do modo oficial beta ainda não deve ser confundido com progressão Emerald comprovada.
5. **Contas verificadas e Supabase implantado**: há arquivos e Arena Supabase do pacote anterior, mas o servidor de mundo compartilhado ainda usa sessões de visitante via cookie. Não publique a versão como MMO público seguro sem implementar e auditar login, segurança, moderação e banco persistente.
6. **100 bots com campanha completa fiel**: apenas o simulador de capítulos e bots existente, agora mantido; não foram criados os capítulos ausentes.
7. **Teste visual Chromium**: tentativa feita, mas bloqueada pela política do ambiente (`ERR_BLOCKED_BY_ADMINISTRATOR`). O teste HTTP dos arquivos e do fluxo Factory foi aprovado.

### Testes executados

- `npm test` na raiz: **207 testes Node passaram; 0 falharam**.
- API HTTP: `GET /jogo/frontier.html`, `GET /jogo/frontier/frontier.js`, sessão de visitante, SSE, início de Factory LAB, abertura de batalha e ação de movimento — **aprovados**.
- Sintaxe Node verificada para novos módulos.
- Os quatro arquivos de dados nacionais, a autonomia dos bots e os módulos de Arena foram comparados byte a byte com a versão anterior.

### Como rodar

```sh
npm test
npm start
```

Em seguida, abra `http://localhost:8787/jogo/online.html`, crie uma sessão e entre em **Battle Frontier LAB**. A página da Frontier exige a conexão SSE do servidor Node. Em hospedagem puramente estática, as APIs `/api/frontier/...` não existirão.

### APIs novas/atualizadas

- `GET /api/frontier`
- `POST /api/frontier/start` — `{ "facility":"factory", "practice":true, "levelRule":"level50" }`
- `POST /api/frontier/next` — `{}`
- `POST /api/frontier/swap` — `{ "oldId":"...", "newSpecies":"Breloom" }`
- `POST /api/frontier/use-item` — `{ "item":"potion", "pokemonId":"..." }` (Pyramid)
- `POST /api/frontier/retire` — `{}`

Todas exigem uma sessão válida, e as mutações exigem conexão ativa. O modo de treino não altera recompensas oficiais.

### Próxima etapa necessária para concluir os estudos

Implementar conteúdo e progressão completos da campanha (quatro a oito ginásios restantes, Liga, pós-jogo), integrar regras de Double/Multi ao resolvedor, validar a Gen III com casos da ROM, implementar as regras originais detalhadas das sete instalações, migrar para backend persistente/autenticado e completar a bateria de testes de navegação móvel.

**Nenhum deploy no site público ou alteração no Supabase foi realizado.**
