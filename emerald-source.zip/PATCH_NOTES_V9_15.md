# 🌿 V9.15 — Passos visíveis e controle de velocidade

- Passos laterais com os dois quadros de pernas visíveis em cada tile.
- Última direção preservada ao parar, sem girar no lugar.
- Arquivos originais 32×48 dos 20 personagens preservados.
- Menu de velocidade da simulação de 1× até 200× no modo pessoal e no observador.
- Escolha de velocidade persistida e sincronizada entre os controles.
- Limite de carga por frame para preservar a responsividade do Android.
- Scripts de animação com identificadores novos para atualização de cache.
- Testes de atlas, velocidade, navegador Android e regressão (108/108 na última rodada).

Limites: desempenho real de 100×/200× depende do aparelho. Recursos oficiais externos dos mapas continuam sujeitos à conexão. Alguns testes antigos de progressão de IA mostram intermitência.
