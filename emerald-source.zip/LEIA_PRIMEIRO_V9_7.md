# 🌿 Emerald Living World V9.7 — Minha Jornada

## Como começar

1. Abra `index.html` (que encaminha para `jogo/index.html`) ou publique a pasta completa numa hospedagem estática.
2. Na nova tela inicial, veja a prévia do mapa, os Pokémon de Hoenn e escolha um inicial entre 27 opções (9 gerações).
3. Escolha **🎮 Jogar só com meu bot** para iniciar uma jornada com **1 bot** em um mundo novo.
4. Se já houver um save anterior, esse botão **preserva os outros treinadores**, mas **só movimenta e exibe o seu bot** enquanto o modo solo estiver ativo; não apaga os outros automaticamente. Use **⚙️ Ajustar meu treinador → Modo de jogo e saves** para reiniciar explicitamente com um treinador caso queira apagar/recomeçar.
5. Escolha **🌎 Observar as IAs** para continuar a simulação antiga com vários treinadores.

## Novas decisões do usuário

- Nos momentos importantes contra May/Brendan e Wally, quando o seu bot chega ao encontro, aparece uma escolha: **Treinar primeiro** ou **Enfrentar agora**.
- **Treinar primeiro** agenda três sessões. Nas Rotas 103, 110 e 119 elas iniciam batalhas reais contra Pokémon selvagens da rota, sem conceder níveis ou insígnias automaticamente. Outras áreas sem encontros usam o treino simplificado já existente no motor.
- Após as três sessões o jogo pergunta novamente se deseja enfrentar ou treinar mais.
- No modo solo, as batalhas aguardam a escolha do usuário: quatro golpes disponíveis (respeitando PP), troca quando há parceiro apto, Potion quando há item e captura em encontros selvagens.
- Marque **Golpes automáticos** se preferir que o próprio bot escolha os ataques.
- A experiência, HP, evolução, insígnias e itens continuam sendo geridos pelo motor de batalha existente.

## Mudanças de layout

- Tela inicial limpa (sem rankings, tabelas e controles avançados).
- Abertura com imagem de uma cena real da versão anterior do jogo (não é captura da ROM Quetzal) e três Pokémon de Hoenn.
- **Minha Jornada** tornou-se o painel principal em modo solo: localização, missão, equipe, escolhas e batalha.
- Menus grandes, rankings e configuração avançada ficam fora do caminho principal, mas continuam acessíveis.
- No mapa do modo solo, os outros bots ficam invisíveis e pausados (se existirem num save antigo).
- Layout testado em Chromium nos tamanhos Android (390×844) e desktop (1280×800).

## Arquivos principais alterados

- `jogo/index.html`: novo painel de entrada e opção de apenas um bot.
- `jogo/js/engine.js`: decisões persistentes, treinos contra rivais, golpes manuais, modos de simulação.
- `jogo/js/my-bot.js`: novo painel pessoal com combate interativo.
- `jogo/js/world.js`: oculta outros bots no mapa durante o modo solo.
- `jogo/js/start-setup.js`: não abre um modal cheio de configurações ao chegar na nova tela de entrada.
- `jogo/js/personal-landing.js`: navegação inicial, opções solo/simulação.
- `jogo/css/personal-landing.css`: tema de entrada e do painel pessoal.
- `jogo/assets/ui/hoenn-scene-preview.webp`: imagem do próprio mapa do jogo, recortada de um teste de interface anterior.
- `tests/browser-v9-7.py`: testes do fluxo no navegador.

## Verificação executada

- **92 testes Node.js** no projeto. Uma execução anterior passou 92/92; nas verificações finais, **91/92** passaram porque o teste legado de EXP/evolução do bot em `tests/multiplayer/autonomy.test.cjs` falhou na execução conjunta (e passou isoladamente). Essa instabilidade ainda exige correção; os testes específicos da nova interface passaram.
- Teste em navegador Chromium com tela Android: entrada limpa, 27 iniciais, modo solo com 1 bot, escolha antes do rival, turno manual selecionado, escolha de treino persistida, primeiro encontro de treinamento iniciado, sem erro de JavaScript ou rolagem horizontal indevida.
- Teste em navegador Chromium desktop: modo observador com 20 IAs ainda disponível.
- Capturas e evidências em `tests/v9_7_*.png` e `tests/v9_7_browser_report.json`.

## Limites conhecidos

- A campanha completa e os mapas de Hoenn/Quetzal ainda **não** são inteiramente reproduzidos. O motor offline ainda combina mapas de recuperação, eventos adaptados e alguns treinos simplificados.
- A navegação até um encontro de história não é testada integralmente pelo novo teste de interface: a prova dos botões usa uma **posição de teste já colocada no checkpoint do rival**. Não é prova de campanha completa.
- O multiplayer experimental com Node.js foi preservado, mas a escolha manual de golpes desta versão foi integrada apenas à simulação **offline do seu bot**, não ao servidor MMO.
- O jogo não fica executando no servidor após o usuário fechar a aba no modo offline; o save continua no dispositivo.
- Para atualizar, faça backup do save por **Configurações → Exportar save** e publique esta pasta inteira. O site que já está no ar **não foi atualizado por este pacote**.
