# 🌿 Patch Notes — Emerald Living World 3.0.0 (edição jogável local)

## Correções desta compilação em relação à 3.0 RC7

- **Frontier, resultado idempotente**: só o token do confronto realmente pendente pode avançar a sequência. Resultados duplicados ou dados incompletos são ignorados.
- **Frontier, interrupções**: não é possível iniciar outra batalha enquanto há confronto pendente sem resultado. A saída segura é retomar a batalha existente ou abandonar a sequência, sem recompensas indevidas.
- **Factory e Pyramid**: trocas de aluguéis e Potion da Battle Bag são bloqueadas se existe combate pendente.
- **Vitória correta**: quando o último Pokémon desmaia ao mesmo tempo que o adversário (por exemplo, Explosion), o desafio não concede vitória ou medalha.
- **Persistência**: arquivos `world.json`, `.bak` e `.tmp` gravados com permissões privadas no sistema Unix, inclusive ao sobrescrever saves preexistentes.
- **Regressões**: novos testes para os cenários de integridade, mais testes completos, auditoria do catálogo e do pacote.
- **Identidade da versão**: pacote 3.0.0 local (sem RC), mantendo avisos precisos de regras adaptadas.

## Preservado

- Catálogos nacionais e habitats dos Pokémon capturáveis pelos bots, sem exclusão de espécies.
- Arena Competitiva, progressão de ginásios e Liga, Hall da Fama, Double de Tate e Liza, sete Frontier Brains e mapas existentes.
- Saves anteriores compatíveis pelo mesmo formato de dados.

## Ainda não homologado como reprodução integral nem lançamento público

O motor Gen III continua parcial; as sete instalações são adaptações com recompensas LAB (não Símbolos/BP oficiais); integrações Supabase e PvP com usuários reais não foram validadas; o projeto não foi publicado remotamente.
