# Instalação e validação — Emerald Living World 3.0 RC7

## Instalação

1. Guarde um backup dos seus saves e da versão RC6.
2. Extraia o ZIP RC7 em uma pasta limpa (não misture arquivos com versões antigas).
3. Instale Node.js 20 ou mais recente.
4. Execute no diretório principal: `npm test` e `npm run audit:preservation`.
5. Execute `npm start` e abra `http://localhost:8787/jogo/online.html`.
6. Para os sete desafios, abra `http://localhost:8787/jogo/frontier.html`.

## Regras novas

- **Pike**: 14 salas por bloco; Lucy nas salas 28 e 140 no modo LAB.
- **Dome**: 16 inscritos, chave com 15 jogos e quatro vitórias necessárias por torneio; Tucker está na quinta e na décima finais.
- **Desafio ativo**: não é permitido andar, mudar de canal, comprar, curar a equipe externamente ou iniciar outra batalha. Use a página da Frontier para jogar ou abandonar o desafio.
- **Capturas nacionais**: os Pokémon disponíveis para os bots e os habitats permanecem idênticos à RC6; confirme com o verificador de SHA-256 incluso.

## Auditorias

- `npm test` — testes do projeto.
- `npm run audit:preservation` — compara oito arquivos críticos com a RC6.
- `npm run audit:release` — checagens de desenvolvimento e lista de bloqueios.
- `npm run audit:production` — falha intencionalmente até o lançamento público ser homologado.

A Frontier ainda usa pontos e medalhas **LAB**, sem BP ou Símbolos oficiais. Para ambiente público, são necessários Node.js, HTTPS, armazenamento persistente e autenticação Supabase verificada com `AUTH_MODE=required`. Não coloque chaves secretas no navegador. A integração real com o projeto Supabase e a publicação no site **não foram realizadas** por esta atualização.
