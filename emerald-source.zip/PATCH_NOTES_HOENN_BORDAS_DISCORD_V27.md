# 🌿 Emerald Living World — Patch Notes 2.7

## 🌲 Bordas naturais
- Substituído o espaço preto ao redor das rotas externas por árvores, ondas ou rochas decorativas, conforme a região de Hoenn.
- Decoração determinística, renderizada perto da câmera sem carregar novos mapas ou bloquear caminhos.
- Mantidas as conexões oficiais e as colisões do jogo.

## 💬 Discord oficial
- Novo convite **Entrar no Discord oficial** na tela inicial e na página de apresentação do projeto.
- Link **Nosso Discord** no rodapé do site.
- Convite: https://discord.gg/6r9w3kA4sh

## ⚡ Qualidade e compatibilidade
- Preservadas as 100 IAs, as rotas externas contínuas, o cache de chunks, os interiores e os dados de progresso.
- 145 testes automatizados passaram; teste visual Android simulado concluído para as bordas e navegação.
- A conferência completa em Android físico e todas as conexões oficiais ainda é necessária.
