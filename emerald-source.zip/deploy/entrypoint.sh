#!/bin/sh
# O volume do Railway e montado como root. Ajuste apenas os arquivos de saves,
# entao execute o jogo como o usuario 'node' (sem privilegios de root).
set -eu
DATA_DIR="${DATA_DIR:-/data}"
case "$DATA_DIR" in
  /*) ;;
  *) echo "DATA_DIR precisa ser absoluto" >&2; exit 1;;
esac
mkdir -p "$DATA_DIR"
chown -R node:node "$DATA_DIR"
chmod 700 "$DATA_DIR"
exec su-exec node node server/app.cjs
