# 🌿 Emerald Living World 3.0 Beta — Caminho de Hoenn ampliado

## Este ZIP é a versão 3.0 solicitada

Base de origem: `Emerald_Living_World_4_0_Beta_Frontier_LAB_Gen3_Bots.zip`. A numeração **3.0** é a versão pública escolhida pelo autor, não um sinal de que todos os estudos estão 100% concluídos.

### Preservação obrigatória: Pokémon dos bots

- **Não removemos** Pokémon nem espécies dos encontros nacionais, tabelas de habitats, catálogo Quetzal ou equipes já existentes.
- Os módulos `national-pools.js`, `national-habitats.js`, `national-catalog.js`, `quetzal-catalog.json` foram copiados sem qualquer modificação.
- A simulação continua usando o mesmo comportamento de captura nacional por habitat. A mudança no arquivo `server/autonomy.cjs` só continua os objetivos da jornada depois da terceira insígnia.
- A Arena Competitiva (`jogo/arena`) não foi substituída pelo motor clássico.

### Novos recursos implementados

1. **Oito ginásios com confrontos reais no servidor de teste**: a estrutura de batalha, insígnias por vitória, validação de posição e equipes com os níveis de Emerald agora cobre Flannery, Norman, Winona, Tate & Liza e Juan, além dos três existentes.
2. **Cinco confrontos da Liga**: Sidney, Phoebe, Glacia, Drake e Wallace. Um desafio só libera o seguinte após vitória contra todos os Pokémon da equipe. Ao vencer Wallace, `champion` e registro do Hall da Fama são salvos no perfil do servidor, desbloqueando a Frontier oficial experimental.
3. **Mapas conectados adaptados** até Lavaridge, Petalburg, Fortree, Mossdeep, Sootopolis, Victory Road, Liga e Hall da Fama. São áreas demonstrativas originais — não os mapas gráficos oficiais de Pokémon Emerald.
4. **Bots**: os 100 bots agora podem estabelecer objetivos para os próximos ginásios, treinar, recuperar HP, lutar por insígnias e tentar a Liga. Eles não recebem vitórias automáticas; alguns podem ficar presos ou perder por limitações da IA e do motor.
5. **Interface**: botão para desafiar o membro da Liga quando próximo, progresso de cinco vitórias e status de campeão.
6. **Preservados**: Battle Frontier LAB (sete protótipos), Arena Competitiva, Supabase de arquivos de configuração, sprites e todas as capturas nacionais dos bots.

### O que não está completo

- As rotas, eventos intermediários da história (Times Aqua/Magma, HM puzzles, Groudon/Kyogre/Rayquaza), scripts de NPC e cenários originais da ROM **não são uma campanha Emerald fiel**. O novo caminho é **uma campanha jogável adaptada de teste**.
- **Tate & Liza continuam em Single no servidor** (quatro Pokémon em sequência), pois Double/Multi não estão inteiramente resolvidos. O combate Double original é requisito para fidelidade total.
- A IA dos bots pode encontrar desafios desproporcionais ao nível ou derrotas repetidas, sem vitória garantida. A progressão exige batalhas vencidas.
- O cálculo Gen III ainda possui aproximações e golpes genéricos para Pokémon do catálogo. Os 54 estudos não estão implementados integralmente.
- A Frontier continua **LAB**: sete instalações com protótipos, ainda não reproduz 100% Frontier Brains e não concede símbolos sem derrotas reais.
- O servidor do mundo ainda utiliza sessões de visitante, sem autenticação Supabase completa. Não publique como MMO seguro sem autenticação, autorização, auditoria e revisão de segurança.
- Mapas e testes visuais em navegador real exigem validação adicional. Não foi feito deploy, nem ligação com Supabase remoto.

### Testes executados

- `npm test`: **215 testes automatizados aprovados**.
- `GET /jogo/campanha.html`, `GET /jogo/online.html` e `GET /api/campaign` (com sessão) respondem corretamente nos testes HTTP locais.
- Um bot simulado com RNG determinístico conquistou oito insígnias, cinco confrontos da Liga e o título sem vitórias automáticas.
- Os quatro principais arquivos de catálogo nacional e os dois módulos centrais da Arena foram comparados por SHA-256 e permanecem idênticos.
- Ainda não foi concluído um teste visual completo em navegador real.

### Executar localmente

```bash
npm test
npm start
```

Abra `http://localhost:8787/jogo/online.html` e entre como visitante; use as setas para percorrer as rotas e desafie os líderes, a Liga e os modos LAB. Os botões do servidor só funcionam com o processo Node ligado. Hospedagem estática não executa as APIs do servidor.
