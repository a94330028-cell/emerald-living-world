# 🌿 Emerald Living World 3.0 — Organização, tema e chat

- Navegação mais clara com atalhos para áreas importantes do site.
- Ajustes de espaçamento, hierarquia visual, contrastes e layout mobile.
- Tema escuro abrangente, incluindo a tela inicial e controles do usuário.
- Painel de chat global com balões por treinador, salas temáticas, denunciar e ocultar.
- O chat exige Supabase configurado, contas verificadas e migração SQL; não está ativo no ZIP sozinho.
- CSS do chat Node existente reorganizado sem alterar seu protocolo/servidor.
- Atualização mantém arquivos, mapas e saves da versão 2.9.
- Testes de navegador com backend simulado e testes Node incluídos.
