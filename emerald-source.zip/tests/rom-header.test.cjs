const test=require('node:test'),assert=require('node:assert/strict');
const {readGbaHeader}=require('../jogo/rom/validation/gba-header.js');
function header(name='POKEMON EMER',code='BPEE'){
 const h=new Uint8Array(192);for(let i=0;i<name.length;i++)h[0xA0+i]=name.charCodeAt(i);
 for(let i=0;i<4;i++)h[0xAC+i]=code.charCodeAt(i);
 h[0xB0]=0x30;h[0xB1]=0x31;h[0xB2]=0x96;
 let sum=0;for(let i=0xA0;i<=0xBC;i++)sum+=h[i];h[0xBD]=(0xE7-sum)&255;return h;
}
test('accepts valid Emerald header without needing whole ROM',()=>{
 const result=readGbaHeader(header());assert.equal(result.valid,true);assert.equal(result.emerald,true);assert.equal(result.gameCode,'BPEE');
});
test('rejects malformed headers and identifies other GBA games',()=>{
 let buf=header();buf[0xB2]=0;assert.equal(readGbaHeader(buf).valid,false);
 buf=header('POKEMON RUBY','AXVE');assert.equal(readGbaHeader(buf).emerald,false);
 buf=header();buf[0xA0]^=1;assert.equal(readGbaHeader(buf).checksumOk,false);
 assert.equal(readGbaHeader(new Uint8Array(50)).valid,false);
});

test('Quetzal GBA is detected as a distinct Emerald-family hack, not original Emerald',()=>{
 const hdr=header('PKM QUETZAL','BPEE');const info=readGbaHeader(hdr);
 assert.equal(info.valid,true);assert.equal(info.quetzal,true);
 assert.equal(info.emerald,false);assert.equal(info.emeraldFamily,true);
});
