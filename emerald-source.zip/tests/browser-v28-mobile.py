"""Smoke test offline em Chromium com viewports mobile (nao equivale a Safari/iPhone real)."""
from pathlib import Path
from urllib.parse import urlparse,unquote
from playwright.sync_api import sync_playwright
import json,mimetypes
ROOT=Path(__file__).resolve().parents[1]
HOST='v28-test.local'
report={'environment':'Chromium headless offline, Android 390x844 + iPhone-size 390x844 (nao Safari)', 'checks':[], 'errors':[]}
def route_files(route):
 u=urlparse(route.request.url)
 if u.hostname!=HOST:return route.abort('failed')
 p=(ROOT/unquote(u.path).lstrip('/')).resolve()
 if not p.is_relative_to(ROOT) or not p.is_file():return route.fulfill(status=404,body='')
 return route.fulfill(status=200,body=p.read_bytes(),content_type=mimetypes.guess_type(p.name)[0] or 'application/octet-stream')
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for device in ['Android','iPhone-size']:
  page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
  errs=[]
  page.on('pageerror',lambda exc:errs.append(str(exc)))
  page.route('**/*',route_files)
  html=(ROOT/'jogo/index.html').read_text().replace('<head>',f'<head><base href="https://{HOST}/jogo/">',1)
  page.set_content(html,wait_until='domcontentloaded',timeout=45000)
  page.wait_for_function('window.emeraldTrainers?.length>0&&window.EmeraldEdgeScenery&&window.emeraldLiveDraw',timeout=40000)
  assert page.locator('#elwQuality').count()==1
  assert page.locator('#elwMetricsStatus').count()==1
  assert page.evaluate('window.ELWTelemetry.debug().consent')=='unset'
  assert page.evaluate('window.ELWTelemetry.debug().sent')==0
  page.locator('#elwQuality').select_option('economy',force=True)
  assert page.evaluate('window.ELWQuality.get()')=='economy'
  # Esse teste não injeta credenciais Supabase: consentimento não envia telemetria.
  page.locator('#elwMetricsYes').click(force=True)
  assert page.evaluate('window.ELWTelemetry.debug().consent')=='yes'
  assert page.evaluate('window.ELWTelemetry.debug().sent')==0
  page.locator('#elwMetricsNo').click(force=True)
  assert page.evaluate('window.ELWTelemetry.debug().consent')=='no'
  report['checks'].append(device+': abertura, renderizador, qualidade e consentimento opcional')
  page.locator('#landingSolo').click(force=True)
  page.wait_for_function('document.getElementById("page-jogador")?.hidden===false',timeout=25000)
  # Chunks oficiais simulados: valida cópia exata do canvas nos tiles de borda.
  visual=page.evaluate('''() => {
   const sc=window.EmeraldEdgeScenery,source=document.createElement('canvas');source.width=256;source.height=256;
   const c=source.getContext('2d');c.fillStyle='#d44327';c.fillRect(0,0,256,256);
   for(let y=0;y<256;y+=16)for(let x=0;x<256;x+=16){c.fillStyle='#1bad61';c.fillRect(x+2,y+2,10,10);}
   const canvas=document.createElement('canvas');canvas.width=320;canvas.height=220;const ctx=canvas.getContext('2d');
   const before=JSON.stringify({name:'Route101',x:0,y:0,width:20,height:20});
   const region={name:'Route101',x:0,y:0,width:20,height:20};
   const meta=sc.draw(ctx,{x:-90,y:-90},[region],{width:320,height:220,scale:2,official:{ensureChunk:()=>({value:{base:source}})}});
   return {meta,pixel:[...ctx.getImageData(40,40,1,1).data],unchanged:before===JSON.stringify(region),hasGeneratedTreeSprites:'treeSprite' in sc};
  }''')
  assert visual['meta']['officialTiles']>0,visual
  assert visual['meta']['placeholders']==0,visual
  assert visual['unchanged'] and not visual['hasGeneratedTreeSprites'],visual
  assert visual['pixel'][3]==255,visual
  report['checks'].append(device+': espelho dos tiles fornecidos pela fonte sem árvores artificiais')
  report['checks'].append(device+': entrada em jornada e sprites do jogo preservados')
  overflow=page.evaluate('document.documentElement.scrollWidth>innerWidth+3')
  assert not overflow,(device,overflow)
  assert not errs,(device,errs[:6]);report['errors']+=errs
  page.screenshot(path=str(ROOT/f'tests/v28_{device.lower()}_screen.png'),full_page=False)
  page.close()
 # Gate admin: sem config mostra instrução; não renderiza dados.
 page=browser.new_page(viewport={'width':900,'height':700})
 page.route('**/*',route_files)
 html=(ROOT/'admin/index.html').read_text().replace('<head>',f'<head><base href="https://{HOST}/admin/">',1)
 page.set_content(html,wait_until='domcontentloaded')
 page.wait_for_function("document.getElementById('adminGate')?.textContent.includes('Supabase')",timeout=10000)
 assert page.locator('#adminContent').is_hidden()
 report['checks'].append('admin nao mostra dados sem autenticacao/configuracao')
 page.close()
 browser.close()
 (ROOT/'tests/v28_browser_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
 print(json.dumps(report,ensure_ascii=False,indent=2))
