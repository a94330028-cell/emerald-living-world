'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const DEX=require('../server/dex.cjs');
const Pools=require('../jogo/game/pokemon/national-pools.js');
const Habitats=require('../jogo/game/pokemon/national-habitats.js');
const World=require('../server/world.cjs');
const Nav=require('../server/navigation.cjs');

test('all 1025 National species have an explicit saved simulator location policy',()=>{
 assert.equal(Object.keys(Habitats.ENTRIES).length,1025);
 for(const mon of DEX.PRIMARY){
  const meta=Pools.encounterInfo(mon),saved=Habitats.ENTRIES[mon.key];
  assert.ok(saved,`missing habitat: ${mon.key}`);
  assert.deepEqual(meta.locations,saved.locations);
  assert.ok(Number.isInteger(saved.minBadges)&&saved.minBadges>=0&&saved.minBadges<=8);
  assert.ok(['special','wild'].includes(saved.method));
  assert.equal(new Set(saved.locations).size,saved.locations.length);
  for(const area of saved.locations){assert.ok(Pools.AREA_DEFS[area],mon.key+' unknown area '+area);}
  if(saved.method==='special')assert.deepEqual(saved.locations,[]);
 }
});

test('named first routes are curated and species cannot spawn globally',()=>{
 const route=Pools.pool(DEX.PRIMARY,{location:'Route101',badges:0,matchHabitat:true}).map(x=>x.key);
 assert.ok(route.length>=3&&route.length<=9,route.length);
 assert.ok(route.includes('Zigzagoon')&&route.includes('Poochyena'));
 assert.ok(!route.includes('Tinkaton')&&!route.includes('Pecharunt'));
 for(const location of ['Littleroot','Rustboro','Mauville','Center','Mart','RandomLocation']){
  assert.deepEqual(Pools.pool(DEX.PRIMARY,{location,badges:8,champion:true}),[]);
 }
 assert.deepEqual(Pools.encounterInfo(DEX.BY_KEY.get('Pecharunt')).locations,[]);
});

test('Pokédex uses the same species-to-location list as the online wild table',()=>{
 const check=['Sprigatito','Mudkip','Pikachu','Tinkaton','Pecharunt'];
 for(const name of check){const mon=DEX.BY_KEY.get(name),info=Pools.encounterInfo(mon);
  for(const location of info.locations){
   assert.ok(Pools.pool(DEX.PRIMARY,{location,badges:8,champion:true,matchHabitat:true}).some(m=>m.key===name),name+'@'+location);
  }
 }
});

test('all adapted maps have accessible portals and no actor or wall on their arrival tiles',()=>{
 assert.ok(Object.keys(World.MAPS).length>=28);
 assert.deepEqual(World.validateWorld(),[]);
 let total=0;
 for(const [name,m] of Object.entries(World.MAPS)){
  for(const p of m.portals){
   const directions=Nav.localDirections(name,14,10,p.x,p.y,true);
   assert.ok(directions,`${name}->${p.to} inaccessible`);
   assert.ok(World.walkable(p.to,p.tx,p.ty));total++;
  }
  for(const a of m.npcs||[]){assert.equal(World.walkable(name,a.x,a.y),false);}
 }
 assert.ok(total>=61);
 const legacy={area:'Oldale',x:26,y:10,badges:0,story:{}};
 assert.equal(World.step(legacy,'right'),true);
 assert.equal(legacy.area,'Route103');
});

test('a trainer can route around NPCs, cannot walk through them, and respects a gym gate',()=>{
 const bot={area:'Route110',x:14,y:10,badges:2,story:{rival110:true}};
 assert.equal(World.step({...bot},'down'),false);
 const local=Nav.localDirections('Route110',14,10,14,12,false);
 assert.ok(local&&local.length>2);
 for(const direction of local)assert.equal(World.step(bot,direction),true);
 assert.deepEqual([bot.x,bot.y],[14,12]);
 const before={area:'Mauville',x:14,y:10,badges:2,story:{wally:false}};
 assert.equal(Nav.walkToward(before,{area:'MauvilleGym',x:14,y:10}).ok,false);
 before.story.wally=true;
 let arrived=false;
 for(let i=0;i<80;i++){
  const r=Nav.walkToward(before,{area:'MauvilleGym',x:14,y:10});
  assert.equal(r.ok,true);
  if(r.arrived){arrived=true;break}
 }
 assert.equal(arrived,true);
});

test('100 concurrent bots reach Rustboro with validated steps and cached paths',()=>{
 const start=Nav.stats();
 const bots=Array.from({length:100},(_,i)=>({id:'load-'+i,area:'Littleroot',x:14,y:10,badges:0,story:{}}));
 for(let turn=0;turn<200;turn++)for(const b of bots){
  const result=Nav.walkToward(b,{area:'Rustboro',x:14,y:11});
  assert.equal(result.ok,true,`${b.id}: ${result.reason}`);
  assert.ok(World.walkable(b.area,b.x,b.y),b.id+' invalid tile');
 }
 assert.equal(bots.filter(b=>b.area==='Rustboro'&&b.x===14&&b.y===11).length,100);
 const diff={builds:Nav.stats().builds-start.builds,hits:Nav.stats().hits-start.hits};
 assert.ok(diff.builds<1500,diff.builds);
 assert.ok(diff.hits>10000,diff.hits);
});
