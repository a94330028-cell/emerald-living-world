const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {frameIndex}=require('../../jogo/client/animation/trainer-frames.js');
test('all idle/walk frame rows map to one consistent direction',()=>{
 for(const [dir,row] of [[2,0],[0,1],[3,2],[1,3]]){
  assert.equal(frameIndex(dir,false,0,0),row*3);
  assert.equal(frameIndex(dir,true,.5,0),row*3+1);
  assert.equal(frameIndex(dir,true,.5,1),row*3+2);
  assert.equal(frameIndex(dir,true,.99,2),row*3+2);
 }
});
test('all animation atlases are now 32x48 and 96x192',()=>{
 for(const name of ['brendan','may','red','leaf']){
  const b=fs.readFileSync(path.join(__dirname,'../../jogo/assets/overworld/characters/',name+'.png'));
  assert.equal(b.subarray(1,4).toString(),'PNG');
  assert.equal(b.readUInt32BE(16),96);assert.equal(b.readUInt32BE(20),192);
 }
});
