const test=require('node:test'),assert=require('node:assert/strict');
const art=require('../../jogo/client/animation/trainer-sprites.js');
test('only 32x48 source atlas exists in centralized renderer',()=>{
 assert.equal(art.atlas().frameWidth,32);assert.equal(art.atlas().frameHeight,48);
 assert.equal(art.atlas('compact').frameWidth,32);
 for(const kind of art.IDS){assert.equal(art.frameRect(kind,2,false).sw,32);assert.equal(art.frameRect(kind,2,false).sh,48);}
});
test('4 directions have three correctly ordered steps for 32x48 sprites',()=>{
 for(const id of art.IDS)for(const [dir,row] of [[2,0],[0,1],[3,2],[1,3]]){
  for(const col of [0,1,2]){
   const r=art.frameRect(id,dir,col!==0,.5,col===2?1:0);
   assert.equal(r.sy,row*48);assert.equal(r.sx,col*32);
   assert.ok(r.sy+r.sh<=192&&r.sx+r.sw<=96);
  }
 }
});
test('hitbox is one tile footprint, never the full 48px drawing',()=>{
 const ctx={save(){},restore(){},fillRect(){},strokeRect(){}};
 for(const [w,h] of [[16,24],[32,48]]){
  const r=art.drawHitbox(ctx,'may',0,0,w,h);
  assert.equal(r.y+r.height,h);assert.equal(r.x+r.width/2,w/2);
  assert.ok(r.height<=16);
 }
});
