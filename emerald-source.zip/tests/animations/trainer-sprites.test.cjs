const test=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs');const path=require('node:path');const Sprites=require('../../jogo/client/animation/trainer-sprites.js');
test('20 user supplied characters all use exact 32x48 frames',()=>{
 assert.equal(Sprites.IDS.length,20);
 for(const name of Sprites.IDS){
  const def=Sprites.get(name);
  assert.equal(def.id,name);assert.equal(def.atlas.frameWidth,32);assert.equal(def.atlas.frameHeight,48);
  const png=fs.readFileSync(path.join(__dirname,'../../jogo/assets/overworld/characters',name+'.png'));
  assert.equal(png.subarray(1,4).toString(),'PNG');
  assert.equal(png.readUInt32BE(16),96);assert.equal(png.readUInt32BE(20),192);
 }
});
test('frame selection respects idle/walking and exact direction',()=>{
 assert.deepEqual(Sprites.frameRect('red',2,false,0,0),{index:0,sx:0,sy:0,sw:32,sh:48});
 assert.deepEqual(Sprites.frameRect('may',0,false,0,0),{index:3,sx:0,sy:48,sw:32,sh:48});
 assert.deepEqual(Sprites.frameRect('leaf',3,true,.5,0),{index:7,sx:32,sy:96,sw:32,sh:48});
 assert.deepEqual(Sprites.frameRect('serena',1,true,.5,1),{index:11,sx:64,sy:144,sw:32,sh:48});
});
