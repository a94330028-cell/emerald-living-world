'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const face=require('../../jogo/client/animation/movement-facing.js');

test('a 16-pixel tile step faces its real movement, with all four cardinal directions',()=>{
 assert.equal(face.fromStep(2,2,2,1),0);
 assert.equal(face.fromStep(2,2,3,2),1);
 assert.equal(face.fromStep(2,2,2,3),2);
 assert.equal(face.fromStep(2,2,1,2),3);
 assert.equal(face.fromStep(2,2,3,3),null);
 assert.equal(face.fromStep(2,2,2,2),null);
 assert.equal(face.fromStep(2,2,29,29),null);
});
test('blocked input, idle frames and map warps cannot spin the player sprite',()=>{
 assert.equal(face.hold(1,{x:4,y:5},{x:4,y:5}),1);
 assert.equal(face.hold(3,{x:4,y:5},{x:60,y:90}),3);
 assert.equal(face.hold(2,{x:4,y:5},{x:5,y:5}),1);
 assert.equal(face.hold(1,{x:5,y:5},{x:5,y:4}),0);
});
test('path cleanup removes ABAB loops without skipping any collision-grid step',()=>{
 const start={x:1,y:1};
 const withLoop=[{x:2,y:1},{x:3,y:1},{x:2,y:1},{x:3,y:1},{x:4,y:1},{x:4,y:2}];
 const cleaned=face.removeLoops(start,withLoop);
 assert.deepEqual(cleaned,[{x:2,y:1},{x:3,y:1},{x:4,y:1},{x:4,y:2}]);
 assert.equal(face.turns(start,cleaned),1);
 assert.equal(face.removeLoops(start,[{x:2,y:2}]),null);
});
test('wandering stationary NPCs no longer rotate through four directions without walking',()=>{
 const nav=require('../../jogo/game/navigation/core.js');
 const code=fs.readFileSync(path.join(__dirname,'../../jogo/js/official-runtime.js'),'utf8');
 const root={EmeraldNavigation:nav,EmeraldMovementFacing:face,emeraldOptions:{speed:0},emeraldTrainers:[]};
 vm.runInNewContext(code,{window:root,Date,Math,DataView,Uint8Array,ArrayBuffer,Int32Array,Promise,AbortController,setTimeout,clearTimeout,fetch:()=>Promise.reject(Error('offline'))});
 const map={name:'TestTurners',meta:{object_events:[
  {x:2,y:2,trainer_type:'TRAINER_TYPE_NORMAL',movement_type:'MOVEMENT_TYPE_WANDER_AROUND',trainer_sight_or_berry_tree_id:3,flag:'0'},
  {x:4,y:2,trainer_type:'TRAINER_TYPE_NORMAL',movement_type:'MOVEMENT_TYPE_FACE_DOWN_UP',trainer_sight_or_berry_tree_id:3,flag:'0'},
 ]}};
 const [wander,look]=root.emeraldOfficialWorld.trainerSentries(map);
 assert.equal(wander.rotating,false);
 assert.equal(root.emeraldOfficialWorld.sentryFacing(wander,0),root.emeraldOfficialWorld.sentryFacing(wander,50000));
 assert.equal(look.rotating,true);
 assert.equal(root.emeraldOfficialWorld.sentryFacing(look,10000),root.emeraldOfficialWorld.sentryFacing(look,14000));
});
