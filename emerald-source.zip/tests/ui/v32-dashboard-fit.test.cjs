'use strict';
const {test}=require('node:test'), assert=require('node:assert/strict');
const fs=require('node:fs'), path=require('node:path');
const root=path.resolve(__dirname,'../..'), site=path.join(root,'jogo');
const read=n=>fs.readFileSync(path.join(site,n),'utf8');
test('all bundled Hoenn sprite images have a new fitted counterpart',()=>{
 const dest=path.join(site,'assets/pokemon_fit');
 const originals=['rom_pokemon','pokemon'].flatMap(folder=>fs.readdirSync(path.join(site,'assets',folder)).filter(name=>/\.(?:png|gif)$/.test(name)));
 assert.equal(originals.length,432);
 for(const name of originals)assert(fs.statSync(path.join(dest,name)).size>0,`Missing ${name}`);
 const art=read('js/pokemon-art.js');
 assert.match(art,/assets\/pokemon_fit\/mudkip\.png/);
 assert.match(art,/assets\/pokemon_fit\/mudkip\.gif/);
});
test('mobile dashboard has manual choices, top six, and 1x equals old 40x',()=>{
 const bot=read('js/my-bot.js'),style=read('css/pokemon-sprite-fit-v32.css');
 assert.match(bot,/data-journey-action="story"/);
 assert.match(bot,/data-journey-action="explore"/);
 assert.match(bot,/botTopSixList/);
 assert.match(style,/object-fit:contain/);
 const speed=require(path.join(site,'game/simulation/speed.js'));
 assert.equal(speed.effectiveMultiplier(1),40);
 assert.equal(speed.effectiveMultiplier(5),200);
});
