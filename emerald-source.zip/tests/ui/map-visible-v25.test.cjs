const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname,'../..');
const read = relative => fs.readFileSync(path.join(root,relative),'utf8');

test('Jogo has the real canvas BEFORE expandable camera / collision tools in static HTML',()=>{
 const html = read('jogo/index.html');
 const panelStart = html.indexOf('<section class="directorPanel" id="directorPanel"');
 const canvas = html.indexOf('id="liveWorld"',panelStart);
 const tools = html.indexOf('id="classicMapTools"',panelStart);
 assert(panelStart>=0 && canvas>panelStart && tools>canvas);
 assert.match(html,/<details id="classicMapTools" class="classicMapTools"/);
 assert.match(html,/<canvas id="liveWorld" width="640" height="416"/);
});

test('switching from the welcome screen cannot move canvas before a missing DOM anchor',()=>{
 const js = read('jogo/js/personal-landing.js');
 assert.match(js,/originalAnchor\?\.parentElement===originalStage/);
 assert.match(js,/originalStage\.insertBefore\(part,anchor\|\|null\)/);
});

test('saved progress logic remains separate from visual map placement',()=>{
 const html = read('jogo/index.html');
 assert.match(html,/js\/engine\.js\?v=[\w-]+/);
 assert.match(html,/js\/pokemon-illustrated-ui\.js\?v=[\w-]+/);
 assert.match(html,/js\/personal-landing\.js\?v=25-resume/);
});
