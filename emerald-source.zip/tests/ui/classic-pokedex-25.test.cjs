const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.join(__dirname,'../../jogo');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('classic 2.5 keeps game, dex, rank tabs and all older project pages',()=>{
 const html=read('index.html');
 for(const id of ['gamePage','page-pokedex','page-ranking','page-creditos','page-historico','page-recuperacao','page-config','page-mapa','directorPanel','classicDexSearch','classicDexEntries','classicDexDetails']){
  assert.match(html,new RegExp(`id="${id}"`),`missing ${id}`);
 }
 assert.match(html,/css\/emerald-classic-25\.css/);
 assert.match(html,/js\/emerald-classic-dex\.js/);
 for(const id of ['jogo','pokedex','ranking'])assert.match(html,new RegExp(`data-page="${id}"`));
});

test('Pokédex presents real national species and correctly grouped generation ranges',()=>{
 const d=JSON.parse(read('data/quetzal-catalog.json'));
 const rows=d.pokemon.filter(x=>x.kind==='species'&&Number.isInteger(x.dex)&&x.dex>=1&&x.dex<=1025);
 assert.equal(rows.length,1025);
 assert.equal(rows.filter(x=>x.dex>=252&&x.dex<=386).length,135);
 const dex=read('js/emerald-classic-dex.js');
 assert.match(dex,/fetch\('data\/quetzal-catalog\.json'\)/);
 assert.match(dex,/\.addEventListener\('input',filter\)/);
 assert.match(dex,/\.addEventListener\('click',\(\)=>choose/);
});

test('new visual resources are local and do not modify game save keys',()=>{
 const css=read('css/emerald-classic-25.css');
 const art=path.join(root,'assets/ui/hoenn-pixel-banner.png');
 assert.ok(fs.existsSync(art));
 assert.match(css,/\.pokedexDevice/);
 assert.match(css,/\.pokedexEntry\[aria-selected=true\]/);
 assert.match(css,/image-rendering:pixelated/);
 const dex=read('js/emerald-classic-dex.js');
 assert.doesNotMatch(dex,/localStorage\.|sessionStorage\.|indexedDB\.|deleteDatabase/);
});
