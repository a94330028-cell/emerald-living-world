'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const ROOT=path.resolve(__dirname,'../..');
const html=fs.readFileSync(path.join(ROOT,'jogo/index.html'),'utf8');
const bot=fs.readFileSync(path.join(ROOT,'jogo/js/my-bot.js'),'utf8');
const pages=fs.readFileSync(path.join(ROOT,'jogo/js/pages.js'),'utf8');
const engine=fs.readFileSync(path.join(ROOT,'jogo/js/engine.js'),'utf8');

test('exactly three main tabs in header and bottom navigation',()=>{
 const header=html.match(/<nav class="siteNav"[^>]*>([\s\S]*?)<\/nav>/)?.[1];
 const bottom=html.match(/<div class="bottomNav"[^>]*>([\s\S]*?)<\/div>/)?.[1];
 assert.ok(header&&bottom);
 const main=[...header.matchAll(/data-page="([^"]+)"/g)].map(x=>x[1]);
 const mobile=[...bottom.matchAll(/data-page="([^"]+)"/g)].map(x=>x[1]);
 assert.deepEqual(main,['jogo','pokedex','ranking']);
 assert.deepEqual(mobile,main);
 assert.match(bottom,/id="bottomMore" hidden/);
});
test('solo party appears before original shared world canvas mount',()=>{
 const first=bot.indexOf('<section class="personalPartyCard"');
 const map=bot.indexOf('<section class="personalWorldCard"');
 assert.ok(first>0&&map>first);
 assert.match(bot,/id="botRoster"/);
 assert.match(bot,/id="myBotMapMount"/);
});
test('badge ranking separated from power statistics and both route in the app',()=>{
 assert.ok(html.includes('id="page-forca"'));
 assert.ok(html.includes('id="forceStrongTeams"'));
 assert.ok(html.includes('id="forceStrongestPokemon"'));
 assert.ok(html.includes('id="forceTopSix"'));
 assert.match(engine,/badgeSorted=\[\.\.\.trainers\]/);
 assert.match(engine,/\$\('#ranking'\)\.innerHTML=badgeSorted/);
 assert.match(pages,/page==='jogo'&&document\.body\.dataset\.worldMode==='player'/);
});
