const test=require('node:test');
const assert=require('node:assert/strict');
const {readFileSync}=require('node:fs');
const {join}=require('node:path');
const base=join(__dirname,'../../jogo');
const html=readFileSync(join(base,'index.html'),'utf8');
const js=readFileSync(join(base,'js/clean-navigation-v99.js'),'utf8');
const bot=readFileSync(join(base,'js/my-bot.js'),'utf8');
const css=readFileSync(join(base,'css/home-team-25.css'),'utf8');

test('home page keeps the map and exposes six full Pokémon slots below the trainer',()=>{
 assert.match(html,/id="liveWorld"/);
 assert.match(html,/id="watchTrainerPortrait"/);
 assert.match(html,/id="watchPartyCards"/);
 assert.match(html,/id="watchFullTeamCards"/);
 assert.ok(html.indexOf('id="watchFullTeamCards"')>html.indexOf('id="watchPartyCards"'));
 assert.match(html,/home-team-25\.css\?v=25-full-team-1/);
});
test('team render includes name, level, HP, power, known moves, and actual Pokémon details',()=>{
 assert.match(js,/Array\.from\(\{length:6\}/);
 for(const marker of ['homeMonIdentity','homeHpBar','homeMonStats','homeMoveChips','EmeraldMonDetails?.html(m)'])assert.ok(js.includes(marker),marker);
 assert.match(js,/const expanded=new Set/);
 assert.match(js,/if\(expanded\.has\(d\.dataset\.teamSlot\)\)d\.open=true/);
 assert.match(bot,/personalKnownMoves/);
});
test('home team grids work on Android and in both Emerald and dark themes',()=>{
 assert.match(css,/grid-template-columns:repeat\(3,minmax\(0,1fr\)\)/);
 assert.match(css,/@media\(max-width:540px\)/);
 assert.match(css,/data-poke-theme="dark"/);
 assert.match(css,/personalParty/);
});
