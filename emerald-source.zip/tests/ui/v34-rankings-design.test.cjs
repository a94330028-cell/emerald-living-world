'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.join(__dirname,'../..');
const rank=require('../../jogo/js/trainer-rankings-v34.js');
const html=fs.readFileSync(path.join(root,'jogo/index.html'),'utf8');
const bot=fs.readFileSync(path.join(root,'jogo/js/my-bot.js'),'utf8');
test('strongest team uses engine strength and only active team members',()=>{
 const weak={id:1,name:'Fraco',team:[{species:'Magikarp'}],stage:27};
 const strong={id:2,name:'Forte',team:[{species:'Mudkip'},{species:'Treecko'}],pc:[{species:'Rayquaza'}],stage:2};
 const rankData=rank.ranks([weak,strong],t=>t.id===2?300:120);
 assert.equal(rankData.strength[0].t.name,'Forte');assert.equal(rankData.strength[0].score,300);
 assert.equal(rankData.story[0].t.name,'Fraco');
});
test('champion beats non-champion; same story stage ranks by league rounds',()=>{
 const x={name:'Gym',stage:26,badges:7};
 const y={name:'League round 4',stage:27,leagueRound:4,badges:8};
 const z={name:'League round 2',stage:27,leagueRound:2,badges:8};
 const champion={name:'Champion',stage:27,leagueRound:5,badges:8,champion:true};
 assert.deepEqual(rank.ranks([x,z,champion,y],()=>1).story.map(r=>r.t.name),['Champion','League round 4','League round 2','Gym']);
 assert.equal(rank.progressValue(champion),100);assert.match(rank.chapter(y),/Liga Pokémon/);
});
test('main landing has no links to broken multiplayer and rank has two trainer boards',()=>{
 assert.doesNotMatch(html,/href="online\.html"/);
 assert.doesNotMatch(html,/Mundo multiplayer Beta|TOP 6 — POKÉMON MAIS FORTES/);
 assert.match(html,/id="rankStrongTeams"/);assert.match(html,/id="rankStoryProgress"/);
 assert.match(html,/v34-modern-layout\.css/);
 assert.match(bot,/times mais fortes|Times mais fortes/);assert.match(bot,/História mais avançada/);
});
