"""Emerald Living World V3.5: isolated offline mobile tutorial checks."""
from pathlib import Path
import re,json
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
SITE=ROOT/'jogo'
source=(SITE/'index.html').read_text()
scripts=[]
def inline_js(m):
    p=(SITE/m.group(1).split('?',1)[0]).resolve()
    if not p.is_relative_to(SITE) or not p.is_file():return m.group(0)
    scripts.append((p.name,p.read_text()))
    return ''
source=re.sub(r'<script\b[^>]*\bsrc="([^"]+)"[^>]*>\s*</script>',inline_js,source,flags=re.I)
def inline_css(m):
    p=(SITE/m.group(1).split('?',1)[0]).resolve()
    return '<style>'+p.read_text()+'</style>' if p.is_relative_to(SITE) and p.is_file() else m.group(0)
source=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"[^>]*>',inline_css,source,flags=re.I)
source=source.replace('</body>','\n'.join('<script>'+code.replace('</script','<\\/script')+'\n//# sourceURL=elw/'+name+'</script>' for name,code in scripts)+'</body>')
report={'checks':[],'errors':[]}
with sync_playwright() as p:
    b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    page=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
    page.on('pageerror',lambda e:report['errors'].append(str(e)[:300]))
    page.route('**/*',lambda r:r.abort())
    page.evaluate('''() => {
      const storage={};const api={getItem:k=>storage[k]??null,setItem:(k,v)=>{storage[k]=String(v)},removeItem:k=>{delete storage[k]}};
      Object.defineProperty(window,'localStorage',{configurable:true,value:api});
      Object.defineProperty(window,'sessionStorage',{configurable:true,value:api});
      window.fetch=async()=>new Response('[]',{status:200,headers:{'Content-Type':'application/json'}});
    }''')
    page.set_content(source,wait_until='domcontentloaded',timeout=35000)
    page.wait_for_timeout(800)
    assert page.locator('#elwLearnBanner').is_visible(),'welcome tutorial prompt must be visible on first visit'
    assert not page.evaluate('document.documentElement.scrollWidth > innerWidth + 3'),'landing horizontal overflow'
    page.locator('#elwLearnBanner [data-guide-open]').click()
    assert page.locator('#guideDialog').is_visible()
    assert 'Bem-vindo' in page.locator('#guideTitle').inner_text()
    assert page.locator('#elwTutorialProgress').get_attribute('aria-valuenow')=='1'
    report['checks'].append('first-visit entry tutorial opens correctly')
    for i in range(1,7):
        page.locator('#elwTutorialNext').click()
        assert page.locator('#elwTutorialProgress').get_attribute('aria-valuenow')==str(i+1)
        assert page.locator('#elwTutorialItems .elw-tutorial-item').count()==3
    assert 'Pronto' in page.locator('#guideTitle').inner_text()
    assert page.locator('#elwTutorialNext').inner_text().startswith('✓')
    page.screenshot(path=str(ROOT/'tests/v35_tutorial_mobile.png'))
    page.locator('#elwTutorialBack').click()
    assert page.locator('#elwTutorialProgress').get_attribute('aria-valuenow')=='6'
    page.locator('#elwTutorialNext').click()
    page.locator('#elwTutorialNext').click()
    assert not page.locator('#guideDialog').is_visible()
    assert page.locator('#elwLearnBanner').is_hidden()
    assert page.evaluate('localStorage.getItem("elw_onboarding_v35_completed")')=='1'
    report['checks'].append('next/back, completion and one-time landing banner')
    page.locator('#landingWorld').click(force=True)
    page.wait_for_timeout(300)
    page.locator('#navMore').click(force=True)
    assert page.locator('.elw-drawer-guide').is_visible()
    page.locator('.elw-drawer-guide').click()
    assert page.locator('#guideDialog').is_visible()
    page.evaluate('document.documentElement.dataset.pokeTheme="dark"')
    color=page.locator('#guideDialog').evaluate('(e)=>getComputedStyle(e).backgroundColor')
    assert color in ('rgb(16, 27, 37)','rgb(16, 27, 37)') ,color
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth+3')
    assert page.locator('#elwTutorialNext').is_visible()
    report['checks'].append('reopen from header and dark mode contrast on 390px Android')
    page.screenshot(path=str(ROOT/'tests/v35_tutorial_dark.png'))
    page.locator('#closeGuide').click()
    page.set_viewport_size({'width':320,'height':640})
    page.locator('#navMore').click(force=True)
    page.locator('.elw-drawer-guide').click()
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth + 3')
    assert page.locator('#elwTutorialNext').bounding_box()['x']>0
    assert page.locator('#guideDialog').bounding_box()['width']<=320
    report['checks'].append('tutorial navigation remains usable at 320px viewport')
    page.screenshot(path=str(ROOT/'tests/v35_tutorial_small.png'))
    b.close()
(ROOT/'tests/v35_tutorial_browser_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
