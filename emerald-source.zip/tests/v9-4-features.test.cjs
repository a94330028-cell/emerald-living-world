'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const Starters=require('../jogo/game/pokemon/starters.js');
const Pools=require('../jogo/game/pokemon/national-pools.js');
const Dex=require('../server/dex.cjs');
const Battle=require('../server/battle.cjs');
const Bots=require('../server/autonomy.cjs');
const root=path.resolve(__dirname,'..');
test('27 starters from 9 generations are supported by both engines and new server bots',()=>{
 assert.equal(Starters.ALL.length,27);assert.equal(Starters.TRIOS.length,9);
 assert.equal(new Set(Starters.ALL).size,27);
 for(const [i,name] of Starters.ALL.entries()){
  assert.ok(Battle.SPEC[name],`${name} unsupported`);
  assert.ok(Battle.create(name,5).maxHp>0);
  assert.equal(Starters.GENERATION[name],Math.floor(i/3)+1);
 }
 const samples=Array.from({length:27},(_,i)=>Bots.createBot(i+1));
 assert.equal(new Set(samples.map(b=>b.starter)).size,27);
 assert.equal(samples[0].starter,'Treecko');
});
test('evolving a starter after real gained EXP updates HP, attack, speed, and persists IV/EV',()=>{
 const mon=Battle.create('Sprigatito',15),before={species:mon.species,ivs:{...mon.ivs},evs:{...mon.evs},maxHp:mon.maxHp,atk:Battle.stat(mon,'atk'),spe:Battle.stat(mon,'spe')};
 const opponent=Battle.create('Chansey',50),log=[];
 for(let i=0;i<12&&mon.species==='Sprigatito';i++)Battle.grantExp(mon,opponent,{badges:1},log);
 assert.equal(mon.species,'Floragato',log.join('\n'));
 assert.ok(mon.maxHp>before.maxHp);assert.ok(Battle.stat(mon,'atk')>before.atk);
 assert.ok(Battle.stat(mon,'spe')>before.spe);
 assert.deepEqual(mon.ivs,before.ivs);assert.deepEqual(mon.evs,before.evs);
 assert.ok(log.some(e=>e.includes('evoluiu')));
 const saved=JSON.parse(JSON.stringify(mon));assert.equal(saved.species,'Floragato');
});
test('National wild locations are fixed, repeatable and do not exist inside safe towns',()=>{
 const e=Dex.PRIMARY.find(x=>x.key==='Sprigatito');
 const positions=Pools.locationsFor(e);
 assert.ok(positions.length>0,positions.join(','));
 assert.deepEqual(Pools.locationsFor(e),positions);
 assert.ok(positions.includes('Woods'));
 assert.equal(Pools.hasEncounters('Rustboro'),false);
 assert.equal(Pools.hasEncounters('Mauville'),false);
 assert.equal(Pools.pool(Dex.PRIMARY,{location:'Rustboro',champion:true}).length,0);
 const possible=Pools.pool(Dex.PRIMARY,{location:'Woods',badges:0});
 assert.ok(possible.length>0);
 assert.ok(possible.every(row=>Pools.locationsFor(row).includes('Woods')));
 for(let i=0;i<75;i++)assert.ok(Pools.locationsFor(Pools.pick(Dex.PRIMARY,{location:'Woods',badges:0})).includes('Woods'));
});
test('wild battle rejects cities and uses only that specific route pool',()=>{
 const p={starter:'Mudkip',badges:0,area:'Littleroot',team:[Battle.create('Mudkip',5)],bag:{pokeballs:5}};
 assert.throws(()=>Battle.begin(p,{type:'wild',national:true}),/indisponíveis/);
 p.area='Route101';for(let i=0;i<40;i++){
  const b=Battle.begin(p,{type:'wild',national:true});
  assert.ok(Pools.locationsFor(Battle.DEX.BY_KEY.get(b.enemy.species)).includes('Route101')||Battle.AREAS.Route101.includes(b.enemy.species));
  p.battle=null;
 }
});
test('offline page has exactly one visible team grid plus an accessible team shortcut',()=>{
 const html=fs.readFileSync(path.join(root,'jogo/index.html'),'utf8');
 assert.ok(html.includes('id="team" class="team"'));
 assert.ok(html.includes('id="oneTeamViewer"'));
 assert.ok(html.includes('id="liveTeam" class="liveTeam" aria-live="off" style="display:none"'));
 assert.ok(html.includes('MAIS AVANÇADOS NA HISTÓRIA'));
});
test('server and online client include top six live owned Pokémon',()=>{
 const app=fs.readFileSync(path.join(root,'server/app.cjs'),'utf8');
 const client=fs.readFileSync(path.join(root,'jogo/multiplayer/client.js'),'utf8');
 assert.ok(app.includes("'/api/top-pokemon'"));
 assert.ok(app.includes('.slice(0,6)'));
 assert.ok(client.includes("getApi('top-pokemon')"));
});

test('live online API accepts a ninth-generation starter and returns six strongest owned Pokémon',async t=>{
 const os=require('node:os');
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'emerald-v94-top6-'));
 process.env.DATA_DIR=temp;
 const app=require('../server/app.cjs');
 const server=await app.start(0,'127.0.0.1');
 t.after(async()=>{await app.stop();fs.rmSync(temp,{recursive:true,force:true});});
 const origin=`http://127.0.0.1:${server.address().port}`;
 const guest=await fetch(`${origin}/api/session`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name:'Prova V9.4',starter:'Sprigatito',mode:'online',channel:1,avatar:'may'})});
 assert.equal(guest.status,200);
 const session=await guest.json();assert.equal(session.profile.starter,'Sprigatito');
 const cookie=guest.headers.get('set-cookie').split(';')[0];
 for(let i=0;i<6;i++){
  const peer=await fetch(`${origin}/api/session`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name:'Treinador '+i,starter:Starters.ALL[i],mode:'online',channel:1,avatar:'brendan'})});
  assert.equal(peer.status,200);
 }
 const response=await fetch(`${origin}/api/top-pokemon`,{headers:{cookie}});
 assert.equal(response.status,200);
 const result=await response.json();
 assert.equal(result.top.length,6);
 assert.ok(result.top.every(x=>x.owner&&x.species&&x.level>=1&&Number.isInteger(x.power)&&x.power>0));
 for(let i=1;i<result.top.length;i++)assert.ok(result.top[i-1].power>=result.top[i].power);
});
