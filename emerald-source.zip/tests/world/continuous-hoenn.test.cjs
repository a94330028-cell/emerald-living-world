'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const world=require('../../jogo/game/world/continuous-hoenn.js');
function map(name,width,height,connections=[],warps=[]){
 return {name,width,height,meta:{map_type:'MAP_TYPE_ROUTE',connections,
  warp_events:warps}};
}
function sim(maps){
 const cache=new Map(Object.entries(maps).map(([key,value])=>[key,{value}]));
 const loaded=[];
 const api={cache,resolve:n=>n,mapName:n=>n,ensureNav:async name=>{
  loaded.push(name);if(!cache.has(name))cache.set(name,{value:map(name,20,15)});
  return cache.get(name).value;}};
 return {world:world.createWorld(api),loaded,cache};
}
test('Hoenn list covers all 34 numbered external routes plus cities and islands',()=>{
 for(let n=101;n<=134;n++)assert(world.OUTDOORS.has(`Route${n}`));
 for(const x of ['LittlerootTown','OldaleTown','RustboroCity','FallarborTown',
  'FortreeCity','LilycoveCity','PacifidlogTown','SootopolisCity',
  'EverGrandeCity','JaggedPass','MtChimney'])assert(world.OUTDOORS.has(x));
 for(const x of ['PetalburgWoods','RusturfTunnel','FieryPath','VictoryRoad_1F'])
  assert(!world.OUTDOORS.has(x));
});
test('official offset stitches Route101 north of Littleroot without fake door',()=>{
 const maps={LittlerootTown:map('LittlerootTown',20,18,[{direction:'up',offset:-3,map:'Route101'}]),
  Route101:map('Route101',25,30,[{direction:'down',offset:3,map:'LittlerootTown'}])};
 const s=sim(maps),w=s.world;
 assert.deepEqual(w.seed('LittlerootTown'),{name:'LittlerootTown',x:0,y:0,width:20,height:18,component:1});
 assert.equal(w.position('Route101').x,-3);
 assert.equal(w.position('Route101').y,-30);
 assert.deepEqual(w.position('LittlerootTown'),{name:'LittlerootTown',x:0,y:0,width:20,height:18,component:1});
});
test('warp transitions never stitch Petalburg Woods or Sootopolis across the sea',()=>{
 const s=sim({Route104:map('Route104',32,44,[],[{dest_map:'PetalburgWoods'}]),
  Route126:map('Route126',48,42,[],[{dest_map:'SootopolisCity'}]),
  SootopolisCity:map('SootopolisCity',22,19)}),w=s.world;
 w.seed('Route104');w.seed('Route126');
 assert.equal(w.position('SootopolisCity'),null);
 w.seed('SootopolisCity');
 assert.notEqual(w.position('Route126').component,w.position('SootopolisCity').component);
 assert.equal(w.position('PetalburgWoods'),null);
});
test('nearby border prefetches only connected map, not whole region',async()=>{
 const maps={Route119:map('Route119',20,80,[{direction:'up',offset:0,map:'FortreeCity'},
  {direction:'down',offset:0,map:'Route118'},
  {direction:'left',offset:0,map:'Route111'}])};
 const s=sim(maps),w=s.world;w.seed('Route119');
 w.prefetchNear('Route119',15,4,10);
 await new Promise(r=>setTimeout(r,5));
 assert(s.loaded.includes('FortreeCity'));
 assert(!s.loaded.includes('Route118'));
 assert(!s.loaded.includes('Route111'));
 assert.equal(w.metrics().inflight,0);
});
test('viewport emits only 16x16 on-screen chunks and ignores other components',()=>{
 const maps={Route101:map('Route101',64,64),Route131:map('Route131',50,40)};
 const s=sim(maps),w=s.world;w.seed('Route101');w.seed('Route131');
 w.seed('Route101');const rects=w.visible({x:0,y:0,width:320,height:208});
 assert.equal(rects.length,1);assert.equal(rects[0].name,'Route101');
 const chunks=w.chunks(rects[0],{x:0,y:0,width:320,height:208});
 assert.equal(chunks.length,2);
 assert(chunks.every(c=>c.cx<=1&&c.cy===0));
});
test('adjacent separately discovered components merge after official edge is known',()=>{
 const maps={Route101:map('Route101',22,24),OldaleTown:map('OldaleTown',20,22)};
 const s=sim(maps),w=s.world;w.seed('Route101');w.seed('OldaleTown');
 assert.notEqual(w.position('Route101').component,w.position('OldaleTown').component);
 maps.Route101.meta.connections.push({direction:'down',offset:2,map:'OldaleTown'});
 w.seed('Route101');
 assert.equal(w.position('Route101').component,w.position('OldaleTown').component);
 assert.equal(w.position('OldaleTown').x,2);
 assert.equal(w.position('OldaleTown').y,24);
});
