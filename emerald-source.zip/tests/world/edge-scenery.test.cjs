'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const scenery=require('../../jogo/game/world/edge-scenery.js');
const area=(name,x,y,width=20,height=20)=>({name,x,y,width,height});
test('somente regiões oficiais definem o bioma da borda',()=>{
 for(const [name,biome] of [['Route101','forest'],['LittlerootTown','forest'],['Route124','sea'],['MossdeepCity','sea'],['JaggedPass','rocky']])
  assert.equal(scenery.biomeForName(name),biome);
});
test('borda não espelha pedaços contendo casas ou caminhos',()=>{
 assert.equal(scenery.TILE,16);
 assert.equal(scenery.PATCH,64);
 assert.equal('reflectTile' in scenery,false);
 assert.equal('sourceAt' in scenery,false);
 const ctx={save(){},restore(){},set imageSmoothingEnabled(v){},set fillStyle(s){this.color=s},fillRect(){},drawImage(){throw Error('Não deveria copiar mapa sem fonte verificada')}};
 const rect=area('Route101',0,0),original=JSON.stringify(rect);
 let unsolicited=0;
 const official={ensureChunk(){unsolicited++;throw Error('Não solicitar downloads sem mapa oficial carregado')},cache:new Map()};
 const stats=scenery.draw(ctx,{x:-100,y:-100},[rect],{width:320,height:220,scale:2,official});
 assert.ok(stats.placeholders>0);
 assert.equal(stats.trees,0);
 assert.equal(stats.officialTiles,0);
 assert.equal(unsolicited,0);
 assert.equal(JSON.stringify(rect),original);
});
test('áreas marítimas não recebem árvores nem verde falso',()=>{
 const paints=[],ctx={save(){},restore(){},set imageSmoothingEnabled(v){},set fillStyle(s){this.color=s},fillRect(){paints.push(this.color)},drawImage(){throw Error('Não desenhar árvores no oceano')}};
 const stats=scenery.draw(ctx,{x:-80,y:-96},[area('Route124',0,0)],{width:320,height:220,scale:2});
 assert.ok(stats.sea>0);
 assert.equal(stats.trees,0);
 assert.ok(paints.every(c=>c==='#2878a4'));
});
test('amostra candidata exige vegetação com contraste e cobertura bloqueada',()=>{
 const W=64,buf=new Uint8ClampedArray(W*W*4);
 for(let y=0;y<W;y++)for(let x=0;x<W;x++){
  const at=(y*W+x)*4;
  buf[at]=120;buf[at+1]=120;buf[at+2]=120;buf[at+3]=255;
 }
 assert.equal(scenery.patchScore(buf,W,0,0,{},{},0,{walkable:()=>true}),-1);
 assert.equal(scenery.patchScore(buf,W,0,0,null,0,0,null),-1);
});
