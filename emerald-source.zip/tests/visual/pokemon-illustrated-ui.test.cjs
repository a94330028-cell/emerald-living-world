const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const dir=path.join(__dirname,'../../jogo');
const html=fs.readFileSync(path.join(dir,'index.html'),'utf8');
const css=fs.readFileSync(path.join(dir,'css/pokemon-illustrated-25.css'),'utf8');
const js=fs.readFileSync(path.join(dir,'js/pokemon-illustrated-ui.js'),'utf8');
test('classic design has real markup for portrait, team, and a working theme control',()=>{
 for(const id of ['themeToggle','watchTrainerPortrait','watchPartyCards','classicTrainerPC','pokedexDevice','rankStoryProgress'])assert.match(html,new RegExp(`id="${id}"`));
 assert.match(html,/pokemon-illustrated-25\.css/);
 assert.match(html,/pokemon-illustrated-ui\.js/);
 assert.match(js,/window\.emeraldMyBot/);
 assert.match(js,/localStorage\.setItem\(themeKey/);
 assert.match(js,/classicTrainerPC/);
});
test('styling contains separate Emerald and night palettes, with same six partner slots',()=>{
 assert.match(css,/html\[data-poke-theme="dark"\]/);
 assert.match(css,/classicPcMons/);
 assert.match(css,/grid-template-columns:repeat\(6,minmax\(0,1fr\)\)/);
 assert.match(css,/\.pokedexDevice/);
});
test('actual supplied 32x48 sprite atlas for trainer portrait is present',()=>{
 for(const id of ['brendan','may','red','leaf']){
  const png=fs.readFileSync(path.join(dir,`assets/overworld/characters/${id}.png`));
  assert.equal(png.subarray(1,4).toString(),'PNG');
  assert.equal(png.readUInt32BE(16),96);
  assert.equal(png.readUInt32BE(20),192);
 }
});
