"""V9.4 browser proof: Android DOM, starters, single visible team, top-6, and UI errors."""
from pathlib import Path
from urllib.parse import urlparse,unquote
import json,mimetypes
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
base='https://emerald-test.local/jogo/'
html=(ROOT/'jogo/index.html').read_text(encoding='utf-8').replace('<head>',f'<head><base href="{base}">',1)
errors=[]
def asset(route):
 u=urlparse(route.request.url)
 if u.hostname!='emerald-test.local': return route.abort('failed')
 path=(ROOT/unquote(u.path).lstrip('/')).resolve()
 if not path.is_relative_to(ROOT) or not path.is_file():return route.fulfill(status=404,body='missing')
 return route.fulfill(status=200,body=path.read_bytes(),content_type=mimetypes.guess_type(path.name)[0] or 'application/octet-stream')
with sync_playwright() as play:
 browser=play.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 page.route('**/*',asset)
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('dialog',lambda d:d.accept())
 page.evaluate("""() => { const data = new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>data.has(k)?data.get(k):null,setItem:(k,v)=>data.set(k,String(v)),removeItem:k=>data.delete(k),clear:()=>data.clear()}}); }""")
 page.set_content(html,wait_until='load',timeout=30000)
 page.wait_for_function('window.emeraldTrainers?.length >= 5 && window.EmeraldStarters?.ALL.length===27',timeout=30000)
 p=page.evaluate('''() => ({
  all:window.EmeraldStarters.ALL.length,
  setup:document.querySelector('#setupStarter').options.length,
  mybot:document.querySelector('#botStarter').options.length,
  hiddenDuplicate:getComputedStyle(document.querySelector('#liveTeam')).display==='none',
  hasViewer:!!document.getElementById('oneTeamViewer'),
  national:window.emeraldNationalSimulation.count,
  horizontalOverflow:document.documentElement.scrollWidth>window.innerWidth+2
 })''')
 assert p['all']==27 and p['setup']==27 and p['mybot']==27,p
 assert p['hiddenDuplicate'] and p['hasViewer'] and not p['horizontalOverflow'],p
 if page.locator('#worldSetupDialog').is_visible():page.locator('#setupKeep').click()
 # UI fixture: isolated test origin lacks official map traversal; real progression is
 # covered separately by the battle/server integration tests.
 page.evaluate('''() => {
  const species=['Treecko','Torchic','Mudkip','Sprigatito','Fuecoco','Quaxly','Pikachu','Tinkaton'];
  species.forEach((name,i)=>{const t=window.emeraldTrainers[i%3]; t.team.push({species:name,level:5+i*3,hp:25+i,maxHp:25+i,atk:20+i*3,def:22+i*2,spAtk:21+i*2,spDef:22+i,spe:23+i*2,moves:['Tackle'],pp:{Tackle:10}});});
  window.emeraldSelectTrainer(0);
  document.getElementById('liveFocus').dispatchEvent(new Event('change'));
 }''')
 page.locator('.bottomNav [data-page="jogo"]').click()
 page.wait_for_timeout(1400)
 # Director button opens the sole detailed roster panel.
 page.locator('#oneTeamViewer').click()
 page.wait_for_timeout(200)
 result=page.evaluate('''() => ({
  teamViewVisible:document.querySelector('#page-equipes')?.hidden===false,
  topSixEntries:document.querySelectorAll('#liveTopPokemon .liveRow').length,
  oneVisibleRoster:document.querySelector('#liveTeam').style.display==='none',
  uniqueSlots:document.querySelectorAll('#team .mon').length,
  horizontalOverflow:document.documentElement.scrollWidth>window.innerWidth+2
 })''')
 assert result['teamViewVisible'] and result['oneVisibleRoster'],result
 assert 1<=result['topSixEntries']<=6,result
 assert not result['horizontalOverflow'],result
 page.locator('.bottomNav [data-page="jogo"]').click()
 page.locator('#liveTopPokemon').scroll_into_view_if_needed()
 page.screenshot(path=str(ROOT/'tests/v9_4_android.png'),full_page=False)
 assert not errors,errors
 report={'startup':p,'interface':result,'pageErrors':errors}
 (ROOT/'tests/v9_4_browser_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
 print(json.dumps(report,ensure_ascii=False,indent=2))
 browser.close()
