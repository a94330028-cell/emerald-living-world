"""Smoke offline: scripts inline preservando ordem defer, sem simular rede oficial.
Não substitui teste Android real, navegação integral nem banco Supabase.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import re,json
ROOT=Path(__file__).resolve().parents[1]; SITE=ROOT/'jogo'; s=(SITE/'index.html').read_text()
files=[]
def take(m):
 path=(SITE/m.group(1).split('?',1)[0]).resolve()
 if not path.is_relative_to(SITE) or not path.is_file():return m.group(0)
 files.append((str(path.relative_to(SITE)),path.read_text()))
 return ''
s=re.sub(r'<script\b[^>]*\bsrc="([^"]+)"[^>]*>\s*</script>',take,s,flags=re.I)
def css_inline(m):
 src=m.group(1).split('?',1)[0]
 path=(SITE/src).resolve()
 if path.is_relative_to(SITE) and path.is_file(): return '<style>'+path.read_text()+'</style>'
 return m.group(0)
s=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"[^>]*>',css_inline,s,flags=re.I)
# Inline no fim do body equivale a scripts defer, depois de todos os dialogs.
inlined='\n'.join('<script>'+code.replace('</script','<\\/script')+'\n//# sourceURL=elw/'+filename+'</script>' for filename,code in files)
s=s.replace('</body>',inlined+'</body>')
report={'environment':'Chromium headless 390x844, scripts em linha, sem rede','errors':[],'checks':[]}
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 store={}
 page.evaluate('''() => {
  const db={};const memory={getItem:k=>Object.prototype.hasOwnProperty.call(db,k)?db[k]:null,setItem:(k,v)=>{db[k]=String(v)},removeItem:k=>{delete db[k]},clear:()=>Object.keys(db).forEach(k=>delete db[k])};
  Object.defineProperty(window,'localStorage',{configurable:true,value:memory});
  Object.defineProperty(window,'sessionStorage',{configurable:true,value:memory});
 }''')
 page.on('pageerror',lambda e:report['errors'].append(str(e)+' @ '+str(e.stack).splitlines()[-1]))
 page.route('**/*',lambda r:r.abort())
 page.set_content(s,wait_until='domcontentloaded',timeout=20000)
 page.wait_for_timeout(1100)
 assert page.locator('#liveWorld').count()==1
 assert page.locator('#landingSolo').count()==1
 assert page.locator('#elwQuality').count()==1
 assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+3')
 assert page.evaluate('window.emeraldTrainers?.length >= 1')
 report['checks'].append('abertura, 1 canvas, sprites/treinadores e responsividade sem overflow')
 page.screenshot(path=str(ROOT/'tests/v29_inline_home.png'),full_page=False)
 try:
  page.locator('#landingSolo').click(force=True,timeout=4000)
  page.wait_for_timeout(500)
  report['checks'].append('clique em jornada: '+str(page.evaluate("({landing:document.body.classList.contains('landing-active'),player:document.getElementById('page-jogador').hidden,message:document.getElementById('landingMessage')?.textContent})")))
  page.screenshot(path=str(ROOT/'tests/v29_inline_jornada.png'),full_page=False)
 except Exception as e: report['errors'].append('ação jornada: '+str(e)[:300])
 b.close()
(ROOT/'tests/v29_browser_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
