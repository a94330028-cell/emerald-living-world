"""Browser test: no external network, simulated origin, real JS and images.
The test deliberately forces map downloads to fail to verify offline recovery.
It does NOT verify pixel-perfect official map data or a real Android device.
"""
from pathlib import Path
from urllib.parse import urlparse,unquote
import mimetypes,json
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
html=(root/'jogo/index.html').read_text(encoding='utf8').replace('<head>','<head><base href="https://emerald-test.local/jogo/">',1)
errors=[];bad_requests=[]
mock_storage="""(seed => {const backing=new Map(Object.entries(seed||{}));Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>backing.get(k)||null,setItem:(k,v)=>backing.set(String(k),String(v)),removeItem:k=>backing.delete(k),clear:()=>backing.clear()}})} )"""
def asset(route):
 u=urlparse(route.request.url)
 if u.hostname!='emerald-test.local':return route.abort('failed')
 path=(root/unquote(u.path).lstrip('/')).resolve()
 if not path.is_relative_to(root) or not path.is_file():
  bad_requests.append(str(path));return route.fulfill(status=404,body='Not found')
 return route.fulfill(status=200,body=path.read_bytes(),content_type=mimetypes.guess_type(path.name)[0] or 'application/octet-stream')
def make_page(browser,seed=None):
 page=browser.new_page(viewport={'width':1280,'height':800},device_scale_factor=1)
 page.route('**/*',asset)
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('dialog',lambda d:d.accept())
 page.evaluate(mock_storage,seed or {})
 page.set_content(html,wait_until='load',timeout=30000)
 page.wait_for_timeout(500)
 if page.locator('#worldSetupDialog').is_visible():page.locator('#setupKeep').click()
 page.locator('[data-page="jogo"]').first.click()
 return page
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=make_page(browser)
 page.wait_for_timeout(1000)
 # Execute logical turns without waiting for real-world wall clock; allow microtasks between batches.
 page.evaluate('window.emeraldOptions.speed=0')
 for _ in range(10):
  page.evaluate('for(let i=0;i<70;i++)window.emeraldDebugStep()')
  page.wait_for_timeout(35)
 # The world continues to progress after map fallback has loaded.
 page.wait_for_timeout(2500)
 page.locator('#pause').click() if page.locator('#pause').inner_text().startswith('⏸') else None
 state=page.evaluate('window.emeraldExport()')
 observed=[t for t in state['trainers'] if (t.get('walkCount') or 0)>0]
 bad_positions=[]
 for t in state['trainers']:
  if not t.get('officialMap') or not isinstance(t.get('walkX'),int) or not isinstance(t.get('walkY'),int):continue
  m=page.evaluate('(name)=>window.emeraldOfficialWorld.cache.get(name)?.value && ({w:window.emeraldOfficialWorld.cache.get(name).value.width,h:window.emeraldOfficialWorld.cache.get(name).value.height})',t['officialMap'])
  if m and not(0<=t['walkX']<m['w'] and 0<=t['walkY']<m['h']):bad_positions.append(t['id'])
 snapshot={'bots':len(state['trainers']),'turns':state['turns'],'moved_bots':len(observed),'bad_positions':bad_positions,
  'world':page.evaluate('window.emeraldOfficialWorld?.navStats?.()'),
  'core':page.evaluate('!!window.EmeraldNavigation'),
  'trainerFrames':page.evaluate('!!window.EmeraldTrainerFrames'),
  'romHeader':page.evaluate('!!window.EmeraldRomHeader'),
  'worldVisible':page.locator('#liveWorld').is_visible(),
  'initialImages':page.evaluate('Array.from(document.querySelectorAll(".starterArtwork img")).every(i=>i.naturalWidth>0)'),
  'bad_local_requests':bad_requests[:20]}
 page.locator('#liveWorld').scroll_into_view_if_needed()
 page.screenshot(path=str(root/'tests/smoke_desktop.png'),full_page=False)
 page.set_viewport_size({'width':390,'height':844});page.wait_for_timeout(200)
 snapshot['androidCanvas']=page.locator('#liveWorld').is_visible()
 snapshot['androidOverflow']=page.evaluate('document.documentElement.scrollWidth > innerWidth+2')
 page.locator('#liveWorld').scroll_into_view_if_needed()
 page.screenshot(path=str(root/'tests/smoke_android.png'),full_page=False)
 page.locator('#save').click()
 saved=page.evaluate("localStorage.getItem('emerald_living_world_v26')")
 assert saved,'save not persisted'
 page.close()
 new_page=make_page(browser,{'emerald_living_world_v26':saved})
 new_state=new_page.evaluate('window.emeraldExport()')
 snapshot['save_roundtrip']=(len(new_state['trainers'])==len(state['trainers']) and new_state['turns']==state['turns'] and
  all(a['id']==b['id'] and a['badges']==b['badges'] for a,b in zip(state['trainers'],new_state['trainers'])))
 snapshot['errors']=errors
 new_page.close();browser.close()
 print(json.dumps(snapshot,ensure_ascii=False,indent=2))
 (root/'tests/browser_report.json').write_text(json.dumps(snapshot,ensure_ascii=False,indent=2),encoding='utf8')
 assert snapshot['core'] and snapshot['trainerFrames'] and snapshot['romHeader']
 assert snapshot['bots']==20 and snapshot['moved_bots']>=3
 assert snapshot['worldVisible'] and snapshot['androidCanvas'] and not snapshot['androidOverflow']
 assert snapshot['save_roundtrip'] and not snapshot['bad_positions'] and not snapshot['errors']
 assert not snapshot['bad_local_requests']
