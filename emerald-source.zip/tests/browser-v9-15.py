"""V9.15 Android: sprite step sequencing and saved speed settings.
External official map resources are intentionally offline: tests fallback graphics.
"""
from pathlib import Path
from urllib.parse import urlparse,unquote
import json,mimetypes
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
BASE='https://v915-test.local/jogo/'
report={'viewport':'390x844 mobile Chrome (Chromium)','errors':[]}

def fulfill(route):
 u=urlparse(route.request.url)
 if u.hostname!='v915-test.local':return route.abort('failed')
 if u.path.startswith('/api/'):
  return route.fulfill(status=200,body='{}',content_type='application/json')
 p=(ROOT/unquote(u.path).lstrip('/')).resolve()
 if not p.is_relative_to(ROOT) or not p.is_file():return route.fulfill(status=404,body='')
 return route.fulfill(status=200,body=p.read_bytes(),content_type=mimetypes.guess_type(p.name)[0] or 'application/octet-stream')
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 page.route('**/*',fulfill)
 page.on('pageerror',lambda e:report['errors'].append(str(e)))
 page.on('dialog',lambda d:d.accept())
 page.evaluate('''() => {const m=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear()}})}''')
 html=(ROOT/'jogo/index.html').read_text().replace('<head>',f'<head><base href="{BASE}">',1)
 page.set_content(html,wait_until='domcontentloaded',timeout=30000)
 page.wait_for_function('window.emeraldTrainers?.length>0&&window.EmeraldTrainerFrames&&document.getElementById("landingSolo")',timeout=25000)
 print("DEBUG speed",page.locator("#speed").count(),page.locator("#speed").evaluate("e=>e.outerHTML") if page.locator("#speed").count() else "NONE",flush=True)
 assert page.locator('#speed option[value="200"]').count()==1
 page.locator('#landingSolo').click()
 page.wait_for_function('document.getElementById("botSpeed")&&document.getElementById("page-jogador")?.hidden===false',timeout=20000)
 page.locator('#botSpeed').select_option('100')
 page.wait_for_function('window.emeraldOptions.speed===100')
 assert page.evaluate('document.getElementById("speed").value')=='100'
 page.locator('#botSpeed').select_option('200')
 page.wait_for_function('window.emeraldOptions.speed===200')
 assert page.evaluate('JSON.parse(localStorage.getItem("emerald_v21_options")||"{}").speed')==200
 step=page.evaluate('''()=>{const f=window.EmeraldTrainerFrames.frameIndex;return {left0:f(3,true,.25,0),left1:f(3,true,.75,0),right0:f(1,true,.25,0),right1:f(1,true,.75,0),idle:f(3,false,.75,0)}}''')
 assert step['left0']!=step['left1'] and step['right0']!=step['right1']
 assert step['idle']%3==0
 assert page.evaluate('window.EmeraldTrainerSprites.IDS.length')==20
 report['control']={'100x':True,'200x':True,'persisted':True,'soloVisible':True}
 report['sprites']={'20Atlases':True,'lateralFootFramesAlternate':True,'frames':step}
 report['horizontalOverflow']=page.evaluate('document.documentElement.scrollWidth > window.innerWidth+3')
 assert not report['horizontalOverflow'], 'horizontal overflow'
 page.locator('.personalSpeedControl').scroll_into_view_if_needed()
 page.screenshot(path=str(ROOT/'tests/v9_15_android_velocidade.png'),full_page=False)
 assert not report['errors'],report['errors']
 (ROOT/'tests/v9_15_browser_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
 print(json.dumps(report,ensure_ascii=False,indent=2))
 browser.close()
