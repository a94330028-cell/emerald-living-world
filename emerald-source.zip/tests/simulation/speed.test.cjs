'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path');
const sim=require('../../jogo/game/simulation/speed.js');
const frames=require('../../jogo/client/animation/trainer-frames.js');
const sprites=require('../../jogo/client/animation/trainer-sprites.js');

test('visual feet switch during each real left/right tile step, never while idle',()=>{
 for(const dir of [1,3])for(const id of sprites.IDS){
  const idle=frames.frameIndex(dir,false,.95,0),early=frames.frameIndex(dir,true,.25,0),late=frames.frameIndex(dir,true,.75,0);
  assert.notEqual(early,late,`${id} ${dir} did not alternate stride`);
  assert.equal(Math.floor(early/3),Math.floor(late/3));
  assert.equal(Math.floor(early/3),Math.floor(idle/3));
  assert.equal(idle%3,0);
  assert.equal(frames.frameIndex(dir,true,.25,1),late);
  assert.equal(frames.frameIndex(dir,true,.75,1),early);
 }
});

test('1x uses the former 40x simulation budget; old saves are migrated safely',()=>{
 assert.deepEqual(sim.PRESETS,[1,2,3,5]);
 for(const v of sim.PRESETS){assert.equal(sim.normalize(String(v)),v);assert.equal(sim.effectiveMultiplier(v),v*40)}
 assert.equal(sim.normalize('999999'),1);
 assert.equal(sim.normalize(''),1);
 assert.equal(sim.normalize(0,true),0);
 assert.equal(sim.normalize(0),1);
 assert.equal(sim.fromLegacy(3),1);
 assert.equal(sim.fromLegacy(40),1);
 assert.equal(sim.fromLegacy(100),2);
 assert.equal(sim.fromLegacy(200),5);
});

test('fast modes have limited per-frame work instead of an unlimited blocking while loop',()=>{
 assert.ok(sim.frameLimit(1)>=4);
 assert.ok(sim.frameLimit(5)>sim.frameLimit(1));
 assert.ok(sim.frameLimit(5)<=16);
 assert.ok(sim.CPU_BUDGET_MS<=10);
 const index=fs.readFileSync(path.join(__dirname,'../../jogo/index.html'),'utf8');
 const engine=fs.readFileSync(path.join(__dirname,'../../jogo/js/engine.js'),'utf8');
 assert.ok(index.includes('id="speed"')&&index.includes('value="5"'));
 assert.ok(engine.includes('SIM_SPEED.CPU_BUDGET_MS'));
 assert.ok(engine.includes('SIM_SPEED.frameLimit(speed)'));
 assert.ok(engine.includes('SIM_SPEED.effectiveMultiplier(speed)'));
});
