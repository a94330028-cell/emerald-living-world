'use strict';
/** Re-run to replace v7_evidence.json with measurements from this execution. */
const fs=require('node:fs');const path=require('node:path');
const AI=require('../server/autonomy.cjs');const W=require('../server/world.cjs');
const one=AI.createBot(1),gymOpponents=new Map(),gymFrames=[];
for(let i=0;i<5200;i++){
 if(one.battle?.type==='gym'){
  const foe=one.battle.enemy;gymOpponents.set(foe.id,{species:foe.species,level:foe.level});
  if(gymFrames.length<100)gymFrames.push({tick:one.ticks,turn:one.battle.turn,foe:foe.species,foeHp:foe.hp,own:one.team[one.activeIndex]?.species,ownHp:one.team[one.activeIndex]?.hp});
 }
 AI.advance(one);
 if(one.badges===1&&one.milestones.some(m=>m.type==='evolution'))break;
}
const many={};for(const count of [20,100]){
 const bots=Array.from({length:count},(_,i)=>AI.createBot(i+1));
 const t=performance.now();for(let tick=0;tick<500;tick++)for(const b of bots)AI.advance(b);
 many[count]={bots:count,ticksEach:500,elapsedMs:Math.round(performance.now()-t),
   captured:bots.filter(b=>b.milestones.some(e=>e.type==='capture')).length,
   traveledBeyondLittleroot:bots.filter(b=>b.visitedAreas.includes('Route101')).length,
   uniqueIds:new Set(bots.map(b=>b.id)).size,
   outOfBounds:bots.filter(b=>!W.walkable(b.area,b.x,b.y)).map(b=>b.id),
   invalidBadges:bots.filter(b=>b.badges&&!b.milestones.some(e=>e.type==='badge')).map(b=>b.id),
   individualPhaseSample:bots.slice(0,5).map(b=>({id:b.id,phase:b.phase,area:b.area,team:b.team.map(m=>({species:m.species,level:m.level})),badges:b.badges}))};
}
const report={generatedAt:new Date().toISOString(),scope:'Synthetic test maps from V7. No claim of full Hoenn or complete Gen III.',
 singleBot:{id:one.id,ticks:one.ticks,location:one.area,phase:one.phase,
  starter:one.starter,bag:one.bag,badges:one.badges,wins:one.wins,losses:one.losses,
  visitedAreas:one.visitedAreas,team:one.team.map(m=>({species:m.species,level:m.level,exp:m.exp,hp:m.hp,maxHp:m.maxHp})),
  milestones:one.milestones,roxanneOpponents:[...gymOpponents.values()],gymBattleFrameSample:gymFrames},
 parallelRuns:many,automatedTests:'node --test (34 tests passed in recorded run)',
 persistenceTest:'tests/multiplayer/restart.test.cjs stops and restarts a real Node process with the same DATA_DIR',
 uiTest:'tests/browser-v7.py uses a mocked HTTP layer in Chromium because localhost browsing is blocked in this environment'};
 const out=path.join(__dirname,'v7_evidence.json');fs.writeFileSync(out,JSON.stringify(report,null,2));
console.log(JSON.stringify({singleBot:{ticks:one.ticks,badges:one.badges,starter:one.starter,team:report.singleBot.team,milestones:one.milestones.map(m=>m.type),gymOpponents:report.singleBot.roxanneOpponents},parallelRuns:Object.fromEntries(Object.entries(many).map(([k,v])=>[k,{captured:v.captured,invalidBadges:v.invalidBadges,outOfBounds:v.outOfBounds,elapsedMs:v.elapsedMs}]))},null,2));
if(one.badges!==1||!one.milestones.some(e=>e.type==='evolution')||many[100].outOfBounds.length||many[100].invalidBadges.length)process.exitCode=1;
