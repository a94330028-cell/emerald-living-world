"""Offline mobile layout test; remote art deliberately unavailable (local fallback expected)."""
from pathlib import Path
import re,json,base64
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'jogo';s=(SITE/'index.html').read_text()
files=[]
def scripts(m):
 path=(SITE/m.group(1).split('?',1)[0]).resolve()
 if not path.is_relative_to(SITE) or not path.is_file():return m.group(0)
 files.append((str(path.relative_to(SITE)),path.read_text(encoding='utf-8')))
 return ''
s=re.sub(r'<script\b[^>]*\bsrc="([^"]+)"[^>]*>\s*</script>',scripts,s,flags=re.I)
def style(m):
 path=(SITE/m.group(1).split('?',1)[0]).resolve()
 return '<style>'+path.read_text(encoding='utf-8')+'</style>' if path.is_relative_to(SITE) and path.is_file() else m.group(0)
s=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"[^>]*>',style,s,flags=re.I)
s=s.replace('</body>','\n'.join('<script>'+code.replace('</script','<\\/script')+'\n//# sourceURL=elw/'+name+'</script>' for name,code in files)+'</body>')
report={'errors':[], 'checks':[]}
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 page.on('pageerror', lambda err:report['errors'].append(str(err)))
 page.route('**/*',lambda r:r.abort())
 page.evaluate('''() => {const values={};const store={getItem:k=>values[k]??null,setItem:(k,v)=>values[k]=String(v),removeItem:k=>delete values[k]};Object.defineProperty(window,'localStorage',{configurable:true,value:store});Object.defineProperty(window,'sessionStorage',{configurable:true,value:store});window.fetch=async()=>new Response('[]',{status:200,headers:{'Content-Type':'application/json'}})}''')
 page.set_content(s,wait_until='domcontentloaded',timeout=30000)
 page.wait_for_timeout(550)
 assert page.evaluate('window.EmeraldPokemonArt.getVisualMode()')=='hd'
 page.locator('#landingSolo').click(force=True)
 page.wait_for_timeout(300)
 page.evaluate('window.emeraldShowPage("ranking")')
 page.wait_for_timeout(450)
 # Diagnostic fixture: only when the fresh save does not yet contain six ranked species.
 if page.locator('#rankTopSix .cleanStatRow').count()==0:
  rows=[]
  for i,name in enumerate(['treecko','mudkip','torchic','pikachu','ralts','spheal']):
   png=SITE/'assets/pokemon_fit'/f'{name}.png'
   rows.append({'name':name.title(),'src':'data:image/png;base64,'+base64.b64encode(png.read_bytes()).decode(),'pts':100-i*5})
  page.evaluate('''(rows) => {const el=document.getElementById('rankTopSix');el.innerHTML=rows.map((r,i)=>`<div class="cleanStatRow"><span class="cleanRankNumber">${i+1}º</span><img src="${r.src}" alt="${r.name}"><div><b>${r.name}</b><small>Treinador · Nv. 12</small></div><strong class="cleanRankScore">${r.pts} pts</strong></div>`).join('');}''',rows)
 data=page.evaluate('''() => ({width:innerWidth,documentWidth:document.documentElement.scrollWidth,items:[...document.querySelectorAll('#rankTopSix .cleanStatRow')].slice(0,6).map(card=>{const img=card.querySelector('img');return {w:card.getBoundingClientRect().width,h:card.getBoundingClientRect().height,photoW:img?.getBoundingClientRect().width||0}})})''')
 assert data['documentWidth']<=data['width']+6, data
 for row in data['items']:
  assert row['photoW']>=80,row
 report['checks'].append(data)
 page.screenshot(path=str(ROOT/'tests/v33_mobile_rank.png'),full_page=False)
 browser.close()
print(json.dumps(report,ensure_ascii=False,indent=2))
