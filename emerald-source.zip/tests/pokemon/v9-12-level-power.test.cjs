'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const Battle=require('../../server/battle.cjs');
const base=path.join(__dirname,'../..');
test('same species with same IV EV Nature grows in real server stats from level 5 through 60',()=>{
 const candidates=['Litten','Popplio','Piplup','Charmander','Treecko','Mudkip'];
 for(const species of candidates){
  const ivs={hp:15,atk:15,def:15,spa:15,spd:15,spe:15};
  const evs={hp:0,atk:0,def:0,spa:0,spd:0,spe:0};
  const score=level=>{
   const mon={species,level,ivs,evs,nature:'Hardy'};
   return ['hp','atk','def','spa','spd','spe'].reduce((sum,key)=>sum+Battle.stat(mon,key),0);
  };
  assert.ok(score(6)>score(5),species+' level 6 must exceed level 5');
  assert.ok(score(60)>score(50),species+' level 60 must exceed level 50');
 }
});
test('rank images have no Poké Ball underlay and missing artwork has a neutral asset',()=>{
 const css=fs.readFileSync(path.join(base,'jogo/css/game-rank-v911.css'),'utf8');
 const svg=fs.readFileSync(path.join(base,'jogo/assets/ui/pokemon_missing.svg'),'utf8');
 const js=fs.readFileSync(path.join(base,'jogo/js/pokemon-art.js'),'utf8');
 assert.ok(!css.includes('pokemon_placeholder.png'));
 assert.ok(js.includes('pokemon_missing.svg'));
 assert.ok(svg.startsWith('<svg')&&!/unknown|pok[eé]\s?ball|ball\b/i.test(svg));
});
