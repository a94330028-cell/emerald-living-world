"""Test actual map-first DOM in Chromium with file-backed responses (localhost blocked)."""
from pathlib import Path
from urllib.parse import urlparse,unquote
import mimetypes,json
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
BASE='https://emerald-map-first.test/jogo/'
summary={"pageErrors":[]}

def fulfill(route):
 u=urlparse(route.request.url)
 if u.hostname!='emerald-map-first.test':return route.fulfill(status=204,body='')
 if u.path.startswith('/api/'):
  return route.fulfill(status=200,body='{}',content_type='application/json')
 p=(ROOT/unquote(u.path).lstrip('/')).resolve()
 if not p.is_relative_to(ROOT) or not p.is_file():return route.fulfill(status=404,body='')
 return route.fulfill(status=200,body=p.read_bytes(),content_type=mimetypes.guess_type(p.name)[0] or 'application/octet-stream')

with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 page.route('**/*',fulfill)
 page.on('pageerror',lambda e: summary['pageErrors'].append(str(e)))
 page.on('dialog',lambda d:d.accept())
 # Browser's persistent storage may be blocked in an isolated test origin.
 page.evaluate('''() => {const m=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear()}})}''')
 html=(ROOT/'jogo/index.html').read_text().replace('<head>',f'<head><base href="{BASE}">',1)
 page.set_content(html,wait_until='domcontentloaded',timeout=25000)
 page.wait_for_timeout(4000)
 # If mode picker is visible, enter spectate/world (same game view as user screenshot).
 if page.locator('#landingSolo').count() and page.locator('#landingSolo').is_visible():
  page.locator('#landingSolo').click()
  page.wait_for_timeout(800)
 summary.update(page.evaluate('''() => {const m=document.querySelector('#liveWorld'),host=document.querySelector('#myBotMapMount'),r=m.getBoundingClientRect();return {mode:document.body.dataset.worldMode,canvasParent:m.parentElement?.id||m.parentElement?.className,mapInsideSolo:!!host?.contains(m),mapVisible:getComputedStyle(m).display!=='none'&&r.width>0&&r.height>0,size:[r.width,r.height],noHorizontalOverflow:document.documentElement.scrollWidth<=innerWidth+4}}'''))
 print('SOLO_TEST',json.dumps(summary,ensure_ascii=False))
 assert summary['mapInsideSolo'] and summary['mapVisible'] and summary['noHorizontalOverflow'],summary
 page.locator('#liveWorld').scroll_into_view_if_needed(timeout=10000)
 page.screenshot(path=str(ROOT/'tests/v25_mapa_solo_android.png'),full_page=False)
 browser.close()
