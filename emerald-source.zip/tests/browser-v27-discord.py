"""Offline Android-style visual check of the Discord entry points."""
from pathlib import Path
from urllib.parse import urlparse,unquote
import json,mimetypes
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
BASE='https://v27-discord.local/jogo/'
report={'browser':'Chromium Android emulation, 390x844','checks':{},'errors':[]}
def fulfill(route):
 u=urlparse(route.request.url)
 if u.hostname!='v27-discord.local':return route.abort('failed')
 if u.path.startswith('/api/'):return route.fulfill(status=200,body='{}',content_type='application/json')
 f=(ROOT/unquote(u.path).lstrip('/')).resolve()
 if not f.is_relative_to(ROOT) or not f.is_file():return route.fulfill(status=404,body='')
 return route.fulfill(status=200,body=f.read_bytes(),content_type=mimetypes.guess_type(f.name)[0] or 'application/octet-stream')
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':390,'height':844},device_scale_factor=1,is_mobile=True,has_touch=True)
 page.route('**/*',fulfill)
 page.on('pageerror',lambda error:report['errors'].append(str(error)))
 page.evaluate("""() => {const m=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear()}})}""")
 html=(ROOT/'jogo/index.html').read_text(encoding='utf-8').replace('<head>',f'<head><base href="{BASE}">',1)
 page.set_content(html,wait_until='domcontentloaded',timeout=30000)
 page.locator('.communityDiscordIntro').wait_for(timeout=15000)
 data=page.evaluate('''() => {
   const all=[...document.querySelectorAll('.communityDiscordLink')];
   const link=document.querySelector('.communityDiscordIntro');
   const r=link.getBoundingClientRect();
   return {
    count:all.length,
    targets:all.map(el=>[el.href,el.target,el.rel]),
    introVisible:r.width>50&&r.height>=44&&getComputedStyle(link).display!='none',
    introStyle:getComputedStyle(link).display,
    overflow:document.documentElement.scrollWidth>window.innerWidth+3,
    buttonMinHeight:parseFloat(getComputedStyle(link).minHeight),
    styleLoaded:[...document.styleSheets].some(x=>x.href?.includes('community-discord-v27.css'))
   };
 }''')
 report['checks']['landing']=data
 assert data['count']==3,data
 assert data['introVisible'] and data['styleLoaded'],data
 assert data['buttonMinHeight']>=44,data
 assert all(target==['https://discord.gg/6r9w3kA4sh','_blank','noopener noreferrer'] for target in data['targets']),data
 assert not data['overflow'],data
 page.screenshot(path=str(ROOT/'tests/v27_discord_android.png'),full_page=True)
 page.evaluate("document.body.classList.remove('landing-active');document.querySelector('#page-projeto').hidden=false")
 report['checks']['inSite']=page.evaluate('''() => ({project: document.querySelector('.communityDiscordInline').getBoundingClientRect().width>0, footer:document.querySelector('.communityDiscordFooter').getBoundingClientRect().width>0})''')
 assert all(report['checks']['inSite'].values())
 assert not report['errors'],report['errors']
 (ROOT/'tests/v27_discord_browser_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
 print(json.dumps(report,ensure_ascii=False,indent=2))
 b.close()
