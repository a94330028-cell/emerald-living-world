# Testes da V5

Para os testes unitários não é necessário instalar pacotes npm:

```bash
node --test tests/maps/*.test.cjs tests/animations/*.test.cjs tests/rom-header.test.cjs
```

O teste de navegador é opcional e requer Python, Playwright e um Chromium local:

```bash
python tests/browser-smoke.py
```

A origem web é simulada e os arquivos são atendidos diretamente do pacote,
sem servidor. Requisições para o repositório externo são bloqueadas para
verificar a recuperação offline. As imagens não provam compatibilidade real
com Android e não substituem testes em dispositivos físicos.

Os diretórios `bots`, `battles` e `multiplayer` ficam reservados para suites de
integração quando os respectivos serviços estiverem completos.
