'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');
const root=path.resolve(__dirname,'..');const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const html=read('jogo/index.html'),css=read('jogo/css/community-ui-v30.css'),script=read('jogo/js/community-chat-v30.js'),sql=read('supabase/community_chat.sql');
test('chat accessible from landing and floating action without changing game views',()=>{
 assert.ok((html.match(/data-elw-open-chat/g)||[]).length>=2);
 for(const label of ['Geral','Ajuda','Times e estratégias'])assert.match(html,new RegExp(label));
 assert.match(html,/id="liveWorld"/);assert.match(html,/id="cloudConflictDialog"/);
});
test('dark theme includes game, landing, form, Pokédex and chat, and persists preference',()=>{
 assert.match(css,/html\[data-poke-theme="dark"\]/);for(const part of ['#personalLanding','.pokedexDevice','.cloudDialog','.welcomePanel','.introShell'])assert.ok(css.includes(part));
 assert.match(read('jogo/js/community-theme-v30.js'),/elw_visual_theme_25/);
});
test('messages use textContent, never insert remote message HTML',()=>{
 assert.match(script,/body\.textContent=m\.body/);assert.doesNotMatch(script,/innerHTML\s*=\s*m\.body/);
 assert.match(html,/id="elwChatInput" maxlength="280"/);
});
test('database disallows direct user chat writes and enforces verified sender plus anti-spam',()=>{
 assert.match(sql,/revoke all on public\.elw_chat_messages from public, anon, authenticated/);
 assert.match(sql,/email_confirmed_at is not null/);
 assert.match(sql,/interval '4 seconds'/);assert.match(sql,/interval '1 minute'/);
 assert.match(sql,/grant execute on function public\.elw_send_chat_message\(text,text\) to authenticated/);
 assert.doesNotMatch(sql,/grant insert on public\.elw_chat_messages to authenticated/);
});
test('chat has ability to mute and report, with visible offline configuration state',()=>{
 assert.match(script,/elw_chat_muted_v30/);assert.match(script,/elw_report_chat_message/);assert.match(script,/Aguardando configuração do servidor/);
 assert.match(html,/elwChatStatus/);assert.match(html,/Denunciar|denunciar/);
});
