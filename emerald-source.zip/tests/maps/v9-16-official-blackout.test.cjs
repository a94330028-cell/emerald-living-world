'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const Nav=require('../../jogo/game/navigation/core.js');
const src=fs.readFileSync(path.join(__dirname,'../../jogo/js/official-runtime.js'),'utf8');
function runtime(){
 const win={EmeraldNavigation:Nav,emeraldOptions:{speed:0},emeraldTrainers:[]};
 vm.runInNewContext(src,{window:win,ArrayBuffer,DataView,Uint8Array,Int32Array,Math,Date,Promise,
  setTimeout,clearTimeout,AbortController,fetch:()=>Promise.reject(Error('intentionally offline'))});
 return win.emeraldOfficialWorld;
}

test('offline bot may relocate from Route104 to a Pokémon Center only after blackout',async()=>{
 const world=runtime();
 const source=await world.ensureNav('Route104');
 const dest=await world.ensureNav('OldaleTown_PokemonCenter_1F');
 const at=world.nearest(source,{x:15,y:12});
 const t={id:2,stage:9,storyNavStage:9,location:'Centro Pokémon • Oldale Town',
  officialMap:'Route104',walkX:at.x,walkY:at.y,officialSpawn:false,badges:0,
  walkPath:[],team:[{hp:0},{hp:0}],healing:{from:'Route104',city:'Oldale Town',wiped:true,phase:'arrival'}};
 assert.equal(world.stepTrainer(t),true);
 assert.equal(t.officialMap,'OldaleTown_PokemonCenter_1F');
 assert.equal(t.healing.blackoutArrived,true);
 assert.equal(t.healing.wiped,false);
 assert.equal(world.walkable(dest,t.walkX,t.walkY),true);
});

test('a blocked saved position stays untouched instead of snapping to a walkable tile',async()=>{
 const world=runtime(),source=await world.ensureNav('Route104');
 const t={id:4,stage:9,storyNavStage:9,location:'Rustboro City',officialMap:'Route104',
  walkX:0,walkY:0,officialSpawn:false,badges:0,walkPath:[],team:[{hp:10}]};
 assert.equal(world.walkable(source,0,0),false);
 assert.equal(world.stepTrainer(t),true);
 assert.equal(t.officialMap,'Route104');
 assert.deepEqual([t.walkX,t.walkY],[0,0]);
 assert.match(t.officialError,/Posição bloqueada/);
});

test('a live team must navigate and cannot materialize at the Center before walking',async()=>{
 const world=runtime(),source=await world.ensureNav('Route104');
 await world.ensureNav('OldaleTown_PokemonCenter_1F');
 const at=world.nearest(source,{x:14,y:12});
 const t={id:3,stage:9,storyNavStage:9,location:'Centro Pokémon • Oldale Town',
  officialMap:'Route104',walkX:at.x,walkY:at.y,officialSpawn:false,badges:0,
  walkPath:[],team:[{hp:0},{hp:8}],healing:{from:'Route104',city:'Oldale Town',wiped:false,phase:'arrival'}};
 world.stepTrainer(t);
 assert.equal(t.officialMap,'Route104');
 assert.ok(Math.abs(t.walkX-at.x)+Math.abs(t.walkY-at.y)<=1);
});
