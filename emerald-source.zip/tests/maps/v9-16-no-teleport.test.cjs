'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const World=require('../../server/world.cjs');
const Nav=require('../../jogo/game/navigation/core.js');
const Bot=require('../../server/autonomy.cjs');

function grid(){
 const width=12,height=10,blocks=new DataView(new ArrayBuffer(width*height*2));
 const attrs=new DataView(new ArrayBuffer(1024*2));
 for(let y=0;y<height;y++)for(let x=0;x<width;x++){
  const fence=(x===5&&y>=1&&y<=8),edge=x===0||y===0||x===width-1||y===height-1;
  blocks.setUint16((y*width+x)*2,1|((fence||edge)?0x400:0),true);
 }
 return {width,height,blocks,primaryAttrs:attrs,secondaryAttrs:attrs,
  layout:{primary_tileset:'test'},solidObjects:new Set(['3:3']),meta:{object_events:[],warp_events:[],connections:[]}};
}

test('a fence is not a walkway and its enclosed component cannot leak via A*',()=>{
 const m=grid();
 assert.equal(Nav.walkable(m,5,4),false);
 assert.equal(Nav.canStep(m,{x:4,y:4},{x:5,y:4}),false);
 assert.equal(Nav.findPath(m,{x:2,y:4},{x:7,y:4}).length,0);
});
test('NPC event tiles are solid even if the terrain below them is open',()=>{
 const m=grid();
 assert.equal(Nav.walkable(m,3,3),false);
 assert.equal(Nav.canStep(m,{x:3,y:4},{x:3,y:3}),false);
 assert.ok(Nav.findPath(m,{x:2,y:3},{x:4,y:3}).every(t=>t.x!==3||t.y!==3));
});
test('only complete defeat allows a Pokémon Center respawn; normal and wounded trainers never relocate',()=>{
 for(const team of [[{hp:0},{hp:8}],[{hp:3},{hp:12}],[]]){
  const p={area:'Route101',x:14,y:10,team};
  assert.equal(World.blackoutRespawn(p),false);
  assert.equal(p.area,'Route101');assert.deepEqual([p.x,p.y],[14,10]);
 }
 const lost={area:'Route101',x:14,y:10,team:[{hp:0},{hp:0}]};
 assert.equal(World.blackoutRespawn(lost),true);
 assert.equal(lost.area,'Center');
 assert.deepEqual([lost.x,lost.y],[14,17]);
 assert.equal(lost.blackouts,1);
 assert.ok(World.walkable(lost.returnDoor.area,lost.returnDoor.x,lost.returnDoor.y));
 assert.equal(World.blackoutRespawn(lost),false,'blackout cannot repeat each tick');
});
test('blocked saved bot remains at original location instead of teleporting to Littleroot',()=>{
 const bot=Bot.createBot(1);
 bot.area='Route101';bot.x=3;bot.y=3;
 const original=[bot.area,bot.x,bot.y];Bot.migrate(bot);
 assert.deepEqual([bot.area,bot.x,bot.y],original);
 assert.equal(bot.navigationBlocked,true);
 Bot.advance(bot);
 assert.deepEqual([bot.area,bot.x,bot.y],original);
});
