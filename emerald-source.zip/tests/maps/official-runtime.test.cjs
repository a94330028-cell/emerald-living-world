'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const nav=require('../../jogo/game/navigation/core.js');
const source=fs.readFileSync(require('node:path').join(__dirname,'../../jogo/js/official-runtime.js'),'utf8');
const stub={EmeraldNavigation:nav,emeraldTrainers:[],emeraldOptions:{speed:0}};
const sandbox={window:stub,DataView,ArrayBuffer,Uint8Array,Int32Array,AbortController,Date,Math,Promise,
 setTimeout,clearTimeout, fetch:()=>Promise.reject(Error('Simulação offline para testar modo de recuperação'))};
vm.runInNewContext(source,sandbox,{filename:'official-runtime.js'});
const world=stub.emeraldOfficialWorld;
test('runtime exports API, loads offline recovery map when official server is inaccessible',async()=>{
 assert.ok(world);const m=await world.ensureNav('LittlerootTown');
 assert.equal(m.fallback,true);assert.equal(m.name,'LittlerootTown');
 assert.equal(world.diagnoseMap('LittlerootTown').source,'adapted');
});
test('gym recovery maps have reachable doors with reciprocal valid spawn points',async()=>{
 const gyms=['RustboroCity_Gym','DewfordTown_Gym','MauvilleCity_Gym','LavaridgeTown_Gym_1F',
 'PetalburgCity_Gym','FortreeCity_Gym','MossdeepCity_Gym','SootopolisCity_Gym_1F'];
 for(const name of gyms){
  const m=await world.ensureNav(name);
  const from=world.nearest(m,{x:Math.floor(m.width/2),y:Math.floor(m.height/2)});
  assert.ok(from,`${name} no spawn`);
  assert.ok(m.meta.warp_events.length>0,`${name} no warps`);
  const to=m.meta.warp_events[0];
  const portal=world.warpGoal(m,to,from);
  assert.ok(portal,`${name} inaccessible door`);
  let prev=from;for(const step of portal.path){assert.ok(world.canStep(m,prev,step),`${name} crosses blocked tile`);prev=step;}
  const arrival=await world.destinationOf(portal,m,prev);
  assert.ok(arrival,`${name} invalid destination`);
  assert.ok(world.walkable(arrival.map,arrival.at.x,arrival.at.y),`${name} arrives inside wall`);
 }
});
test('an invalid/missing target warp must not teleport to center',async()=>{
 const m=await world.ensureNav('RustboroCity_Gym');
 const missing={kind:'warp',destination:'RustboroCity',warp:{dest_warp_id:'-1'}};
 assert.equal(await world.destinationOf(missing,m,{x:3,y:3}),null);
 const unknown={kind:'warp',destination:'RustboroCity',warp:{dest_warp_id:'999'}};
 assert.equal(await world.destinationOf(unknown,m,{x:3,y:3}),null);
});
test('arrivalAt never chooses a tile out of bounds or distant from the door',async()=>{
 const m=await world.ensureNav('DewfordTown_Gym');
 assert.equal(world.arrivalAt(m,{x:-1,y:99}),null);
 assert.equal(world.arrivalAt(m,null),null);
});
test('edge landings respect the overlapping border (no wraparound teleport)',async()=>{
 const m=await world.ensureNav('Route101');
 const bad={kind:'edge',destination:'OldaleTown',edge:{direction:'up',offset:500}};
 assert.equal(await world.destinationOf(bad,m,{x:2,y:0}),null);
});

function rustboroFixture({accessibleGym=false}={}){
 const width=14,height=10;
 const buff=new ArrayBuffer(width*height*2),blocks=new DataView(buff);
 const attrs=new DataView(new ArrayBuffer(1024*2));
 for(let y=0;y<height;y++)for(let x=0;x<width;x++){
  const blocked=x===0||y===0||x===width-1||y===height-1||x===6;
  blocks.setUint16(2*(y*width+x),1|(blocked?0x400:0),true);
 }
 if(accessibleGym)blocks.setUint16(2*(4*width+6),1,true);
 const m={name:'RustboroCity',width,height,blocks,primaryAttrs:attrs,secondaryAttrs:attrs,
  layout:{primary_tileset:'test'},meta:{map_type:'MAP_TYPE_TOWN',connections:[],
  warp_events:[{x:10,y:3,dest_map:'MAP_RUSTBORO_CITY_GYM',dest_warp_id:0}],object_events:[]}};
 world.cache.set('RustboroCity',{value:m,promise:Promise.resolve(m)});
 return m;
}
function rustboroBot(){return {id:4,stage:7,badges:0,location:'RustboroCity_Gym',officialMap:'RustboroCity',
 walkX:2,walkY:4,walkCount:16,walkPath:[],officialTarget:'RustboroCity_Gym',officialTransitCounts:{}}}
test('Rustboro: route is planned through a real reachable doorway, never through a wall',()=>{
 const m=rustboroFixture({accessibleGym:true}),t=rustboroBot();
 const result=world.selectGoal(t,m);
 assert.ok(result,'should find entrance after gap in wall');
 assert.equal(result.destination,'RustboroCity_Gym');
 let here={x:t.walkX,y:t.walkY};
 for(const at of result.path){assert.equal(world.canStep(m,here,at),true);here=at;}
 assert.equal(t.officialRescueKey,undefined,'normal route must not relocate trainer');
});
test('Rustboro: unreachable fence never causes automatic relocation, even after repeated attempts',()=>{
 const m=rustboroFixture(),t=rustboroBot();
 for(let i=0;i<12;i++){
  assert.equal(world.selectGoal(t,m),null);
  assert.deepEqual([t.walkX,t.walkY],[2,4],`attempt ${i} relocated trainer`);
 }
 assert.equal(t.officialRescueKey,undefined);
 assert.match(t.officialError,/Nenhuma saída/);
});
test('Rustboro: manual replan alone never relocates a trainer',()=>{
 const m=rustboroFixture(),t=rustboroBot();
 world.replan(t);
 assert.deepEqual([t.walkX,t.walkY],[2,4]);
 assert.equal(world.choosePortal(t,m,{x:2,y:4},'RustboroCity_Gym'),null);
});
test('Rustboro: a nearby accessible exit is never used to wrap around a fenced gym',()=>{
 const m=rustboroFixture(),t=rustboroBot();
 m.meta.warp_events.push({x:3,y:3,dest_map:'MAP_ROUTE104',dest_warp_id:0});
 for(let i=0;i<8;i++){
  assert.equal(world.selectGoal(t,m),null);
  assert.deepEqual([t.walkX,t.walkY],[2,4]);
 }
 assert.equal(t.officialRescueKey,undefined);
});
