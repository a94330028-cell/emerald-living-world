'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const nav=require('../../jogo/game/navigation/core.js');
const code=fs.readFileSync(path.join(__dirname,'../../jogo/js/official-runtime.js'),'utf8');
const runtime={EmeraldNavigation:nav,emeraldTrainers:[],emeraldOptions:{speed:0}};
vm.runInNewContext(code,{window:runtime,DataView,ArrayBuffer,Uint8Array,Int32Array,AbortController,Date,Math,Promise,setTimeout,clearTimeout,fetch:()=>Promise.reject(Error('offline'))});
const world=runtime.emeraldOfficialWorld;
const towns=['LittlerootTown','OldaleTown','PetalburgCity','RustboroCity','MauvilleCity','SlateportCity','DewfordTown'];
test('offline maps have visible house/tree/furniture footprints with matching solid collision',async()=>{
 for(const name of [...towns,'Route101','PetalburgWoods','RustboroCity_Gym']){
  const m=await world.ensureNav(name),plan=m.recoveryPlan;
  assert.equal(m.fallback,true);
  assert.ok(plan);
  const structures=[...plan.buildings,...plan.forest,...plan.furniture];
  assert.ok(structures.length>=1,`${name}: empty recovery artwork`);
  for(const r of structures){for(let y=r.y;y<r.y+r.h;y++)for(let x=r.x;x<r.x+r.w;x++){
   assert.equal(world.walkable(m,x,y),false,`${name}: painted obstacle lacks collision at ${x},${y}`);
  }}
 }
});
test('offline fallback routes remain physically connected to every available warp',async()=>{
 for(const name of [...towns,'Route101','Route103','Route104','PetalburgWoods','RustboroCity_Gym','DewfordTown_Gym','MauvilleCity_Gym']){
  const m=await world.ensureNav(name);
  let center=world.nearest(m,{x:15,y:10});assert.ok(center,`${name} has no spawn`);
  for(const warp of m.meta.warp_events){
   assert.ok(world.walkable(m,warp.x,warp.y),`${name}: blocked warp`);
   const path=world.findPath(m,center,{x:warp.x,y:warp.y});
   assert.ok(path.length||center.x===warp.x&&center.y===warp.y,`${name}: inaccessible warp ${warp.dest_map}`);
   let here=center;for(const step of path){assert.ok(world.canStep(m,here,step),`${name} invalid step`);here=step;}
  }
 }
});
