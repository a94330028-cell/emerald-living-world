'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const nav=require('../../jogo/game/navigation/core.js');
function map(w=8,h=8){
 const bytes=new ArrayBuffer(w*h*2),blocks=new DataView(bytes),attrs=new DataView(new ArrayBuffer(1024*2));
 const m={name:'Test',width:w,height:h,blocks,primaryAttrs:attrs,secondaryAttrs:attrs,layout:{primary_tileset:'test'},meta:{map_type:'MAP_TYPE_INDOOR',warp_events:[],connections:[]}};
 const tile=(x,y,{collision=0,elevation=0,behavior=0}={})=>{
  const id=1+(behavior&255);
  blocks.setUint16((y*w+x)*2,id|collision<<10|elevation<<12,true);
  attrs.setUint16(id*2,behavior,true);
 };
 for(let y=0;y<h;y++)for(let x=0;x<w;x++)tile(x,y,{collision:(x===0||y===0||x===w-1||y===h-1)?1:0});
 return {m,tile};
}
test('walls, out of bounds, diagonals and valid cardinal steps',()=>{
 const {m,tile}=map();
 assert.equal(nav.walkable(m,0,1),false);assert.equal(nav.walkable(m,1,1),true);
 assert.equal(nav.canStep(m,{x:1,y:1},{x:2,y:1}),true);
 assert.equal(nav.canStep(m,{x:1,y:1},{x:2,y:2}),false);
 tile(2,1,{collision:1});assert.equal(nav.canStep(m,{x:1,y:1},{x:2,y:1}),false);
 assert.equal(nav.findPath(m,{x:1,y:1},{x:2,y:1}).length,0); // A* must not snap to a random neighbor.
});
test('directional blocking matches BOTH axes rather than independently',()=>{
 const {m,tile}=map();tile(3,3,{behavior:0x30}); // east restriction
 assert.equal(nav.canStep(m,{x:3,y:3},{x:4,y:3}),false);
 assert.equal(nav.canStep(m,{x:3,y:3},{x:2,y:3}),true);
 assert.equal(nav.canStep(m,{x:3,y:3},{x:3,y:2}),true);
 assert.equal(nav.canStep(m,{x:3,y:3},{x:3,y:4}),true);
});
test('ledges only permit their directed step, elevations cannot be crossed arbitrarily',()=>{
 const {m,tile}=map();tile(2,2,{behavior:0x3b});
 assert.equal(nav.canStep(m,{x:2,y:2},{x:2,y:3}),true);
 assert.equal(nav.canStep(m,{x:2,y:2},{x:3,y:2}),false);
 tile(4,4,{elevation:1});tile(5,4,{elevation:2});
 assert.equal(nav.canStep(m,{x:4,y:4},{x:5,y:4}),false);
});
test('water is gated and surf does not ignore solid collision',()=>{
 const {m,tile}=map();tile(3,3,{behavior:0x10});
 assert.equal(nav.walkable(m,3,3),false);assert.equal(nav.walkable(m,3,3,'surf'),true);
 tile(4,3,{behavior:0x10,collision:1});assert.equal(nav.walkable(m,4,3,'surf'),false);
});
test('shortest walk respects actual connected area and never crosses closed barriers',()=>{
 const {m,tile}=map();for(let y=1;y<=6;y++)tile(4,y,{collision:1});
 assert.deepEqual(nav.findPath(m,{x:1,y:1},{x:6,y:6}),[]);
 tile(4,4,{});const path=nav.findPath(m,{x:1,y:1},{x:6,y:6});
 assert.ok(path.length>=10);let previous={x:1,y:1};for(const step of path){assert.ok(nav.canStep(m,previous,step));previous=step;}
});
test('safe landing search is bounded, never teleport to a distant floor',()=>{
 const {m,tile}=map();for(let y=1;y<=6;y++)for(let x=1;x<=6;x++)tile(x,y,{collision:1});tile(6,6,{});
 assert.equal(nav.nearest(m,{x:1,y:1},'walk',2),null);
 assert.deepEqual(nav.nearest(m,{x:5,y:5},'walk',2),{x:6,y:6});
});
