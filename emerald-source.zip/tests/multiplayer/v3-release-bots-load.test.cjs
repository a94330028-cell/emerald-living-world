'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const BotAI=require('../../server/autonomy.cjs');
const {walkable}=require('../../server/world.cjs');
const NationalPools=require('../../jogo/game/pokemon/national-pools.js');
const Dex=require('../../server/dex.cjs');
test('100 bots podem executar rodadas independentes sem perder encontros nacionais',()=>{
 const bots=Array.from({length:100},(_,i)=>BotAI.createBot(i+1));
 assert.equal(new Set(bots.map(bot=>bot.id)).size,100);
 const original=Math.random;let seed=20261107;
 Math.random=()=>((seed=(Math.imul(seed,1664525)+1013904223)|0)>>>0)/4294967296;
 try{for(let round=0;round<100;round++)for(const bot of bots){BotAI.advance(bot);assert.equal(walkable(bot.area,bot.x,bot.y),true);}}
 finally{Math.random=original;}
 assert.ok(bots.every(bot=>bot.ticks>=100));
 const national=NationalPools.pool(Dex.PRIMARY,{location:'Route101',badges:0,champion:false,matchHabitat:true});
 assert.ok(national.length>0,'regional national encounter catalogue remains available');
});
