'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const World=require('../../server/world.cjs');const Battle=require('../../server/battle.cjs');

test('optional trainers appear in multiple route maps and block occupied tiles',()=>{
 const npcs=Object.entries(World.OPTIONAL_TRAINERS).flatMap(([area,trainers])=>trainers.map(t=>({...t,area})));
 assert.ok(npcs.length>=10);
 for(const npc of npcs){
  assert.equal(World.walkable(npc.area,npc.x,npc.y),false);
  assert.equal(World.MAPS[npc.area]._walls.has(`${npc.x}:${npc.y}`),false);
  assert.ok(npc.team.length>=1&&npc.team.every(([species,lv])=>Battle.SPEC[species]&&lv>=1));
  assert.equal(World.publicMap(npc.area).npcs.find(n=>n.id===npc.id).avatar,npc.avatar);
 }
});

test('NPC fights take real actions, pay rewards, persist victory and cannot be refarmed',()=>{
 const mon=Battle.create('Mudkip',15),id='calvin101';
 const p={area:'Route101',x:14,y:11,team:[mon],activeIndex:0,money:0,story:{},badges:0,npcDefeated:{}};
 assert.equal(Battle.optionalTrainerAt(p)?.id,id);
 const battle=Battle.begin(p,{type:'npc',trainerId:id});
 assert.equal(battle.enemy.species,'Poochyena');assert.equal(p.wins||0,0);
 let result;
 for(let i=0;i<40&&p.battle;i++){
  result=Battle.act(p,{type:'move',move:p.team[0].moves.find(m=>Battle.MOVES[m].power>0)||p.team[0].moves[0]});
 }
 assert.equal(p.battle,null);
 assert.equal(p.wins,1);
 assert.equal(p.npcDefeated[id],true);
 assert.equal(Battle.optionalTrainerAt(p),null);
 assert.ok(p.money>0);
 assert.equal(JSON.parse(JSON.stringify(p)).npcDefeated[id],true);
 assert.throws(()=>Battle.begin(p,{type:'npc',trainerId:id}),/derrotado|distante|encontrado/);
});

test('cannot fight route NPC from another map or capture their owned Pokémon',()=>{
 const p={area:'Littleroot',x:14,y:10,team:[Battle.create('Treecko',12)],activeIndex:0,story:{},badges:0};
 assert.equal(Battle.optionalTrainerAt(p),null);
 assert.throws(()=>Battle.begin(p,{type:'npc',trainerId:'calvin101'}),/NPC/);
 p.area='Route101';p.x=14;p.y=11;
 Battle.begin(p,{type:'npc',trainerId:'calvin101'});
 assert.throws(()=>Battle.act(p,{type:'ball'}),/capturar/i);
});
