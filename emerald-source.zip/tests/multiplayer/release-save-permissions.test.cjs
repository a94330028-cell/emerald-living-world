'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const os=require('node:os'),path=require('node:path'),fs=require('node:fs');
test('o save do servidor não é legível por outros usuários locais',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'elw-save-perms-'));
 const old=process.env.DATA_DIR;process.env.DATA_DIR=dir;
 const app=require('../../server/app.cjs');
 try{
  app.persist();const file=path.join(dir,'world.json');
  const data=JSON.parse(fs.readFileSync(file,'utf8'));
  assert.ok(Array.isArray(data.profiles));
  assert.ok(Array.isArray(data.bots));
  if(process.platform!=='win32')assert.equal(fs.statSync(file).mode&0o077,0);
  app.persist();assert.equal(fs.statSync(file+'.bak').mode&0o077,0);
 }finally{
  if(old===undefined)delete process.env.DATA_DIR;else process.env.DATA_DIR=old;
  fs.rmSync(dir,{recursive:true,force:true});
 }
});
