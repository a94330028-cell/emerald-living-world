'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'emerald-v6-'));
process.env.DATA_DIR=tmp;
const app=require('../../server/app.cjs');
const {MAPS,walkable,step,validateWorld}=require('../../server/world.cjs');
const nap=t=>new Promise(resolve=>setTimeout(resolve,t));
let origin,controller1,controller2;
function cookie(response){return response.headers.get('set-cookie').split(';')[0]}
async function req(route,body,c=''){const result=await fetch(origin+'/api/'+route,{method:'POST',headers:{'content-type':'application/json',...(c?{cookie:c}:{})},body:JSON.stringify(body)});return {status:result.status,headers:result.headers,data:await result.json()};}
async function stream(c){const controller=new AbortController();const res=await fetch(origin+'/api/stream',{headers:{cookie:c},signal:controller.signal});assert.equal(res.status,200);const reader=res.body.getReader();const first=await reader.read();const decoded=new TextDecoder().decode(first.value);assert.match(decoded,/snapshot/);const match=decoded.match(/data: ([^\n]+)/);assert.ok(match);return {controller,snapshot:JSON.parse(match[1]),reader};}
test('all standalone map doors lead to traversable positions',()=>{assert.deepEqual(validateWorld(),[]);for(const [name,m] of Object.entries(MAPS)){for(const p of m.portals){assert.ok(walkable(name,p.x,p.y));assert.ok(walkable(p.to,p.tx,p.ty));}}});
test('authoritative world refuses walls, diagonal steps and nonexistent portals',()=>{const p={area:'Littleroot',x:14,y:10,facing:'down'};assert.equal(step(p,'teleport'),false);assert.equal(step(p,'up'),true);assert.equal(p.x,14);p.x=3;p.y=2;assert.equal(step(p,'down'),false);assert.equal(step(p,'right'),true);});
test('shared Pokémon Center returns to the same city, not the wrong city',()=>{
 for(const area of ['Oldale','Petalburg']){
  const p={area,x:20,y:10,facing:'down'};
  assert.equal(step(p,'up'),true);
  assert.equal(p.area,'Center');assert.deepEqual(p.returnDoor,{area,x:20,y:10});
  p.x=14;p.y=18;
  assert.equal(step(p,'down'),true);
  assert.equal(p.area,area);assert.equal(p.x,20);assert.equal(p.y,10);
  assert.equal(p.returnDoor,undefined);
 }
});
test('two visitors persist, channel isolate, move and chat safely',async t=>{
 const server=await app.start(0,'127.0.0.1');origin='http://127.0.0.1:'+server.address().port;
 t.after(async()=>{controller1?.abort();controller2?.abort();await app.stop();fs.rmSync(tmp,{recursive:true,force:true});});
 const ready=await fetch(origin+'/api/health');assert.equal(ready.status,200);
 const a=await req('session',{name:'May A',channel:1,avatar:'may',starter:'Treecko'}),b=await req('session',{name:'Brendan B',channel:2,avatar:'brendan',starter:'Mudkip'});
 assert.equal(a.status,200);assert.equal(b.status,200);assert.notEqual(a.data.profile.id,b.data.profile.id);
 const ca=cookie({headers:a.headers}),cb=cookie({headers:b.headers});
 const A=await stream(ca),B=await stream(cb);controller1=A.controller;controller2=B.controller;
 assert.equal(A.snapshot.self.channel,1);assert.equal(B.snapshot.self.channel,2);
 assert.equal(A.snapshot.players.some(p=>p.id===b.data.profile.id),false);
 const invalid=await req('move',{dir:'teleport'},ca);assert.equal(invalid.status,422);
 const motion=await req('move',{dir:'up'},ca);assert.equal(motion.status,200);assert.equal(motion.data.self.y,9);
 // Force a recent authoritative movement timestamp: parallel test load can
 // otherwise exceed the 110 ms rate-limit window between HTTP requests.
 app.profiles.get(a.data.profile.id).lastMove=Date.now();
 const fast=await req('move',{dir:'up'},ca);assert.equal(fast.status,429);
 const view=await req('session',{mode:'spectator'},cb);assert.equal(view.status,200);assert.equal(view.data.profile.mode,'spectator');
 const spectateMove=await req('move',{dir:'up'},cb);assert.equal(spectateMove.status,403);
 await req('session',{mode:'online'},cb);
 const wrong=await req('channel',{channel:999},cb);assert.equal(wrong.status,422);
 const change=await req('channel',{channel:1},cb);assert.equal(change.status,200);
 // Route-specific encounters: Littleroot is a safe town; the player must walk
 // through the northern gate into Route101 before starting a wild battle.
 const unsafeTown=await req('battle/start',{type:'wild'},ca);assert.equal(unsafeTown.status,422);
 const traveler=app.profiles.get(a.data.profile.id);
 for(let i=0;i<10&&traveler.area==='Littleroot';i++)step(traveler,'up');
 assert.equal(traveler.area,'Route101');
 const wild=await req('battle/start',{type:'wild'},ca);assert.equal(wild.status,200);assert.ok(wild.data.self.battle);assert.ok(wild.data.self.team[0].moves.includes('Pound'));
 await nap(150);
 const locked=await req('move',{dir:'up'},ca);assert.equal(locked.status,409);
 const lockedChannel=await req('channel',{channel:2},ca);assert.equal(lockedChannel.status,409);
 const badMove=await req('battle/action',{type:'move',move:'HyperBeam'},ca);assert.equal(badMove.status,422);
 const hit=await req('battle/action',{type:'move',move:'Pound'},ca);assert.equal(hit.status,200);
 await nap(340);
 if(hit.data.self.battle){const run=await req('battle/action',{type:'run'},ca);assert.equal(run.status,200);assert.equal(run.data.self.battle,null);}
 const sanitize=await req('chat',{message:'<script>oi</script>'},ca);assert.equal(sanitize.status,200);
 const links=await req('chat',{message:'acesse https://example.com'},cb);assert.equal(links.status,422);
 const stored=await req('session',{},ca);assert.equal(stored.status,200);assert.equal(stored.data.profile.y,18);assert.equal(stored.data.profile.starter,'Treecko');
 await nap(30);app.persist();const data=JSON.parse(fs.readFileSync(path.join(tmp,'world.json')));assert.equal(data.profiles.length,2);assert.equal(data.profiles.find(x=>x.id===a.data.profile.id).y,18);
 const staticHtml=await fetch(origin+'/jogo/online.html');assert.equal(staticHtml.status,200);assert.match(await staticHtml.text(),/Mundo Compartilhado/);
 const privateSource=await fetch(origin+'/server/app.cjs');assert.equal(privateSource.status,404);
});
