'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const Dex=require('../../server/dex.cjs');const Battle=require('../../server/battle.cjs');
test('ROM Quetzal PT-BR Alpha9v1: 1,025 distinct National species and all 1,528 slots',()=>{
 assert.equal(Dex.META.nationalSpecies,1025);assert.equal(Dex.META.internalVariants,494);
 assert.equal(Dex.META.experimentalFormSlots,9);assert.equal(Dex.POKEMON.length,1528);
 assert.equal(Dex.PRIMARY.length,1025);assert.equal(new Set(Dex.PRIMARY.map(p=>p.name)).size,1025);
 assert.equal(new Set(Dex.POKEMON.map(p=>p.key)).size,1528);
 assert.deepEqual(Dex.PRIMARY.map(p=>p.dex),Array.from({length:1025},(_,i)=>i+1));
});
test('ROM-derived base stats and types are physically valid, including Fairy, regional and new species',()=>{
 const checks=[['Bulbasaur',[45,49,49,65,65,45],['Grass','Poison']],
 ['Pikachu',[35,55,40,50,50,90],['Electric']],
 ['Sprigatito',[40,61,54,45,45,65],['Grass']],
 ['Pecharunt',[88,88,160,88,88,88],['Poison','Ghost']]];
 for(const [key,stats,types] of checks){const p=Dex.BY_KEY.get(key);assert.deepEqual(p.base,stats,key);assert.deepEqual(p.types,types,key);}
 for(const p of Dex.POKEMON){
  assert.equal(p.base.length,6);
  assert.ok(p.base.every(x=>Number.isInteger(x)&&x>0),`Bad ROM stats ${p.key}`);
  assert.ok(p.types.length===1||p.types.length===2);
  assert.ok(p.types.every(x=>x!=='???'));
  assert.ok(Number.isInteger(p.exp)&&p.exp>=0);
  assert.ok(Battle.SPEC[p.key],`Missing playable species data ${p.key}`);
  assert.ok(Battle.SPEC[p.key].moves.length>0);
  assert.ok(Battle.SPEC[p.key].moves.every(m=>Battle.MOVES[m]));
 }
});
test('all registered species can instantiate and calculate distinct real level stats',()=>{
 for(const name of ['Charizard','Tinkaton','Arceus','Miraidon','Pecharunt','Venusaur@0899','Browt@1520']){
  const low=Battle.create(name,5),high=Battle.create(name,20);
  assert.equal(low.species,name);assert.equal(high.species,name);
  assert.equal(Battle.stat(high,'hp')>Battle.stat(low,'hp'),true);
  assert.ok(high.moves.every(m=>Battle.MOVES[m]));
 }
});
test('curated nine-generation starter evolutions are level-driven without inventing methods for all others',()=>{
 for(const [a,target] of [['Bulbasaur','Ivysaur'],['Chimchar','Monferno'],['Froakie','Frogadier'],['Rowlet','Dartrix'],['Sobble','Drizzile'],['Sprigatito','Floragato'],['Fuecoco','Crocalor'],['Quaxly','Quaxwell']]){
  assert.equal(Battle.SPEC[a].evolve[1],target);
 }
 assert.equal(Battle.SPEC.Tinkaton.evolve,undefined); // No fabricated evolution method.
});
test('Pokédex search, generation, forms, pagination and typing',()=>{
 const grass=Dex.query({type:'Grass',generation:'9',kind:'species',limit:4});
 assert.ok(grass.total>0);assert.ok(grass.results.every(p=>p.dex>=906&&p.types.includes('Grass')));
 assert.equal(Dex.query({search:'pecharunt'}).results[0].dex,1025);
 assert.equal(Dex.query({search:'Flabebe'}).total,1);
 assert.equal(Dex.query({kind:'variant'}).total,494);
 assert.equal(Dex.query({kind:'experimental'}).total,9);
 assert.equal(Dex.query({kind:'all'}).total,1528);
 assert.equal(Dex.query({limit:9999}).limit,80);
});
test('National wild encounters use ROM species and a biome, never create a Pokémon for free',()=>{
 const profile={id:'test',team:[Battle.create('Mudkip',15)],bag:{pokeballs:10},area:'Woods',badges:0,starter:'Mudkip',x:13,y:10};
 for(let i=0;i<35;i++){
  const result=Battle.begin(profile,{type:'wild',national:true});
  assert.ok(Dex.BY_KEY.has(result.enemy.species));
  assert.ok(result.enemy.level>=5&&result.enemy.level<=10);
  assert.ok(result.enemy.hp>0);
  assert.ok(result.enemy.types===undefined); // battle view is the Pokémon instance, types live in SPEC
  profile.battle=null;
 }
 assert.equal(profile.team.length,1);
});
