'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const Palace=require('../../server/frontier-palace.cjs');
const Arena=require('../../server/frontier-arena.cjs');
const Battle=require('../../server/battle.cjs');
const Frontier=require('../../server/frontier.cjs');
function profile(){const p={id:'test-rc4',starter:'Mudkip',name:'Frontier',area:'Littleroot',x:14,y:10,badges:8,champion:true,activeIndex:0,team:[]};
 p.team=['Swampert','Sceptile','Blaziken'].map(n=>Battle.create(n,50));return p;}
test('Palace possui 25 naturezas e porcentagens completas em ambas faixas de HP',()=>{
 assert.equal(Object.keys(Palace.NATURE_WEIGHTS).length,25);
 for(const nature of Object.keys(Palace.NATURE_WEIGHTS)){
  for(const low of [false,true]){const w=Palace.weights(nature,low);assert.equal(w.reduce((a,b)=>a+b),100);assert.ok(w.every(v=>v>=0&&v<=100));}
 }
 assert.deepEqual(Palace.weights('Brave',false),[70,15,15]);
 assert.deepEqual(Palace.weights('Brave',true),[32,60,8]);
 assert.deepEqual(Palace.weights('Lonely',true),[84,8,8]);
});
test('Palace escolhe categorias pela natureza, pode ficar incapaz e ignora comando do jogador',()=>{
 const m={nature:'Brave',hp:100,maxHp:100};
 const moves={Tackle:{power:40},Recover:{power:0},Growl:{power:0}};
 const all=['Tackle','Recover','Growl'];
 assert.equal(Palace.choose(m,all,moves,()=>.05).move,'Tackle');
 assert.equal(Palace.choose(m,all,moves,()=>.75).move,'Recover');
 assert.equal(Palace.choose(m,all,moves,()=>.99).move,'Growl');
 const rolls=[.72,.2];const impossible=Palace.choose(m,['Tackle'],moves,()=>rolls.shift());
 assert.equal(impossible.incapable,true);assert.equal(impossible.move,null);
 const p=profile();Frontier.start(p,{facility:'palace',teamIds:p.team.map(x=>x.id),practice:true});Frontier.next(p);
 const first=Battle.firstAlive(p);first.moves=['Tackle'];first.pp={Tackle:35};
 assert.doesNotThrow(()=>Battle.act(p,{type:'move',move:'AtaqueNaoAprendido'}));
});
test('Arena Mind e Skill não usam só HP e julgamento permite empate',()=>{
 assert.equal(Arena.mindPoints('Tackle',Battle.MOVES),1);
 assert.equal(Arena.mindPoints('Protect',Battle.MOVES),-1);
 assert.equal(Arena.mindPoints('FakeOut',Battle.MOVES),-1);
 assert.equal(Arena.skillPoints({species:'Mudkip'},'Tackle',['Mudkip usou Tackle: acerto 1, 10 HP.'],2),2);
 assert.equal(Arena.skillPoints({species:'Mudkip'},'Tackle',['Mudkip errou Tackle.']),-2);
 const own={id:'a',species:'Mudkip',hp:80,maxHp:100},foe={id:'b',species:'Treecko',hp:80,maxHp:100};
 const round=Arena.init(own,foe);
 Arena.record(round,'own',own,'Tackle',Battle.MOVES,['Mudkip usou Tackle: 10 HP.']);
 Arena.record(round,'foe',{...foe,species:'Treecko'},'Protect',Battle.MOVES,['Treecko usou Protect!']);
 assert.equal(Arena.judge(round,own,foe).winner,'own');
 assert.equal(Arena.judge(Arena.init(own,foe),own,foe).winner,'tie');
});
test('Arena exibe o resultado de Mind, Skill e Body após três turnos',()=>{
 const p=profile();Frontier.start(p,{facility:'arena',teamIds:p.team.map(x=>x.id),practice:true});Frontier.next(p);
 for(const m of p.team){m.moves=['Growl'];m.pp.Growl=40;}
 p.battle.enemy.moves=['Growl'];p.battle.enemy.pp.Growl=40;
 let logs=[];
 for(let i=0;i<3&&p.battle;i++){
  const result=Battle.act(p,{type:'move',move:'Growl'});
  logs=logs.concat(result.log||[]);
 }
 assert.ok(logs.some(x=>x.includes('Battle Arena — Mind')),logs.join('\n'));
});
