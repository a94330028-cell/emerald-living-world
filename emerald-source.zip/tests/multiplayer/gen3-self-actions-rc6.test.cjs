'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const Battle=require('../../server/battle.cjs');
const Target=require('../../server/gen3-doubles.cjs');
function wild(move){
 const p={id:'rc6-player',starter:'Treecko',area:'Route101',badges:0,channel:1,x:10,y:10};
 Battle.createProfileStarter(p);
 const hero=Battle.create('Sceptile',90);
 hero.moves=[move,'Tackle'];hero.pp={[move]:15,Tackle:35};hero.stages.accuracy=-6;
 p.team=[hero];
 Battle.begin(p,{type:'wild'});
 p.battle.enemy.protected=true;
 p.battle.enemy.stages.evasion=6;
 p.battle.enemy.status='sleep';p.battle.enemy.sleepTurns=5;
 return {p,hero,foe:p.battle.enemy};
}
test('Protect adversário não bloqueia Recover, mesmo com estágios extremos de evasão',()=>{
 const {p,hero,foe}=wild('Recover');hero.hp=Math.floor(hero.maxHp/3);
 const before=hero.hp;
 const out=Battle.act(p,{type:'move',move:'Recover'});
 assert.ok(hero.hp>before);assert.ok(out.log.some(line=>line.includes('usou Recover')));
 assert.equal(out.log.some(line=>line.includes('se protegeu de Recover')),false);
 assert.equal(foe.hp,foe.maxHp);
});
test('Swords Dance e Calm Mind afetam usuário apesar do Protect rival',()=>{
 for(const [move,stages] of [['SwordsDance',['atk']],['CalmMind',['spa','spd']]]){
  const {p,hero}=wild(move);
  Battle.act(p,{type:'move',move});
  for(const stat of stages)assert.equal(hero.stages[stat],move==='SwordsDance'?2:1,`${move}: ${stat}`);
 }
});
test('Clima e Wish são efeitos de campo/usuário, não ataques contra Protect',()=>{
 const rain=wild('RainDance');Battle.act(rain.p,{type:'move',move:'RainDance'});
 assert.equal(rain.p.battle.weather,'rain');
 const wish=wild('Wish');Battle.act(wish.p,{type:'move',move:'Wish'});
 assert.ok(wish.p.battle.wishes.own);
 assert.equal(wish.p.battle.wishes.foe,undefined);
});
test('Explosion é autodestrutivo mesmo quando o alvo usa Protect',()=>{
 const {p,hero,foe}=wild('Explosion');
 const hp=foe.hp;
 const out=Battle.act(p,{type:'move',move:'Explosion'});
 assert.equal(hero.hp,0);assert.equal(foe.hp,hp);
 assert.equal(out.done,true);assert.equal(out.victory,false);
});
test('Explosion também desmaia o usuário quando Wonder Guard impede dano',()=>{
 const {p,hero,foe}=wild('Explosion');foe.protected=false;foe.ability='WonderGuard';
 Battle.act(p,{type:'move',move:'Explosion'});
 assert.equal(hero.hp,0);assert.equal(foe.hp,foe.maxHp);
});
test('Double: golpes próprios selecionam o próprio slot; suporte não retargeta',()=>{
 const board={A1:{id:'a1',hp:100},A2:{id:'a2',hp:100},B1:{id:'b1',hp:100},B2:{id:'b2',hp:100}};
 for(const move of ['Protect','Recover','SwordsDance','CalmMind','Wish','Howl']){
  assert.equal(Target.targetClass(move),'self',move);
  assert.deepEqual(Target.resolveTargets(board,'A1',move,'B1',{followMe:'B2'}),['A1'],move);
 }
 assert.equal(Target.targetClass('RainDance'),'field');
 assert.deepEqual(Target.resolveTargets(board,'B2','RainDance','A1'),[]);
});
