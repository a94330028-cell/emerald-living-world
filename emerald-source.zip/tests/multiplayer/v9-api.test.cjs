'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'emerald-v9-'));
process.env.DATA_DIR=tmp;process.env.BOT_TICK_MS='60000';
const app=require('../../server/app.cjs'),Battle=require('../../server/battle.cjs');
const cookie=r=>r.headers.get('set-cookie')?.split(';')[0];
test('real HTTP multiplayer: two guests, bot route, contested duel, HP persisted on bot',async t=>{
 const srv=await app.start(0,'127.0.0.1'),base=`http://127.0.0.1:${srv.address().port}`;
 const aborts=[];t.after(async()=>{for(const c of aborts)c.abort();await app.stop();fs.rmSync(tmp,{force:true,recursive:true})});
 app.advanceBots(); // Legitimately select starters via BotAI, not a forged Pokémon.
 async function post(path,body,c=''){const r=await fetch(base+'/api/'+path,{method:'POST',headers:{'content-type':'application/json',...(c?{cookie:c}:{})},body:JSON.stringify(body)});return {r,data:await r.json()}}
 const a=await post('session',{name:'Jogadora A',channel:1,starter:'Mudkip'}),b=await post('session',{name:'Jogadora B',channel:1,starter:'Treecko'});
 const ca=cookie(a.r),cb=cookie(b.r);assert.ok(ca&&cb);
 async function stream(c){const ctl=new AbortController();aborts.push(ctl);const res=await fetch(base+'/api/stream',{headers:{cookie:c},signal:ctl.signal});assert.equal(res.status,200);await res.body.getReader().read();}
 await stream(ca);await stream(cb);
 const same=await fetch(base+'/api/route/bot-1',{headers:{cookie:ca}});assert.equal(same.status,200);const route=await same.json();assert.equal(route.ok,true);
 const other=await fetch(base+'/api/route/bot-2',{headers:{cookie:ca}});const otherRoute=await other.json();assert.equal(otherRoute.reason,'different-channel');
 const my=app.profiles.get(a.data.profile.id);my.team=[Battle.create('Mudkip',24)];
 const bot=app.onlineBots[0];assert.equal(bot.area,'Littleroot');bot.team[0].hp=1;const persistentId=bot.team[0].id;
 const begun=await post('battle/start',{type:'bot',botId:bot.id},ca);assert.equal(begun.r.status,200,JSON.stringify(begun.data));
 assert.equal(begun.data.self.battle.enemy.id,persistentId);assert.equal(bot.duelWith,my.id);
 const clash=await post('battle/start',{type:'bot',botId:bot.id},cb);assert.equal(clash.r.status,422);
 const action=await post('battle/action',{type:'move',move:'WaterGun'},ca);assert.equal(action.r.status,200,JSON.stringify(action.data));
 assert.equal(action.data.result.done,true);assert.equal(bot.team[0].hp,0);assert.equal(bot.duelWith,undefined);
 assert.equal(bot.losses,1);assert.equal(my.wins,1);
 app.persist();const disk=JSON.parse(fs.readFileSync(path.join(tmp,'world.json')));assert.equal(disk.bots[0].team[0].hp,0);
});
