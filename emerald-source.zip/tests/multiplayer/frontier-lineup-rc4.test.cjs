'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const Battle=require('../../server/battle.cjs');
const Frontier=require('../../server/frontier.cjs');
function makeProfile(){const p={name:'Teste',id:'rc4-fixture',champion:true,starter:'Mudkip',team:['Swampert','Sceptile','Blaziken'].map(n=>Battle.create(n,50)),activeIndex:0};return p;}
test('Dome permite escolher qualquer dupla legal entre três registrados antes da batalha',()=>{
 const p=makeProfile(),ids=p.team.map(m=>m.id);
 Frontier.start(p,{facility:'dome',practice:true,teamIds:ids});
 const f=Frontier.selectLineup(p,{teamIds:[ids[1],ids[2]]});
 assert.deepEqual(f.active.selectedTeamIds,[ids[1],ids[2]]);
 assert.equal(p.activeIndex,1);
 assert.throws(()=>Frontier.selectLineup(p,{teamIds:[ids[1],ids[1]]}),/diferentes/);
 assert.throws(()=>Frontier.selectLineup(p,{teamIds:[ids[1],Battle.create('Mudkip',5).id]}),/não registrado/);
 const battle=Frontier.next(p);
 assert.equal(battle.type,'frontier');assert.equal(battle.activePokemonId,ids[1]);
 assert.deepEqual(p.battle.selectedTeamIds,[ids[1],ids[2]]);
 assert.throws(()=>Frontier.selectLineup(p,{teamIds:[ids[0],ids[1]]}),/confronto/);
});
test('Factory deixa escolher três dos seis aluguéis e bloqueia trocar seleção após primeira batalha',()=>{
 const p=makeProfile(),original=p.team.map(m=>m.id);
 Frontier.start(p,{facility:'factory',practice:true});
 const all=p.frontier.active.rentals;
 assert.equal(all.length,6);
 const selected=all.slice(3,6).map(m=>m.id);
 Frontier.selectLineup(p,{teamIds:selected});
 assert.deepEqual(p.frontier.active.teamIds,selected);
 assert.equal(p.activeIndex,3);
 const battle=Frontier.next(p);
 assert.equal(battle.activePokemonId,selected[0]);
 assert.deepEqual(p.team.map(m=>m.id),original);
 assert.equal(p.frontier.active.lineupLocked,true);
 Frontier.recordResult(p,p.battle,true);p.battle=null;
 assert.throws(()=>Frontier.selectLineup(p,{teamIds:all.slice(0,3).map(m=>m.id)}),/primeira batalha/);
});
test('nem a selection de rental nem a do Dome mexem nos habitats de captura',()=>{
 const national=require('../../jogo/game/pokemon/national-pools.js');
 assert.equal(typeof national.pool,'function');
 assert.equal(typeof national.encounterInfo,'function');
});
