'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),b=require('../../server/battle.cjs');
function profile(starter='Mudkip',area='Route101',badges=0){const p={id:'p1',starter,area,channel:1,x:10,y:10,badges};b.createProfileStarter(p);return p;}
test('Gen III formulas grow with level and use IV EV Nature',()=>{const a=b.create('Mudkip',5),c={...a,level:20};assert.ok(b.stat(c,'hp')>b.stat(a,'hp'));assert.ok(b.stat(c,'atk')>b.stat(a,'atk'));
 const high={...a,ivs:{...a.ivs,atk:31},evs:{...a.evs,atk:252},nature:'Adamant'},low={...a,ivs:{...a.ivs,atk:0},evs:{...a.evs,atk:0},nature:'Modest'};
 assert.ok(b.stat({...high,level:50},'atk')>b.stat({...low,level:50},'atk'));
});
test('Gen III type chart and level affect damage',()=>{const water=b.create('Mudkip',20),fire=b.create('Torchic',15);assert.equal(b.effective('Water',fire),2);assert.equal(b.effective('Ground',b.create('Taillow',10)),0);
 const low={...water,level:5};assert.ok(b.estimate(water,fire,'WaterGun')>b.estimate(low,fire,'WaterGun'));
});
test('wild encounters are server-authoritative and update team experience',()=>{const p=profile();p.team[0]=b.create('Mudkip',15);p.team[0].moves=['WaterGun'];b.begin(p);assert.ok(p.battle);assert.throws(()=>b.begin(p),/andamento/);
 p.battle.enemy.hp=1;const outcome=b.act(p,{type:'move',move:'WaterGun'});assert.equal(outcome.done,true);assert.equal(outcome.victory,true);assert.equal(p.wins,1);assert.equal(p.battle,null);assert.equal(p.team[0].level,15);assert.ok(p.team[0].exp>3375,'earned XP is not deleted at advisory cap');
});
test('capture consumes a ball, persists Pokémon and rejects trainer capture',()=>{const p=profile();b.begin(p);p.battle.enemy.hp=1;
 const prev=Math.random;Math.random=()=>0;try{const result=b.act(p,{type:'ball'});assert.equal(result.done,true);assert.equal(p.team.length,2);assert.equal(p.bag.pokeballs,4);assert.equal(p.battle,null)}finally{Math.random=prev}
 const bot={id:'bot-1',name:'Red',area:p.area,channel:1,x:p.x,y:p.y,team:[{species:'Treecko',level:5}]};b.begin(p,{type:'bot',bot});assert.throws(()=>b.act(p,{type:'ball'}),/Não é permitido/);
});
test('evolution recalculates stats and follows next badge cap',()=>{const p=profile('Treecko','Route101',1);p.team[0]=b.create('Treecko',15);p.team[0].exp=4095;b.begin(p);p.battle.enemy.hp=1;
 const won=b.act(p,{type:'move',move:'Pound'});assert.equal(won.done,true);assert.equal(p.team[0].level,16);assert.equal(p.team[0].species,'Grovyle');assert.equal(p.team[0].maxHp,b.stat(p.team[0],'hp'));
});
test('battles only start with a living Pokémon, and heal requires Center',()=>{const p=profile();p.team[0].hp=0;assert.throws(()=>b.begin(p),/sem HP/);assert.throws(()=>b.heal(p),/Centro Pokémon/);p.area='Center';b.heal(p);assert.equal(p.team[0].hp,p.team[0].maxHp);
});
