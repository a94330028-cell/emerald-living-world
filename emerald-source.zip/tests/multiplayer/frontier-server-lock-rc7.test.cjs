'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const os=require('node:os');
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'elw-rc7-gate-'));
process.env.DATA_DIR=tmp;
process.env.BOT_TICK_MS='60000';
process.env.AUTH_MODE='optional';
const app=require('../../server/app.cjs');
const Battle=require('../../server/battle.cjs');
function header(r){return r.headers.get('set-cookie')?.split(';')[0]||'';}

test('HTTP: a Frontier isola o desafio e libera o jogador ao abandonar',async t=>{
 const srv=await app.start(0,'127.0.0.1');const host='http://127.0.0.1:'+srv.address().port;
 const ctrl=new AbortController();
 t.after(async()=>{ctrl.abort();await app.stop();fs.rmSync(tmp,{recursive:true,force:true});});
 const post=async (name,body,cookie)=>{const r=await fetch(host+'/api/'+name,{method:'POST',headers:{'content-type':'application/json',cookie},body:JSON.stringify(body)});return {status:r.status,data:await r.json()};};
 const response=await fetch(host+'/api/session',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name:'Desafio'})});
 const c=header(response);assert.ok(c);
 const payload=await response.json();const p=app.profiles.get(payload.profile.id);
 p.area='Center';p.champion=true;p.badges=8;p.team=['Swampert','Sceptile','Blaziken'].map(name=>Battle.create(name,50));
 const stream=await fetch(host+'/api/stream',{headers:{cookie:c},signal:ctrl.signal});
 assert.equal(stream.status,200);await stream.body.getReader().read();
 let r=await post('frontier/start',{facility:'pike',practice:false,teamIds:p.team.map(mon=>mon.id)},c);
 assert.equal(r.status,200,JSON.stringify(r.data));
 p.team[0].hp=1;
 for(const [name,body] of [['battle/heal',{}],['battle/start',{type:'wild'}],['shop/buy',{item:'pokeballs',count:1}],['story/interact',{}],['move',{dir:'up'}],['channel',{channel:2}]]){
  r=await post(name,body,c);
  assert.equal(r.status,409,name+' '+JSON.stringify(r.data));
 }
 assert.equal(p.team[0].hp,1);
 r=await post('session',{name:'Renomear',channel:2,mode:'spectator'},c);
 assert.equal(r.status,409);
 r=await post('session',{name:'Renomear',channel:2,mode:'online'},c);
 assert.equal(r.status,200);
 assert.equal(p.channel,1);
 assert.equal(p.mode,'online');
 r=await post('frontier/retire',{},c);assert.equal(r.status,200);
 r=await post('battle/heal',{},c);assert.equal(r.status,200);
 assert.equal(p.team[0].hp,p.team[0].maxHp);
});
