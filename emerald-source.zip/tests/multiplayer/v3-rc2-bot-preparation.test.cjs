'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const AI=require('../../server/autonomy.cjs');
const Battle=require('../../server/battle.cjs');
function bot(){const b=AI.createBot(1);AI.advance(b);b.phase='prepareBrawly';b.badges=1;b.story={roxanne:true,peeko:true,steven:true};
 b.team=[Battle.create('Swampert',91),Battle.create('Wingull',13)];b.activeIndex=0;
 b.area='Route106';b.x=14;b.y=12;b.bag={pokeballs:4};return b;}
test('um Wingull desmaiado em preparação para Brawly deve ser levado para recuperar',()=>{
 const b=bot();b.team[1].hp=0;AI.advance(b);
 assert.equal(b.recovering,true);
 assert.equal(b.badges,1);
 assert.notEqual(b.battle?.type,'gym');
});
test('bot interrompe grind improdutivo e tenta desafio real sem insígnia gratuita',()=>{
 const b=bot();b.brawlySupportTraining=300;AI.advance(b);
 assert.equal(b.phase,'gymBrawly');assert.equal(b.badges,1);
 assert.equal(b.story.brawly,undefined);
});
