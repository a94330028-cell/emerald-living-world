'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const {resolveOne,resetOnSwitch}=require('../../server/gen3-residual.cjs');
test('weather before leftovers before seed before poison',()=>{
 const m={maxHp:160,hp:100,status:'poison'};
 const r=resolveOne(m,{weather:'sandstorm',leftovers:true,seeded:true});
 assert.deepEqual(r.events.map(e=>e.kind),['weather','leftovers','leech-seed-damage','poison']);
 assert.equal(m.hp,60);
});
test('leftovers can heal before poison faints the Pokemon',()=>{
 const m={maxHp:160,hp:5,status:'poison'};
 assert.deepEqual(resolveOne(m,{leftovers:true}).events.map(e=>e.kind),['leftovers','poison','faint']);
 assert.equal(m.hp,0);
});
test('weather faint stops further events',()=>{
 const m={maxHp:160,hp:5,status:'poison'};
 assert.deepEqual(resolveOne(m,{weather:'hail',leftovers:true}).events.map(e=>e.kind),['weather','faint']);
});
test('toxic counter increases and resets on switch',()=>{
 const m={maxHp:160,hp:160,status:'toxic',toxicCounter:0};
 resolveOne(m);assert.equal(m.hp,150);resolveOne(m);assert.equal(m.hp,130);
 resetOnSwitch(m);resolveOne(m);assert.equal(m.hp,120);
});
test('weather immunity prevents weather damage',()=>{
 const m={maxHp:160,hp:100,status:null};
 assert.equal(resolveOne(m,{weather:'sandstorm',weatherImmune:true}).events.length,0);
});
test('no healing after faint',()=>{
 const m={maxHp:160,hp:0,status:'poison'};
 assert.equal(resolveOne(m,{leftovers:true}).events.length,0);
});
test('unsupported status is not silently misinterpreted',()=>{
 assert.throws(()=>resolveOne({maxHp:100,hp:90,status:'sleep'}),/Unsupported/);
});
