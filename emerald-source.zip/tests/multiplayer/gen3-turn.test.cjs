const test=require('node:test');const assert=require('node:assert/strict');const g=require('../../server/gen3-turn.cjs');
test('Gen III move priority including ExtremeSpeed',()=>{assert.equal(g.priority('HelpingHand'),5);assert.equal(g.priority('Protect'),3);assert.equal(g.priority('ExtremeSpeed'),1);assert.equal(g.priority('Surf'),0);assert.equal(g.priority('Counter'),-5);});
test('priority beats speed',()=>assert.equal(g.moveGoesFirst({move:'QuickAttack',speed:10},{move:'Surf',speed:200}),true));
test('speed breaks priority ties',()=>assert.equal(g.moveGoesFirst({move:'Surf',speed:100},{move:'Tackle',speed:120}),false));
test('speed ties are randomized, not biased to player',()=>{assert.equal(g.moveGoesFirst({move:'Surf',speed:100},{move:'Tackle',speed:100},()=>0),true);assert.equal(g.moveGoesFirst({move:'Surf',speed:100},{move:'Tackle',speed:100},()=>.99),false)});
test('paralysis speed reduction',()=>assert.equal(g.speedWithParalysis(121,true),30));
test('Gen III physical special by type',()=>{assert.equal(g.isPhysical('Ghost'),true);assert.equal(g.isPhysical('Dark'),false)});
test('fixed damage moves',()=>{assert.equal(g.fixedDamage('NightShade',48,100),48);assert.equal(g.fixedDamage('DragonRage',48,100),40);assert.equal(g.fixedDamage('SuperFang',48,101),50)});
test('spread modifier Gen III',()=>{assert.equal(g.gen3SpreadMultiplier('both-opponents',2),.5);assert.equal(g.gen3SpreadMultiplier('all-other',3),1)});
