'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const Battle=require('../../server/battle.cjs');
const Frontier=require('../../server/frontier.cjs');
function trainer(){return {id:'integrity-test',name:'Integridade',champion:true,badges:8,area:'Center',
 team:['Snorlax','Swampert','Sceptile'].map(n=>Battle.create(n,50)),activeIndex:0};}
function enter(p,facility){Frontier.start(p,{facility,practice:false,levelRule:'level50',teamIds:p.team.map(m=>m.id)});}
test('uma batalha pendente não pode ser substituída nem conceder vitória sem resultado autenticado',()=>{
 const p=trainer();enter(p,'tower');Frontier.next(p);const run=p.frontier.active,b=p.battle;
 assert.ok(run.pendingEncounter);
 p.battle=null; // simula um save ou reinício incompleto
 assert.throws(()=>Frontier.next(p),/Encontro pendente/);
 Frontier.recordResult(p,{type:'frontier',frontierRunId:run.id,frontierChallengeNumber:1},true);
 assert.equal(run.streak,0);
 assert.ok(run.pendingEncounter);
 Frontier.recordResult(p,{...b,frontierResultId:'token-incorreto'},true);
 assert.equal(run.streak,0);
 Frontier.recordResult(p,b,true);
 assert.equal(run.streak,1);
 assert.equal(run.pendingEncounter,null);
 Frontier.recordResult(p,b,true);
 assert.equal(run.streak,1);
});
test('trocas da Factory exigem vitória no desafio anterior, não apenas desaparecimento da batalha',()=>{
 const p=trainer();Frontier.start(p,{facility:'factory',practice:false});Frontier.next(p);
 const r=p.frontier.active; p.battle=null;
 r.swaps=['Wingull'];
 assert.throws(()=>Frontier.swap(p,{oldId:r.teamIds[0],newSpecies:'Wingull'}),/resolvidas/);
 assert.throws(()=>Frontier.next(p),/Encontro pendente/);
});
test('a Pyramid não permite consumir Battle Bag enquanto um combate estiver pendente',()=>{
 const p=trainer();enter(p,'pyramid');const run=p.frontier.active;
 p.team[0].hp=10;run.pendingEncounter='persistente';
 assert.throws(()=>Frontier.useBattleBag(p,{pokemonId:p.team[0].id}),/pendentes/);
});
test('se o último Pokémon usa Explosion e ambos desmaiam, não há vitória nem medalha LAB',()=>{
 const p=trainer();enter(p,'tower');Frontier.next(p);
 const own=Battle.firstAlive(p);
 own.moves=['Explosion'];own.pp={Explosion:5};p.team[1].hp=0;p.team[2].hp=0;
 p.battle.enemy.hp=1;p.battle.enemy.moves=['Growl'];p.battle.enemy.pp={Growl:40};p.battle.remaining=[];
 const result=Battle.act(p,{type:'move',move:'Explosion'});
 assert.equal(result.done,true);assert.equal(result.victory,false);
 assert.equal(p.frontier.active,null);
 assert.equal(p.frontier.labBP,0);
 assert.deepEqual(p.frontier.labSymbols,{});
});
test('uma vitória normal ainda contabiliza um encontro resolvido',()=>{
 const p=trainer();enter(p,'tower');Frontier.next(p);
 const own=Battle.firstAlive(p);own.moves=['QuickAttack'];own.pp={QuickAttack:30};
 p.battle.enemy.hp=1;p.battle.enemy.moves=['Growl'];p.battle.enemy.pp={Growl:40};p.battle.remaining=[];
 const result=Battle.act(p,{type:'move',move:'QuickAttack'});
 assert.equal(result.done,true);assert.equal(result.victory,true);
 assert.equal(p.frontier.active.streak,1);
 assert.equal(p.frontier.active.pendingEncounter,null);
});
