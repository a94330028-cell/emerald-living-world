'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),net=require('node:net');
const {spawn}=require('node:child_process');
const root=path.resolve(__dirname,'../..');
const nap=ms=>new Promise(ok=>setTimeout(ok,ms));
async function openPort(){return new Promise((resolve,reject)=>{const s=net.createServer();s.on('error',reject);s.listen(0,'127.0.0.1',()=>{const port=s.address().port;s.close(()=>resolve(port));});});}
async function launch(port,dataDir){const child=spawn(process.execPath,['server/app.cjs'],{cwd:root,env:{...process.env,HOST:'127.0.0.1',PORT:String(port),DATA_DIR:dataDir,BOT_COUNT:'5',BOT_TICK_MS:'110'},stdio:['ignore','pipe','pipe']});
 let stderr='';child.stderr.on('data',buf=>stderr+=buf.toString());
 for(let attempts=0;attempts<80;attempts++){
  if(child.exitCode!==null)throw Error(`server died: ${stderr}`);
  try{const r=await fetch(`http://127.0.0.1:${port}/api/health`);if(r.ok)return child;}catch{}
  await nap(70);
 }child.kill('SIGTERM');throw Error('server did not respond');}
async function shutdown(child){if(child.exitCode!==null)return;
 const done=new Promise(resolve=>child.once('exit',resolve));child.kill('SIGTERM');await Promise.race([done,nap(6000).then(()=>{throw Error('server failed to stop')})]);}
async function get(port,p,cookie=''){const res=await fetch(`http://127.0.0.1:${port}/api/${p}`,{headers:cookie?{cookie}:{}});return {status:res.status,body:await res.json()};}
test('true process restart restores bot objective, team, location, time and visitor session',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'emerald-v7-restart-'));
 const port=await openPort();let a,b;t.after(async()=>{if(a)await shutdown(a);if(b)await shutdown(b);fs.rmSync(dir,{recursive:true,force:true})});
 a=await launch(port,dir);
 const created=await fetch(`http://127.0.0.1:${port}/api/session`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name:'Visitante salvo',mode:'spectator'})});
 assert.equal(created.status,200);const cookie=created.headers.get('set-cookie').split(';')[0];
 await nap(1600);
 const before=await get(port,'bots/bot-1',cookie);assert.equal(before.status,200);assert.ok(before.body.bot.ticks>3);
 await shutdown(a);a=null;
 const disk=JSON.parse(fs.readFileSync(path.join(dir,'world.json'),'utf8'));
 const stored=disk.bots.find(x=>x.id==='bot-1');assert.ok(stored.ticks>=before.body.bot.ticks);
 assert.ok(stored.milestones.some(x=>x.type==='starter'));assert.ok(Array.isArray(stored.team)&&stored.team.length);
 b=await launch(port,dir);
 const after=await get(port,'bots/bot-1',cookie);assert.equal(after.status,200);
 assert.ok(after.body.bot.ticks>=stored.ticks);assert.equal(after.body.bot.starter,stored.starter);
 assert.equal(after.body.bot.team[0].species,stored.team[0].species);
 assert.ok(after.body.bot.milestones?.some(x=>x.type==='starter'));
 const ranking=await get(port,'ranking',cookie);assert.equal(ranking.status,200);assert.equal(ranking.body.ranking.length,5);
 const health=await get(port,'health');assert.equal(health.body.bots,5);
 await nap(440);const resumed=await get(port,'bots/bot-1',cookie);assert.ok(resumed.body.bot.ticks>after.body.bot.ticks);
});

test('real process restart preserves three earned badges, story flags and captured team',async t=>{
 const AI=require('../../server/autonomy.cjs');
 const bot=AI.createBot(3);
 for(let turn=0;turn<40000&&bot.badges<3;turn++)AI.advance(bot);
 assert.equal(bot.badges,3,'fixture must earn its badges via Battle.act before saving');
 assert.equal(bot.story.wattson,true);
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'emerald-v8-three-badges-'));
 fs.writeFileSync(path.join(dir,'world.json'),JSON.stringify({schema:2,simTick:bot.ticks,bots:[bot],profiles:[]}));
 const port=await openPort();let first,second;
 t.after(async()=>{if(first)await shutdown(first);if(second)await shutdown(second);fs.rmSync(dir,{recursive:true,force:true});});
 first=await launch(port,dir);
 const resp=await fetch(`http://127.0.0.1:${port}/api/session`,{method:'POST',headers:{'content-type':'application/json'},body:'{}'});
 const cookie=resp.headers.get('set-cookie').split(';')[0];
 const before=await get(port,'bots/bot-3',cookie);
 assert.equal(before.body.bot.badges,3);
 assert.ok(['next','lateGym'].includes(before.body.bot.phase),`valid progress phase: ${before.body.bot.phase}`); // restored bot may advance while server is running
 await shutdown(first);first=null;
 const stored=JSON.parse(fs.readFileSync(path.join(dir,'world.json'),'utf8')).bots.find(b=>b.id==='bot-3');
 assert.equal(stored.story.peeko,true);assert.equal(stored.story.steven,true);
 assert.equal(stored.story.wattson,true);assert.equal(stored.badges,3);
 const ids=stored.team.map(m=>m.id);
 second=await launch(port,dir);
 const after=await get(port,'bots/bot-3',cookie);
 assert.equal(after.status,200);assert.equal(after.body.bot.badges,3);
 const current=require('node:fs').readFileSync(path.join(dir,'world.json'),'utf8');
 const currentBot=JSON.parse(current).bots.find(b=>b.id==='bot-3');
 assert.deepEqual(currentBot.team.map(m=>m.id),ids);
 assert.deepEqual(currentBot.milestones.filter(e=>e.type==='badge').map(e=>e.badges),[1,2,3]);
});
