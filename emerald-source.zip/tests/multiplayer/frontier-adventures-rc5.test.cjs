'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const Adventures=require('../../server/frontier-adventures.cjs');
const Frontier=require('../../server/frontier.cjs');
const Battle=require('../../server/battle.cjs');
function profile(){return {id:crypto.randomUUID(),name:'Aventura',champion:true,starter:'Mudkip',area:'Route101',activeIndex:0,team:['Swampert','Sceptile','Blaziken'].map(n=>Battle.create(n,50))};}
function enter(p,facility){return Frontier.start(p,{facility,practice:false,teamIds:facility==='factory'?[]:p.team.map(m=>m.id)});}
test('Pike: três portas persistentes, pista restrita e validação da escolha',()=>{
 const p=profile();const state=enter(p,'pike');const doors=state.active.pikeDoors;
 assert.equal(doors.doors.length,3);assert.equal(doors.doors.every(x=>Object.keys(x).join()==='index'),true);
 assert.match(doors.hint.text, /passagem/);assert.deepEqual(Frontier.info(p).active.pikeDoors,doors);
 assert.throws(()=>Frontier.next(p,{door:9}),/portas/);
 assert.deepEqual(Frontier.info(p).active.pikeDoors,doors);
 const result=Frontier.next(p,{door:doors.hint.door});
 assert.ok(result.type==='frontier'||result.event);
 assert.equal(p.frontier.active.room,1);
 if(p.battle){assert.throws(()=>Frontier.next(p,{door:1}),/batalha/);Frontier.recordResult(p,p.battle,true);p.battle=null;}
 assert.equal(p.frontier.active.streak,1);
 assert.equal(Frontier.info(p).active.pikeDoors.doors.length,3);
});
test('Dome: 16 inscritos, quatro rodadas e progressão sem vitória grátis',()=>{
 const p=profile();let s=enter(p,'dome');assert.equal(s.active.domeBracket.entrants.length,16);
 assert.equal(s.active.domeBracket.rounds.length,4);
 for(let i=0;i<4;i++){
  const b=Frontier.next(p);assert.equal(b.type,'frontier');
  assert.equal(p.frontier.active.domeBracket.rounds[i].completed,false);
  Frontier.recordResult(p,p.battle,true);p.battle=null;
  assert.equal(p.frontier.active.domeBracket.rounds[i].completed,true);
 }
 assert.equal(p.frontier.active.streak,4);
 assert.equal(p.frontier.active.domeBracket.completed,true);
 s=Frontier.next(p);assert.equal(s.type,'frontier');
 assert.equal(p.frontier.active.domeBracket.number,2);
 assert.equal(p.frontier.active.domeBracket.entrants.length,16);
});
test('Pyramid: 5x5 caminho alcançável; só encontrar a saída avança um andar',()=>{
 for(let run=0;run<12;run++){
  const floor=Adventures.createPyramidFloor(run+1);
  assert.equal(floor.tiles.length,25);
  const map=new Map(floor.tiles.filter(t=>t.kind!=='wall').map(t=>[`${t.x},${t.y}`,t]));
  const visited=new Set(['0,0']),queue=[[0,0]];
  while(queue.length){const [x,y]=queue.shift();for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){
   const key=`${x+dx},${y+dy}`;if(map.has(key)&&!visited.has(key)){visited.add(key);queue.push([x+dx,y+dy]);}
  }}
  assert.ok(visited.has('4,4'));
  assert.equal(Adventures.exposedPyramidFloor(floor).cells.filter(x=>x.kind!=='unknown').length<25,true);
 }
 const p=profile();enter(p,'pyramid');const first=Frontier.next(p);
 assert.equal(first.event,'explore');assert.equal(p.frontier.active.streak,0);
 const same=Frontier.next(p);assert.equal(same.event,'explore');assert.equal(p.frontier.active.streak,0);
 assert.throws(()=>Frontier.explore(p,{direction:'invalid'}),/Direção inválida/);
 assert.equal(Frontier.info(p).active.pyramidFloor.floor,1);
 // Simulate legit movements until exit: route is derived from the actual map.
 let steps=0;
 while(p.frontier.active.pyramidFloor&&steps++<100){
  const floor=p.frontier.active.pyramidFloor,at=floor.position;
  const queue=[[at.x,at.y,[]]],seen=new Set([`${at.x},${at.y}`]);let path=null;
  while(queue.length&&!path){const [x,y,route]=queue.shift();if(x===4&&y===4){path=route;break;}
   for(const [direction,dx,dy] of [['east',1,0],['west',-1,0],['south',0,1],['north',0,-1]]){
    const xx=x+dx,yy=y+dy,k=`${xx},${yy}`;
    if(!seen.has(k)&&floor.tiles.find(t=>t.x===xx&&t.y===yy&&t.kind!=='wall')){seen.add(k);queue.push([xx,yy,[...route,direction]]);}
   }}
  assert.ok(path);
  for(const direction of path){const result=Frontier.explore(p,{direction});
   if(p.battle){const streak=p.frontier.active.streak;Frontier.recordResult(p,p.battle,true);p.battle=null;assert.equal(p.frontier.active.streak,streak);}
   if(result.event==='floor-complete')break;
  }
 }
 assert.equal(p.frontier.active.streak,1);
 assert.equal(p.frontier.active.pyramidFloor,null);
});
test('confronto de Brain da Pyramid não é substituído pelo labirinto',()=>{
 const p=profile();enter(p,'pyramid');p.frontier.active.streak=20;
 const result=Frontier.next(p);assert.equal(result.frontierBrain.name,'Brandon');
});
