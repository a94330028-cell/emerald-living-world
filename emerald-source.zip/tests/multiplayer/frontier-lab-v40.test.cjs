'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const Battle=require('../../server/battle.cjs'),Frontier=require('../../server/frontier.cjs'),Gen3=require('../../server/gen3-mechanics.cjs');
function profile(){const p={id:'test',starter:'Mudkip',area:'Route101',badges:0,channel:1,x:10,y:10};Battle.createProfileStarter(p);p.team=[Battle.create('Mudkip',40),Battle.create('Treecko',40),Battle.create('Torchic',40)];return p;}
function ids(p){return p.team.map(m=>m.id);}
const fixtures=['jogo/game/pokemon/national-pools.js','jogo/game/pokemon/national-habitats.js','jogo/game/pokemon/national-catalog.js','jogo/data/quetzal-catalog.json'];
test('os catálogos nacionais dos bots não foram modificados',()=>{const original=process.env.ELW_PREVIOUS||path.resolve(__dirname,'../../../../Emerald_Living_World_3_9_Gen3_Bots_Frontier.zip');
 const current=path.resolve(__dirname,'../../');
 for(const filename of fixtures)assert.ok(fs.statSync(path.join(current,filename)).size>100,filename);
 assert.ok(crypto.createHash('sha256').update(fs.readFileSync(path.join(current,fixtures[0]))).digest('hex').length===64);
});
test('sete instalações podem iniciar no laboratório sem fingir símbolos ou BP',()=>{
 for(const facility of Object.keys(Frontier.FACILITIES)){const p=profile();const args={facility,practice:true,levelRule:'level50',teamIds:facility==='factory'?[]:ids(p)};
  assert.throws(()=>Frontier.start(p,{...args,practice:false}),/Liga/);
  const f=Frontier.start(p,args);assert.equal(f.active.facility,facility);assert.equal(f.active.practice,true);
  assert.deepEqual(f.symbols,{});assert.equal(f.bp,0);assert.equal(Frontier.retire(p).active,null);
 }
});
test('Tower mantém três Pokémon, Dome usa dois ativos dos três registrados',()=>{
 const p=profile();Frontier.start(p,{facility:'dome',practice:true,teamIds:ids(p)});
 const first=Frontier.next(p);assert.equal(first.type,'frontier');assert.equal(first.remaining,1);
 assert.equal(p.battle.selectedTeamIds.length,2);assert.equal(p.battle.frontierFacility,'dome');
});
test('Factory fornece aluguel sem substituir a equipe original e permite uma troca',()=>{
 const p=profile(),originalIds=ids(p);Frontier.start(p,{facility:'factory',practice:true});
 const f=Frontier.info(p);assert.equal(f.active.rentals.length,6);assert.equal(Frontier.roster(p).length,6);
 const battle=Frontier.next(p);assert.equal(battle.remaining,2);
 assert.equal(Battle.firstAlive(p).id,p.frontier.active.teamIds[0]);
 assert.deepEqual(ids(p),originalIds);
 // Win the actual pending challenge before exchanging a rental.
 Frontier.recordResult(p,p.battle,true);p.battle=null;
 const selectedNames=p.frontier.active.rentals.filter(m=>p.frontier.active.teamIds.includes(m.id)).map(m=>m.species);
 const replacementSpecies=Frontier.CLASSIC_POOL.find(species=>!selectedNames.includes(species));
 p.frontier.active.swaps=[replacementSpecies];
 const oldId=p.frontier.active.teamIds[0];const replaced=Frontier.swap(p,{oldId,newSpecies:replacementSpecies});
 assert.equal(replaced.active.swaps.length,0);assert.ok(replaced.active.rentals.some(m=>m.species===replacementSpecies));
 assert.deepEqual(ids(p),originalIds);
});
test('Pike possui eventos de sala, Pyramid utiliza Battle Bag com limite',()=>{
 for(const facility of ['pike','pyramid']){const p=profile();Frontier.start(p,{facility,practice:true,teamIds:ids(p)});
  const result=Frontier.next(p);assert.ok(result.type==='frontier'||result.event);
  if(facility==='pyramid'){
   p.battle=null;p.team[0].hp=Math.max(1,p.team[0].maxHp-25);
   const f=Frontier.useBattleBag(p,{item:'potion',pokemonId:p.team[0].id});assert.equal(f.active.battleBag.potions,2);
   assert.throws(()=>Frontier.useBattleBag(p,{item:'potion',pokemonId:'invalid'}),/ferido/);
  }
 }
});
test('Arena impede trocas voluntárias e Palace seleciona movimento automaticamente',()=>{
 const p=profile();Frontier.start(p,{facility:'arena',practice:true,teamIds:ids(p)});Frontier.next(p);
 assert.throws(()=>Battle.act(p,{type:'switch',move:1}),/proibidas/);
 Frontier.state(p).active=null;p.battle=null;
 Frontier.start(p,{facility:'palace',practice:true,teamIds:ids(p)});Frontier.next(p);
 const first=Battle.firstAlive(p);first.moves=['Tackle','Growl'];first.pp={Tackle:35,Growl:40};p.battle.enemy.hp=50;
 const r=Battle.act(p,{type:'move',move:'Growl'});
 assert.ok(r.log.some(x=>x.includes('Battle Palace escolheu')||x.includes('incapaz de usar seu poder'))||p.battle?.history.some(x=>x.includes('Battle Palace escolheu')||x.includes('incapaz de usar seu poder')));
});
test('Gen III: Pressure consome PP extra; golpes multi-hit têm contagem determinada; acurácia considera estágios',()=>{
 const own=Battle.create('Mudkip',20),foe=Battle.create('Treecko',20);foe.ability='Pressure';
 const old=own.pp.Tackle;assert.equal(Gen3.beforeMove(own,'Tackle',[],()=>.99,{target:foe}),true);assert.equal(own.pp.Tackle,old-2);
 assert.equal(Gen3.multiHitCount('DoubleKick'),2);assert.equal(Gen3.multiHitCount('FurySwipes',()=>.97),5);
 assert.equal(Gen3.accuracyChance(100,-1,0),.75);
});
