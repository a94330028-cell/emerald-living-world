'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const http=require('node:http'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'elw-v3-auth-'));
const id1='123e4567-e89b-42d3-a456-426614174000';
const id2='123e4567-e89b-42d3-a456-426614174001';
const GOOD='account-one-token-abcdefghij';
const SECOND='account-two-token-abcdefghij';
const MOCK_KEY='mock-publishable-key';
function send(req,res){
 if(req.url!=='/auth/v1/user'||req.method!=='GET'){res.writeHead(404);return res.end('{}')}
 if(req.headers.apikey!==MOCK_KEY){res.writeHead(403);return res.end('{}')}
 const value=req.headers.authorization;
 if(!['Bearer '+GOOD,'Bearer '+SECOND,'Bearer anonymous-test-abcdefghij'].includes(value)){res.writeHead(401);return res.end('{}')}
 res.writeHead(200,{'content-type':'application/json'});
 res.end(JSON.stringify({id:value==='Bearer '+SECOND?id2:id1,is_anonymous:value.includes('anonymous')}));
}
function cookie(response){return response.headers.get('set-cookie')?.split(';')[0]||''}
async function post(origin,endpoint,body,opts={}){
 const r=await fetch(origin+endpoint,{method:'POST',headers:{'content-type':'application/json',...(opts.token?{authorization:'Bearer '+opts.token}:{}),...(opts.cookie?{cookie:opts.cookie}:{})},body:JSON.stringify(body)});
 return {status:r.status,body:await r.json(),cookie:cookie(r)};
}
test('Supabase Auth obrigatório bloqueia convidados e não mistura saves entre usuários',async t=>{
 const auth=http.createServer(send);await new Promise(ok=>auth.listen(0,'127.0.0.1',ok));
 process.env.AUTH_MODE='required';process.env.NODE_ENV='test';process.env.DATA_DIR=tmp;
 process.env.SUPABASE_URL='http://127.0.0.1:'+auth.address().port;process.env.SUPABASE_ANON_KEY=MOCK_KEY;
 const app=require('../../server/app.cjs');const srv=await app.start(0,'127.0.0.1'),base='http://127.0.0.1:'+srv.address().port;
 t.after(async()=>{await app.stop();await new Promise(ok=>auth.close(ok));fs.rmSync(tmp,{recursive:true,force:true});});
 let r=await fetch(base+'/api/auth-config');assert.deepEqual(await r.json(),{required:true,enabled:true,provider:'supabase'});
 r=await fetch(base+'/api/health');assert.equal((await r.json()).authRequired,true);
 assert.equal((await post(base,'/api/session',{name:'Sem login'})).status,401);
 assert.equal((await post(base,'/api/session',{name:'Falso'},{token:'invalid-token-0123456789'})).status,401);
 assert.equal((await post(base,'/api/session',{name:'Anônimo'},{token:'anonymous-test-abcdefghij'})).status,401);
 const a=await post(base,'/api/session',{name:'A',starter:'Treecko'},{token:GOOD});assert.equal(a.status,200);
 assert.equal(a.body.guest,false);const aId=a.body.profile.id;
 const b=await post(base,'/api/session',{name:'B',starter:'Torchic'},{token:SECOND});assert.equal(b.status,200);
 assert.notEqual(aId,b.body.profile.id);
 assert.equal(b.body.profile.starter,'Torchic');
 // Invalid signed-in token must never fall back to an existing account cookie.
 assert.equal((await post(base,'/api/session',{name:'A'},{token:'invalid-token-0123456789',cookie:a.cookie})).status,401);
 const anon=await fetch(base+'/api/campaign');assert.equal(anon.status,401);
 assert.equal((await fetch(base+'/api/campaign',{headers:{cookie:a.cookie}})).status,200);
 const same=await post(base,'/api/session',{name:'A2',starter:'Mudkip'},{token:GOOD,cookie:a.cookie});assert.equal(same.status,200);
 assert.equal(same.body.profile.id,aId);assert.equal(same.body.profile.starter,'Treecko');
 const logout=await post(base,'/api/logout',{}, {cookie:a.cookie});assert.equal(logout.status,200);
 assert.equal((await fetch(base+'/api/campaign',{headers:{cookie:a.cookie}})).status,401);
 const returned=await post(base,'/api/session',{name:'A3',starter:'Mudkip'},{token:GOOD});assert.equal(returned.body.profile.id,aId);
 assert.equal(returned.body.profile.starter,'Treecko');
 // Even a valid local cookie cannot outlive server-side account verification.
 const stored=app.profiles.get(aId);stored.accountAuthUntil=Date.now()-1;
 assert.equal((await fetch(base+'/api/campaign',{headers:{cookie:returned.cookie}})).status,401);
 const renewed=await post(base,'/api/session',{name:'A3'},{token:GOOD,cookie:returned.cookie});
 assert.equal(renewed.status,200);assert.equal(renewed.body.profile.id,aId);
 assert.equal((await fetch(base+'/api/campaign',{headers:{cookie:renewed.cookie}})).status,200);
 assert.equal((await fetch(base+'/server/auth-provider.cjs')).status,404);
});
