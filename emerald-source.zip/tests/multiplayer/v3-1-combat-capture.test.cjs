'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const fs=require('node:fs');
const path=require('node:path');
const Hit=require('../../server/gen3-damage.cjs');
const Catch=require('../../server/gen3-capture.cjs');
const Battle=require('../../server/battle.cjs');
const BotAI=require('../../server/autonomy.cjs');
const NationalPools=require('../../jogo/game/pokemon/national-pools.js');
const base=path.resolve(__dirname,'../../');
function mon(species,level=50){const m=Battle.create(species,level);for(const x of ['hp','atk','def','spa','spd','spe']){m.ivs[x]=15;m.evs[x]=0;}m.nature='Hardy';m.maxHp=Battle.stat(m,'hp');m.hp=m.maxHp;return m;}
function power(speciesA='Swampert',speciesB='Sceptile',opts={}){
 const a=mon(speciesA),b=mon(speciesB);
 a.stages={};b.stages={};
 return Hit.calculate({attacker:a,defender:b,move:{id:'Surf',type:'Water',power:95},stat:Battle.stat,typesOf:s=>Battle.SPEC[s].types,
  typeMultiplier:(t,dt)=>({Fire:{Grass:.5},Water:{Grass:.5,Ground:2}}[t]?.[dt]??1),...opts});
}
test('dano Gen III: random 85..100, STAB e clima em ordem inteira',()=>{
 const higher=power();const lower=power(undefined,undefined,{randomRoll:85});
 assert.ok(higher>=lower&&lower>0);
 const rainy=power(undefined,undefined,{weather:'rain'});
 assert.ok(rainy>higher,'chuva aumenta Surf');
 assert.equal(rainy,power(undefined,undefined,{weather:'rain',randomRoll:100}));
});
test('crítico ignora redução de Attack e aumento de Defense, não itens e STAB',()=>{
 const a=mon('Swampert'),b=mon('Sceptile');a.stages.atk=-6;b.stages.def=6;
 const common={attacker:a,defender:b,move:{id:'Earthquake',type:'Ground',power:100},stat:Battle.stat,
  typesOf:s=>Battle.SPEC[s].types,typeMultiplier:()=>1};
 const boosted=Hit.calculate({...common,critical:true});
 a.stages.atk=0;b.stages.def=0;
 assert.equal(boosted,Hit.calculate({...common,critical:true}));
 assert.ok(boosted>Hit.calculate({...common,critical:false}));
});
test('redução Gen III Surf e Explosion por Defense pela metade',()=>{
 const a=mon('Swampert'),b=mon('Sceptile');
 const common={attacker:a,defender:b,stat:Battle.stat,typesOf:s=>Battle.SPEC[s].types,typeMultiplier:()=>1};
 const surf=Hit.calculate({...common,move:{id:'Surf',type:'Water',power:95}});
 const spread=Hit.calculate({...common,move:{id:'Surf',type:'Water',power:95},spread:0.5});
 assert.ok(spread<surf&&spread>0);
 const boom=Hit.calculate({...common,move:{id:'Explosion',type:'Normal',power:250}});
 const plain=Hit.calculate({...common,move:{id:'Tackle',type:'Normal',power:250}});
 assert.ok(boom>plain);
});
test('imunidade zera dano e RNG fora da faixa é rejeitado',()=>{
 const a=mon('Torchic'),b=mon('Swampert');const args={attacker:a,defender:b,move:{id:'Ember',type:'Fire',power:40},stat:Battle.stat,typesOf:s=>Battle.SPEC[s].types,typeMultiplier:()=>0};
 assert.equal(Hit.calculate(args),0);
 assert.throws(()=>Hit.calculate({...args,randomRoll:84}),/85/);
});
test('captura Gen III: sleep/freeze dobra; paralysis/poison/toxic/burn aumenta em 50%',()=>{
 const wild={maxHp:120,hp:20,rate:45};
 const plain=Catch.modifiedRate(wild);
 assert.equal(Catch.modifiedRate({...wild,status:'sleep'}),Math.min(255,plain*2));
 assert.equal(Catch.modifiedRate({...wild,status:'freeze'}),Math.min(255,plain*2));
 assert.ok(Catch.modifiedRate({...wild,status:'paralysis'})>plain);
 assert.equal(Catch.modifiedRate({...wild,status:'toxic'}),Catch.modifiedRate({...wild,status:'poison'}));
});
test('quatro checks e captura garantida em taxa modificada 255',()=>{
 const mon={hp:1,maxHp:100,status:'sleep'};
 assert.deepEqual(Catch.throwBall(mon,255,()=>.999),{success:true,shakes:4,modifiedRate:255});
 const fresh={hp:100,maxHp:100,status:null};
 assert.equal(Catch.throwBall(fresh,45,()=>.999).success,false);
 assert.equal(Catch.throwBall(fresh,45,()=>0).shakes,4);
});
test('catálogos nacionais e Arena preservados sem modificação',()=>{
 const files=['jogo/game/pokemon/national-pools.js','jogo/game/pokemon/national-habitats.js','jogo/game/pokemon/national-catalog.js','jogo/data/quetzal-catalog.json','jogo/arena/core.mjs','jogo/arena/species.mjs'];
 const manifest=JSON.parse(fs.readFileSync(path.join(base,'tests/fixtures/preserved-v3-content.sha256.json'),'utf8'));
 for(const relative of files){
  assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(base,relative))).digest('hex'),manifest[relative],relative);
 }
 assert.equal(NationalPools.FIXED.Route101.includes('Bidoof'),true);
 const bot=BotAI.createBot(10);assert.equal(bot.nationalEncounters,true);
});
test('typing histórico Emerald isola Fairy moderno sem apagar espécies do catálogo',()=>{
 const gardevoir=mon('Gardevoir');
 assert.equal(Battle.effective('Dragon',gardevoir,'gen3_extended'),0,'Gardevoir moderno é Fada');
 assert.equal(Battle.effective('Dragon',gardevoir,'gen3_emerald'),1,'Gardevoir Gen III é só Psíquico');
 assert.equal(Battle.effective('Fighting',mon('Clefairy'),'gen3_emerald'),2,'Clefairy Gen III é Normal');
 assert.equal(Battle.effective('Fighting',mon('Clefairy'),'gen3_extended'),.5,'Clefairy moderno é Fada');
});
