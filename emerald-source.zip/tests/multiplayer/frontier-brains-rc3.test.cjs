'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const B=require('../../server/battle.cjs');
const F=require('../../server/frontier.cjs');
const Br=require('../../server/frontier-brains.cjs');

function trainer(champion=true){
 const p={id:crypto.randomUUID(),name:'Teste',starter:'Mudkip',area:'Route101',
   champion,badges:champion?8:0,channel:1,x:10,y:10,team:[],
   activeIndex:0,bag:{pokeballs:5}};
 p.team=['Swampert','Sceptile','Blaziken'].map(name=>B.create(name,50));
 return p;
}
function select(p){return p.team.map(x=>x.id)}
test('sete Frontier Brains, duas etapas e marcos específicos',()=>{
 assert.equal(Object.keys(Br.BRAINS).length,7);
 const markers={tower:[35,70],dome:[20,40],palace:[21,42],arena:[28,56],
  factory:[21,42],pike:[28,140],pyramid:[21,70]};
 for(const [id,milestones] of Object.entries(markers)){
  assert.deepEqual(Br.BRAINS[id].triggers,milestones);
  assert.equal(Br.tierAt(id,milestones[0]),'silver');
  assert.equal(Br.tierAt(id,milestones[1]),'gold');
  assert.equal(Br.tierAt(id,milestones[0]-1),null);
  assert.equal(Br.tierAt(id,milestones[1]+1),null);
 }
});
test('todos os encontros Brain do LAB têm Pokémon válidos e golpes suportados pelo servidor',()=>{
 for(const [facility,config] of Object.entries(Br.BRAINS)){
  for(const tier of ['silver','gold']){
   const team=Br.lineup(facility,tier,50,()=>['Geodude','Zubat','Pelipper']);
   assert.equal(team.length,facility==='dome'?2:3);
   for(const mon of team){
    assert.equal(mon.level,50);
    assert.ok(B.SPEC[mon.species]?.dex<=386,mon.species);
    assert.ok(mon.moves.every(move=>B.MOVES[move]),mon.species);
    assert.ok(mon.moves.every(move=>mon.pp[move]>0),mon.species);
   }
   if(facility!=='factory')assert.equal(team[0].species,config[tier][0]);
  }
 }
});
test('Anabel aparece somente na 35ª batalha e medalha LAB exige vitória',()=>{
 const p=trainer();
 F.start(p,{facility:'tower',practice:false,levelRule:'level50',teamIds:select(p)});
 const run=p.frontier.active;
 run.streak=34;
 const battle=F.next(p);
 assert.equal(battle.frontierBrain.name,'Anabel');
 assert.equal(battle.frontierBrain.tier,'silver');
 assert.equal(p.battle.enemy.species,'Alakazam');
 assert.equal(p.battle.remaining.length,2);
 const round=p.battle;
 F.recordResult(p,round,true);
 const f=F.info(p);
 assert.equal(f.labSymbols.tower,'silver');
 assert.deepEqual(f.symbols,{});
 assert.equal(f.bp,0);
 assert.equal(run.streak,35);
 const points=f.labBP;
 F.recordResult(p,round,true);
 assert.equal(run.streak,35);
 assert.equal(F.info(p).labBP,points);
});
test('derrota para Frontier Brain não concede medalha nem recorde oficial',()=>{
 const p=trainer();
 F.start(p,{facility:'arena',practice:false,teamIds:select(p)});
 p.frontier.active.streak=27;
 F.next(p);
 F.recordResult(p,p.battle,false);
 assert.equal(F.info(p).active,null);
 assert.deepEqual(F.info(p).labSymbols,{});
 assert.equal(F.info(p).bp,0);
});
test('Pike e Pyramid exigem batalha no checkpoint Brain em vez de sala grátis',()=>{
 for(const [id,number] of [['pike',28],['pyramid',21]]){
  const p=trainer();
  F.start(p,{facility:id,practice:true,teamIds:select(p)});
  p.frontier.active.streak=number-1;
  const event=F.next(p);
  assert.equal(event.type,'frontier');
  assert.equal(event.frontierBrain.name,Br.BRAINS[id].name);
 }
});
test('Noland usa Pokémon alugados e não substitui time do jogador',()=>{
 const p=trainer(),orig=select(p);
 F.start(p,{facility:'factory',practice:true});
 p.frontier.active.streak=20;
 const challenge=F.next(p);
 assert.equal(challenge.frontierBrain.name,'Noland');
 assert.equal(challenge.remaining,2);
 assert.deepEqual(select(p),orig);
});
test('regulamento Frontier rejeita banidos sem remover espécies do catálogo',()=>{
 const p=trainer();
 p.team[0]=B.create('Mewtwo',50);
 assert.throws(()=>F.start(p,{facility:'tower',practice:true,teamIds:select(p)}),/proibido/);
 assert.ok(B.SPEC.Mewtwo);
});

test('medalha LAB só nasce quando três Pokémon do Brain são vencidos em batalha',()=>{
 const p=trainer(true);
 F.start(p,{facility:'tower',practice:true,teamIds:select(p)});
 p.frontier.active.streak=34;
 for(const mon of p.team){mon.moves=['QuickAttack'];mon.pp={QuickAttack:30};}
 F.next(p);
 assert.equal(F.info(p).labSymbols.tower,undefined);
 let result;
 for(let j=0;j<3;j++){
  assert.ok(p.battle);
  p.battle.enemy.hp=1; // fixture de integração, não é um comando aceito da rede
  p.battle.enemy.moves=['Growl'];p.battle.enemy.pp={Growl:40};
  result=B.act(p,{type:'move',move:'QuickAttack'});
 }
 assert.equal(result.done,true);
 assert.equal(result.victory,true);
 assert.equal(F.info(p).labSymbols.tower,'silver');
 assert.equal(F.info(p).symbols.tower,undefined);
 assert.equal(F.info(p).bp,0);
});
