'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const Battle=require('../../server/battle.cjs');
const Gen3=require('../../server/gen3-mechanics.cjs');
function mon(species='Sceptile',level=60){return Battle.create(species,level);}
function battle(){const p={starter:'Treecko',area:'Route101',badges:0,x:10,y:10};Battle.createProfileStarter(p);p.team=[mon('Sceptile',70)];p.team[0].moves=['Tackle'];p.team[0].pp={Tackle:0};Battle.begin(p,{type:'wild'});p.battle.enemy.status='sleep';p.battle.enemy.sleepTurns=5;return p;}
test('PP é preservado quando sono, congelamento, paralisia, confusão ou flinch impedem ação',()=>{
 for(const status of ['sleep','freeze','paralysis','confusion','flinch']){
  const p=mon();p.moves=['Tackle'];p.pp.Tackle=10;
  if(status==='confusion')p.confusionTurns=2;
  else if(status==='flinch')p.flinched=true;
  else p.status=status;
  if(status==='sleep')p.sleepTurns=3;
  assert.equal(Gen3.beforeMove(p,'Tackle',[],()=>status==='freeze'?.99:0),false,status);
  assert.equal(p.pp.Tackle,10,status);
 }
});
test('Pressure cobra 2 PP de golpe alvo e 1 PP de golpe pessoal apenas se a ação executar',()=>{
 const own=mon();own.moves=['Tackle','Recover'];own.pp={Tackle:8,Recover:8};own.status='paralysis';
 const foe=mon('Poochyena');foe.ability='Pressure';
 assert.equal(Gen3.beforeMove(own,'Tackle',[],()=>0,{target:foe}),false);
 assert.equal(own.pp.Tackle,8);
 assert.equal(Gen3.beforeMove(own,'Recover',[],()=>0,{target:foe}),false);
 assert.equal(own.pp.Recover,8);
 own.status=null;
 assert.equal(Gen3.beforeMove(own,'Tackle',[],()=>.99,{target:foe}),true);
 assert.equal(own.pp.Tackle,6);
 assert.equal(Gen3.beforeMove(own,'Recover',[],()=>.99,{target:foe}),true);
 assert.equal(own.pp.Recover,7);
});
test('Fake Out causa flinch ao acertar; não funciona depois do primeiro turno, mas consome PP',()=>{
 const own=mon(),foe=mon('Poochyena');own.moves=['FakeOut'];own.pp.FakeOut=10;
 assert.equal(Gen3.beforeMove(own,'FakeOut',[],()=>.5,{target:foe}),true);
 Gen3.afterHit(own,foe,'FakeOut',10,['Dark'],['Grass'],[],()=>.99);
 assert.equal(foe.flinched,true);
 own.turnsActive=1;
 assert.equal(Gen3.beforeMove(own,'FakeOut',[],()=>.5,{target:foe}),false);
 assert.equal(own.pp.FakeOut,8);
});
test('Struggle tem força dependente de atributos, atinge Fantasma e causa recuo pelo dano real',()=>{
 const p=battle();const foe=mon('Duskull',35);foe.status='sleep';foe.sleepTurns=5;p.battle.enemy=foe;
 const hp=foe.hp,own=p.team[0],ownHp=own.hp;
 const result=Battle.act(p,{type:'move',move:'Struggle'});
 assert.ok(result.log.some(s=>s.includes('Struggle')));
 const dealt=hp-foe.hp;assert.ok(dealt>0,'Struggle ignora imunidade Fantasma');
 assert.equal(ownHp-own.hp,Math.max(1,Math.floor(dealt/4)));
});
test('Aerial Ace não erra por redução de accuracy ou aumento de evasão',()=>{
 const p=battle();const own=p.team[0];own.moves=['AerialAce'];own.pp={AerialAce:20};own.stages.accuracy=-6;
 const foe=p.battle.enemy;foe.stages.evasion=6;const hp=foe.hp;
 Battle.act(p,{type:'move',move:'AerialAce'});
 assert.ok(foe.hp<hp,'Aerial Ace precisa ignorar stages de evasão');
});
test('Fake Out não ativa habilidades de contato na Gen III e não causa flinch em Inner Focus/Shield Dust',()=>{
 const own=mon('Sceptile'),foe=mon('Poochyena');own.hp=own.maxHp;foe.ability='RoughSkin';
 Gen3.afterHit(own,foe,'FakeOut',12,['Dark'],['Grass'],[],()=>0);
 assert.equal(own.hp,own.maxHp,'Fake Out não é contato na Gen III');
 for(const ability of ['InnerFocus','ShieldDust']){
  foe.ability=ability;foe.flinched=false;
  Gen3.afterHit(own,foe,'FakeOut',12,['Dark'],['Grass'],[],()=>0);
  assert.equal(foe.flinched,false,ability);
 }
});
test('Struggle não atravessa Protect e não causa recuo quando foi bloqueado',()=>{
 const p=battle();const own=p.team[0],foe=p.battle.enemy;const hp=own.hp,foeHp=foe.hp;foe.protected=true;
 Battle.act(p,{type:'move',move:'Struggle'});
 assert.equal(foe.hp,foeHp);assert.equal(own.hp,hp);
});
test('Struggle de Gen III verifica precisão contra evasão; não há recuo se errar',()=>{
 const p=battle();const own=p.team[0],foe=p.battle.enemy;
 own.stages.accuracy=-6;foe.stages.evasion=6;const hp=own.hp,foeHp=foe.hp;
 const random=Math.random;try{Math.random=()=>.99;Battle.act(p,{type:'move',move:'Struggle'});}finally{Math.random=random;}
 assert.equal(foe.hp,foeHp);assert.equal(own.hp,hp);
});
