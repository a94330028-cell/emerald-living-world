'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const crypto=require('node:crypto');
const Battle=require('../../server/battle.cjs');
const Gen3=require('../../server/gen3-mechanics.cjs');
const Double=require('../../server/gen3-doubles.cjs');
const Frontier=require('../../server/frontier.cjs');
const National=require('../../jogo/game/pokemon/national-pools.js');
const BotAI=require('../../server/autonomy.cjs');
function profile(){const p={id:'p',starter:'Mudkip',area:'Route101',badges:0,channel:1,x:10,y:10};Battle.createProfileStarter(p);return p;}
function mon(species='Mudkip',level=20){return Battle.create(species,level);}
test('todos os Pokémon modernos e habitats de captura dos bots permanecem',()=>{
 assert.ok(Battle.DEX.POKEMON.length>=1025);
 for(const name of ['Sprigatito','Fuecoco','Quaxly','Bulbasaur','Mudkip','Shroomish','Geodude','Wingull'])assert.ok(Battle.SPEC[name],name);
 assert.deepEqual(National.FIXED.Route101,['Zigzagoon','Poochyena','Wurmple','Bidoof','Starly','Sentret']);
 assert.ok(National.FIXED.Woods.includes('Sprigatito'));
 const b=BotAI.createBot(17);assert.equal(b.nationalEncounters,true);
 assert.equal(b.phase,'starter');
});
test('encontro nacional com espécie moderna não some da captura',()=>{
 const p=profile();p.team[0]=mon('Mudkip',12);p.phase='capture';p.bag.pokeballs=40;
 const current=Battle.begin(p,{type:'wild',national:true});assert.ok(current.enemy);
 assert.ok(Battle.SPEC[current.enemy.species]);assert.ok(['gen3_emerald','gen3_extended'].includes(current.ruleset));
});
test('PP inicial, migração de saves e cura no Centro',()=>{
 const m=mon();assert.equal(m.pp.Tackle,35);
 m.pp.Tackle=0;Gen3.initialize(m);assert.equal(m.pp.Tackle,0);
 m.moves.push('Protect');Gen3.initialize(m);assert.equal(m.pp.Protect,10);
 const p=profile();p.team[0].pp.Tackle=0;p.area='Center';Battle.heal(p);assert.equal(p.team[0].pp.Tackle,35);
});
test('PP é consumido e golpe sem PP não é executado',()=>{
 const m=mon(),history=[];m.moves=['Tackle'];m.pp.Tackle=1;
 assert.equal(Gen3.beforeMove(m,'Tackle',history,()=>.99),true);
 assert.equal(m.pp.Tackle,0);
 assert.equal(Gen3.beforeMove(m,'Tackle',history,()=>.99),false);
 assert.deepEqual(Battle.availableMoves(m),['Struggle']);
});
test('paralisia muda ordem, Quick Claw não altera prioridade de Protect',()=>{
 const a=mon('Poochyena');const b=mon('Mudkip');a.item='QuickClaw';
 assert.equal(Gen3.order({mon:a,move:'Tackle',speed:100},{mon:b,move:'Protect',speed:10},()=>0),false);
 assert.equal(Gen3.order({mon:a,move:'Tackle',speed:30},{mon:b,move:'Pound',speed:90},()=>0),true);
 a.status='paralysis';assert.equal(Gen3.speed(a,Battle.stat),Math.max(1,Math.floor(Battle.stat(a,'spe')/4)));
});
test('status e itens: Sitrus (30 HP), Leftovers, Natural Cure',()=>{
 const a=mon('Treecko');const b=mon('Torchic');a.item='SitrusBerry';a.hp=10;a.maxHp=100;
 Gen3.triggerBerry(a,[]);assert.equal(a.hp,40);assert.equal(a.item,null);
 a.item='Leftovers';a.hp=40;const fake={turn:1,weather:null};Gen3.endTurn(a,b,fake,s=>Battle.SPEC[s].types,Battle.stat,[],()=>1);
 assert.equal(a.hp,46);
 a.ability='NaturalCure';a.status='poison';Gen3.switchOut(a);assert.equal(a.status,null);
});
test('Wish cura no turno seguinte e respeita posição do aliado',()=>{
 const a=mon('Mudkip');const b=mon('Treecko');a.hp=20;a.maxHp=100;
 const bat={turn:0,weather:null,wishes:{own:{turns:2,heal:50}}};
 Gen3.endTurn(a,b,bat,s=>Battle.SPEC[s].types,Battle.stat,[],()=>1);assert.equal(a.hp,20);
 Gen3.endTurn(a,b,bat,s=>Battle.SPEC[s].types,Battle.stat,[],()=>1);assert.equal(a.hp,70);
});
test('Sun/Rain Weather e Intimidate têm efeito condicionado',()=>{
 const a=mon('Mightyena');const b=mon('Treecko');Gen3.onEntry(a,[b],[]);assert.equal(b.stages.atk,-1);
 assert.equal(Gen3.damageWithModifiers(100,a,'Ember','Fire','sun'),150);
 assert.equal(Gen3.damageWithModifiers(100,a,'Ember','Fire','rain'),50);
});
test('Doubles: Surf não atinge aliado; Earthquake atinge; Helping Hand elegível',()=>{
 const board={A1:{id:'a',hp:80,trainerId:'t1'},A2:{id:'b',hp:80,trainerId:'t2'},B1:{id:'c',hp:60,trainerId:'t3'},B2:{id:'d',hp:60,trainerId:'t4'}};
 assert.deepEqual(Double.resolveTargets(board,'A1','Surf'),['B1','B2']);
 assert.deepEqual(Double.resolveTargets(board,'A1','Earthquake'),['A2','B1','B2']);
 assert.equal(Double.spreadMultiplier('Surf',['B1','B2']),.5);
 assert.equal(Double.spreadMultiplier('Earthquake',['A2','B1','B2']),1);
 assert.equal(Double.helpingHand(board,'A1').target,'A2');
 assert.equal(Double.helpingHand(board,'A1',new Set(['A2'])).ok,false);
});
test('Doubles: Follow Me só redireciona alvo único; substituição Multi respeita treinador',()=>{
 const board={A1:{id:'a',hp:80,trainerId:'t1'},A2:{id:'b',hp:0,trainerId:'t2'},B1:{id:'c',hp:60,trainerId:'t3'},B2:{id:'d',hp:60,trainerId:'t4'}};
 assert.deepEqual(Double.resolveTargets(board,'A1','Tackle','B1',{followMe:'B2'}),['B2']);
 assert.deepEqual(Double.resolveTargets(board,'A1','Surf','B1',{followMe:'B2'}),['B1','B2']);
 assert.throws(()=>Double.replaceFainted(board,'A2',{id:'e',hp:50,trainerId:'t1'},'t2'));
 Double.replaceFainted(board,'A2',{id:'e',hp:50,trainerId:'t2'},'t2');assert.equal(board.A2.id,'e');
});
test('Frontier mantém 7 instalações, exige Liga e não inventa símbolos',()=>{
 const p=profile();p.team=[mon('Mudkip',50),mon('Treecko',50),mon('Torchic',50)];
 assert.equal(Object.keys(Frontier.FACILITIES).length,7);
 assert.throws(()=>Frontier.start(p,{teamIds:p.team.map(x=>x.id)}),/Liga/);
 p.champion=true;
 const status=Frontier.start(p,{teamIds:p.team.map(x=>x.id)});
 assert.equal(status.active.streak,0);assert.equal(status.bp,0);
 assert.deepEqual(status.symbols,{});
 assert.throws(()=>Frontier.start(p,{teamIds:p.team.map(x=>x.id)}),/sequência/);
 assert.throws(()=>Frontier.next({...p,battle:{type:'wild'}}),/batalha atual/);
});
test('Frontier Tower: três adversários reais, sem EXP gratuito nem captura, com registro da vitória',()=>{
 const p=profile();p.champion=true;p.team=[mon('Mudkip',50),mon('Treecko',50),mon('Torchic',50)];
 for(const member of p.team){member.moves=['QuickAttack'];member.pp={QuickAttack:30};}
 const exp=p.team.map(x=>x.exp),money=p.money;
 Frontier.start(p,{teamIds:p.team.map(x=>x.id)});
 const opened=Frontier.next(p);assert.equal(opened.type,'frontier');assert.equal(opened.remaining,2);
 assert.throws(()=>Battle.act(p,{type:'ball'}),/Não é permitido/);
 assert.throws(()=>Battle.act(p,{type:'run'}),/Não é permitido/);
 const old=Math.random;Math.random=()=>0.5;try{
  for(let n=0;n<3;n++){p.battle.enemy.hp=1;let result=Battle.act(p,{type:'move',move:Battle.firstAlive(p).moves[0]});
   assert.equal(result.done,n===2);}
 }finally{Math.random=old;}
 assert.equal(Frontier.info(p).active.streak,1);
 assert.deepEqual(p.team.map(x=>x.exp),exp);assert.equal(p.money,money);
 assert.equal(Frontier.info(p).bp,0);assert.deepEqual(Frontier.info(p).symbols,{});
});
