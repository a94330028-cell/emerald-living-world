'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const crypto=require('node:crypto'),fs=require('node:fs'),path=require('node:path');
const Battle=require('../../server/battle.cjs');
const Double=require('../../server/gen3-doubles.cjs');
const ROOT=path.resolve(__dirname,'../..');
function profile(){const p={name:'Verificador',starter:'Mudkip',area:'MossdeepGym',x:14,y:9,badges:6,story:{}};
 Battle.createProfileStarter(p);
 p.team=[Battle.create('Swampert',100),Battle.create('Sceptile',100),Battle.create('Blaziken',100)];
 for(const mon of p.team){mon.moves=['WaterGun','Tackle','Protect','RainDance'];mon.pp={WaterGun:50,Tackle:50,Protect:50,RainDance:50};}
 return p;}
test('Tate e Liza exigem dois Pokémon aptos e não dão insígnia ao iniciar',()=>{
 const p=profile();p.team[1].hp=0;p.team[2].hp=0;
 assert.throws(()=>Battle.begin(p,{type:'gym'}),/dois Pokémon/i);
 assert.equal(p.battle,undefined);
 p.team[1].hp=p.team[1].maxHp;
 const state=Battle.begin(p,{type:'gym'});
 assert.equal(state.format,'double');assert.equal(state.ally?.id,p.team[1].id);
 assert.equal(state.enemy.species,'Claydol');assert.equal(state.enemyPartner.species,'Xatu');
 assert.equal(state.remaining,2);assert.equal(p.badges,6);
 assert.throws(()=>Battle.act(p,{type:'ball'}),/capturar/i);
 assert.throws(()=>Battle.act(p,{type:'move',move:'FalsoGolpe'}),/Movimento indisponível/);
});
test('Double valida ações dos dois jogadores, aplica PP e oferece alvos distintos',()=>{
 const p=profile();Battle.begin(p,{type:'gym'});
 const status=Battle.act(p,{type:'move',move:'Tackle',partnerMove:'WaterGun',target:'B1',partnerTarget:'B2'});
 assert.equal(status.done,false);assert.equal(status.battle.format,'double');
 assert.equal(status.battle.turn,1);
 assert.ok(p.team[0].pp.Tackle<50);assert.ok(p.team[1].pp.WaterGun<50);
});
test('Doubles preenche dois alvos, desmaios e concede a sétima insígnia apenas após equipe completa',()=>{
 const p=profile();Battle.begin(p,{type:'gym'});
 for(let turn=0;turn<20&&p.battle;turn++){
  // Fixture que reduz HP para testar progressão, sem modificar o jogo distribuído.
  if(p.battle.enemy)p.battle.enemy.hp=1;
  if(p.battle.enemyPartner)p.battle.enemyPartner.hp=1;
  for(const mon of p.team){if(mon.hp>0){mon.hp=mon.maxHp;mon.status=null;mon.pp.WaterGun=50;}}
  Battle.act(p,{type:'move',move:'WaterGun',partnerMove:'WaterGun',target:'B1',partnerTarget:'B2'});
 }
 assert.equal(p.battle,null,'equipe adversária completa deve ser derrotada');
 assert.equal(p.badges,7);assert.equal(p.story.tate_liza,true);
 assert.equal(p.wins,1);
});
test('Protect, Follow Me, Surf e Earthquake mantêm regras distintas de alvo',()=>{
 const board={A1:{id:'a1',hp:10},A2:{id:'a2',hp:10},B1:{id:'b1',hp:10},B2:{id:'b2',hp:10}};
 assert.deepEqual(Double.resolveTargets(board,'A1','Surf'),['B1','B2']);
 assert.deepEqual(Double.resolveTargets(board,'A1','Earthquake'),['A2','B1','B2']);
 assert.deepEqual(Double.resolveTargets(board,'A1','Tackle','B1',{followMe:'B2'}),['B2']);
 assert.deepEqual(Double.resolveTargets(board,'A1','Protect'),['A1']);
 assert.equal(Double.spreadMultiplier('Surf',['B1','B2']),.5);
 assert.equal(Double.spreadMultiplier('Earthquake',['A2','B1','B2']),1);
});
test('capturas nacionais e Arena continuam byte-a-byte iguais ao manifesto original',()=>{
 const manifest=JSON.parse(fs.readFileSync(path.join(ROOT,'tests/fixtures/preserved-v3-content.sha256.json')));
 for(const [file,hash] of Object.entries(manifest))assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(ROOT,file))).digest('hex'),hash,file);
});
test('Double permite continuar com o último Pokémon sem duplicar seu slot',()=>{
 const p=profile();Battle.begin(p,{type:'gym'});
 p.team[0].hp=0;p.team[2].hp=0;
 const before=Battle.publicBattle(p);
 assert.equal(before.activePokemonId,p.team[1].id);
 assert.equal(before.ally,null);
 const result=Battle.act(p,{type:'move',move:'WaterGun',target:'B1'});
 assert.equal(result.battle?.format,'double');
 assert.equal(result.battle.ally,null);
});
test('Double admite efeito de campo uma vez e avança clima uma vez por turno',()=>{
 const p=profile();Battle.begin(p,{type:'gym'});
 const result=Battle.act(p,{type:'move',move:'RainDance',partnerMove:'Tackle',target:'B1',partnerTarget:'B1'});
 assert.equal(result.done,false);
 assert.equal(p.battle.weather,'rain');
 assert.equal(p.battle.weatherTurns,4);
 assert.equal(p.team[0].pp.RainDance,4);
});
