'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),crypto=require('node:crypto'),path=require('node:path');
const World=require('../../server/world.cjs'),Nav=require('../../server/navigation.cjs');
const Battle=require('../../server/battle.cjs'),AI=require('../../server/autonomy.cjs'),Frontier=require('../../server/frontier.cjs');
function trainer(area='Mauville',badges=3){const p={starter:'Mudkip',name:'Tester',area,x:14,y:10,badges,story:{peeko:true,steven:true,rival110:true,wally:true}};Battle.createProfileStarter(p);p.team=[Battle.create('Swampert',100),Battle.create('Sceptile',100),Battle.create('Blaziken',100)];return p;}

test('version 3.0 supplies eight leaders and five League members, with valid species and levels',()=>{
 const gyms=Object.values(Battle.GYMS).sort((a,b)=>a.badge-b.badge);
 assert.equal(gyms.length,8);assert.equal(Battle.LEAGUE.length,5);
 assert.deepEqual(gyms.map(g=>g.name),['Roxanne','Brawly','Wattson','Flannery','Norman','Winona','Tate & Liza','Juan']);
 assert.deepEqual(Battle.LEAGUE.map(g=>g.name),['Sidney','Phoebe','Glacia','Drake','Wallace']);
 for(const g of [...gyms,...Battle.LEAGUE]){
  assert.ok(World.MAPS[g.area]);assert.ok(g.team.length>=3);
  for(const [species,level] of g.team){assert.ok(Battle.SPEC[species],g.name+': '+species);assert.ok(level>=10&&level<=60);}
 }
 assert.deepEqual(World.validateWorld(),[]);
});

test('all late gym gates require previous badges and actual complete battle victories',()=>{
 for(const gym of Object.values(Battle.GYMS).filter(g=>g.badge>=4)){
  const p=trainer(gym.area,gym.badge-1);
  assert.equal(Battle.gymAt(p)?.id,gym.id);
  const preview=Battle.begin(p,{type:'gym'});
  assert.equal(preview.remaining,gym.team.length-(gym.format==='double'?2:1));
  assert.equal(p.badges,gym.badge-1,'merely starting the gym may not grant a badge');
  assert.throws(()=>Battle.act(p,{type:'ball'}),/capturar/i);
  p.battle=null;p.badges=gym.badge-2;
  assert.equal(Battle.gymAt(p),null,'cannot skip a badge');
  assert.throws(()=>Battle.begin(p,{type:'gym'}));
 }
});

test('League unlocks in order, requires five victories, and saves Hoenn title',()=>{
 const p=trainer('LeagueSidney',8);
 assert.equal(Frontier.info(p).unlocked,false);
 assert.equal(Battle.leagueAt(p)?.id,'sidney');
 assert.equal(p.champion,undefined);
 for(const [i,boss] of Battle.LEAGUE.entries()){
  p.area=boss.area;p.x=14;p.y=10;
  if(i>0){const rewind={...p,area:Battle.LEAGUE[i-1].area};assert.equal(Battle.leagueAt(rewind),null);}
  assert.equal(Battle.leagueAt(p)?.id,boss.id);
  const first=Battle.begin(p,{type:'league'});
  assert.equal(first.remaining,boss.team.length-1);
  assert.equal(p.story[boss.flag],undefined,'cannot grant story flag just by starting');
  assert.throws(()=>Battle.act(p,{type:'ball'}),/capturar/);
  let turns=0;
  // Explicit 1-HP opponents are a test fixture; the real server does not set
  // opponents to 1 HP and only grants league wins through Battle.act victory.
  while(p.battle&&turns++<50){
   p.battle.enemy.hp=1;
   const mon=Battle.firstAlive(p);
   if(mon){mon.hp=mon.maxHp;mon.status=null;for(const m of mon.moves)mon.pp[m]=40;} // fixture only
   const usable=['WaterGun','Absorb','Ember','DragonBreath','MudSlap'].find(m=>mon.moves.includes(m))||mon.moves.find(m=>Battle.MOVES[m]?.type!=='Normal'&&Battle.MOVES[m]?.power>0);
   const action={type:'move',move:usable||mon.moves[0]};
   Battle.act(p,action);
  }
  assert.equal(p.battle,null,`${boss.name} resolved`);
  assert.equal(p.story[boss.flag],true,`${boss.name} earned`);
  assert.equal(p.leagueWins,i+1);
  if(i<4)assert.equal(p.champion,undefined);
 }
 assert.equal(p.champion,true);assert.equal(p.hallOfFame.length,1);
 assert.equal(p.hallOfFame[0].team.length,3);
 assert.equal(Frontier.info(p).unlocked,true);
 assert.equal(Battle.leagueAt(p),null,'finished champion fight is not infinitely farmable');
 assert.equal(JSON.parse(JSON.stringify(p)).hallOfFame.length,1,'save compatibility');
});

test('routes are walkable without teleporting, and progression gates prevent early access',()=>{
 const p=trainer('Mauville',2);p.x=14;p.y=12;
 assert.equal(Nav.mapRoute('Mauville','LavaridgeGym',p),null);
 p.badges=3;
 assert.ok(Nav.mapRoute('Mauville','LavaridgeGym',p));
 for(const goal of ['Gym','FortreeGym','MossdeepGym','SootopolisGym'])assert.ok(Nav.mapRoute('Mauville',goal,p),goal);
 assert.equal(Nav.mapRoute('Mauville','LeagueSidney',p),null);
 p.badges=8;assert.ok(Nav.mapRoute('Mauville','LeagueSidney',p));
 assert.equal(Nav.mapRoute('Mauville','LeaguePhoebe',p),null);
 p.story.league_sidney=true;assert.ok(Nav.mapRoute('Mauville','LeaguePhoebe',p));
});

test('100-bot capture catalogue, habitats, and Arena remain byte-identical to V4 beta input',()=>{
 for(const relative of ['jogo/game/pokemon/national-pools.js','jogo/game/pokemon/national-habitats.js','jogo/game/pokemon/national-catalog.js','jogo/data/quetzal-catalog.json','jogo/arena/core.mjs','jogo/arena/species.mjs']){
  const original=path.join(__dirname,'../../../emerald_v40_work',relative); // absolute companion working copy when available
  const current=path.resolve(__dirname,'../../',relative);
  assert.ok(fs.statSync(current).size>0);
  if(fs.existsSync(original))assert.equal(crypto.createHash('sha256').update(fs.readFileSync(current)).digest('hex'),crypto.createHash('sha256').update(fs.readFileSync(original)).digest('hex'),relative);
 }
});

test('autonomous trainer progresses past old three-badge stopping point without inventing awards',()=>{
 const b=AI.createBot(1);b.team=[Battle.create('Swampert',29),Battle.create('Sceptile',29),Battle.create('Breloom',29)];
 b.badges=3;b.phase='next';b.area='Mauville';b.x=14;b.y=12;b.story={roxanne:true,brawly:true,wattson:true,peeko:true,steven:true,wally:true,rival110:true};
 const initialWins=b.wins;
 const reached=new Set([b.area]);
 for(let i=0;i<3500&&b.badges<4;i++){
  const before=b.area;AI.advance(b);assert.ok(World.walkable(b.area,b.x,b.y));if(before!==b.area)reached.add(b.area);
 }
 assert.ok(reached.has('Route111')&&reached.has('FieryPath')&&reached.has('Lavaridge'),Array.from(reached).join(','));
 assert.ok(b.ticks>0&&b.badges>=3);
 if(b.badges>=4){assert.ok(b.wins>initialWins);assert.equal(b.story.flannery,true);assert.ok(b.milestones.some(x=>x.type==='badge'&&x.badges===4));}
});


test('autonomous trainer earns all eight badges and five League wins with repeatable RNG',()=>{
 const nativeRandom=Math.random;let seed=1337;
 Math.random=()=>((seed=(Math.imul(seed,1664525)+1013904223)|0)>>>0)/4294967296;
 const b=AI.createBot(1);
 try{for(let i=0;i<80000&&!b.champion;i++){
  AI.advance(b);
  assert.ok(World.walkable(b.area,b.x,b.y));
 }}finally{Math.random=nativeRandom;}
 assert.equal(b.badges,8,`bot stopped at badge ${b.badges} (${b.phase}, ${b.area})`);
 assert.equal(b.leagueWins,5,'each League victory must be earned through battles');
 assert.equal(b.champion,true,'champion status must be earned');
 assert.equal(b.milestones.filter(x=>x.type==='badge').length,8);
 assert.ok(b.milestones.some(x=>x.type==='capture'),'national/species capture process stays active');
 assert.equal(b.hallOfFame.length,1);
});

test('navigating from Lavaridge to Norman never uses the shared Center as a teleport shortcut',()=>{
 const b={area:'Lavaridge',x:18,y:11,badges:4,story:{peeko:true,steven:true,wally:true,rival110:true}};
 const visited=new Set();
 for(let i=0;i<380&&b.area!=='Gym';i++){
  const result=Nav.walkToward(b,{area:'Gym',x:14,y:10});
  assert.ok(result.ok,`failed: ${result.reason}`);
  visited.add(b.area);
 }
 assert.equal(b.area,'Gym');
 assert.equal(visited.has('Center'),false,'must not use any Center as a cross-region shortcut');
});
