'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const Battle=require('../../server/battle.cjs');
const Duel=require('../../server/shared-duel.cjs');
const Nav=require('../../server/navigation.cjs');
const World=require('../../server/world.cjs');
const bots=(name='Red 01')=>({id:'bot-1',name,area:'Littleroot',channel:1,x:14,y:10,team:[Battle.create('Treecko',6),Battle.create('Zigzagoon',5)],losses:0,wins:0});
const player=()=>{const p={id:'p-1',name:'Jogadora',starter:'Mudkip',area:'Littleroot',channel:1,x:14,y:10,badges:0};Battle.createProfileStarter(p);p.team=[Battle.create('Mudkip',24)];return p};
test('duel uses exact persistent bot Pokémon identity, HP, and party; does not mint a second species',()=>{
 const p=player(),b=bots(),first=b.team[0],next=b.team[1];first.hp=Math.max(1,Math.floor(first.maxHp*.7));
 Duel.begin(p,b,1000);
 assert.equal(p.battle.type,'bot');assert.equal(p.battle.enemy.id,first.id);assert.equal(p.battle.enemy.hp,first.hp);
 assert.equal(p.battle.remaining[0].id,next.id);assert.equal(b.duelWith,p.id);
 assert.throws(()=>Duel.begin(player(),b,1001),/batalha/);
 // Attack and copy real HP state back to the persistent bot.
 p.battle.enemy.hp=1;const outcome=Duel.action(p,b,{type:'move',move:'WaterGun'},1100);
 assert.equal(b.team[0].hp,0);assert.equal(b.team[1].id,p.battle.enemy.id);
 assert.equal(outcome.done,false);
 assert.equal(b.duelWith,p.id);
 p.battle.enemy.hp=1;const final=Duel.action(p,b,{type:'move',move:'WaterGun'},1200);
 assert.equal(final.done,true);assert.equal(final.victory,true);assert.equal(b.duelWith,undefined);
 assert.equal(b.losses,1);assert.equal(b.team[1].hp,0);assert.ok(p.wins===1);
});
test('duel cannot start from wrong channel, distant location, or when bot is busy',()=>{
 const b=bots();let p=player();p.channel=2;assert.throws(()=>Duel.begin(p,b),/perto/);
 p=player();p.x=1;assert.throws(()=>Duel.begin(p,b),/perto/);
 p=player();b.battle={type:'wild'};assert.throws(()=>Duel.begin(p,b),/enfrentando/);
});
test('abandoned duel unlocks bot without creating artificial victories or badges',()=>{
 const b=bots(),p=player();Duel.begin(p,b,123);
 assert.deepEqual(Duel.expire(new Map([[p.id,p]]),[b],123+Duel.DUPLEX_MS+1),[b.id]);
 assert.equal(p.battle,null);assert.equal(b.duelWith,undefined);assert.equal(b.wins,0);assert.equal(p.badges,0);
});
test('no shortcut navigation: path respects progression gates and stays on walkable tiles',()=>{
 const p=player();p.area='BrineyHouse';p.x=14;p.y=5;
 assert.equal(Nav.mapRoute('BrineyHouse','Dewford',p),null);
 p.story={peeko:true};const edges=Nav.mapRoute('BrineyHouse','Dewford',p);assert.ok(edges?.length);
 const door=edges[0].portal,dirs=Nav.localDirections(p.area,p.x,p.y,door.x,door.y,true);
 assert.ok(dirs?.length>0);for(const dir of dirs){assert.ok(World.step(p,dir));assert.ok(World.walkable(p.area,p.x,p.y))}
 assert.equal(p.area,'Dewford');
});

test('dynamic shared Pokémon Center exit routes to the city the traveler actually entered from',()=>{
 const p=player();p.area='Dewford';p.x=19;p.y=11;
 assert.equal(World.step(p,'up'),true);
 assert.equal(p.area,'Center');assert.equal(p.returnDoor.area,'Dewford');
 const edges=Nav.mapRoute('Center','Route106',p);
 assert.equal(edges[0].portal.to,'Dewford');
 assert.equal(edges.at(-1).portal.to,'Route106');
});
