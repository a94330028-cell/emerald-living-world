'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const World=require('../../server/world.cjs');
const Nav=require('../../server/navigation.cjs');
const Battle=require('../../server/battle.cjs');
const Story=require('../../server/story.cjs');
const Shop=require('../../server/shop.cjs');
const AI=require('../../server/autonomy.cjs');

test('chapter 2/3 map portals are valid and story gates cannot be bypassed',()=>{
 assert.ok(Object.keys(World.MAPS).length>=28); // V9.5 connects Oldale to Route103
 assert.deepEqual(World.validateWorld(),[]);
 const p={area:'BrineyHouse',x:14,y:4,badges:1,story:{},facing:'down'};
 assert.equal(World.step(p,'up'),false);
 assert.deepEqual([p.area,p.x,p.y],['BrineyHouse',14,4]);
 assert.equal(Nav.mapRoute('RusturfTunnel','Dewford',p),null);
 p.story.peeko=true;
 assert.equal(World.step(p,'up'),true);
 assert.equal(p.area,'Dewford');
 p.area='BrineyHouse';p.x=11;p.y=5;p.story.steven=false;
 assert.equal(World.step(p,'up'),false);
 p.story.steven=true;assert.equal(World.step(p,'up'),false,'two badges also required');
 p.badges=2;assert.equal(World.step(p,'up'),true);assert.equal(p.area,'Slateport');
});
test('Steven story interaction requires actual location and remains idempotently locked',()=>{
 const p={area:'Dewford',x:14,y:10,badges:1,story:{}};
 assert.equal(Story.nearby(p),null);assert.throws(()=>Story.interact(p));
 p.area='StevenChamber';p.x=14;p.y=9;
 assert.equal(Story.interact(p).id,'steven');assert.equal(p.story.steven,true);
 assert.equal(Story.nearby(p),null);assert.throws(()=>Story.interact(p));
});
test('Poké Mart purchase deducts real money and rejects invalid requests',()=>{
 const p={area:'Mauville',bag:{pokeballs:1},money:850};
 assert.throws(()=>Shop.buy(p,'pokeballs',2),/Mart/);
 p.area='Mart';const r=Shop.buy(p,'pokeballs',3);
 assert.deepEqual([r.cost,p.money,p.bag.pokeballs],[600,250,4]);
 assert.throws(()=>Shop.buy(p,'pokeballs',2),/insuficiente/);
 assert.deepEqual([p.money,p.bag.pokeballs],[250,4]);
 for(const qty of [0,-1,1.5,100])assert.throws(()=>Shop.buy(p,'pokeballs',qty),/inválida/);
});
test('gym challenges enforce proper gym, position, and preceding badge',()=>{
 for(const [area,badges,name] of [['RustboroGym',0,'Roxanne'],['DewfordGym',1,'Brawly'],['MauvilleGym',2,'Wattson']]){
  const p={starter:'Mudkip',area,x:14,y:10,badges,story:{}};Battle.createProfileStarter(p);
  assert.equal(Battle.gymAt(p)?.name,name);
  const first=Battle.begin(p,{type:'gym'});
  assert.equal(first.trainerName,name);
  assert.equal(p.badges,badges,'entering a challenge is not a win');
  assert.throws(()=>Battle.act(p,{type:'ball'}),/Não é permitido/);
  p.battle=null;p.badges=badges+1;assert.equal(Battle.gymAt(p),null);
  assert.throws(()=>Battle.begin(p,{type:'gym'}));
 }
});
test('first story trainer cannot mint Peeko completion by proximity',()=>{
 const p={starter:'Mudkip',badges:1,story:{},area:'RusturfTunnel',x:14,y:10,channel:1};Battle.createProfileStarter(p);
 assert.equal(Battle.storyTrainerAt(p)?.id,'aqua_grunt');
 Battle.begin(p,{type:'trainer',trainerId:'aqua_grunt'});
 assert.equal(p.story.peeko,undefined);assert.throws(()=>Battle.act(p,{type:'ball'}));
 assert.throws(()=>Battle.begin(p,{type:'trainer',trainerId:'aqua_grunt'}),/andamento/);
});
test('one real AI journey per starter reaches three badges with corresponding earned event flags',()=>{
 for(const botNumber of [1,2,3]){
  const bot=AI.createBot(botNumber);
  let peak=0;
  for(let i=0;i<40000&&bot.badges<3;i++){
   AI.advance(bot);
   assert.ok(World.walkable(bot.area,bot.x,bot.y));
   assert.ok(bot.badges>=peak&&bot.badges<=peak+1,'no badge leaps');peak=bot.badges;
  }
  assert.equal(bot.badges,3,`${bot.name} ${bot.phase} ${bot.area} after ${bot.ticks} ticks; story=${JSON.stringify(bot.story)}`);
  assert.equal(bot.story.roxanne,true);assert.equal(bot.story.brawly,true);assert.equal(bot.story.wattson,true);
  for(const key of ['peeko','steven','rival110','wally'])assert.equal(bot.story[key],true);
  assert.equal(bot.milestones.filter(e=>e.type==='badge').length,3);
  assert.ok(bot.milestones.some(e=>e.type==='capture'));
  assert.ok(bot.visitedAreas.includes('DewfordGym')&&bot.visitedAreas.includes('MauvilleGym'));
  console.log(`# ${bot.name} reached badge #3 at tick ${bot.ticks} with ${bot.losses} losses`);
 }
});
test('parallel twenty-bot simulation preserves independent progress and map safety',()=>{
 const bots=Array.from({length:20},(_,i)=>AI.createBot(i+1));
 for(let t=0;t<1600;t++)for(const b of bots)AI.advance(b);
 assert.equal(new Set(bots.map(b=>b.id)).size,20);
 assert.ok(bots.every(b=>World.walkable(b.area,b.x,b.y)));
 assert.ok(bots.every(b=>b.milestones.every(e=>e.type!=='badge'||e.badges<=b.badges)));
 assert.ok(bots.every(b=>b.team.length>0));
 assert.ok(bots.some(b=>b.wins>0));
});
test('one hundred bots retain safe positions without inventing badges during 500 turns',()=>{
 const bots=Array.from({length:100},(_,i)=>AI.createBot(i+1));
 const start=performance.now();
 for(let t=0;t<500;t++)for(const b of bots)AI.advance(b);
 assert.ok(bots.every(b=>World.walkable(b.area,b.x,b.y)));
 assert.ok(bots.every(b=>b.ticks===500));
 assert.ok(bots.every(b=>b.badges<=b.milestones.filter(e=>e.type==='badge').length));
 console.log(`# 100 bots × 500 turns: ${Math.round(performance.now()-start)}ms`);
});
