'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const Pass=require('../../server/frontier-pass-lab.cjs');
const Frontier=require('../../server/frontier.cjs');
const Battle=require('../../server/battle.cjs');
const ids=Pass.IDS;
test('FWS LAB é informativo, nunca oficial e começa zerado',()=>{
 const result=Pass.calculate();
 assert.equal(result.value,0);assert.equal(result.official,false);
 assert.equal(result.kind,'experimental-lab');assert.equal(result.facilities.length,7);
 assert.equal(result.goldCount,0);
});
test('ouro substitui prata sem duplicação e 7 ouros dão 600 pontos de símbolos',()=>{
 const symbols=Object.fromEntries(ids.map(id=>[id,'gold']));
 const result=Pass.calculate({labSymbols:symbols});
 assert.equal(result.symbolScore,600);assert.equal(result.performanceScore,0);
 assert.equal(result.value,600);
});
test('completando metas máximas com 7 ouros, score LAB é 1000',()=>{
 const symbols=Object.fromEntries(ids.map(id=>[id,'gold']));
 const records=Object.fromEntries(ids.map(id=>[`${id}:level50:single`,Pass.GOLD_TARGET[id]]));
 const result=Pass.calculate({labSymbols:symbols,labRecords:records});
 assert.equal(result.value,1000);assert.equal(result.performanceScore,400);
});
test('Dome registra vitórias em partidas e precisa de 40 para 10 torneios',()=>{
 const result=Pass.calculate({labRecords:{'dome:level50:single':20}});
 const dome=result.facilities.find(f=>f.id==='dome');
 assert.equal(dome.goal,40);assert.equal(dome.performanceFraction,.5);
});
test('melhor registro entre Level 50 e Open, sem somar nem superar máximo',()=>{
 const f=Pass.calculate({labRecords:{'tower:level50:single':35,'tower:open:single':90}});
 const tower=f.facilities.find(x=>x.id==='tower');
 assert.equal(tower.best,90);assert.equal(tower.performanceFraction,1);
 assert.equal(Pass.calculate({labRecords:{'tower:level50:single':35,'tower:open:single':28}}).facilities[0].best,35);
});
test('Frontier Pass integrado ao status sem criar Símbolos oficiais',()=>{
 const p={id:crypto.randomUUID(),champion:true,team:['Swampert','Sceptile','Blaziken'].map(n=>Battle.create(n,50))};
 const start=Frontier.start(p,{facility:'tower',practice:false,teamIds:p.team.map(m=>m.id)});
 assert.equal(start.labPass.official,false);assert.equal(start.labPass.value,0);
 assert.deepEqual(start.symbols,{});
 assert.equal(start.labPass.facilities.length,7);
});
