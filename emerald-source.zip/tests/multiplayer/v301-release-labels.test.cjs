'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'../..');
const text=name=>fs.readFileSync(path.join(root,name),'utf8');
test('versão da interface e do servidor coincide com o pacote',()=>{
 const release=require('../../package.json').version;
 assert.equal(require('../../server/package.json').version,release);
 for(const file of ['index.html','jogo/index.html','jogo/online.html','jogo/frontier.html','jogo/campanha.html'])
  assert.ok(text(file).includes(release),`${file}: versão atual ausente`);
 assert.equal(text('jogo/online.html').includes('Candidata à final'),false);
});
test('cinco rotas documentadas para os modos de jogo existem',()=>{
 for(const file of ['jogo/index.html','jogo/online.html','jogo/campanha.html','jogo/frontier.html','jogo/arena.html'])
  assert.ok(fs.statSync(path.join(root,file)).isFile(),file);
});
