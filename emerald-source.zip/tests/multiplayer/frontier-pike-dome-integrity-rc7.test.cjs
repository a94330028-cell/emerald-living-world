'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const Frontier=require('../../server/frontier.cjs');
const Adventures=require('../../server/frontier-adventures.cjs');
const Brains=require('../../server/frontier-brains.cjs');
const Battle=require('../../server/battle.cjs');
const Shop=require('../../server/shop.cjs');
const Story=require('../../server/story.cjs');
function p(){return {id:crypto.randomUUID(),name:'RC7',area:'Center',champion:true,badges:8,
 team:['Swampert','Sceptile','Blaziken'].map(n=>Battle.create(n,50)),activeIndex:0,money:4000};}
function start(p,facility,practice=false){return Frontier.start(p,{facility,practice,levelRule:'level50',teamIds:p.team.map(m=>m.id)});}

test('Pike usa 14 salas por bloco, com Lucy nas salas 28 e 140',()=>{
 assert.equal(Frontier.FACILITIES.pike.block,14);
 assert.deepEqual(Brains.BRAINS.pike.triggers,[28,140]);
 const player=p();start(player,'pike');
 const run=player.frontier.active;
 // A quiet room is a legitimate route advancement but not a free battle win.
 for(let i=0;i<14;i++){
  run.pikeDoors={doors:[{index:0,event:'quiet'},{index:1,event:'battle'},{index:2,event:'heal'}],hint:{door:0,text:'Passagem calma'}};
  const response=Frontier.next(player,{door:0});
  assert.equal(response.event,'quiet');
 }
 assert.equal(run.streak,14);assert.equal(run.block,1);
 assert.equal(player.frontier.labBP,2);
 run.streak=27;
 const confrontation=Frontier.next(player,{door:0});
 assert.equal(confrontation.frontierBrain.name,'Lucy');
 assert.equal(confrontation.frontierBrain.tier,'silver');
});

test('Dome mantém chave de 16 participantes e 15 partidas com confrontos projetados',()=>{
 const bracket=Adventures.createDomeTournament(2,50,Frontier.CLASSIC_POOL);
 assert.equal(bracket.entrants.length,16);
 assert.deepEqual(bracket.matches.map(group=>group.length),[8,4,2,1]);
 assert.equal(bracket.matches.flat().length,15);
 assert.equal(bracket.matches.flat().filter(m=>m.firstId==='player'||m.secondId==='player').length,4);
 assert.equal(bracket.matches.flat().filter(m=>m.winnerId==='player').length,0);
 for(let i=0;i<4;i++){
  const game=bracket.matches[i].find(m=>m.firstId==='player'||m.secondId==='player');
  const opponent=game.firstId==='player'?game.secondId:game.firstId;
  assert.equal(bracket.rounds[i].opponentId,opponent);
 }
});

test('Tucker ocupa vaga no torneio 5, com suas três espécies reveladas para o scouting',()=>{
 const p5=p();start(p5,'dome');
 p5.frontier.active.streak=16;
 const battle=Frontier.next(p5);
 assert.equal(battle.type,'frontier');
 const bracket=p5.frontier.active.domeBracket;
 assert.equal(bracket.number,5);
 assert.equal(bracket.entrants.length,16);
 assert.equal(bracket.entrants.filter(e=>e.id==='frontier-brain').length,1);
 assert.equal(bracket.rounds[3].opponent,'Tucker');
 assert.deepEqual(bracket.rounds[3].registered,Brains.BRAINS.dome.silver);
 Frontier.recordResult(p5,p5.battle,true);
 assert.equal(bracket.matches[0][0].winnerId,'player');
 assert.equal(bracket.rounds[0].completed,true);
 assert.deepEqual(p5.frontier.symbols,{});
});

test('Desafio Frontier bloqueia cura, compras, história e batalhas externas',()=>{
 const profile=p();start(profile,'pike');
 const before=profile.team[0].maxHp;
 profile.team[0].hp=1;
 assert.throws(()=>Battle.heal(profile),/Frontier/);
 assert.throws(()=>Battle.begin(profile,{type:'wild'}),/Frontier/);
 assert.throws(()=>Shop.buy(profile,'pokeballs',1),/Frontier/);
 assert.throws(()=>Story.interact(profile),/Frontier/);
 assert.equal(profile.team[0].hp,1);assert.ok(profile.team[0].hp<before);
 assert.equal(profile.money,4000);
 Frontier.retire(profile);
 assert.equal(Battle.heal(profile).length,3);
 assert.equal(profile.team[0].hp,before);
});
