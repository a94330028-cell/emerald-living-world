'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const AI=require('../../server/autonomy.cjs');
const Battle=require('../../server/battle.cjs');
const Nav=require('../../server/navigation.cjs');
const World=require('../../server/world.cjs');

test('goal routing crosses real world.step transitions, rejects walls',()=>{
 const b=AI.createBot(1);const route=Nav.mapRoute('Littleroot','Rustboro');
 assert.ok(route.length>=6);assert.equal(route[0].portal.to,'Route101');
 for(let i=0;i<400&&b.area!=='Rustboro';i++){
  const prev={area:b.area,x:b.x,y:b.y};const r=Nav.walkToward(b,{area:'Rustboro',x:14,y:10});
  assert.ok(r.ok,JSON.stringify({r,prev,b}));
  assert.ok(World.walkable(b.area,b.x,b.y));
  if(prev.area===b.area)assert.equal(Math.abs(prev.x-b.x)+Math.abs(prev.y-b.y),1);
 }
 assert.equal(b.area,'Rustboro');
});

test('same bot has logged starter, real capture, Roxanne victory, saveable badge and EXP evolution',()=>{
 const b=AI.createBot(1),seenGyms=new Set(),visited=[];
 const nativeRandom=Math.random;Math.random=()=>0.10; // reproducible RNG; normal battle/capture API still applies
 assert.equal(b.badges,0);assert.equal(b.team.length,0);
 try{for(let i=0;i<24000;i++){
  if(b.battle?.type==='gym')seenGyms.add(b.battle.enemy.id);
  const before=b.area;AI.advance(b);
  assert.ok(World.walkable(b.area,b.x,b.y),'bot never spawns on blocked tile');
  if(before!==b.area)visited.push(b.area);
  if(b.badges>0&&b.team[0]?.species==='Grovyle'&&b.milestones.some(m=>m.type==='evolution'&&/Treecko evoluiu para Grovyle/.test(m.message)))break;
 }}finally{Math.random=nativeRandom;}
 const kinds=b.milestones.map(e=>e.type);
 assert.ok(kinds.includes('starter'),JSON.stringify(b.milestones));
 assert.ok(kinds.includes('capture'),'actual Battle.act(ball) must add a captured Pokémon');
 assert.ok(kinds.includes('badge'),'badge must only be awarded when trainer battle ends in victory');
 assert.ok(kinds.includes('evolution'),'EXP after victory must cause Grovyle evolution');
 assert.ok(badgesExactlyOne(b));
 assert.ok(seenGyms.size>=3,`Roxanne must send three Pokémon, saw ${seenGyms.size}`);
 assert.ok(b.wins>0&&b.team[0].exp>=Math.pow(16,3));
 assert.equal(b.team[0].species,'Grovyle');
 for(const area of ['Route101','Oldale','Route102','Petalburg','Route104','Woods','Route104North','Rustboro','RustboroGym'])assert.ok(visited.includes(area),`did not reach ${area}`);
 const same=JSON.parse(JSON.stringify(b));assert.deepEqual(same.milestones,b.milestones);
 assert.equal(same.badges,1);assert.equal(same.team[0].exp,b.team[0].exp);
});
function badgesExactlyOne(bot){return bot.badges===1&&bot.story?.roxanne===true&&bot.milestones.some(x=>x.type==='badge');}

test('twenty bots move independently, have their own initial, battle, and progress',()=>{
 const bots=Array.from({length:20},(_,i)=>AI.createBot(i+1));
 for(let tick=0;tick<600;tick++)for(const b of bots)AI.advance(b);
 assert.equal(new Set(bots.map(b=>b.id)).size,20);
 assert.ok(bots.every(b=>b.ticks===600));
 assert.ok(bots.every(b=>b.visitedAreas.includes('Route101')));
 assert.ok(bots.every(b=>World.walkable(b.area,b.x,b.y)));
 assert.ok(bots.every(b=>b.team[0]?.ivs?.hp>=0));
 assert.ok(bots.filter(b=>b.milestones.some(x=>x.type==='capture')).length>=12);
 assert.ok(new Set(bots.map(b=>b.starter)).size>=18,'All generations should be represented in 20 autonomous bots');
 // Never mint a badge by reaching a room or on a timer.
 assert.ok(bots.every(b=>!b.badges||b.milestones.some(x=>x.type==='badge')));
});

test('one hundred bots for five hundred ticks: no invalid positions or artificial badges',()=>{
 const bots=Array.from({length:100},(_,i)=>AI.createBot(i+1));
 const start=performance.now();
 for(let t=0;t<500;t++)for(const b of bots)AI.advance(b);
 const ms=performance.now()-start;
 assert.ok(bots.every(b=>World.walkable(b.area,b.x,b.y)));
 assert.ok(bots.every(b=>b.ticks===500));
 assert.ok(bots.every(b=>(b.badges||0)===0||b.milestones.some(e=>e.type==='badge')));
 assert.ok(bots.filter(b=>b.team.length>=2).length>=75);
 console.log(`# 100 bots × 500 ticks: ${Math.round(ms)} ms, ${bots.filter(b=>b.team.length>=2).length} captured Pokémon`);
});

test('gym cannot mint badge from entering: must defeat real three-mon trainer party',()=>{
 const p={starter:'Mudkip',area:'RustboroGym',x:14,y:10,channel:1,badges:0};Battle.createProfileStarter(p);
 assert.equal(p.badges,0);
 const battle=Battle.begin(p,{type:'gym'});
 assert.equal(battle.enemy.species,'Geodude');assert.equal(battle.remaining,2);
 assert.equal(p.badges,0);
 assert.throws(()=>Battle.act(p,{type:'ball'}),/Não é permitido/);
 assert.throws(()=>Battle.act(p,{type:'run'}),/Não é permitido/);
 const wrong={...p,battle:null,area:'Littleroot',x:14,y:10};
 assert.throws(()=>Battle.begin(wrong,{type:'gym'}),/Aproxime-se/);
});
