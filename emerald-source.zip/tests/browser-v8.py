"""Visual smoke in emulated Android and desktop Chromium, network isolated.
HTTP is mocked solely because sandbox Chromium blocks localhost; authoritative
HTTP and process restart are tested by Node.js independently.
"""
from pathlib import Path
from urllib.parse import urlparse,unquote
import json,mimetypes
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
ERRORS=[]
MOCK=r"""
(()=>{
 const own={id:'visit-1',name:'Visitante',starter:'Mudkip',avatar:'brendan',channel:1,area:'Littleroot',x:14,y:10,facing:'down',mode:'online',badges:0,team:[{species:'Mudkip',level:5,hp:22,maxHp:22,moves:['Tackle','Growl','WaterGun']}],bag:{pokeballs:5},money:500,battle:null};
 const red={id:'bot-1',name:'Red 01',starter:'Treecko',avatar:'brendan',channel:1,area:'Route104North',x:14,y:12,facing:'down',mode:'bot',badges:1,wins:32,losses:4,objective:'Treinar após Roxanne',steps:340,team:[{species:'Grovyle',level:16,hp:38,maxHp:45}]};
 const may={id:'bot-2',name:'Red 02',starter:'Torchic',avatar:'may',channel:2,area:'Littleroot',x:14,y:10,facing:'down',mode:'bot',badges:0,wins:1,losses:0,objective:'Sair de Littleroot',steps:9,team:[{species:'Torchic',level:5,hp:21,maxHp:21}]};
 const bots=[red,may];const maps={Littleroot:{name:'Littleroot',title:'Littleroot · praça de teste'},Route104North:{name:'Route104North',title:'Rota 104 norte · mapa de teste'}};
 function map(area){return {...(maps[area]||maps.Littleroot),seed:1,width:28,height:20,walls:[],portals:[]}}
 let follow=null;let listeners=new Set();
 function snapshot(){const focused=own.mode==='spectator'&&follow?bots.find(x=>x.id===follow):null;const area=focused?.area||own.area,ch=focused?.channel||own.channel;
 return {self:own,map:map(area),players:focused?[]:[own],bots:bots.filter(x=>x.area===area&&x.channel===ch),camera:focused||null,chat:[],online:1,interactions:{gym:null,trainer:null,story:null},simulation:{tick:1875,bots:2,running:true}};}
 function notify(){for(const es of listeners)es.send('snapshot',{data:JSON.stringify(snapshot())})}
 window.EventSource=class {constructor(){this.handlers={};listeners.add(this);setTimeout(()=>{this.send('open',{});notify()},30)}addEventListener(k,cb){(this.handlers[k]??=[]).push(cb)}send(k,v){for(const f of (this.handlers[k]||[]))f(v)}close(){listeners.delete(this)}};
 const original=window.fetch.bind(window);
 window.fetch=async(route,opts={})=>{
  if(!String(route).startsWith('/api/'))return original(route,opts);
  const key=String(route).slice(5),body=JSON.parse(opts.body||'{}');let result={ok:true},status=200;
  if(key==='session'){own.name=body.name||own.name;own.mode=body.mode||'online';own.channel=body.channel||1;result={profile:own,guest:true}}
  else if(key==='bots')result={tick:1875,total:2,bots};
  else if(key.startsWith('bots/')){const b=bots.find(x=>x.id===key.slice(5));result={bot:{...b,events:[{tick:1,type:'starter',message:b.name+' escolheu '+b.starter,area:'Littleroot'},{tick:1850,type:'badge',message:'Stone Badge conquistada após três Pokémon',area:'RustboroGym'}],ticks:1875,bag:{pokeballs:3},money:500}}}
  else if(key==='ranking')result={ranking:bots,hallOfFame:[]};
  else if(key==='spectate'){follow=body.botId;setTimeout(notify,0)}
  else if(key==='move'){const diff={up:[0,-1],down:[0,1],left:[-1,0],right:[1,0]}[body.dir];if(diff){own.x+=diff[0];own.y+=diff[1];own.facing=body.dir;setTimeout(notify,0)}result={self:own};}
  else if(key==='battle/start'){own.battle={type:'wild',turn:0,enemy:{species:'Zigzagoon',level:4,hp:9,maxHp:9},log:['Zigzagoon apareceu!'],remaining:0};result={self:own,result:own.battle};setTimeout(notify,0)}
  else if(key==='battle/action'){own.battle=null;result={self:own,result:{done:true,victory:true,log:['Vitória!']}};setTimeout(notify,0)}
  else if(key==='battle/heal')result={self:own,result:{healed:1}};
  else if(key==='channel'){own.channel=body.channel;result={self:own};setTimeout(notify,0)}
  else if(key==='chat')result={ok:true};
  else {status=404;result={error:'Endpoint não simulado'}}
  return new Response(JSON.stringify(result),{status,headers:{'content-type':'application/json'}});
 };
})();
"""
def assets(route):
 url=urlparse(route.request.url)
 if url.hostname!='emerald-test.local':return route.abort('failed')
 rel=unquote(url.path).lstrip('/')
 file=(ROOT/rel).resolve()
 if not file.is_relative_to(ROOT) or not file.is_file():return route.fulfill(status=404,body='not found')
 return route.fulfill(status=200,body=file.read_bytes(),content_type=mimetypes.guess_type(file.name)[0] or 'application/octet-stream')

def page_test(browser,viewport,mode,path):
 ctx=browser.new_context(viewport=viewport,device_scale_factor=1)
 ctx.add_init_script(MOCK)
 page=ctx.new_page()
 page.route('**/*',assets)
 page.on('pageerror',lambda e:ERRORS.append(str(e)))
 html=(ROOT/'jogo/online.html').read_text().replace('<head>','<head><base href="https://emerald-test.local/jogo/">',1)
 page.set_content(html,wait_until='load',timeout=30000)
 page.locator('#mode').select_option(mode)
 page.locator('#enter').click()
 page.locator('#game').wait_for(state='visible',timeout=10000)
 page.wait_for_function("document.querySelector('#botDetails').textContent.includes('Red 01')",timeout=10000)
 assert 'Red 01' in page.locator('#watchBot').inner_text()
 assert 'Stone Badge' in page.locator('#botEvents').inner_text()
 assert 'Red 01' in page.locator('#botRanking').inner_text()
 if mode=='spectator':
  page.locator('#followBot').click()
  page.wait_for_function("document.querySelector('#stageHint').textContent.includes('Red 01')",timeout=10000)
  assert 'Route104North'==page.evaluate('window.EmeraldTrainerFrames?document.querySelector("#areaName").textContent.includes("104 norte")?"Route104North":"missing":"sprite missing"')
 else:
  page.locator('#findWild').click()
  page.locator('#battleView').wait_for(state='visible',timeout=10000)
  page.locator('#battleActions button').first.click()
  page.locator('#battleView').wait_for(state='hidden')
 page.screenshot(path=str(ROOT/path),full_page=True)
 overflow=page.evaluate('document.documentElement.scrollWidth>window.innerWidth+2')
 assert not overflow, 'horizontal overflow at '+str(viewport)
 ctx.close()
 return {'mode':mode,'width':viewport['width'],'height':viewport['height'],'overflow':overflow,'observation':True,'screenshot':path}

with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 mobile=page_test(browser,{'width':390,'height':844},'spectator','tests/v8_android_spectator.png')
 desktop=page_test(browser,{'width':1280,'height':800},'online','tests/v8_desktop_online.png')
 browser.close()
 result={'chrome_android_emulation':mobile,'chrome_desktop':desktop,'js_errors':ERRORS,'real_http_in_chromium':'blocked by environment administrator; tested separately with Node HTTP'}
 (ROOT/'tests/v8_browser_report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(result,ensure_ascii=False,indent=2))
 assert not ERRORS,ERRORS
