'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const Dex=require('../../server/dex.cjs');
const Pools=require('../../jogo/game/pokemon/national-pools.js');
const Battle=require('../../server/battle.cjs');
const Autonomy=require('../../server/autonomy.cjs');
const fs=require('node:fs');const path=require('node:path');const vm=require('node:vm');
const browserWindow={};vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../../jogo/game/pokemon/national-catalog.js'),'utf8'),{window:browserWindow});
const records=browserWindow.EmeraldNationalCatalog.map(Pools.adapt);
test('offline AI has all National species, variant records, without bundling ROM',()=>{
 assert.equal(records.length,1528);assert.equal(records.filter(x=>x.kind==='species').length,1025);
 assert.equal(records.filter(x=>x.kind==='variant').length,494);
 assert.equal(records.filter(x=>x.kind==='experimental').length,9);
 assert.equal(new Set(records.map(x=>x.key)).size,1528);
 assert.equal(records.find(x=>x.key==='Tinkaton').base[1],75);
 assert.equal(records.find(x=>x.key==='Pecharunt').dex,1025);
});
test('all 1,025 species are available to postgame national encounters, variants opt-in',()=>{
 const all=Pools.pool(records,{champion:true,badges:8});
 assert.equal(all.length,1025);
 assert.equal(all.some(x=>x.key==='Miraidon'),true);
 assert.equal(all.some(x=>x.key==='Pecharunt'),true);
 assert.equal(Pools.pool(records,{champion:true,badges:8,allowForms:true}).length,1519);
});
test('early route protects difficulty: biome and total power limits, no early legendary',()=>{
 const area=Pools.pool(records,{location:'Woods',habitat:'forest',badges:0,matchHabitat:true});
 assert.ok(area.length>=6&&area.length<=20,area.length); // V9.5 caps early habitats to curated species
 assert.ok(area.every(x=>x.types.some(t=>Pools.TYPE_BIOMES.forest.includes(t))));
 assert.ok(area.every(x=>x.base.reduce((a,b)=>a+b,0)<=420));
 assert.ok(area.every(x=>x.catch>=10));
 assert.equal(area.some(x=>x.key==='Mewtwo'),false);
 assert.equal(area.some(x=>x.key==='Sprigatito'),true);
});
test('biome distribution can pick multiple generations and four different areas',()=>{
 let seed=777;const rng=()=>((seed=(seed*1664525+1013904223)>>>0)/2**32);
 const chosen=new Set();
 for(const location of ['Woods','GraniteCave','Route110','Route106'])for(let i=0;i<150;i++){
  const e=Pools.pick(records,{location,badges:3,owned:chosen},rng);assert.ok(e);chosen.add(e.key);
 }
 assert.ok(chosen.size>80,chosen.size); // V9.5 distributes species in explicit, restricted locations
 assert.ok(chosen.has('Sprigatito')||chosen.has('Rookidee')||chosen.has('Tinkatink'));
});
test('online bot uses a National wild battle and only catches via actual battle',()=>{
 const bot=Autonomy.createBot(1);bot.phase='capture';bot.area='Route101';bot.team=[Battle.create('Mudkip',12)];bot.activeIndex=0;bot.bag.pokeballs=70;
 let initial=bot.team.length;
 Autonomy.advance(bot);assert.ok(bot.battle);assert.equal(bot.battle.nationalEncounter,true);
 assert.equal(bot.team.length,initial);assert.ok(Dex.BY_KEY.has(bot.battle.enemy.species));
 assert.ok(Battle.SPEC[bot.battle.enemy.species]);
 let rounds=0;
 while(bot.battle&&rounds++<60)Autonomy.advance(bot);
 assert.ok(rounds<60,'battle stuck');
 assert.ok(bot.team.length>=initial);
 assert.ok(bot.events.some(e=>e.type==='capture'||e.type==='victory'||e.type==='defeat'),JSON.stringify(bot.events.slice(-8)));
});
test('National specimen has real stats, can enter a save and keep them on migration',()=>{
 const bot=Autonomy.createBot(2);const specimen=Battle.create('Sprigatito',10);
 assert.ok(specimen.maxHp>0);const hp=specimen.hp;
 bot.team=[specimen];bot.phase='travel';const saved=JSON.parse(JSON.stringify(bot));
 Autonomy.migrate(saved);
 assert.equal(saved.team[0].species,'Sprigatito');
 assert.equal(saved.team[0].hp,hp);
 assert.deepEqual(saved.team[0].ivs,specimen.ivs);
});
