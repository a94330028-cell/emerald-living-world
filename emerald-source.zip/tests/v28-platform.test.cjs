'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..'),read=p=>fs.readFileSync(path.join(root,p),'utf8');
test('sem chaves secretas no navegador; admin valida role no servidor',()=>{
 const cloud=read('jogo/js/cloud-config.js'),fn=read('supabase/functions/admin-dashboard/index.ts');
 assert.doesNotMatch(cloud,/service_role.*:\s*['"][^'"\s]/);assert.match(fn,/auth\.getUser|authorized\(/);
 assert.match(fn,/email_confirmed_at/);assert.match(fn,/\.eq\('user_id',user\.id\)/);
 assert.match(fn,/member\?\.role!=='admin'/);
});
test('RLS de analytics nao fornece leitura direta para visitantes',()=>{
 const sql=read('supabase/analytics_admin.sql');
 for(const table of ['elw_admins','elw_profiles','elw_analytics_sessions','elw_analytics_events','elw_error_reports'])
  assert.match(sql,new RegExp('alter table public\\.'+table+' enable row level security'));
 assert.match(sql,/revoke all on public\.elw_admins/);assert.match(sql,/from anon, authenticated/);
 assert.match(sql,/security invoker/);assert.match(sql,/grant execute on function public\.elw_admin_report/);
});
test('nao dispara telemetry antes de consentimento e 100 bots nao viram visitantes',()=>{
 const js=read('jogo/js/telemetry-v28.js');
 assert.match(js,/read\(CONSENT\)==='yes'&&ready/);assert.match(js,/crypto\.randomUUID/);
 assert.match(js,/storage\(\)\?\.removeItem\(VISITOR\)/);
 const report=read('supabase/analytics_admin.sql');assert.match(report,/is_playing and last_seen/);
});
test('SEO: sitemap e llms publicos, admin com noindex',()=>{
 const site=read('sitemap.xml'),llms=read('llms.txt'),robots=read('robots.txt'),html=read('jogo/index.html');
 for(const p of ['sobre.html','atualizacoes.html','jogo/estatisticas.html','privacidade.html']){
  assert.ok(site.includes(p),p);assert.ok(llms.includes(p),p);
 }
 assert.match(robots,/Disallow: \/admin\//);assert.doesNotMatch(site,/\/admin\//);
 assert.match(html,/og:image/);assert.match(read('admin/index.html'),/noindex,nofollow/);
 assert.ok(fs.existsSync(path.join(root,'jogo/assets/ui/emerald-share-1200x630.jpg')));
});
test('qualidade mobile e bordas sao opcionais sem alterar o save',()=>{
 const world=read('jogo/js/world.js');assert.match(world,/ELWQuality/);
 assert.match(world,/EdgeScenery\?\.draw\(ctx,camera,placed,\{width:W,height:H,scale:2,official\}\)/);
 const js=read('jogo/js/mobile-quality-v28.js');assert.match(js,/economy/);assert.match(js,/high/);
 assert.doesNotMatch(js,/emerald_living_world_v26/);
});
