"""V9.10 visual navigation smoke: local off-line recovery, secondary pages, mobile and desktop."""
from pathlib import Path
from urllib.parse import urlparse,unquote
import json,mimetypes
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
base='https://emerald-test.local/jogo/'
html=(ROOT/'jogo/index.html').read_text(encoding='utf-8').replace('<head>',f'<head><base href="{base}">',1)
reports={};errors=[]
def serve(route):
 u=urlparse(route.request.url)
 if u.hostname!='emerald-test.local':return route.abort('failed')
 f=(ROOT/unquote(u.path).lstrip('/')).resolve()
 if not f.is_relative_to(ROOT) or not f.is_file():return route.fulfill(status=404,body='missing')
 return route.fulfill(status=200,body=f.read_bytes(),content_type=mimetypes.guess_type(f.name)[0] or 'application/octet-stream')
def fresh(browser,viewport,mobile=False):
 pg=browser.new_page(viewport=viewport,is_mobile=mobile,has_touch=mobile)
 pg.route('**/*',serve)
 pg.on('pageerror',lambda e:errors.append(str(e)))
 pg.on('dialog',lambda d:d.accept())
 pg.evaluate("""() => {const data=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>data.has(k)?data.get(k):null,setItem:(k,v)=>data.set(k,String(v)),removeItem:k=>data.delete(k),clear:()=>data.clear()}})}""")
 pg.set_content(html,wait_until='domcontentloaded',timeout=30000)
 pg.wait_for_function("typeof window.emeraldShowPage==='function'&&window.emeraldTrainers?.length>0",timeout=25000)
 return pg
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 p=fresh(browser,{'width':390,'height':844},True)
 p.locator('#landingWorld').click();p.wait_for_timeout(350)
 p.wait_for_function("window.emeraldOfficialWorld?.cache.get('LittlerootTown')?.value",timeout=10000)
 p.wait_for_timeout(450)
 # Ensure fallback scenery includes structures and navigation stays usable.
 mapstate=p.evaluate('''() => {const m=window.emeraldOfficialWorld.cache.get('LittlerootTown').value;return {fallback:m.fallback,buildings:m.recoveryPlan?.buildings.length,baseVisible:!document.querySelector('#gamePage').hidden,canvas:document.querySelector('#liveWorld').width}}''')
 assert mapstate['fallback'] and mapstate['buildings']>=2,mapstate
 p.screenshot(path=str(ROOT/'tests/v9_10_mundo_android.png'))
 p.evaluate("""() => {const s=document.querySelector('#scenePreview');const opt=[...s.options].find(o=>o.value.includes('Littleroot'));if(opt){s.value=opt.value;s.onchange?.()}}""")
 p.wait_for_timeout(300)
 p.locator('#liveWorld').screenshot(path=str(ROOT/'tests/v9_10_mapa_adaptado.png'))
 # Secondary menu is distinct from 3 primary tabs.
 p.locator('#headerMorePages').click()
 assert p.locator('#navDrawer').is_visible()
 labels=p.locator('[data-drawer-page]').evaluate_all('(nodes)=>nodes.map(x=>x.dataset.drawerPage)')
 assert all(x in labels for x in ['recuperacao','historico','creditos','config','corrida','hall','mapa','forca','frontier']),labels
 p.locator('[data-drawer-page="creditos"]').click()
 assert p.locator('#page-creditos').is_visible()
 p.screenshot(path=str(ROOT/'tests/v9_10_creditos_android.png'))
 p.locator('#headerMorePages').click();p.locator('[data-drawer-page="recuperacao"]').click()
 assert p.locator('#page-recuperacao').is_visible()
 assert p.locator('#recoveryExportSave').is_visible()
 p.screenshot(path=str(ROOT/'tests/v9_10_recuperacao_android.png'))
 p.locator('#recoveryBackGame').click()
 assert p.locator('#gamePage').is_visible()
 assert p.evaluate('''() => [...document.querySelectorAll('.bottomNav [data-page]')].filter(x=>getComputedStyle(x).display!=='none').map(x=>x.dataset.page).join(',')''')=='jogo,pokedex,ranking'
 assert not p.evaluate('document.documentElement.scrollWidth>innerWidth+2')
 walk=p.evaluate('''async () => {window.emeraldSetOption('speed',0);const clock=Date.now;let simulatedTime=clock();try{Date.now=()=>simulatedTime;for(let i=0;i<650;i++){simulatedTime+=400;window.emeraldDebugStep();if(i%25===0)await new Promise(resolve=>setTimeout(resolve,0))}}finally{Date.now=clock}const ts=window.emeraldTrainers;return {total:ts.length,moved:ts.filter(t=>t.walkCount>0).length,invalid:ts.filter(t=>{const m=window.emeraldOfficialWorld.cache.get(t.officialMap)?.value;return m&&!window.emeraldOfficialWorld.walkable(m,t.walkX,t.walkY)}).length,progress:ts.slice(0,5).map(t=>({name:t.name,map:t.officialMap,steps:t.walkCount,target:t.officialTarget,location:t.location,stage:t.stage,objective:t.walkObjective,error:t.officialError,pending:!!t.officialPending,arrived:!!t.storyArrived}))}}''')
 assert walk['total']==20 and walk['moved']>=10 and walk['invalid']==0,walk
 reports['watch']={'map':mapstate,'extraPages':len(labels),'overflow':False,'walking':walk}
 # Solo: header menu also works, without breaking the player's map.
 s=fresh(browser,{'width':390,'height':844},True)
 s.locator('#landingSolo').click()
 s.locator('#headerMorePages').click()
 s.locator('[data-drawer-page="recuperacao"]').click()
 assert s.locator('#page-recuperacao').is_visible()
 s.locator('#recoveryBackGame').click()
 assert s.locator('#page-jogador').is_visible()
 assert s.evaluate('document.body.dataset.liveMapHost')=='personal'
 reports['solo']={'pageRecovery':True,'mapReturned':True}
 d=fresh(browser,{'width':1280,'height':800})
 d.locator('#landingWorld').click();d.locator('#headerMorePages').click()
 assert d.locator('[data-drawer-page="config"]').is_visible()
 d.locator('[data-drawer-page="historico"]').click()
 assert d.locator('#page-historico').is_visible()
 assert not d.evaluate('document.documentElement.scrollWidth>innerWidth+2')
 reports['desktop']={'secondaryMenu':True,'history':True}
 assert not errors,errors
 reports['errors']=errors
 (ROOT/'tests/v9_10_browser_report.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(reports,ensure_ascii=False,indent=2))
 browser.close()
