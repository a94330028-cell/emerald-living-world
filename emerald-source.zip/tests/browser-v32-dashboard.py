"""Offline Chromium mobile dashboard smoke test. No live service or device claims."""
from pathlib import Path
import json,re
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'jogo';s=(SITE/'index.html').read_text()
files=[]
def include_script(m):
 path=(SITE/m.group(1).split('?',1)[0]).resolve()
 if not path.is_relative_to(SITE) or not path.is_file():return m.group(0)
 files.append((str(path.relative_to(SITE)),path.read_text(encoding='utf-8')))
 return ''
s=re.sub(r'<script\b[^>]*\bsrc="([^"]+)"[^>]*>\s*</script>',include_script,s,flags=re.I)
def include_css(m):
 path=(SITE/m.group(1).split('?',1)[0]).resolve()
 return '<style>'+path.read_text(encoding='utf-8')+'</style>' if path.is_relative_to(SITE) and path.is_file() else m.group(0)
s=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"[^>]*>',include_css,s,flags=re.I)
s=s.replace('</body>','\n'.join('<script>'+code.replace('</script','<\\/script')+'\n//# sourceURL=elw/'+name+'</script>' for name,code in files)+'</body>')
report={'tests':[],'errors':[],'environment':'Offline Chromium mobile'}
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 page.on('pageerror',lambda e:report['errors'].append(str(e)))
 page.route('**/*',lambda r:r.abort())
 page.evaluate('''() => {const o={};const m={getItem:k=>o[k]||null,setItem:(k,v)=>o[k]=String(v),removeItem:k=>delete o[k]};Object.defineProperty(window,'localStorage',{configurable:true,value:m});Object.defineProperty(window,'sessionStorage',{configurable:true,value:m});window.fetch=async()=>new Response('[]',{status:200,headers:{'Content-Type':'application/json'}});}''')
 page.set_content(s,wait_until='domcontentloaded',timeout=30000)
 page.wait_for_timeout(600)
 assert page.locator('#landingSolo').count()==1
 page.locator('#landingSolo').click(force=True)
 page.wait_for_timeout(500)
 report['tests'].append('Player mode opens')
 for k in ['personalWorldCard','botRoster','botJourneyDecision','botTopSixCard']:
  assert page.locator('#'+k).count()==1,k
 report['tests'].append('Map, team, decisions, and Top Six mount once')
 order=page.evaluate('''() => ['personalWorldCard','botRoster','botJourneyDecision','botTopSixCard'].map(id=>document.getElementById(id).getBoundingClientRect().top)''')
 assert order==sorted(order),order
 report['tests'].append('Mobile order: game image > team > choice > Top Six')
 assert page.locator('#botJourneyDecision [data-journey-action]').count()==5
 report['tests'].append('Five manual action buttons')
 assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+6')
 report['tests'].append('No horizontal overflow on 390px mobile')
 assert 'pokemon_fit' in page.locator('.introStarter img').first.get_attribute('src')
 report['tests'].append('Starter assets use fitted sprites')
 assert page.evaluate('window.EmeraldSimSpeed.effectiveMultiplier(1)')==40
 assert page.evaluate('typeof window.emeraldChooseJourneyAction')=='function'
 report['tests'].append('Speed mapping and action handler exist')
 page.screenshot(path=str(ROOT/'tests/v32_dashboard_mobile.png'),full_page=False)
 browser.close()
(ROOT/'tests/v32_dashboard_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
