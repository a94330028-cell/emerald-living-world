"""Teste de discriminação de floresta: patch não pode copiar áreas de telhado."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json
ROOT=Path(__file__).resolve().parents[1]
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True)
 page.set_content('<html><body><canvas id="c" width="320" height="220"></canvas></body></html>')
 page.add_script_tag(content=(ROOT/'jogo/game/world/edge-scenery.js').read_text())
 result=page.evaluate('''() => {
  const c=document.createElement('canvas');c.width=c.height=256;
  const src=c.getContext('2d');
  // Telhado cinza ocupa a faixa esquerda: NUNCA pode entrar na floresta.
  src.fillStyle='#b8b8b8';src.fillRect(0,0,256,256);
  for(let y=0;y<256;y+=4)for(let x=64;x<256;x+=4){
   const v=((x/4+y/4)|0)%5;
   src.fillStyle=v===0?'#205a31':v===1?'#68ac56':v===2?'#236e39':v===3?'#4b9852':'#8cd77a';
   src.fillRect(x,y,4,4);
  }
  const m={name:'Route101',width:16,height:16,fallback:false};
  let calls=0;
  const official={cache:new Map([['Route101',{value:m}]]),ensureChunk(){calls++;return {value:{base:c}}},walkable:(map,x,y)=>x<4};
  const rects=[{name:'LittlerootTown',x:0,y:0,width:20,height:20}];
  const target=document.getElementById('c'),ctx=target.getContext('2d');
  const stats=EmeraldEdgeScenery.draw(ctx,{x:-80,y:-80},rects,{width:320,height:220,scale:2,official});
  const pixels=ctx.getImageData(0,0,320,80).data;let grey=0,green=0;
  for(let i=0;i<pixels.length;i+=4){if(pixels[i]===184&&pixels[i+1]===184&&pixels[i+2]===184)grey++;if(pixels[i+1]>pixels[i]+10)green++;}
  return {stats,forestSource:EmeraldEdgeScenery.source(),calls,grey,green};
 }''')
 assert result['stats']['officialTiles']>0,result
 assert result['stats']['trees']>0,result
 assert result['forestSource']['map']=='Route101',result
 assert result['grey']==0,result
 assert result['green']>500,result
 assert result['calls']<=3,result
 page.screenshot(path=str(ROOT/'tests/v29_forest_mock.png'))
 browser.close()
 (ROOT/'tests/v29_forest_report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(result,ensure_ascii=False,indent=2))
