from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from threading import Thread
from pathlib import Path
from playwright.sync_api import sync_playwright
import os,json
os.chdir(Path(__file__).resolve().parents[2]);port=18692
server=ThreadingHTTPServer(('127.0.0.1',port),SimpleHTTPRequestHandler);Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  page=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1,is_mobile=True,has_touch=True)
  errors=[];page.on('pageerror',lambda e: errors.append(str(e)))
  import re
  root=Path(__file__).resolve().parents[2]
  html=(root/'jogo/arena.html').read_text()
  css=(root/'jogo/css/arena-v36.css').read_text()
  cloud=(root/'jogo/js/cloud-config.js').read_text()
  init=(root/'jogo/js/cloud-bootstrap.js').read_text()
  core=(root/'jogo/arena/core.mjs').read_text().replace('export const ','const ').replace('export function ','function ')
  specs=(root/'jogo/arena/species.mjs').read_text().replace('export default ','const catalog=')
  ui=(root/'jogo/js/arena-v36.js').read_text()
  ui='\n'.join(ln for ln in ui.splitlines() if not ln.startswith('import '))
  source=html.replace('<link rel="stylesheet" href="css/arena-v36.css">','<style>'+css+'</style>')
  source=source.replace('<script src="js/cloud-config.js"></script>','<script>'+cloud+'</script>')
  source=source.replace('<script src="js/cloud-bootstrap.js"></script>','<script>'+init+'</script>')
  source=source.replace('<script type="module" src="js/arena-v36.js"></script>','')
  source=source.replace('</body>','<script>'+specs+'\n'+core+'\n'+ui+'</script></body>')
  page.route('**/*',lambda r:r.abort())
  page.set_content(source,wait_until='domcontentloaded',timeout=30000)
  page.wait_for_selector('.teamSlot',timeout=10000)
  assert page.locator('.teamSlot').count()==6
  assert page.locator('#arenaLaunch').is_enabled()
  page.locator('#arenaLaunch').click()
  assert page.locator('#combatMoves button').count()==4
  page.locator('#combatMoves button').first.click()
  assert 'Rodada 2' in page.locator('#battleTurn').inner_text()
  page.locator('[data-tab="build"]').click()
  page.locator('#arenaFormat').select_option('3')
  assert page.locator('.teamSlot').count()==3
  page.locator('#arenaRandom').click()
  assert page.locator('#arenaLaunch').is_enabled()
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
  page.screenshot(path='tests/arena/mobile.png',full_page=True)
  assert not errors,errors
  print(json.dumps({'ready':True,'viewWidth':390,'slots':3,'turnWorked':True,'errors':errors}))
  browser.close()
finally:server.shutdown()
