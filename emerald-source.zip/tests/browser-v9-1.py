"""Render the local Quetzal Pokédex against packaged assets without external network access."""
from pathlib import Path
from urllib.parse import urlsplit, unquote
import json, mimetypes
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parent.parent/'jogo'
REPORT=Path(__file__).resolve().parent/'v9_1_browser_report.json'

def route_assets(route):
    parsed=urlsplit(route.request.url)
    name=unquote(parsed.path).lstrip('/')
    path=(ROOT/name).resolve()
    if not path.is_relative_to(ROOT.resolve()) or not path.is_file():
        route.fulfill(status=404,body='not found');return
    typ=mimetypes.guess_type(path.name)[0] or 'application/octet-stream'
    route.fulfill(status=200,content_type=typ,body=path.read_bytes())

with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    results={}
    for size,viewport in [('android',{'width':390,'height':844}),('desktop',{'width':1280,'height':800})]:
        context=browser.new_context(viewport=viewport,device_scale_factor=1,is_mobile=size=='android',has_touch=size=='android')
        page=context.new_page();errors=[]
        page.on('pageerror',lambda error: errors.append(str(error)))
        # This harness blocks network navigation, so load the real page/CSS/JS
        # in-memory and supply the packaged catalog through fetch mock only.
        import re
        html=(ROOT/'quetzal-pokedex.html').read_text(encoding='utf-8')
        html=re.sub(r'<link rel="stylesheet"[^>]*>', '', html)
        html=re.sub(r'<script defer src="js/quetzal-pokedex.js"></script>', '', html)
        page.goto('about:blank')
        page.set_content(html)
        page.add_style_tag(path=str(ROOT/'css/quetzal-pokedex.css'))
        dataset=json.loads((ROOT/'data/quetzal-catalog.json').read_text(encoding='utf-8'))
        page.evaluate('data => {window.fetch=async() => ({ok:true,json:async()=>data});}',dataset)
        page.add_script_tag(path=str(ROOT/'js/quetzal-pokedex.js'))
        page.wait_for_function("document.getElementById('count').textContent.includes('1025') || document.getElementById('count').textContent.includes('1.025')",timeout=12000)
        initial=page.locator('#count').inner_text()
        assert '1025' in initial,initial
        assert page.locator('.entry').count()==48
        page.locator('#search').fill('Tinkaton');page.wait_for_timeout(80)
        assert page.locator('.entry').count()==1,page.locator('#count').inner_text()
        page.locator('.entry').first.click()
        assert 'Tinkaton' in page.locator('#details h2').inner_text()
        page.locator('#search').fill('');page.locator('#kind').select_option('variant');
        assert '494' in page.locator('#count').inner_text()
        page.locator('#kind').select_option('species');page.locator('#generation').select_option('9');
        assert page.locator('.entry').count()>0
        page.locator('#generation').select_option('');page.locator('#search').fill('Sprigatito')
        assert page.locator('.entry').count()==1
        page.locator('.entry').first.click()
        page.locator('#search').fill('')
        scroll_width=page.evaluate('document.documentElement.scrollWidth');viewport_width=viewport['width']
        assert scroll_width<=viewport_width+2,(scroll_width,viewport_width)
        assert not errors,errors
        screenshot=Path(__file__).resolve().parent/f'v9_1_pokedex_{size}.png'
        page.screenshot(path=str(screenshot),full_page=True)
        results[size]={'initial':initial,'javascriptErrors':errors,'scrollWidth':scroll_width,'viewportWidth':viewport_width,'image':screenshot.name,'filtersTested':True}
        context.close()
    browser.close()
REPORT.write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(REPORT.read_text())
