'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');const vm=require('node:vm');
const root=path.join(__dirname,'../..');const catalog=JSON.parse(fs.readFileSync(path.join(root,'jogo/data/quetzal-catalog.json'),'utf8'));
const code=fs.readFileSync(path.join(root,'jogo/js/pokemon-art.js'),'utf8');
const context={window:{},fetch:async()=>({ok:true,json:async()=>catalog}),console};vm.runInNewContext(code,context,{filename:'pokemon-art.js'});
const art=context.window.EmeraldPokemonArt;
test('the national index includes all Quetzal species',()=>{
 art.register(catalog.pokemon);
 const species=catalog.pokemon.filter(p=>p.kind==='species');
 assert.equal(species.length,1025);
 for(const p of species){assert.equal(art.lookup(p.name),p.dex);assert(art.sources(p.name,{dex:p.dex}).some(src=>src.includes(`/${p.dex}.png`)),p.name)}
});
test('a missing local sprite falls back to a national sprite, then an accessible placeholder',()=>{
 const obj={};art.apply(obj,{name:'Tinkaton',dex:959,kind:'species'});
 assert.match(obj.src,/official-artwork\/959\.png$/);
 obj.onerror();assert.match(obj.src,/home\/959\.png$/);
 obj.onerror();assert.match(obj.src,/pokemon\/959\.png$/);
 obj.onerror();assert.match(obj.src,/pokemon_missing\.svg$/);
});
test('unverified variants are labeled as base-species art',()=>{
 const row=catalog.pokemon.find(p=>p.kind==='variant');const obj={};art.apply(obj,row,{dex:row.dex});
 assert.match(obj.title,/espécie-base/);assert(!obj.src.includes('undefined'));assert(!obj.src.includes('NaN'));
});
test('experimental entries do not pretend to have a verified picture',()=>{
 const row=catalog.pokemon.find(p=>p.kind==='experimental');const obj={};art.apply(obj,row);
 assert.match(obj.src,/pokemon_missing\.svg$/);assert.match(obj.title,/Não há imagem identificada/);
});

test('sprites resolve before the large catalog is fetched and local paths exist',()=>{
 const fresh={window:{},fetch:()=>{throw Error('catalog must not block images')}};vm.runInNewContext(code,fresh);const fast=fresh.window.EmeraldPokemonArt;
 assert.equal(fast.lookup('Tinkaton'),959);assert.match(fast.sources('Tinkaton')[0],/official-artwork\/959\.png$/);
 assert(fast.sources('Mudkip').includes('assets/pokemon_fit/mudkip.png'));
 fast.setVisualMode('classic');assert.equal(fast.sources('Mudkip')[0],'assets/pokemon_fit/mudkip.png');
 for(const row of catalog.pokemon.filter(x=>x.kind==='species'))for(const url of fast.sources(row.name))if(url.startsWith('assets/'))assert(fs.existsSync(path.join(root,'jogo',url)),url);
 assert.match(fast.tag('Mudkip'),/loading="eager"/);
});
