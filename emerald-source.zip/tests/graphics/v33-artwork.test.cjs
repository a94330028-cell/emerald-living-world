'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const root=path.resolve(__dirname,'../..');
const code=fs.readFileSync(path.join(root,'jogo/js/pokemon-art.js'),'utf8');
function boot(){const context={window:{},fetch:()=>{throw Error('No network in art tests')}};vm.runInNewContext(code,context);return context.window.EmeraldPokemonArt;}
test('art mode prefers detailed illustrations, has offline fallback and may toggle to classic',()=>{
 const art=boot();
 const d=art.sources('Treecko');
 assert.match(d[0],/official-artwork\/252\.png$/);
 assert(d.includes('assets/pokemon_fit/treecko.png'));
 art.setVisualMode('classic');
 assert.equal(art.sources('Treecko')[0],'assets/pokemon_fit/treecko.png');
 art.setVisualMode('hd');
 assert.match(art.sources('Mudkip')[0],/official-artwork\/258\.png$/);
});
test('rank uses larger normalized squares and high-resolution images are never pixelated',()=>{
 const css=fs.readFileSync(path.join(root,'jogo/css/v33-artwork-hd.css'),'utf8');
 const html=fs.readFileSync(path.join(root,'jogo/index.html'),'utf8');
 assert.match(css,/#page-ranking #rankTopSix .cleanStatRow img/);
 assert.match(css,/104px!important/);
 assert.match(css,/official-artwork/);
 assert.match(css,/image-rendering:auto!important/);
 assert.match(html,/id="elwPokemonArtMode"/);
 assert.match(html,/js\/art-mode-v33\.js/);
});
