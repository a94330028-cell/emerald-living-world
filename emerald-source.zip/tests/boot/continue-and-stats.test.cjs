const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const read=loc=>fs.readFileSync(path.join(__dirname,'../../',loc),'utf8');
test('the game starts paused even when local saves exist; resume requires an explicit action',()=>{
 const engine=read('jogo/js/engine.js'),landing=read('jogo/js/personal-landing.js');
 assert.match(engine,/camera='auto',paused=true,speed=/);
 assert.match(engine,/window\.emeraldResumeWorld=\(\)=>\{bootAuthorized=true;setPause\(false\)/);
 assert.match(landing,/continueButton\.onclick=\(\)=>/);
 assert.match(landing,/window\.emeraldResumeWorld\?\.\(\)/);
});
test('Continue and New Journey controls both exist, without replacing old saves',()=>{
 const html=read('jogo/index.html');
 assert.match(html,/id="landingContinue"[^>]+hidden/);
 assert.match(html,/id="landingNew"/);
 assert.match(html,/id="worldSetupDialog"/);
 assert.match(html,/js\/mon-details\.js\?v=25-combat-fields/);
});
test('Pokémon details display six stats, known moves, PP, type and power',()=>{
 const source=read('jogo/js/mon-details.js');
 const window={emeraldDexAPI:{MOVES:{Tackle:['Normal',40,100]},MOVE_PP:{Tackle:35}}};
 vm.runInNewContext(source,{window,globalThis:window});
 const helper=window.EmeraldMonDetails;
 const html=helper.html({species:'Mudkip',level:5,hp:17,maxHp:20,atk:10,def:9,spAtk:11,spDef:10,speed:9,moves:['Tackle'],pp:{Tackle:31},nature:'Adamant'},{open:true});
 for(const field of ['HP máximo','Ataque','Defesa','Ataque Especial','Defesa Especial','Velocidade','Tackle','Poder 40','Precisão 100%','31 PP','Adamant'])assert.ok(html.includes(field),field);
 assert.match(html,/<details/);
});
test('full combat details are included in team, solo bot, and PC screens',()=>{
 for(const file of ['jogo/js/engine.js','jogo/js/my-bot.js','jogo/js/clean-navigation-v99.js']){
  assert.match(read(file),/EmeraldMonDetails\?\./,file);
 }
});
