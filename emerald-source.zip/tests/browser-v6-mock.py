"""Chromium UI smoke with mocked HTTP APIs and synthetic map binary fixtures.
API correctness is tested separately by server.test.cjs. This verifies UI only.
"""
from pathlib import Path
from urllib.parse import urlparse,unquote
import mimetypes,json,io
from PIL import Image
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
errors=[]
MOCK_API=r"""
(()=>{
 let data={self:{id:'visitor-1',name:'Explorador A',starter:'Mudkip',avatar:'brendan',channel:1,area:'Littleroot',x:14,y:10,facing:'down',team:[{species:'Mudkip',level:5,hp:22,maxHp:22,moves:['Tackle','Growl','WaterGun']}],bag:{pokeballs:5},money:500,battle:null},map:{name:'Littleroot',title:'Littleroot · praça de teste',seed:1,width:28,height:20,walls:[{x:3,y:3,w:6,h:5}],portals:[{x:14,y:0,to:'Route101',tx:14,ty:18}]},players:[],bots:[{id:'bot-1',name:'Red 01',avatar:'may',channel:1,area:'Littleroot',x:12,y:10,facing:'down',team:[{species:'Treecko',level:5}]}],chat:[],online:2};
 data.players=[data.self,{id:'visitor-2',name:'Treinador B',avatar:'may',channel:1,area:'Littleroot',x:15,y:12,facing:'left',team:[]}];
 const listeners=new Set();let playerSession=true;
 const notify=()=>{for(const ev of listeners)ev.send('snapshot',{data:JSON.stringify(data)});};
 window.EventSource=class{
  constructor(){this.handlers={};listeners.add(this);setTimeout(()=>{this.send('open',{});notify()},50)}
  addEventListener(k,f){(this.handlers[k]??=[]).push(f)}
  send(k,p){for(const fn of (this.handlers[k]||[]))fn(p)}
  close(){listeners.delete(this)}
 };
 const original=window.fetch.bind(window);
 window.fetch=async(path,opts={})=>{
  if(!String(path).startsWith('/api/'))return original(path,opts);
  const endpoint=String(path).slice(5), body=JSON.parse(opts.body||'{}');let status=200,result={ok:true};
  if(endpoint==='session'){
   if(body.name)data.self.name=body.name;
   if(body.channel)data.self.channel=Number(body.channel);
   if(body.avatar)data.self.avatar=body.avatar;
   data.players[0]=data.self;result={profile:data.self,guest:true};
  }else if(endpoint==='move'){
   const d={up:[0,-1],down:[0,1],left:[-1,0],right:[1,0]}[body.dir];
   if(d){data.self.x+=d[0];data.self.y+=d[1];data.self.facing=body.dir;data.players[0]=data.self;}result={self:data.self};
  }else if(endpoint==='channel'){
   data.self.channel=Number(body.channel);data.players=[data.self];data.bots=[];result={self:data.self};
  }else if(endpoint==='battle/start'){
   data.self.battle={type:'wild',turn:0,enemy:{species:'Poochyena',level:3,hp:8,maxHp:8},log:['Poochyena apareceu!']};result={self:data.self,result:data.self.battle};
  }else if(endpoint==='battle/action'){
   data.self.battle=null;result={self:data.self,result:{done:true,victory:true,log:['Mudkip usou WaterGun','Vitória!']}};
  }else if(endpoint==='battle/heal'){
   result={self:data.self,result:{healed:1}};
  }else if(endpoint==='chat'){
   data.chat.push({id:String(data.chat.length),author:data.self.name,message:body.message,channel:data.self.channel,area:data.self.area});
  }else{status=404;result={error:'Not found'}}
  setTimeout(notify,0);return new Response(JSON.stringify(result),{status,headers:{'content-type':'application/json'}});
 };
})();
"""

# Indexed 8×8 one-color PNG for synthetic official tileset fixture.
img=Image.new('P',(8,8),1)
img.putpalette([0,0,0,95,170,96]+[0]*(768-6))
buffer=io.BytesIO();img.save(buffer,format='PNG');PNG=buffer.getvalue()
PAL='JASC-PAL\n0100\n16\n'+'\n'.join(['0 0 0','130 180 125']+['180 200 160']*14)+'\n'
LAYOUTS={'layouts':[
 {'id':'LAYOUT_START','width':28,'height':20,'primary_tileset':'gTileset_General','secondary_tileset':'gTileset_Hoenn','blockdata_filepath':'data/layouts/start.bin'},
 {'id':'LAYOUT_HOUSE','width':28,'height':20,'primary_tileset':'gTileset_General','secondary_tileset':'gTileset_Hoenn','blockdata_filepath':'data/layouts/house.bin'}]}
GROUP={'group_order':['gMapGroup_Towns'],'gMapGroup_Towns':['LittlerootTown','LittlerootTown_BrendansHouse_1F']}
MAPS={
 'LittlerootTown':{'layout':'LAYOUT_START','warp_events':[{'x':14,'y':5,'dest_map':'MAP_LITTLEROOT_TOWN_BRENDANS_HOUSE_1F','dest_warp_id':'0'}], 'object_events':[],'connections':[]},
 'LittlerootTown_BrendansHouse_1F':{'layout':'LAYOUT_HOUSE','warp_events':[{'x':14,'y':18,'dest_map':'MAP_LITTLEROOT_TOWN','dest_warp_id':'0'}], 'object_events':[],'connections':[]}}
def service(route):
 url=urlparse(route.request.url)
 if url.hostname=='raw.githubusercontent.com':
  rel=url.path.split('/master/',1)[-1]
  if rel=='data/maps/map_groups.json':return route.fulfill(status=200,body=json.dumps(GROUP),content_type='application/json')
  if rel=='data/layouts/layouts.json':return route.fulfill(status=200,body=json.dumps(LAYOUTS),content_type='application/json')
  if rel.startswith('data/maps/') and rel.endswith('/map.json'):
   name=rel.split('/')[2]
   return route.fulfill(status=200,body=json.dumps(MAPS.get(name,{})),content_type='application/json')
  if rel in ['data/layouts/start.bin','data/layouts/house.bin']:return route.fulfill(status=200,body=bytes(28*20*2),content_type='application/octet-stream')
  if rel.endswith('/tiles.png'):return route.fulfill(status=200,body=PNG,content_type='image/png')
  if rel.endswith('/metatiles.bin'):return route.fulfill(status=200,body=bytes(16),content_type='application/octet-stream')
  if rel.endswith('/metatile_attributes.bin'):return route.fulfill(status=200,body=bytes(2),content_type='application/octet-stream')
  if rel.endswith('.pal'):return route.fulfill(status=200,body=PAL,content_type='text/plain')
  return route.fulfill(status=404,body='unknown synthetic fixture')
 if url.hostname!='emerald-test.local':return route.abort('failed')
 rel=unquote(url.path).lstrip('/')
 file=(ROOT/rel).resolve()
 if not file.is_relative_to(ROOT) or not file.is_file():return route.fulfill(status=404,body='Not found')
 return route.fulfill(status=200,body=file.read_bytes(),content_type=mimetypes.guess_type(file.name)[0] or 'application/octet-stream')

def load(page,name):
 html=(ROOT/"jogo"/name).read_text(encoding="utf8").replace("<head>","<head><base href=\"https://emerald-test.local/jogo/\">",1)
 page.set_content(html,wait_until="load",timeout=30000)

with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 mob=browser.new_context(viewport={'width':390,'height':844},device_scale_factor=1)
 mob.add_init_script(MOCK_API)
 page=mob.new_page();page.route('**/*',service);page.on('pageerror',lambda e:errors.append('online mock: '+str(e)))
 load(page,'online.html')
 page.locator('#enter').click();page.locator('#game').wait_for(state='visible',timeout=10000)
 page.wait_for_function("document.querySelector('#connection').textContent.includes('Online')")
 before=page.locator('#myStatus').inner_text();page.keyboard.press('ArrowUp');page.wait_for_timeout(250);after=page.locator('#myStatus').inner_text()
 assert before!=after,('move did not affect UI',before,after)
 assert 'Treinador B' in page.locator('#players').inner_text()
 page.locator('#findWild').click();page.locator('#battleView').wait_for(state='visible')
 assert 'Poochyena' in page.locator('#enemyMon').inner_text()
 page.locator('#battleActions button').first.click();page.wait_for_function("document.querySelector('#battleView').hidden")
 assert 'Vitória!' in page.locator('#notice').inner_text()
 page.locator('#chatInput').fill('Olá, mundo!');page.locator('#chatForm button').click()
 page.wait_for_function("document.querySelector('#messages').textContent.includes('Olá, mundo')")
 page.screenshot(path=str(ROOT/'tests/v6_online_android.png'),full_page=True)
 overflow=page.evaluate('document.documentElement.scrollWidth>innerWidth+2')
 assert not overflow,'UI overflows mobile'
 page.locator('#inGameChannel').select_option('2');page.wait_for_timeout(150)
 assert 'Treinador B' not in page.locator('#players').inner_text()
 # ROM: valid artificial GBA header, specific test palette/tile data.
 raw=bytearray(512);raw[0xA0:0xAC]=b'POKEMON EMER';raw[0xAC:0xB0]=b'BPEE';raw[0xB0:0xB2]=b'01';raw[0xB2]=0x96;raw[0xBD]=(0x19-sum(raw[0xA0:0xBD]))&255
 raw[0x102:0x104]=bytes([0x1f,0]);raw[0x120:0x140]=bytes([0x11]*32)
 rom=mob.new_page();rom.route('**/*',service);rom.on('pageerror',lambda e:errors.append('ROM: '+str(e)))
 load(rom,'rom-lab.html');rom.locator('#file').set_input_files({'name':'teste.gba','mimeType':'application/octet-stream','buffer':bytes(raw)})
 rom.wait_for_function("document.querySelector('#summary').textContent.includes('Emerald identificado')")
 rom.locator('#tileOffset').fill('120');rom.locator('#palOffset').fill('100');rom.locator('#widthTiles').fill('1');rom.locator('#heightTiles').fill('1');rom.locator('#preview').click()
 assert '8×8' in rom.locator('#result').inner_text()
 rom.screenshot(path=str(ROOT/'tests/v6_rom_lab.png'))
 # Synthetic official source maps test manual walking and verified reciprocal warp.
 maps=mob.new_page();maps.route('**/*',service);maps.on('pageerror',lambda e:errors.append('map UI: '+str(e)))
 load(maps,'mapas-oficiais.html');maps.wait_for_function("document.querySelector('#state').textContent.includes('Catálogo oficial pronto')",timeout=15000)
 maps.locator('#loadBtn').click();maps.wait_for_function("document.querySelector('#state').textContent.includes('carregado')",timeout=15000)
 maps.locator('#walkMode').check()
 for _ in range(5):maps.locator('[data-walk=up]').click()
 maps.wait_for_timeout(250)
 title=maps.locator('#details h2').inner_text()
 assert 'Brendans House' in title,('reciprocal warp failed',title)
 maps.screenshot(path=str(ROOT/'tests/v6_walking_fixture.png'))
 desk=browser.new_context(viewport={'width':1280,'height':840});desk.add_init_script(MOCK_API)
 dp=desk.new_page();dp.route('**/*',service);dp.on('pageerror',lambda e:errors.append('desktop mock: '+str(e)));load(dp,'online.html');dp.locator('#enter').click();dp.locator('#game').wait_for(state='visible');dp.screenshot(path=str(ROOT/'tests/v6_online_desktop.png'))
 result={'online_interface_mock':True,'android_viewport':{'width':390,'height':844,'horizontal_overflow':overflow},'move_ui':True,'visible_players_ui':True,'chat_ui':True,'channel_switch_ui':True,'online_battle_interface_mock':True,'rom_local_preview':True,'official_walk_fixture_warp':True,'console_errors':errors,'notes':'APIs online mocked only; Node integration tests verify real HTTP. Official map fixture synthetic.'}
 print(json.dumps(result,ensure_ascii=False,indent=2))
 (ROOT/'tests/v6_browser_report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
 assert not errors,errors
 browser.close()
