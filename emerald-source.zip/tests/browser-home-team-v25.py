"""Smoke test of complete trainer team on the main Android game view."""
from pathlib import Path
from urllib.parse import urlparse,unquote
import mimetypes, json
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
BASE='https://emerald-team.test/jogo/'
report={'pageErrors':[]}
def fulfill(route):
 u=urlparse(route.request.url)
 if u.hostname!='emerald-team.test':
  return route.fulfill(status=204,body='')
 if u.path.startswith('/api/'):
  return route.fulfill(status=200,body='{}',content_type='application/json')
 f=(ROOT/unquote(u.path).lstrip('/')).resolve()
 if not f.is_relative_to(ROOT) or not f.is_file(): return route.fulfill(status=404,body='')
 return route.fulfill(status=200,body=f.read_bytes(),content_type=mimetypes.guess_type(f.name)[0] or 'application/octet-stream')
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 page.route('**/*',fulfill)
 page.on('pageerror',lambda e:report['pageErrors'].append(str(e)))
 page.on('dialog',lambda d:d.accept())
 page.evaluate("""() => {const m=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear()}})}""")
 html=(ROOT/'jogo/index.html').read_text().replace('<head>',f'<head><base href="{BASE}">',1)
 page.set_content(html,wait_until='domcontentloaded',timeout=30000)
 page.wait_for_timeout(3700)
 page.locator('#landingWorld').click()
 page.wait_for_timeout(2600)
 # If a freshly created world has no team, add a read-only DOM mock to verify
 # cards with 6 real fields. No change to engine state or game files.
 world=page.evaluate('''() => ({trainers:window.emeraldExport?.()?.trainers?.length||0, visible:!document.querySelector('#gamePage').hidden, team:document.querySelectorAll('#watchFullTeamCards .homeFullMon').length, slots:document.querySelectorAll('#watchFullTeamCards .homeMonEmpty').length})''')
 report['world']=world
 if world['team']==0:
  # The explicit-Continue flow leaves new trainers without starters at boot.
  # Seed this isolated browser fixture only; production saves are never touched.
  page.evaluate("""() => {
    const st=window.emeraldExport?.(),t=st?.trainers?.[st.selected]||st?.trainers?.[0];
    if(!t)return;
    const data=[['Mudkip',8],['Pikachu',13],['Treecko',11],['Taillow',10],['Ralts',9],['Torchic',7]];
    t.team=data.map(([species,level])=>({species,level,hp:24+level,maxHp:32+level,atk:17+level,def:15+level,spAtk:19+level,spDef:16+level,speed:17+level,exp:200,nature:'Hardy',moves:['Tackle','Growl'],pp:{Tackle:25,Growl:30}}));
  }""")
  page.wait_for_timeout(1500)
  world=page.evaluate("""() => ({trainers:window.emeraldExport?.()?.trainers?.length||0, visible:!document.querySelector('#gamePage').hidden, team:document.querySelectorAll('#watchFullTeamCards .homeFullMon').length, slots:document.querySelectorAll('#watchFullTeamCards .homeMonEmpty').length})""")
  report['fixture']='Six test Pokémon added in isolated browser memory, not in game files or saves'
  report['world']=world
 if world['team']==0:
  raise AssertionError('team UI did not populate: '+json.dumps(report))
 report['ui']=page.evaluate('''() => {const grid=document.querySelector('#watchFullTeamCards'),r=grid?.getBoundingClientRect();return {gridVisible:!!r&&r.width>0&&r.height>0,teamCount:document.querySelector('#watchFullTeamCount')?.textContent,names:[...grid.querySelectorAll('.homeMonIdentity strong')].map(x=>x.textContent),hp:[...grid.querySelectorAll('.homeHpBar')].length,stats:[...grid.querySelectorAll('.homeMonStats')].length,moves:[...grid.querySelectorAll('.homeMoveChips')].length,details:[...grid.querySelectorAll('.monFullDetails')].length,overflow:document.documentElement.scrollWidth>innerWidth+4}}''')
 page.locator('#watchFullTeamCards').scroll_into_view_if_needed()
 page.screenshot(path=str(ROOT/'tests/v25_equipe_completa_android.png'),full_page=False)
 # Open a panel to verify all current stats + attacks are accessible.
 first=page.locator('#watchFullTeamCards .monFullDetails').first
 first.locator('summary').click()
 report['ui']['expanded']=first.get_attribute('open') is not None
 report['ui']['statCells']=first.locator('.monCombatStat').count()
 report['ui']['attackItems']=first.locator('.monAttackItem').count()
 # Optional solo view: validate existing roster and new move chips.
 page.evaluate('''() => window.emeraldShowEntry?.()''')
 page.locator('#landingSolo').click()
 page.wait_for_timeout(1200)
 report['solo']=page.evaluate('''() => ({visible:!document.querySelector('#page-jogador').hidden, cards:document.querySelectorAll('#botRoster .personalPokemon').length, moves:document.querySelectorAll('#botRoster .personalKnownMoves').length, overflow:document.documentElement.scrollWidth>innerWidth+4})''')
 print('HOME_TEAM_V25',json.dumps(report,ensure_ascii=False))
 assert report['ui']['gridVisible'] and report['ui']['stats']>0 and report['ui']['hp']>0 and not report['ui']['overflow'],report
 assert report['ui']['expanded'] and report['ui']['statCells']==6,report
 assert not report['pageErrors'],report
 b.close()
