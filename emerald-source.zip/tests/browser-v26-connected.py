"""Android browser smoke for seamless sector composition, with official-style map fixture.
Runs fully offline; DOES NOT claim to verify actual downloaded Emerald geometry.
"""
from pathlib import Path
from urllib.parse import urlparse,unquote
import json,mimetypes
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
BASE='https://v26-test.local/jogo/'
report={'browser':'Chromium Android emulation, 390x844','tests':[],'errors':[]}
def fulfill(route):
 u=urlparse(route.request.url)
 if u.hostname!='v26-test.local':return route.abort('failed')
 if u.path.startswith('/api/'):return route.fulfill(status=200,body='{}',content_type='application/json')
 p=(ROOT/unquote(u.path).lstrip('/')).resolve()
 if not p.is_relative_to(ROOT) or not p.is_file():return route.fulfill(status=404,body='')
 return route.fulfill(status=200,body=p.read_bytes(),content_type=mimetypes.guess_type(p.name)[0] or 'application/octet-stream')
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 page.route('**/*',fulfill)
 page.on('pageerror',lambda e:report['errors'].append(str(e)))
 page.on('dialog',lambda d:d.accept())
 page.evaluate("""() => {const m=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear()}})}""")
 html=(ROOT/'jogo/index.html').read_text().replace('<head>',f'<head><base href="{BASE}">',1)
 page.set_content(html,wait_until='domcontentloaded',timeout=30000)
 page.wait_for_function('window.emeraldTrainers?.length>0&&window.emeraldLiveDraw&&window.EmeraldContinuousHoenn',timeout=25000)
 report['tests'].append('20 trainer sprites intact and continuous module loads on Android')
 page.locator('#landingSolo').click()
 page.wait_for_function('document.getElementById("page-jogador")?.hidden===false',timeout=20000)
 fixture=page.evaluate('''() => {
  const off=window.emeraldOfficialWorld,W=20,H=20;
  function make(name,edge){
   const block=new DataView(new ArrayBuffer(W*H*2));
   return {name,width:W,height:H,meta:{map_type:'MAP_TYPE_TOWN',connections:edge,object_events:[],warp_events:[]},
    blocks:block,primaryAttrs:new DataView(new ArrayBuffer(2048)),secondaryAttrs:new DataView(new ArrayBuffer(2048)),
    layout:{primary_tileset:'gTileset_General'}};
  }
  off.cache.set('LittlerootTown',{value:make('LittlerootTown',[{direction:'up',offset:0,map:'Route101'}])});
  off.cache.set('Route101',{value:make('Route101',[{direction:'down',offset:0,map:'LittlerootTown'}])});
  const colors={LittlerootTown:'#38ac62',Route101:'#438bd0'};
  window.__v26Chunks=[];
  off.ensureChunk=(name,cx,cy)=>{
   window.__v26Chunks.push(name+':'+cx+':'+cy);
   const m=off.cache.get(name)?.value;
   if(!m)return {value:null};
   const base=document.createElement('canvas');
   base.width=Math.min(16,m.width-cx*16)*16;base.height=Math.min(16,m.height-cy*16)*16;
   const c=base.getContext('2d');c.fillStyle=colors[name];c.fillRect(0,0,base.width,base.height);
   return {value:{base,foreground:null,width:base.width,height:base.height}};
  };
  const settings=window.emeraldOptions;
  const st=window.emeraldExport();
  const leader=settings.gameMode==='player'?st.trainers.find(t=>t.isUserBot):st.trainers[st.selected];
  const matching=window.emeraldTrainers.find(t=>t.id===leader?.id)||window.emeraldTrainers[0];
  matching.officialMap='LittlerootTown';matching.walkMap='official:LittlerootTown';
  matching.walkX=10;matching.walkY=1;matching.walkPrevX=10;matching.walkPrevY=1;
  matching.walkStepSeq=1;matching.officialSpawn=false;
  window.emeraldLiveDraw();
  return {debug:window.emeraldLiveDebug(),requestedChunks:window.__v26Chunks,id:leader?.id,match:matching.id};
 }''')
 report['fixture']=fixture
 page.locator('#liveWorld').screenshot(path=str(ROOT/'tests/v26_connected_android_mock.png'))
 assert fixture['debug']['continuous']['located']>=2,fixture
 assert fixture['debug']['continuous']['chunkTiles']==16
 assert 'LittlerootTown' in fixture['debug']['officialMap']
 assert any(n.startswith('LittlerootTown:') for n in fixture['requestedChunks']),fixture
 assert any(n.startswith('Route101:') for n in fixture['requestedChunks']),fixture
 report['tests'].append('adjacent synthetic outdoor maps share one canvas without screen transition')
 report['tests'].append('no load all: 16x16 chunks + camera-local images')
 report['tests'].append('existing solo setup and player interface still work')
 perf=page.evaluate("""() => {
  const st=window.emeraldExport(),list=window.emeraldTrainers;
  const originalCount=list.length,previousMode=st.settings.gameMode;
  const sample=list[0];
  for(let i=originalCount;i<100;i++){
   list.push({...sample,id:i,name:'Teste '+i,officialMap:i%2?'Route101':'LittlerootTown',
    walkMap:i%2?'official:Route101':'official:LittlerootTown',walkX:i%16,walkY:18,
    team:sample.team?.slice()||[],isUserBot:false,battle:null});
  }
  st.settings.gameMode='simulator';
  const t0=performance.now();
  for(let n=0;n<12;n++)window.emeraldLiveDraw();
  const ms=performance.now()-t0;
  st.settings.gameMode=previousMode;list.length=originalCount;
  return {bots:100,frames:12,totalMs:+ms.toFixed(2),avgFrameMs:+(ms/12).toFixed(2)};
 }""")
 report['performanceSynthetic']=perf
 assert perf['bots']==100 and perf['frames']==12 and perf['avgFrameMs']<1500,perf
 report['tests'].append('100 simulated trainer records rendered with camera culling; time recorded')
 report['horizontalOverflow']=page.evaluate('document.documentElement.scrollWidth>window.innerWidth+3')
 assert not report['horizontalOverflow']
 assert not report['errors'],report['errors']
 (ROOT/'tests/v26_connected_browser_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False,indent=2))
 browser.close()
