"""Offline test of the v3 interface + mocked Supabase API. NOT evidence of live backend.
Uses actual page scripts/styles inline so no external assets are required.
"""
from pathlib import Path
import re,json
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]; SITE=ROOT/'jogo'; s=(SITE/'index.html').read_text()
files=[]
def take(m):
 name=m.group(1).split('?',1)[0];path=(SITE/name).resolve()
 if not path.is_relative_to(SITE) or not path.is_file():return m.group(0)
 code=path.read_text();
 if name=='js/cloud-config.js':code="window.EMERALD_CLOUD_CONFIG = {supabaseUrl:'https://example.supabase.co',supabaseAnonKey:'fake_public_key_012345678901234567890'};"
 files.append((name,code));return ''
s=re.sub(r'<script\b[^>]*\bsrc="([^"]+)"[^>]*>\s*</script>',take,s,flags=re.I)
def style(m):
 path=(SITE/m.group(1).split('?',1)[0]).resolve()
 return '<style>'+path.read_text()+'</style>' if path.is_relative_to(SITE) and path.is_file() else m.group(0)
s=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"[^>]*>',style,s,flags=re.I)
s=s.replace('</body>','\n'.join('<script>'+code.replace('</script','<\\/script')+'\n//# sourceURL=elw/'+filename+'</script>' for filename,code in files)+'</body>')
report={'tests':[],'errors':[],'environment':'Chromium mobile em modo offline, Supabase simulado'}
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1,is_mobile=True,has_touch=True)
 page.on('pageerror',lambda e:report['errors'].append(str(e)))
 page.route('**/*',lambda route:route.abort())
 page.evaluate('''() => {
  const db={};window._store=db;const mem={getItem:k=>Object.prototype.hasOwnProperty.call(db,k)?db[k]:null,setItem:(k,v)=>{db[k]=String(v)},removeItem:k=>{delete db[k]},clear:()=>Object.keys(db).forEach(k=>delete db[k])};
  Object.defineProperty(window,'localStorage',{configurable:true,value:mem});Object.defineProperty(window,'sessionStorage',{configurable:true,value:mem});
  mem.setItem('elw_cloud_session_v1',JSON.stringify({access_token:'fake_jwt',refresh_token:'fake_refresh',expires_at:9999999999,user:{id:'11111111-1111-1111-1111-111111111111',user_metadata:{display_name:'Treinador Teste'},email_confirmed_at:'2026-01-01T00:00:00Z'}}));
  window._sent=[];window._messages=[{id:1,author_id:'22222222-2222-2222-2222-222222222222',nickname:'Outro Treinador',body:'Bem-vindo a Hoenn!',room:'geral',created_at:'2026-11-06T08:00:00Z'}];
  window.fetch=async (url,opts={}) => {
   url=String(url);
   if(url.includes('elw_chat_messages?'))return new Response(JSON.stringify(window._messages.filter(x=>url.includes('room=eq.'+x.room)).slice(-60)),{status:200,headers:{'Content-Type':'application/json'}});
   if(url.includes('rpc/elw_send_chat_message')){const payload=JSON.parse(opts.body);window._sent.push(payload);window._messages.push({id:window._messages.length+1,author_id:'11111111-1111-1111-1111-111111111111',nickname:'Treinador Teste',body:payload.p_message,room:payload.p_room,created_at:'2026-11-06T08:01:00Z'});return new Response(JSON.stringify(window._messages.length),{status:200,headers:{'Content-Type':'application/json'}})}
   if(url.includes('rpc/elw_report_chat_message'))return new Response('true',{status:200,headers:{'Content-Type':'application/json'}});
   if(url.includes('/auth/v1/'))return new Response(JSON.stringify({id:'11111111-1111-1111-1111-111111111111'}),{status:200,headers:{'Content-Type':'application/json'}});
   return new Response('[]',{status:200,headers:{'Content-Type':'application/json'}})
  }
 }''')
 page.set_content(s,wait_until='domcontentloaded',timeout=30000)
 page.wait_for_timeout(700)
 assert page.evaluate('document.documentElement.scrollWidth <= innerWidth+4'), 'Mobile layout causes horizontal overflow'
 report['tests'].append('Mobile page fits the screen; existing game scripts initialize')
 page.locator('#personalLanding [data-elw-theme-toggle]').click(force=True)
 assert page.evaluate('document.documentElement.dataset.pokeTheme')=='dark'
 bg=page.locator('#personalLanding .introShell').evaluate('(el)=>getComputedStyle(el).backgroundColor')
 assert '255, 255, 255' not in bg and 'rgb(255,' not in bg, bg
 report['tests'].append('Landing dark toggle changes global theme and darkens welcome surface')
 page.locator('#personalLanding [data-elw-open-chat]').click(force=True)
 assert page.locator('#elwChatPanel').is_visible()
 page.wait_for_timeout(800)
 assert 'Outro Treinador' in page.locator('#elwChatMessages').inner_text()
 report['tests'].append('Global community chat opens and reads simulated remote messages')
 page.locator('#elwChatInput').fill('Olá! Meu time tem um Treecko.')
 page.locator('#elwChatSubmit').click()
 page.wait_for_timeout(350)
 assert page.evaluate('window._sent.length')==1
 assert 'Olá! Meu time' in page.locator('#elwChatMessages').inner_text()
 report['tests'].append('Chat sends to a simulated Supabase RPC endpoint and displays reply')
 page.locator('[data-chat-room="ajuda"]').click()
 page.wait_for_timeout(350)
 assert page.locator('[data-chat-room="ajuda"]').get_attribute('aria-selected')=='true'
 report['tests'].append('Switching between topic rooms updates selected state')
 page.screenshot(path=str(ROOT/'tests/v30_mobile_chat.png'),full_page=False)
 page.locator('#elwChatClose').click()
 assert not page.locator('#elwChatPanel').is_visible()
 report['tests'].append('Chat closes and restores navigation')
 # Start the pre-existing local campaign and scan key visible panels for light leaks.
 page.locator('#landingSolo').click(force=True)
 page.wait_for_timeout(450)
 surfaces=page.evaluate('''() => [...document.querySelectorAll('.card,.cloudPanel,.pageHero,.personalPartyCard,.pokedexDevice,.introShell,.welcomePanel')].filter(el=>{const r=el.getBoundingClientRect();return r.width>100&&r.height>60&&getComputedStyle(el).visibility!=='hidden'&&el.getClientRects().length}).slice(0,35).map(el=>({className:el.className,color:getComputedStyle(el).backgroundColor}))''')
 bright=[x for x in surfaces if x['color'].startswith('rgb(') and all(int(a)>215 for a in x['color'][4:-1].split(', ')[:3])]
 report['tests'].append('Inspected '+str(len(surfaces))+' potential UI surfaces in dark theme; bright surfaces: '+str(len(bright)))
 assert not bright, 'Bright panels leaked into dark theme: '+str(bright[:5])
 browser.close()
(ROOT/'tests/v30_browser_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
