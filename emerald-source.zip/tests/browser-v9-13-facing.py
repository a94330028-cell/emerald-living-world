"""V9.13 Android: real asset rendering, direction based on tile movement, idle stable.
The online snapshots are mocked; backend integrity is covered by npm test.
"""
from pathlib import Path
from urllib.parse import urlparse,unquote
import mimetypes,json
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
BASE='https://v913-test.local/jogo/'
report={'environment':'Chromium Android viewport; online snapshots mocked','errors':[]}

def fulfill(route):
    req=route.request
    u=urlparse(req.url)
    if u.hostname!='v913-test.local':return route.abort('failed')
    if u.path.startswith('/api/'):
        if u.path == '/api/session':return route.fulfill(status=200,body=json.dumps({'profile':{'id':'p1'}}),content_type='application/json')
        if u.path == '/api/bots':return route.fulfill(status=200,body=json.dumps({'bots':[]}),content_type='application/json')
        if u.path == '/api/ranking':return route.fulfill(status=200,body=json.dumps({'ranking':[],'hallOfFame':[]}),content_type='application/json')
        if u.path == '/api/top-pokemon':return route.fulfill(status=200,body=json.dumps({'top':[]}),content_type='application/json')
        if u.path == '/api/encounters':return route.fulfill(status=200,body=json.dumps({'area':'Littleroot','badges':0,'total':0,'sample':[]}),content_type='application/json')
        return route.fulfill(status=200,body='{}',content_type='application/json')
    p=(ROOT/unquote(u.path).lstrip('/')).resolve()
    if not p.is_relative_to(ROOT) or not p.is_file():return route.fulfill(status=404,body='')
    return route.fulfill(status=200,body=p.read_bytes(),content_type=mimetypes.guess_type(p.name)[0] or 'application/octet-stream')

SELF={'id':'p1','name':'Jogador','avatar':'brendan','facing':'down','area':'Littleroot','x':14,'y':10,'channel':1,'mode':'online','badges':0,'money':500,'bag':{'pokeballs':5},'story':{},'team':[{'species':'Treecko','level':5,'hp':21,'maxHp':21,'moves':['Pound']}], 'battle':None}
BOT={'id':'bot-1','name':'Red 01','avatar':'may','facing':'left','area':'Littleroot','x':17,'y':10,'channel':1,'mode':'bot','badges':0,'wins':0,'losses':0,'objective':'Explorando','team':[{'species':'Mudkip','level':5,'hp':21,'maxHp':21,'moves':['Tackle']}], 'battle':None}
MAP={'name':'Littleroot','title':'Littleroot','seed':1,'width':28,'height':20,'walls':[], 'npcs':[], 'portals':[]}
def snap(me=SELF,bot=BOT):return {'self':me,'map':MAP,'players':[me],'bots':[bot],'chat':[],'online':1,'interactions':{},'simulation':{'tick':5,'bots':1,'running':True}}

with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
    page.route('**/*',fulfill)
    page.on('pageerror',lambda e:report['errors'].append(str(e)))
    page.evaluate('''s=>{window.__testSnapshot=s;window.EventSource=class MockSource{
      constructor(){this.handlers={};window.__testSSE=this;setTimeout(()=>this.handlers.snapshot?.({data:JSON.stringify(window.__testSnapshot)}),100)}
      addEventListener(k,fn){this.handlers[k]=fn} close(){}
    }}''',snap())
    html=(ROOT/'jogo/online.html').read_text().replace('<head>',f'<head><base href="{BASE}">',1)
    page.set_content(html,wait_until='load',timeout=30000)
    page.locator('#name').fill('Jogador')
    page.locator('#enter').click()
    page.wait_for_function('window.emeraldOnlineVisualDebug?.().facing.p1===2',timeout=15000)
    assert page.evaluate('window.EmeraldTrainerSprites.ready("brendan")&&window.EmeraldTrainerSprites.ready("may")')
    def update(me,bot):
        page.evaluate('s=>window.__testSSE.handlers.snapshot({data:JSON.stringify(s)})',snap(me,bot))
    # Server facing is stale or contradictory; actual displacement must win.
    east={**SELF,'x':15,'facing':'down'}
    update(east,BOT)
    page.wait_for_function('window.emeraldOnlineVisualDebug().facing.p1===1')
    assert page.evaluate('window.emeraldOnlineVisualDebug().moving.some(m=>m.id==="p1"&&m.dir===1)')
    # Changing facing without changing location must not turn the sprite.
    update({**east,'facing':'up'},BOT)
    assert page.evaluate('window.emeraldOnlineVisualDebug().facing.p1')==1
    # Bot moving north must face north, even with stale left-facing snapshot.
    update({**east,'facing':'up'},{**BOT,'y':9,'facing':'left'})
    page.wait_for_function('window.emeraldOnlineVisualDebug().facing["bot-1"]===0')
    page.wait_for_timeout(300)
    assert page.evaluate('window.emeraldOnlineVisualDebug().facing.p1')==1
    page.locator('#onlineCanvas').scroll_into_view_if_needed()
    page.screenshot(path=str(ROOT/'tests/v9_13_android.png'))
    report['online']={'playerMovedEast':True,'idleNotRotating':True,'botMovedNorth':True,'spritesReady':True,'overflow':page.evaluate('document.documentElement.scrollWidth>innerWidth+2')}
    assert not report['online']['overflow']
    # Offline renderer: idle must not use the t.walkDir field if it changes without movement.
    other=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
    other.route('**/*',fulfill)
    other.on('pageerror',lambda e:report['errors'].append(str(e)))
    other.on('dialog',lambda d:d.accept())
    other.evaluate('''() => {const m=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear()}})}''')
    main=(ROOT/'jogo/index.html').read_text().replace('<head>',f'<head><base href="{BASE}">',1)
    other.set_content(main,wait_until='domcontentloaded',timeout=30000)
    other.wait_for_function('window.emeraldTrainers?.length>0&&!!window.emeraldLiveDebug',timeout=20000)
    other.locator('#landingWorld').click()
    other.wait_for_timeout(450)
    before=other.evaluate('''()=>{const t=window.emeraldTrainers[0];return {seq:t.walkStepSeq||0,dir:window.emeraldLiveDebug().position?.dir}}''')
    other.evaluate('''()=>{const t=window.emeraldTrainers[0];t.walkDir=0;t.walkFacingDir=0;}''')
    other.wait_for_timeout(100)
    after=other.evaluate('window.emeraldLiveDebug().position?.dir')
    # A standing character's direction is retained, not overwritten by a changing hint.
    if before['dir'] is not None: assert after==before['dir'],(before,after)
    report['offline']={'idleDirectionBefore':before['dir'],'idleDirectionAfter':after}
    assert not report['errors'],report['errors']
    (ROOT/'tests/v9_13_browser_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    browser.close()
