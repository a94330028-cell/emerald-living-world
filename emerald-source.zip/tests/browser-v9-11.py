"""Reproducible UI check: game, team, badge snapshot, full rank and top six."""
from pathlib import Path
from urllib.parse import urlparse,unquote
import json,mimetypes
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
BASE='https://emerald-ui-test.local/jogo/'
HTML=(ROOT/'jogo/index.html').read_text(encoding='utf-8').replace('<head>',f'<head><base href="{BASE}">',1)
results={}
def serve(route):
 url=urlparse(route.request.url)
 if url.hostname!='emerald-ui-test.local':return route.abort('failed')
 path=(ROOT/unquote(url.path).lstrip('/')).resolve()
 if not path.is_relative_to(ROOT) or not path.is_file():return route.fulfill(status=404,body='')
 return route.fulfill(status=200,body=path.read_bytes(),content_type=mimetypes.guess_type(path.name)[0] or 'application/octet-stream')

def setup(browser):
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 errs=[]
 page.route('**/*',serve)
 page.on('pageerror',lambda e:errs.append(str(e)))
 page.on('dialog',lambda d:d.accept())
 page.evaluate("""() => {let m=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear()}})}""")
 page.set_content(HTML,wait_until='load',timeout=45000)
 page.wait_for_function('window.emeraldTrainers?.length >= 5 && !!window.emeraldPower',timeout=45000)
 return page,errs

def fixture(page):
 page.evaluate("""() => {
  const species=['Treecko','Mudkip','Torchic','Pikachu','Gardevoir','Rayquaza','Sprigatito','Fuecoco'];
  const trainers=window.emeraldTrainers;
  for(let i=0;i<Math.min(3,trainers.length);i++){
   const t=trainers[i];t.badges=3-i;
   for(let j=0;j<(trainers.length===1?6:3);j++){
    const s=species[(i*3+j)%species.length];
    t.team.push({species:s,level:10+i*5+j*3,hp:30,maxHp:30,atk:23+i*4,def:20,spAtk:24,spDef:21,spe:26,moves:['Tackle'],pp:{Tackle:25}});
   }
  }
  window.emeraldRender?.();
 }""")

with sync_playwright() as playwright:
 browser=playwright.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 world,errors=setup(browser)
 world.locator('#landingWorld').click()
 world.wait_for_timeout(1700)
 if world.locator('#worldSetupDialog').is_visible():world.locator('#setupKeep').click()
 fixture(world)
 world.locator('.bottomNav [data-page="jogo"]').click()
 world.wait_for_timeout(1450)
 game=world.evaluate("""() => ({
  worldVisible:!document.getElementById('gamePage').hidden,
  partyCards:document.querySelectorAll('#watchPartyCards .cleanMini').length,
  miniRank:document.querySelectorAll('#watchRankSummary .gameBadgeLine').length,
  miniTopSix:document.querySelectorAll('#watchRankSummary .gameTopPoke').length,
  horizontalOverflow:document.documentElement.scrollWidth>innerWidth+2
 })""")
 assert game['worldVisible'] and game['partyCards']>0 and game['miniRank']==5 and game['miniTopSix']==6 and not game['horizontalOverflow'],game
 world.locator('#watchRankSummary [data-rank-open]').click()
 world.wait_for_timeout(650)
 rank=world.evaluate("""() => ({
  rankVisible:!document.getElementById('page-ranking').hidden,
  badgeRows:document.querySelectorAll('#rankingSlot .cleanBadgeRow').length,
  teamRows:document.querySelectorAll('#rankStrongTeams .cleanStatRow').length,
  strongestRows:document.querySelectorAll('#rankStrongestPokemon .cleanStatRow').length,
  topSixRows:document.querySelectorAll('#rankTopSix .cleanStatRow').length,
  topSixImages:[...document.querySelectorAll('#rankTopSix img')].map(e=>e.getAttribute('src')),
  horizontalOverflow:document.documentElement.scrollWidth>innerWidth+2
 })""")
 assert rank['rankVisible'] and rank['badgeRows']>=3 and rank['teamRows']>=3 and rank['strongestRows']==1 and rank['topSixRows']==6 and len(rank['topSixImages'])==6 and not rank['horizontalOverflow'],rank
 world.locator('#rankTopSixCard').scroll_into_view_if_needed()
 world.screenshot(path=str(ROOT/'tests/v9_11_rank_android.png'),full_page=False)
 world.locator('#rankBackToGame').click()
 world.locator('#watchRankSummary').scroll_into_view_if_needed()
 world.screenshot(path=str(ROOT/'tests/v9_11_jogo_android.png'),full_page=False)
 assert not errors,errors
 results['watch']={'game':game,'ranking':rank,'javascriptErrors':errors}
 world.close()

 solo,soloerrs=setup(browser)
 solo.locator('#landingSolo').click()
 solo.wait_for_timeout(1400)
 if solo.locator('#worldSetupDialog').is_visible():solo.locator('#setupKeep').click()
 fixture(solo)
 solo.locator('.bottomNav [data-page="jogo"]').click()
 solo.wait_for_timeout(1500)
 status=solo.evaluate("""() => ({
  soloVisible:!document.getElementById('page-jogador').hidden,
  personalTeam:document.querySelectorAll('#botRoster .personalPokemon').length,
  miniRank:document.querySelectorAll('#soloRankSummary .gameBadgeLine').length,
  miniTopSix:document.querySelectorAll('#soloRankSummary .gameTopPoke').length,
  horizontalOverflow:document.documentElement.scrollWidth>innerWidth+2
 })""")
 assert status['soloVisible'] and status['miniRank']==1 and status['miniTopSix']==6 and not status['horizontalOverflow'],status
 solo.locator('#soloRankSummary [data-rank-open]').click()
 solo.wait_for_timeout(500)
 assert solo.evaluate("!document.getElementById('page-ranking').hidden && document.querySelectorAll('#rankTopSix .cleanStatRow').length===6")
 assert not soloerrs,soloerrs
 results['solo']={'game':status,'javascriptErrors':soloerrs}
 solo.close()
 browser.close()
(ROOT/'tests/v9_11_ui_report.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(results,ensure_ascii=False,indent=2))
