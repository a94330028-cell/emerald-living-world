"""Android online UI smoke with fixture SSE/API. Server APIs have separate real HTTP tests.
A browser sandbox here blocks direct localhost. This does NOT test a real SSE connection.
"""
import json, pathlib, mimetypes
from urllib.parse import urlparse, unquote
from playwright.sync_api import sync_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
BASE='https://emerald-test.local/jogo/'
HTML=(ROOT/'jogo/online.html').read_text(encoding='utf-8').replace('<head>','<head><base href="'+BASE+'">',1)
SELF={'id':'p1','name':'Teste Android','avatar':'brendan','facing':'down','area':'Littleroot','x':14,'y':10,'channel':1,'mode':'online','badges':0,'money':500,'bag':{'pokeballs':5},'story':{},'team':[{'species':'Mudkip','level':5,'hp':23,'maxHp':23,'moves':['Tackle']}], 'battle':None}
BOT={'id':'bot-1','name':'Red 01','avatar':'may','facing':'left','area':'Littleroot','x':15,'y':10,'channel':1,'mode':'bot','badges':0,'wins':0,'losses':0,'objective':'Sair de Littleroot','team':[{'species':'Treecko','level':5,'hp':20,'maxHp':20}]}
MAP={'name':'Littleroot','title':'Littleroot - teste','seed':1,'width':28,'height':20,'walls':[{'x':3,'y':3,'w':6,'h':5}], 'npcs':[{'x':17,'y':10,'name':'NPC de teste'}], 'portals':[{'x':14,'y':0,'to':'Route101','tx':14,'ty':18}]}
SNAP={'self':SELF,'map':MAP,'players':[SELF],'bots':[BOT],'camera':None,'chat':[],'online':1,'interactions':{},'simulation':{'tick':25,'bots':5,'running':True}}
MOCKS={
 'POST /api/session':{'profile':SELF},
 'GET /api/bots':{'bots':[BOT]},
 'GET /api/bots/bot-1':{'bot':{**BOT,'starter':'Treecko','events':[]}},
 'GET /api/ranking':{'ranking':[BOT],'hallOfFame':[]},
 'GET /api/top-pokemon':{'top':[{'species':'Treecko','owner':'Red 01','level':5,'power':120}]},
 'GET /api/encounters':{'area':'Littleroot','badges':0,'total':0,'sample':[],'source':'adapted-simulator-not-quetzal'}
}
report={'mode':'Android Chromium, mocked SSE/API','errors':[]}
def asset(route):
 req=route.request;url=urlparse(req.url)
 if url.hostname!='emerald-test.local':return route.abort('failed')
 if url.path.startswith('/api/'):
  key=req.method+' '+url.path
  data=MOCKS.get(key,{'error':'not-mocked'})
  return route.fulfill(status=200 if key in MOCKS else 404,body=json.dumps(data),content_type='application/json')
 path=(ROOT/unquote(url.path).lstrip('/')).resolve()
 if not path.is_relative_to(ROOT) or not path.is_file():return route.fulfill(status=404,body='missing')
 return route.fulfill(status=200,body=path.read_bytes(),content_type=mimetypes.guess_type(path.name)[0] or 'application/octet-stream')
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 page.route('**/*',asset)
 page.on('pageerror',lambda e:report['errors'].append(str(e)))
 page.add_init_script('''window.EventSource=class MockSource {
  constructor(){this.handlers={};setTimeout(()=>this.handlers.snapshot?.({data:JSON.stringify(window.__testSnapshot)}),250);}
  addEventListener(name,cb){this.handlers[name]=cb;}
  close(){}
 };''')
 # add_init_script doesn't run for set_content in some contexts; explicitly set mock first
 page.evaluate('''() => {window.EventSource=class MockSource {
  constructor(){this.handlers={};setTimeout(()=>this.handlers.snapshot?.({data:JSON.stringify(window.__testSnapshot)}),250);}
  addEventListener(name,cb){this.handlers[name]=cb;} close(){} };}''')
 page.evaluate('s=>{window.__testSnapshot=s}',SNAP)
 page.set_content(HTML,wait_until='load',timeout=30000)
 page.locator('#name').fill('Teste Android')
 page.locator('#enter').click()
 page.wait_for_function('document.querySelector("#game")?.hidden===false && document.querySelector("#playerCount")?.textContent==="1 online"',timeout=15000)
 page.locator('#showOnlineCollisions').check()
 page.locator('#showOnlinePaths').check()
 page.locator('#showOnlineHitboxes').check()
 page.wait_for_timeout(350)
 report['screen']={
  'gameVisible':page.locator('#game').is_visible(),
  'spritesLoaded':page.evaluate('window.EmeraldTrainerSprites?.ready("brendan")&&window.EmeraldTrainerSprites?.ready("may")'),
  'debugToggles':page.evaluate('[...document.querySelectorAll(".debugSwitches input")].every(x=>x.checked)'),
  'safeCityText':page.locator('#localEncounters').inner_text(),
  'canvasWidth':page.locator('#onlineCanvas').evaluate('(c)=>c.width'),
  'horizontalOverflow':page.evaluate('document.documentElement.scrollWidth>window.innerWidth+2'),
  'npcLabels':page.evaluate('window.__testSnapshot.map.npcs.length'),
 }
 page.locator('#onlineCanvas').scroll_into_view_if_needed()
 page.screenshot(path=str(ROOT/'tests/v9_5_online_android.png'),full_page=False)
 assert report['screen']['gameVisible'] and report['screen']['spritesLoaded'] and report['screen']['debugToggles'],report
 assert not report['screen']['horizontalOverflow'],report
 assert 'sem encontros' in report['screen']['safeCityText'].lower(),report
 assert not report['errors'],report
 (ROOT/'tests/v9_5_online_browser_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
 print(json.dumps(report,ensure_ascii=False,indent=2))
 browser.close()
