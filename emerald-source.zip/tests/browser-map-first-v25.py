"""Test actual map-first DOM in Chromium with file-backed responses (localhost blocked)."""
from pathlib import Path
from urllib.parse import urlparse,unquote
import mimetypes,json
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
BASE='https://emerald-map-first.test/jogo/'
summary={"pageErrors":[]}

def fulfill(route):
 u=urlparse(route.request.url)
 if u.hostname!='emerald-map-first.test':return route.fulfill(status=204,body='')
 if u.path.startswith('/api/'):
  return route.fulfill(status=200,body='{}',content_type='application/json')
 p=(ROOT/unquote(u.path).lstrip('/')).resolve()
 if not p.is_relative_to(ROOT) or not p.is_file():return route.fulfill(status=404,body='')
 return route.fulfill(status=200,body=p.read_bytes(),content_type=mimetypes.guess_type(p.name)[0] or 'application/octet-stream')

with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 page.route('**/*',fulfill)
 page.on('pageerror',lambda e: summary['pageErrors'].append(str(e)))
 page.on('dialog',lambda d:d.accept())
 # Browser's persistent storage may be blocked in an isolated test origin.
 page.evaluate('''() => {const m=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear()}})}''')
 html=(ROOT/'jogo/index.html').read_text().replace('<head>',f'<head><base href="{BASE}">',1)
 page.set_content(html,wait_until='domcontentloaded',timeout=25000)
 page.wait_for_timeout(4000)
 # If mode picker is visible, enter spectate/world (same game view as user screenshot).
 if page.locator('#landingWorld').count() and page.locator('#landingWorld').is_visible():
  page.locator('#landingWorld').click()
  page.wait_for_timeout(800)
 summary.update(page.evaluate('''() => {const d=document.querySelector('#directorPanel');const m=document.querySelector('#liveWorld');const t=document.querySelector('#classicMapTools');const mr=m.getBoundingClientRect(),tr=t.getBoundingClientRect();return {children:[...d.children].map(n=>n.className||n.id),mapVisible:getComputedStyle(m).display!=='none'&&mr.width>0&&mr.height>0,mapBeforeControls:mr.top<tr.top,mapTop:mr.top,toolsTop:tr.top,computedPanel:{display:getComputedStyle(d).display,flexDirection:getComputedStyle(d).flexDirection,gridTemplateRows:getComputedStyle(d).gridTemplateRows},computedGrid:{order:getComputedStyle(d.querySelector('.directorGrid')).order,display:getComputedStyle(d.querySelector('.directorGrid')).display},computedTools:{order:getComputedStyle(t).order,display:getComputedStyle(t).display},controlsCollapsed:!t.open,mapSize:[mr.width,mr.height],noHorizontalOverflow:document.documentElement.scrollWidth<=window.innerWidth+4,worldMode:document.body.dataset.worldMode||null,documentReady:document.readyState}}'''))
 print('BEFORE ASSERT',json.dumps(summary,ensure_ascii=False),flush=True)
 # debug don't assert until CSS audit
 assert summary['noHorizontalOverflow'],summary
 # Screenshot at the map, without including the debug options above it.
 page.locator('#liveWorld').scroll_into_view_if_needed(timeout=10000)
 page.screenshot(path=str(ROOT/'tests/v25_mapa_primeiro_android.png'),full_page=False)
 # Interaction: tools can still be opened and collapsed, while map stays ahead.
 page.locator('#classicMapTools > summary').click()
 assert page.locator('#classicMapTools').evaluate('(el)=>el.open') is True
 page.locator('#classicMapTools > summary').click()
 assert page.locator('#classicMapTools').evaluate('(el)=>el.open') is False
 summary['toolToggleWorks']=True
 # Warn about general errors separately: remote official resources are mocked in this test.
 (ROOT/'tests/v25_map_first_browser_report.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
 print(json.dumps(summary,ensure_ascii=False,indent=2))
 browser.close()
