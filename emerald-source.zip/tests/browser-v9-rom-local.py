"""Pass a user-owned ROM path in the environment; never package ROM bytes."""
import os,json,mimetypes
from pathlib import Path
from urllib.parse import urlparse,unquote
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
rom=os.environ.get('EMERALD_TEST_ROM')
if not rom:raise SystemExit('Defina EMERALD_TEST_ROM apontando para uma ROM local autorizada')
if not Path(rom).is_file():raise SystemExit('ROM não encontrada')
network=[];errors=[]
def assets(route):
 url=urlparse(route.request.url)
 if url.hostname!='emerald-test.local':return route.abort('failed')
 rel=unquote(url.path).lstrip('/')
 f=(ROOT/rel).resolve()
 if not f.is_relative_to(ROOT) or not f.is_file():return route.fulfill(status=404,body='not found')
 return route.fulfill(status=200,body=f.read_bytes(),content_type=mimetypes.guess_type(f.name)[0] or 'application/octet-stream')
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844});page.route('**/*',assets)
 page.on('request',lambda req:network.append({'method':req.method,'url':req.url}) if req.method!='GET' else None)
 page.on('pageerror',lambda e:errors.append(str(e)))
 html=(ROOT/'jogo/rom-lab.html').read_text().replace('<head>','<head><base href="https://emerald-test.local/jogo/">',1)
 page.set_content(html,wait_until='load')
 page.locator('#file').set_input_files(rom)
 page.wait_for_function("document.querySelector('#summary').textContent.includes('Quetzal identificado')",timeout=30000)
 summary=page.locator('#summary').inner_text()
 page.screenshot(path=str(ROOT/'tests/v9_rom_lab.png'),full_page=True)
 assert 'Quetzal identificado' in summary
 assert not errors,errors
 assert not network,network
 result={'header_recognized':True,'summary':summary,'rom_requests':network,'js_errors':errors,'assets_extracted':False,'rom_copied_to_package':False}
 (ROOT/'tests/v9_rom_lab_report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
 print(json.dumps(result,ensure_ascii=False,indent=2))
 browser.close()
