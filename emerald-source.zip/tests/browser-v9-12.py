"""Local UI validation: no Poké Ball background, neutral fallback and real stat power."""
from pathlib import Path
from urllib.parse import urlparse,unquote
import mimetypes,json
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
BASE='https://emerald-v912.local/jogo/'
HTML=(ROOT/'jogo/index.html').read_text(encoding='utf8').replace('<head>',f'<head><base href="{BASE}">',1)
def serve(route):
 u=urlparse(route.request.url)
 if u.hostname!='emerald-v912.local':return route.abort('failed')
 path=(ROOT/unquote(u.path).lstrip('/')).resolve()
 if not path.is_relative_to(ROOT) or not path.is_file():return route.fulfill(status=404,body='')
 return route.fulfill(status=200,body=path.read_bytes(),content_type=mimetypes.guess_type(path.name)[0] or 'application/octet-stream')
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 errors=[]
 page.route('**/*',serve)
 page.on('pageerror',lambda err:errors.append(str(err)))
 page.on('dialog',lambda dia:dia.accept())
 page.evaluate("""() => {let m=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear()}})}""")
 page.set_content(HTML,wait_until='load',timeout=60000)
 page.wait_for_function('window.emeraldTrainers?.length>=1 && !!window.emeraldPower && !!window.EmeraldPokemonArt',timeout=60000)
 page.locator('#landingWorld').click()
 page.wait_for_timeout(750)
 if page.locator('#worldSetupDialog').is_visible():page.locator('#setupKeep').click()
 page.evaluate("""() => {
  const t=window.emeraldTrainers[0];
  t.badges=0;
  t.team=[
   {species:'Litten',level:5,ivs:{},evs:{},nature:'Hardy',moves:['Tackle'],hp:20,maxHp:20},
   {species:'Popplio',level:6,ivs:{},evs:{},nature:'Hardy',moves:['Pound'],hp:20,maxHp:20},
   {species:'Piplup',level:7,ivs:{},evs:{},nature:'Hardy',moves:['Pound'],hp:20,maxHp:20},
   {species:'Charmander',level:8,ivs:{},evs:{},nature:'Hardy',moves:['Scratch'],hp:20,maxHp:20},
   {species:'Mudkip',level:9,ivs:{},evs:{},nature:'Hardy',moves:['Tackle'],hp:20,maxHp:20},
   {species:'Treecko',level:10,ivs:{},evs:{},nature:'Hardy',moves:['Pound'],hp:20,maxHp:20}
  ];
  window.emeraldRender();
 }""")
 page.wait_for_timeout(1500)
 data=page.evaluate("""() => {
  const sample={species:'Litten',level:5,ivs:{},evs:{},nature:'Hardy',moves:['Tackle']};
  const scores=[5,6,50,60].map(level=>window.emeraldPower({...sample,level}));
  const top=document.querySelector('#watchRankSummary');
  const img=top?.querySelector('img');
  return {scores,renderedTop:top?.querySelectorAll('.gameTopPoke').length||0,
   backgroundImage:img?getComputedStyle(img).backgroundImage:null,
   imageSrc:img?.getAttribute('src'),topText:top?.textContent?.slice(0,150),
   overflow:document.documentElement.scrollWidth>innerWidth+2};
 }""")
 assert len(data['scores'])==4 and data['scores'][0]<data['scores'][1] and data['scores'][2]<data['scores'][3],data
 assert data['renderedTop']==6,data
 assert data['backgroundImage']=='none',data
 assert not data['overflow'],data
 assert not errors,errors
 page.locator('#watchRankSummary').scroll_into_view_if_needed()
 page.screenshot(path=str(ROOT/'tests/v9_12_rank_android.png'))
 (ROOT/'tests/v9_12_browser_report.json').write_text(json.dumps({'result':data,'errors':errors},ensure_ascii=False,indent=2))
 print(json.dumps(data,ensure_ascii=False,indent=2))
 browser.close()
