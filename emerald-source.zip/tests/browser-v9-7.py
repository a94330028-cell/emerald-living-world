"""V9.7 local browser visual and interactive smoke tests (mocked static origin)."""
from pathlib import Path
from urllib.parse import urlparse,unquote
import json,mimetypes
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
base='https://emerald-test.local/jogo/'
html=(ROOT/'jogo/index.html').read_text(encoding='utf-8').replace('<head>',f'<head><base href="{base}">',1)
errors=[]
def asset(route):
 u=urlparse(route.request.url)
 if u.hostname!='emerald-test.local': return route.abort('failed')
 path=(ROOT/unquote(u.path).lstrip('/')).resolve()
 if not path.is_relative_to(ROOT) or not path.is_file():return route.fulfill(status=404,body='missing')
 return route.fulfill(status=200,body=path.read_bytes(),content_type=mimetypes.guess_type(path.name)[0] or 'application/octet-stream')
with sync_playwright() as play:
 browser=play.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 page.route('**/*',asset)
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('dialog',lambda d:d.accept())
 page.evaluate('''() => {const data=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>data.has(k)?data.get(k):null,setItem:(k,v)=>data.set(k,String(v)),removeItem:k=>data.delete(k),clear:()=>data.clear()}})}''')
 page.set_content(html,wait_until='load',timeout=30000)
 page.wait_for_function('window.emeraldTrainers?.length>=1&&window.EmeraldStarters?.ALL?.length===27',timeout=30000)
 page.screenshot(path=str(ROOT/'tests/v9_7_landing_android.png'))
 landing=page.evaluate('''() => ({active:document.body.classList.contains('landing-active'),mainHidden:getComputedStyle(document.querySelector('#gamePage')).display==='none',buttons:[!!document.getElementById('landingSolo'),!!document.getElementById('landingWorld')],starterOptions:document.getElementById('landingStarter').options.length,overflow:document.documentElement.scrollWidth>innerWidth+2})''')
 assert landing['active'] and landing['mainHidden'] and all(landing['buttons']) and landing['starterOptions']==27 and not landing['overflow'],landing
 page.locator('#landingSolo').click()
 page.wait_for_timeout(500)
 solo=page.evaluate('''() => ({mode:window.emeraldOptions.gameMode,count:window.emeraldTrainers.length,landingGone:document.getElementById('personalLanding').hidden,personalVisible:!document.getElementById('page-jogador').hidden,manual:window.emeraldMyBot()?.manualBattleEnabled})''')
 assert solo['mode']=='player' and solo['count']==1 and solo['landingGone'] and solo['personalVisible'],solo
 # Force an isolated first rival decision; no fabricated win is awarded.
 page.evaluate('''() => {const t=window.emeraldMyBot();t.stage=13;t.location='Route 103';t.storyArrived=true;t.cooldown=0;t.team=[window.emeraldDiagnostics.createMon('Mudkip',8)];t.starter='Mudkip';t.battle=null;t.userRivalChoice=null;window.emeraldOfficialWorld.stepTrainer=(trainer)=>{trainer.storyArrived=true;trainer.walkJustStepped=false;return true};window.emeraldStep();}''')
 page.wait_for_timeout(150)
 decision=page.evaluate('''() => ({key:window.emeraldMyBot().userRivalChoice?.key,pending:window.emeraldMyBot().userRivalChoice?.choice,visible:!document.getElementById('botRivalDecision').hidden})''')
 assert decision['key']=='first-rival' and decision['pending']=='pending' and decision['visible'],decision
 page.locator('[data-rival-choice="fight"]').click()
 page.evaluate('window.emeraldStep()')
 page.wait_for_timeout(250)
 action=page.evaluate('''() => ({kind:window.emeraldMyBot().battle?.kind,round:window.emeraldMyBot().battle?.round,moves:document.querySelectorAll('#botMoveChoices button[data-action="attack"]').length})''')
 assert action['kind']=='rival' and action['round']==0 and action['moves']>=1,action
 page.screenshot(path=str(ROOT/'tests/v9_7_battle_android.png'))
 page.locator('#botMoveChoices button[data-action="attack"]').first.click()
 page.evaluate('window.emeraldStep()')
 page.wait_for_timeout(150)
 finished=page.evaluate('''() => ({round:window.emeraldMyBot().battle?.round??-1,firstLog:window.emeraldMyBot().battle?.history?.[0],mode:window.emeraldOptions.gameMode,overflow:document.documentElement.scrollWidth>innerWidth+2})''')
 assert finished['round']>=1 and not finished['overflow'],finished
 # Separate personal training choice fixture; the choice must be persisted and must not award a badge.
 page.evaluate('''() => {const t=window.emeraldMyBot();t.battle=null;t.stage=13;t.storyArrived=true;t.cooldown=0;t.officialMap='Route103';t.location='Route 103';t.userRivalChoice={key:'first-rival',label:'May/Brendan na Rota 103',choice:'pending',trainingLeft:0};window.emeraldRefreshMyBot();}''')
 page.locator('[data-rival-choice="train"]').click()
 training=page.evaluate('''() => ({choice:window.emeraldMyBot().userRivalChoice?.choice,left:window.emeraldMyBot().userRivalChoice?.trainingLeft,badges:window.emeraldMyBot().badges,saved:JSON.parse(localStorage.getItem('emerald_living_world_v26')||'{}').trainers?.[0]?.userRivalChoice?.choice})''')
 assert training['choice']=='train' and training['left']==3 and training['badges']==0 and training['saved']=='train',training
 page.evaluate('window.emeraldStep()')
 trainingStep=page.evaluate('''() => ({kind:window.emeraldMyBot().battle?.kind,tag:window.emeraldMyBot().battle?.userTrainingKey,remaining:window.emeraldMyBot().userRivalChoice?.trainingLeft,badges:window.emeraldMyBot().badges})''')
 assert (trainingStep['kind']=='trainingWild' and trainingStep['tag']=='first-rival' or trainingStep['remaining']==2) and trainingStep['badges']==0,trainingStep
 assert not errors,errors
 report={'landing':landing,'solo':solo,'decision':decision,'battle':action,'afterMove':finished,'trainingChoice':training,'firstTrainingStep':trainingStep,'pageErrors':errors}
 (ROOT/'tests/v9_7_browser_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
 print(json.dumps(report,ensure_ascii=False,indent=2))
 # Independent desktop entry and normal observer mode regression.
 desktop=browser.new_page(viewport={'width':1280,'height':800})
 desktop.route('**/*',asset)
 desktop.on('pageerror',lambda e:errors.append(str(e)))
 desktop.evaluate('''() => {const data=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>data.has(k)?data.get(k):null,setItem:(k,v)=>data.set(k,String(v)),removeItem:k=>data.delete(k),clear:()=>data.clear()}})}''')
 desktop.set_content(html,wait_until='load',timeout=30000)
 desktop.wait_for_function('window.emeraldTrainers?.length>0',timeout=30000)
 desktop.screenshot(path=str(ROOT/'tests/v9_7_landing_desktop.png'))
 desktop.locator('#landingWorld').click()
 desktop.wait_for_timeout(200)
 observer=desktop.evaluate('''() => ({mode:window.emeraldOptions.gameMode,bots:window.emeraldTrainers.length,hidden:document.querySelector('#personalLanding').hidden,overflow:document.documentElement.scrollWidth>innerWidth+2})''')
 assert observer['mode']=='watch' and observer['bots']==20 and observer['hidden'] and not observer['overflow'],observer
 report['observerRegression']=observer
 (ROOT/'tests/v9_7_browser_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
 assert not errors,errors
 print('Desktop observer test:',json.dumps(observer,ensure_ascii=False))
 browser.close()
