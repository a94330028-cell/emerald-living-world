"""V3.4 local/offline mobile smoke: checks ranking and entry point visually, without external services."""
from pathlib import Path
import re,json
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'jogo';source=(SITE/'index.html').read_text()
scripts=[]
def js_take(match):
 p=(SITE/match.group(1).split('?',1)[0]).resolve()
 if not p.is_relative_to(SITE) or not p.is_file():return match.group(0)
 scripts.append((str(p.relative_to(SITE)),p.read_text()));return ''
source=re.sub(r'<script\b[^>]*\bsrc="([^"]+)"[^>]*>\s*</script>',js_take,source,flags=re.I)
def css_take(match):
 p=(SITE/match.group(1).split('?',1)[0]).resolve()
 return '<style>'+p.read_text()+'</style>' if p.is_relative_to(SITE) and p.is_file() else match.group(0)
source=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"[^>]*>',css_take,source,flags=re.I)
source=source.replace('</body>','\n'.join('<script>'+code.replace('</script','<\\/script')+'\n//# sourceURL=elw/'+name+'</script>' for name,code in scripts)+'</body>')
report={'checks':[],'errors':[]}
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 pg=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 pg.on('pageerror',lambda e:report['errors'].append(str(e)[:240]))
 pg.route('**/*',lambda r:r.abort())
 pg.evaluate('''() => {
 const store={};const api={getItem:k=>store[k]??null,setItem:(k,v)=>store[k]=String(v),removeItem:k=>delete store[k]};
 Object.defineProperty(window,'localStorage',{configurable:true,value:api});
 Object.defineProperty(window,'sessionStorage',{configurable:true,value:api});
 window.fetch=async()=>new Response('[]',{status:200,headers:{'Content-Type':'application/json'}});
 }''')
 pg.set_content(source,wait_until='domcontentloaded',timeout=30000)
 pg.wait_for_timeout(1300)
 assert pg.evaluate('document.documentElement.scrollWidth <= innerWidth+3'),'Landing horizontal scroll'
 assert pg.locator('#personalLanding').is_visible()
 assert not pg.locator('.elw-chat-launch').is_visible()
 assert not pg.locator('.elw-explore-strip').count()
 assert not pg.locator('a[href="online.html"]').count()
 report['checks'].append('landing com botões compactos, sem multiplayer ou links soltos')
 pg.screenshot(path=str(ROOT/'tests/v34_landing_android.png'))
 pg.locator('#landingWorld').click(force=True)
 pg.wait_for_timeout(300)
 pg.evaluate('window.emeraldShowPage("ranking")')
 pg.wait_for_timeout(1000)
 assert pg.locator('#rankStrongTeamsCard').is_visible()
 assert pg.locator('#rankStoryProgressCard').is_visible()
 assert pg.locator('#rankTopSixCard').count()==0
 assert pg.locator('#rankStoryProgress .elwTrainerRow').count()>0
 assert pg.evaluate('document.documentElement.scrollWidth<=innerWidth+3'), 'Rank horizontal scroll'
 report['checks'].append('ranking de times e avanço da história visíveis, sem Top 6 individual')
 # In-memory fixtures used only for UI validation; no changes to saves or source data.
 pg.evaluate('''() => {
  const list=window.emeraldTrainers;
  const sample=(species,level)=>({species,level,moves:['Tackle'],ivs:{},evs:{},nature:'Hardy',hp:10,maxHp:10});
  list[0].team=[sample('Treecko',30),sample('Mudkip',30)];list[0].stage=27;list[0].badges=8;list[0].leagueRound=3;
  list[1].team=[sample('Torchic',18)];list[1].stage=27;list[1].leagueRound=5;list[1].champion=true;list[1].badges=8;
  window.emeraldShowPage('jogo');window.emeraldShowPage('ranking');
 }''')
 pg.wait_for_timeout(450)
 assert pg.locator('#rankStrongTeams .elwTrainerRow').count()>=2
 assert pg.locator('#rankStoryProgress .elwTrainerRow').first.locator('.elwTrainerTitle strong').inner_text()=='May'
 pg.locator('[data-elw-rank-scroll="rankStoryProgressCard"]').click(force=True)
 assert not pg.locator('#page-ranking').is_hidden(),'Rank tab must not switch SPA page via fragment'
 assert pg.evaluate('document.documentElement.scrollWidth<=innerWidth+3'), 'Rank overflow with data'
 report['checks'].append('treinadores ordenados corretamente com equipe, etapa e campeão; botões de rolagem não mudam a página')
 pg.screenshot(path=str(ROOT/'tests/v34_rank_android.png'))
 # Check theme switch doesn't leave a light ranking panel
 pg.evaluate('document.documentElement.dataset.pokeTheme="dark"')
 assert pg.locator('#rankStrongTeamsCard').is_visible()
 report['checks'].append('página Rank acessível no tema escuro')
 b.close()
(ROOT/'tests/v34_browser_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
