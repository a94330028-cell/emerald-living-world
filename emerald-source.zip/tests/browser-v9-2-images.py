from pathlib import Path
from urllib.parse import urlsplit,unquote
import mimetypes,json,re
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parent.parent/'jogo'
TESTS=Path(__file__).resolve().parent
PNG=(ROOT/'assets/rom_pokemon/pikachu.png').read_bytes()

def route_assets(route):
    parsed=urlsplit(route.request.url)
    if parsed.hostname=='raw.githubusercontent.com':
        # Network fixture: verifies source selection and successful rendering, NOT
        # the copyright-controlled artwork hosted by PokéAPI itself.
        route.fulfill(status=200,content_type='image/png',body=PNG)
        return
    rel=unquote(parsed.path).lstrip('/')
    path=(ROOT/rel).resolve()
    if not path.is_relative_to(ROOT.resolve()) or not path.is_file():
        route.fulfill(status=404,body='missing');return
    route.fulfill(status=200,content_type=mimetypes.guess_type(path.name)[0] or 'application/octet-stream',body=path.read_bytes())

with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 results={}
 for target,viewport in [('android',{'width':390,'height':844}),('desktop',{'width':1280,'height':800})]:
  context=browser.new_context(viewport=viewport,is_mobile=target=='android',has_touch=target=='android',device_scale_factor=1)
  page=context.new_page();errors=[]
  page.on('pageerror',lambda err:errors.append(str(err)))
  page.route('**/*',route_assets)
  html=(ROOT/'quetzal-pokedex.html').read_text(encoding='utf-8')
  html=re.sub(r'<script defer src="js/(pokemon-art|quetzal-pokedex)\.js[^"]*"></script>','',html)
  html=html.replace('<head>','<head><base href="https://preview.game.test/">')
  page.goto('about:blank')
  page.set_content(html)
  page.add_style_tag(path=str(ROOT/'css/quetzal-pokedex.css'))
  page.add_script_tag(path=str(ROOT/'js/pokemon-art.js'))
  page.add_script_tag(path=str(ROOT/'js/quetzal-pokedex.js'))
  page.wait_for_function("document.querySelectorAll('.entryPicture img').length===48")
  assert page.locator('.entryPicture img').count()==48
  page.locator('#search').fill('Pikachu')
  page.wait_for_function("document.querySelectorAll('.entryPicture img').length===1")
  page.wait_for_function("document.querySelector('.entryPicture img').naturalWidth>0")
  local=page.locator('.entryPicture img').get_attribute('src')
  assert '/pikachu.png' in local,local
  page.locator('#search').fill('Tinkaton')
  page.wait_for_function("document.querySelector('.entryPicture img')?.src.includes('/959.png')")
  page.wait_for_function("document.querySelector('.entryPicture img').naturalWidth>0")
  remote=page.locator('.entryPicture img').get_attribute('src')
  page.locator('.entry').first.click()
  assert page.locator('#details img').count()==1
  assert 'Tinkaton' in page.locator('#details h2').inner_text()
  page.locator('#search').fill('');page.locator('#kind').select_option('variant')
  assert '494' in page.locator('#count').inner_text()
  page.locator('.entry').first.click()
  assert 'espécie-base' in page.locator('#details .detailHero small').inner_text()
  page.locator('#kind').select_option('experimental')
  page.locator('.entry').first.click()
  assert 'Sem imagem identificada' in page.locator('#details .detailHero small').inner_text()
  page.locator('#kind').select_option('species');page.locator('#search').fill('Pecharunt')
  assert page.locator('.entry').count()==1
  page.wait_for_function("document.querySelector('.entryPicture img')?.src.includes('/1025.png')")
  assert not errors,errors
  width=page.evaluate('document.documentElement.scrollWidth')
  assert width<=viewport['width']+2,(width,viewport['width'])
  page.locator('#search').fill('Pikachu');page.locator('.entry').first.click()
  page.screenshot(path=str(TESTS/f'v9_2_pokedex_{target}.png'),full_page=True)
  results[target]={'firstPageImages':48,'pikachuLocal':local,'tinkatonRemote':remote,'pecharuntNumbered':1025,'variantsLabeled':True,'experimentalLabeled':True,'horizontalScroll':width>viewport['width']+2,'jsErrors':errors}
  context.close()
 browser.close()
(TESTS/'v9_2_browser_report.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(json.dumps(results,ensure_ascii=False,indent=2))
