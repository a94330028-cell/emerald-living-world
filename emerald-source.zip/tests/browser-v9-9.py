"""V9.9: mobile/desktop routing, badge-only ranking, team at top, separate strengths."""
from pathlib import Path
from urllib.parse import urlparse, unquote
import json,mimetypes
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
base='https://emerald-test.local/jogo/'
html=(ROOT/'jogo/index.html').read_text(encoding='utf-8').replace('<head>',f'<head><base href="{base}">',1)
results={};errors=[]
def asset(route):
 u=urlparse(route.request.url)
 if u.hostname!='emerald-test.local':return route.abort('failed')
 f=(ROOT/unquote(u.path).lstrip('/')).resolve()
 if not f.is_relative_to(ROOT) or not f.is_file():return route.fulfill(status=404,body='missing')
 return route.fulfill(status=200,body=f.read_bytes(),content_type=mimetypes.guess_type(f.name)[0] or 'application/octet-stream')
def fresh(browser,viewport,mobile=False):
 pg=browser.new_page(viewport=viewport,is_mobile=mobile,has_touch=mobile)
 pg.route('**/*',asset)
 pg.on('pageerror',lambda e:errors.append(str(e)))
 pg.on('dialog',lambda d:d.accept())
 pg.evaluate('''() => {const data=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>data.has(k)?data.get(k):null,setItem:(k,v)=>data.set(k,String(v)),removeItem:k=>data.delete(k),clear:()=>data.clear()}})}''')
 print('loading html',viewport,flush=True);pg.set_content(html,wait_until='domcontentloaded',timeout=30000);print('html ready',flush=True)
 pg.wait_for_timeout(1900);print('DIAGNOSTICS',pg.evaluate('''() => ({ready:document.readyState,trainers:window.emeraldTrainers?.length,showPage:typeof window.emeraldShowPage,scripts:document.scripts.length,body:document.body?.className})'''),errors[-10:],flush=True);pg.wait_for_function("window.emeraldTrainers?.length>0&&typeof window.emeraldShowPage==='function'",timeout=15000);print('engine ready',flush=True)
 return pg
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 p=fresh(browser,{'width':390,'height':844},True)
 print('clicking solo',flush=True);p.locator('#landingSolo').click()
 p.wait_for_timeout(350)
 # UI fixture only: a new journey may not have received the starter yet.
 p.evaluate("""() => {const t=window.emeraldMyBot();if(t&&!t.team?.length){t.team=[window.emeraldDiagnostics.createMon('Mudkip',5)]};window.emeraldRefreshMyBot?.()}""")
 solo=p.evaluate('''()=>({mode:document.body.dataset.worldMode,nav:[...document.querySelectorAll('.bottomNav button:not([hidden])[data-page]')].map(b=>b.textContent.trim()),gameActive:!document.getElementById('page-jogador').hidden,firstSection:document.querySelector('#myBotPanel>.personalHero+section')?.className,visibleNav:[...document.querySelectorAll('.bottomNav [data-page]')].filter(x=>getComputedStyle(x).display!=='none').map(x=>x.dataset.page),overflow:document.documentElement.scrollWidth>innerWidth+2})''')
 assert solo['mode']=='player' and solo['gameActive'] and solo['firstSection']=='personalPartyCard',solo
 assert solo['visibleNav']==['jogo','pokedex','ranking'] and not solo['overflow'],solo
 p.screenshot(path=str(ROOT/'tests/v9_9_jogo_android.png'))
 print('clicking Pokemon',flush=True);p.locator('.bottomNav [data-page="pokedex"]').click()
 p.wait_for_timeout(200)
 pokemon=p.evaluate('''()=>({shown:!document.getElementById('page-pokedex').hidden,soloHidden:document.getElementById('page-jogador').hidden,hasTeam:!!document.getElementById('pokemonTeamCards'),label:document.getElementById('pokemonTeamHeading').textContent,overflow:document.documentElement.scrollWidth>innerWidth+2})''')
 assert pokemon['shown'] and pokemon['soloHidden'] and not pokemon['overflow'],pokemon
 p.screenshot(path=str(ROOT/'tests/v9_9_pokemon_android.png'))
 print('clicking Rank',flush=True);p.locator('.bottomNav [data-page="ranking"]').click()
 p.wait_for_timeout(250)
 ranking=p.evaluate('''()=>({shown:!document.getElementById('page-ranking').hidden,title:document.querySelector('#page-ranking h2').textContent,rows:document.querySelectorAll('#ranking .cleanBadgeRow').length,hasForce:document.querySelector('#page-ranking [data-shortcut="forca"]')!==null,overflow:document.documentElement.scrollWidth>innerWidth+2})''')
 assert ranking['shown'] and ranking['rows']>=1 and ranking['hasForce'] and not ranking['overflow'],ranking
 p.screenshot(path=str(ROOT/'tests/v9_9_rank_android.png'))
 print('clicking Forca',flush=True);p.locator('#page-ranking [data-shortcut="forca"]').click()
 p.wait_for_timeout(150)
 strength=p.evaluate('''()=>({shown:!document.getElementById('page-forca').hidden,teams:document.querySelectorAll('#forceStrongTeams .cleanStatRow').length,topSix:document.querySelectorAll('#forceTopSix .cleanStatRow').length,first:document.getElementById('forceStrongestPokemon').textContent.trim().slice(0,150),bottomVisible:[...document.querySelectorAll('.bottomNav [data-page]')].filter(x=>getComputedStyle(x).display!=='none').map(x=>x.dataset.page),overflow:document.documentElement.scrollWidth>innerWidth+2})''')
 assert strength['shown'] and strength['teams']>=1 and 1<=strength['topSix']<=6 and not strength['overflow'],strength
 p.screenshot(path=str(ROOT/'tests/v9_9_forca_android.png'))
 p.locator('#page-forca [data-shortcut="ranking"]').click()
 assert p.evaluate('!document.getElementById("page-ranking").hidden')
 p.locator('.bottomNav [data-page="jogo"]').click()
 assert p.evaluate('!document.getElementById("page-jogador").hidden')
 results['solo']=solo;results['pokemon']=pokemon;results['ranking']=ranking;results['force']=strength
 print('desktop mode',flush=True);d=fresh(browser,{'width':1280,'height':800})
 d.locator('#landingWorld').click()
 d.wait_for_timeout(250)
 watch=d.evaluate('''()=>({mode:document.body.dataset.worldMode,shown:!document.getElementById('gamePage').hidden,nav:[...document.querySelectorAll('.siteNav [data-page]')].map(b=>b.dataset.page),hasMap:!!document.getElementById('liveWorld'),visibleParty:document.getElementById('watchPartyQuick').getBoundingClientRect().height>0,overflow:document.documentElement.scrollWidth>innerWidth+2})''')
 assert watch['mode']=='watch' and watch['shown'] and watch['nav']==['jogo','pokedex','ranking'] and watch['visibleParty'] and not watch['overflow'],watch
 d.screenshot(path=str(ROOT/'tests/v9_9_jogo_desktop.png'))
 d.locator('.siteNav [data-page="pokedex"]').click()
 assert d.evaluate('!document.getElementById("page-pokedex").hidden')
 d.locator('.siteNav [data-page="ranking"]').click()
 assert d.evaluate('!document.getElementById("page-ranking").hidden')
 results['watch']=watch
 assert not errors, errors
 results['errors']=errors
 (ROOT/'tests/v9_9_browser_report.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
 print(json.dumps(results,ensure_ascii=False,indent=2))
 browser.close()
