'use strict';
const {test} = require('node:test');
const assert = require('node:assert/strict');
const {readFileSync} = require('node:fs');
const path = require('node:path');
const html = readFileSync(path.join(__dirname,'..','jogo','index.html'),'utf8');
const css = readFileSync(path.join(__dirname,'..','jogo','css','community-discord-v27.css'),'utf8');
const href = 'href="https://discord.gg/6r9w3kA4sh"';
test('Discord official invite appears in splash, project and footer',()=>{
 assert.ok(html.split(href).length-1 >= 3);
 for(const cls of ['communityDiscordIntro','communityDiscordInline','communityDiscordFooter'])
  assert.match(html, new RegExp(`class="[^"]*${cls}[^"]*" href="https://discord.gg/6r9w3kA4sh"`));
});
test('all Discord links safely open in a new tab',()=>{
 const tags=[...html.matchAll(/<a\s[^>]*href="https:\/\/discord\.gg\/6r9w3kA4sh"[^>]*>/g)].map(x=>x[0]);
 assert.ok(tags.length>=3);
 for(const tag of tags){assert.match(tag,/target="_blank"/);assert.match(tag,/rel="noopener noreferrer"/)}
});
test('Discord button styling includes focus and mobile states',()=>{
 assert.match(css,/\.communityDiscordLink:focus-visible/);
 assert.match(css,/@media\(max-width:760px\)/);
 assert.match(html,/community-discord-v27\.css/);
});
