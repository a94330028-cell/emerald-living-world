"""V9.8: shared real map canvas in landing, solo, and observer without duplication."""
from pathlib import Path
from urllib.parse import urlparse, unquote
import mimetypes, json
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parents[1]
base = 'https://emerald-test.local/jogo/'
html = (ROOT/'jogo/index.html').read_text(encoding='utf-8').replace('<head>',f'<head><base href="{base}">',1)
errors=[]
def asset(route):
    u=urlparse(route.request.url)
    if u.hostname!='emerald-test.local':return route.abort('failed')
    path=(ROOT/unquote(u.path).lstrip('/')).resolve()
    if not path.is_relative_to(ROOT) or not path.is_file():return route.fulfill(status=404, body='missing')
    return route.fulfill(status=200,body=path.read_bytes(),content_type=mimetypes.guess_type(path.name)[0] or 'application/octet-stream')
with sync_playwright() as play:
    browser=play.chromium.launch(headless=True, executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
    page.route('**/*',asset)
    page.on('pageerror',lambda e: errors.append(str(e)))
    page.on('dialog',lambda d:d.accept())
    page.evaluate('''() => {const data=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>data.has(k)?data.get(k):null,setItem:(k,v)=>data.set(k,String(v)),removeItem:k=>data.delete(k),clear:()=>data.clear()}})}''')
    page.set_content(html,wait_until='load',timeout=30000)
    page.wait_for_function('window.emeraldTrainers?.length>=1',timeout=30000)
    print('JS state',page.evaluate('''() => ({hasWorld:typeof window.emeraldLiveDraw,hasMount:typeof window.emeraldPlaceSharedWorld,selected:document.querySelector("#liveWorld")?.parentElement?.id,err:document.getElementById("liveStatus")?.textContent})'''),errors)
    page.wait_for_timeout(300)
    landing=page.evaluate('''() => ({mount:document.getElementById('liveWorld').parentElement.id, numberOfMaps:document.querySelectorAll('#liveWorld').length, scene:document.getElementById('scenePreview').value, previewHidden:!document.querySelector('#personalLanding').hidden, visible:document.querySelector('#liveWorld').getBoundingClientRect().width>100, overflow:document.documentElement.scrollWidth>innerWidth+2})''')
    assert landing['mount']=='landingMapMount' and landing['numberOfMaps']==1 and landing['scene']=='Littleroot' and landing['previewHidden'] and landing['visible'] and not landing['overflow'],landing
    page.screenshot(path=str(ROOT/'tests/v9_8_entrada_android.png'))
    page.locator('#landingSolo').click()
    page.wait_for_timeout(700)
    solo=page.evaluate('''() => ({mode:window.emeraldOptions.gameMode, mount:document.getElementById('liveWorld').parentElement.id, scene:document.getElementById('scenePreview').value, pageVisible:!document.getElementById('page-jogador').hidden, renderFrames:window.emeraldLiveDebug().frames, canvasWidth:document.getElementById('liveWorld').getBoundingClientRect().width, overflow:document.documentElement.scrollWidth>innerWidth+2, team:document.querySelectorAll('#botRoster').length})''')
    assert solo['mode']=='player' and solo['mount']=='myBotMapMount' and solo['scene']=='' and solo['pageVisible'] and solo['canvasWidth']>100 and solo['renderFrames']>0 and solo['team']==1 and not solo['overflow'],solo
    page.locator('#personalWorldCard').scroll_into_view_if_needed()
    page.screenshot(path=str(ROOT/'tests/v9_8_minha_jornada_mapa_android.png'))
    page.locator('#botWorldZoom').click()
    assert page.locator('#personalWorldCard').evaluate('(el)=>el.classList.contains("expanded")')
    # Switch to observer page; same canvas must be back in its original DOM stage.
    page.evaluate('''() => {document.querySelector('.siteNav [data-page="jogo"]').click()}''')
    page.wait_for_timeout(200)
    observer=page.evaluate('''() => ({mount:document.querySelector('#liveWorld').parentElement.className, count:document.querySelectorAll('#liveWorld').length, pageVisible:!document.querySelector('#gamePage').hidden, stage:document.querySelector('.directorStage').contains(document.getElementById('liveWorld'))})''')
    assert observer['stage'] and observer['count']==1 and observer['pageVisible'],observer
    page.evaluate('''() => {document.querySelector('.siteNav [data-page="jogador"]').click()}''')
    page.wait_for_timeout(150)
    again=page.locator('#liveWorld').evaluate('(canvas)=>canvas.parentElement.id')
    assert again=='myBotMapMount',again
    assert not errors,errors
    report={'landing':landing,'solo':solo,'observer':observer,'returnToSoloMount':again,'pageErrors':errors,'externalMapArt':'not verified — network blocked by test'}
    (ROOT/'tests/v9_8_map_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps(report,ensure_ascii=False,indent=2))
    browser.close()
