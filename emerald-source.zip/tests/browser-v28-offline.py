"""Smoke offline sem rede: renderer GBA e portao de admin, Chromium mobile.
Nao substitui teste com mapas reais via internet, Android ou Safari.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json
ROOT=Path(__file__).resolve().parents[1]
report={'browser':'Chromium offline, viewport 390x844','checks':[]}
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 page.set_content('<html><body><canvas id="scenery" width="320" height="220"></canvas></body></html>')
 page.add_script_tag(content=(ROOT/'jogo/game/world/edge-scenery.js').read_text())
 data=page.evaluate('''() => {
  const src=document.createElement('canvas');src.width=src.height=256;
  const a=src.getContext('2d');a.fillStyle='#284fa5';a.fillRect(0,0,256,256);
  a.fillStyle='#b4ea5d';a.fillRect(0,0,16,16);
  const canvas=document.querySelector('#scenery'),c=canvas.getContext('2d');
  const world=[{name:'Route101',x:0,y:0,width:20,height:20}];
  const baseline=JSON.stringify(world);
  const r=EmeraldEdgeScenery.draw(c,{x:-80,y:-90},world,{width:320,height:220,scale:2,official:{ensureChunk:()=>({value:{base:src}})}});
  return {r,rectsUnchanged:JSON.stringify(world)===baseline,colors:[...c.getImageData(40,40,1,1).data],title:EmeraldEdgeScenery.TILE};
 }''')
 assert data['r']['officialTiles']>0 and data['r']['trees']==0 and data['r']['placeholders']==0,data
 assert data['rectsUnchanged'] and data['title']==16
 assert data['colors'][3]==255
 report['checks'].append('copia pixels dos chunks fornecidos sem gerar arvores ficticias, mantendo grade de 16px')
 page.screenshot(path=str(ROOT/'tests/v28_offline_edges.png'))
 page.set_content('''<html><body><div id="adminContent" hidden>Privado</div><div id="adminGate">Verificando...</div>
<select id="days"><option value="7">7</option></select><button id="reload"></button><button id="csv" disabled></button>
<div id="metrics"></div><div id="pages"></div><div id="events"></div><div id="starters"></div><div id="gyms"></div><canvas id="dailyChart"></canvas></body></html>''')
 page.add_script_tag(content=(ROOT/'jogo/js/cloud-config.js').read_text())
 page.add_script_tag(content=(ROOT/'admin/dashboard.js').read_text())
 page.wait_for_function("document.querySelector('#adminGate').textContent.includes('Supabase')",timeout=5000)
 assert page.locator('#adminContent').is_hidden()
 report['checks'].append('painel sem Supabase nao exibe dados privados nem usa permissao local')
 browser.close()
 (ROOT/'tests/v28_browser_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False,indent=2))
