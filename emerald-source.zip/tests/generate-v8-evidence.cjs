'use strict';
/** Reproducible objective logs, not screenshots or claims about real Emerald maps. */
const fs=require('node:fs');const path=require('node:path');
const AI=require('../server/autonomy.cjs'),World=require('../server/world.cjs'),Battle=require('../server/battle.cjs');
const individual=[];
for(const n of [1,2,3]){
 const bot=AI.createBot(n),started=performance.now();
 const gymOpponents=new Map();
 for(let t=0;t<40000&&bot.badges<3;t++){
  if(bot.battle?.type==='gym'){
   const e=bot.battle.enemy;gymOpponents.set(bot.battle.targetId+':'+e.id,{leader:bot.battle.trainerName,species:e.species,level:e.level});
  }
  AI.advance(bot);
 }
 individual.push({bot:bot.id,starter:bot.starter,ticks:bot.ticks,elapsedMs:Math.round(performance.now()-started),
  badges:bot.badges,phase:bot.phase,location:bot.area,visitedAreas:bot.visitedAreas,
  defeatedGymOpponents:[...gymOpponents.values()],
  story:bot.story,team:bot.team.map(m=>({species:m.species,level:m.level,exp:m.exp,ivs:m.ivs,evs:m.evs,nature:m.nature})),
  milestones:bot.milestones.filter(m=>['badge','story','capture','evolution'].includes(m.type)),
  wins:bot.wins,losses:bot.losses,invalidPosition:!World.walkable(bot.area,bot.x,bot.y)});
}
const load=[];for(const count of [20,100]){
 const bots=Array.from({length:count},(_,i)=>AI.createBot(i+1));const t=performance.now();
 for(let turn=0;turn<500;turn++)for(const b of bots)AI.advance(b);
 load.push({botCount:count,ticksEach:500,elapsedMs:Math.round(performance.now()-t),
  captures:bots.filter(b=>b.milestones.some(e=>e.type==='capture')).length,
  invalidPositions:bots.filter(b=>!World.walkable(b.area,b.x,b.y)).map(b=>b.id),
  unexplainedBadges:bots.filter(b=>b.badges!==b.milestones.filter(e=>e.type==='badge').length).map(b=>b.id)});
}
const result={generatedAt:new Date().toISOString(),scope:'V8: 27 handcrafted synthetic online maps, 3 gym chapters; NOT full Pokémon Emerald.',
  maps:Object.keys(World.MAPS).length,species:Object.keys(Battle.SPEC).length,individual,load,
  tests:'npm test, npm run test:browser; independent process restart in tests/multiplayer/restart.test.cjs',
  limitations:['No complete original Hoenn map collision validation','Browser tests use mock HTTP; real Node API tested separately','No complete Gen III moves/abilities/status/doubles','Internet production auth/moderation not implemented']};
fs.writeFileSync(path.join(__dirname,'v8_evidence.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify({maps:result.maps,species:result.species,
 individual:individual.map(x=>({bot:x.bot,starter:x.starter,badges:x.badges,ticks:x.ticks,team:x.team.map(m=>m.species+':'+m.level),opponents:x.defeatedGymOpponents.length})),load},null,2));
if(individual.some(x=>x.badges!==3||x.invalidPosition||x.milestones.filter(m=>m.type==='badge').length!==3)||load.some(x=>x.invalidPositions.length||x.unexplainedBadges.length))process.exitCode=1;
