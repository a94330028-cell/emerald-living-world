"""Browser integration: real V9.3 offline engine and National species data;
network blocked; NOT an end-to-end proof for every species or Quetzal encounter tables."""
from pathlib import Path
from urllib.parse import urlparse,unquote
import json,mimetypes
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
base='https://emerald-test.local/jogo/'
html=(ROOT/'jogo/index.html').read_text(encoding='utf-8').replace('<head>',f'<head><base href="{base}">',1)
errs=[]
def asset(route):
 u=urlparse(route.request.url)
 if u.hostname!='emerald-test.local':return route.abort('failed')
 path=(ROOT/unquote(u.path).lstrip('/')).resolve()
 if not path.is_relative_to(ROOT) or not path.is_file():return route.fulfill(status=404,body='missing')
 return route.fulfill(status=200,body=path.read_bytes(),content_type=mimetypes.guess_type(path.name)[0] or 'application/octet-stream')
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 page.on('pageerror',lambda e:errs.append(str(e)))
 page.on('dialog',lambda d:d.accept())
 page.route('**/*',asset)
 page.evaluate("""() => {const values=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>values.get(k)||null,setItem:(k,v)=>values.set(k,String(v)),removeItem:k=>values.delete(k),clear:()=>values.clear()}})}""")
 page.set_content(html,wait_until='load',timeout=30000)
 page.wait_for_function('window.emeraldNationalSimulation?.count===1025')
 result=page.evaluate('''() => {
  window.emeraldOptions.speed=0;
  const api=window.emeraldNationalSimulation,sim=window.emeraldDiagnostics;
  const stats=window.emeraldSpecies;
  const t=window.emeraldTrainers[0];
  const original={monCount:t.team.length,stage:t.stage};
  const mon=sim.createMon('Sprigatito',10);
  const at5=window.emeraldProgression.levelStats('Sprigatito',5,mon.ivs,mon.evs,mon.nature);
  const at20=window.emeraldProgression.levelStats('Sprigatito',20,mon.ivs,mon.evs,mon.nature);
  const entry=api.choose({location:'Petalburg Woods',habitat:'forest',badges:0},()=>0.2);
  t.stage=18;t.starter='Mudkip';t.location='Petalburg Woods';t.team=[sim.createMon('Mudkip',14)];t.dex=['Mudkip'];t.bag.Pokeball=70;t.battle=null;t.healing=null;t.champion=false;
  // A legitimate tall-grass tile fixture, not official Emerald map data.
  window.emeraldOfficialWorld={resolve:x=>x,cache:{get:()=>({value:{name:'test',width:25,height:25,meta:{map_type:'MAP_TYPE_ROUTE'}}})},infoAt:()=>({behavior:2}),walkable:()=>true};
  let didStart=false,rounds=0,attempts=0,caught=false;
  while(!caught&&attempts++<12){
   t.team[0].hp=t.team[0].maxHp;
   didStart=sim.startBattle(t,{species:'Sprigatito',level:5},'wild')||didStart;
   let actions=0;while(t.battle&&actions++<65){sim.battleTurn(t);rounds++;}
   caught=t.team.some(m=>m.species==='Sprigatito')||(t.pc||[]).some(m=>m.species==='Sprigatito');
  }
  const encounterEvents=(t.events||[]).filter(e=>e.kind==='wild'||e.kind==='capture').slice(0,5).map(e=>e.msg);
  return {registered:Object.keys(stats).length,species:api.count,variants:api.records.filter(e=>e.kind==='variant').length,hasTinkaton:!!stats.Tinkaton,hasPecharunt:!!stats.Pecharunt,exampleNational:entry?.key,statGrowth:at20.maxHp>at5.maxHp&&at20.atk>at5.atk,battleStarted:didStart,rounds,attempts,caught,team:t.team.map(m=>m.species),captureEvents:encounterEvents,options:{nationalEncounters:window.emeraldOptions.nationalEncounters,nationalForms:window.emeraldOptions.nationalForms}};
 }''')
 print(json.dumps(result,ensure_ascii=False,indent=2))
 assert result['registered']>=1528 and result['species']==1025 and result['variants']==494
 assert result['hasTinkaton'] and result['hasPecharunt'] and result['statGrowth']
 assert result['battleStarted'] and result['rounds']<780 and result['caught']
 assert result['options']['nationalEncounters']==True
 assert not errs,errs
 if page.locator('#worldSetupDialog').is_visible(): page.locator('#setupKeep').click()
 page.screenshot(path=str(ROOT/'tests/v9_3_ai_android.png'),full_page=False)
 browser.close()
 result['jsErrors']=errs
 (ROOT/'tests/v9_3_national_browser_report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
