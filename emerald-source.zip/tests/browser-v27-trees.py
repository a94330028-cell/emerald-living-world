"""Android browser smoke for seamless sector composition, with official-style map fixture.
Runs fully offline; DOES NOT claim to verify actual downloaded Emerald geometry.
"""
from pathlib import Path
from urllib.parse import urlparse,unquote
import json,mimetypes
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
BASE='https://v27-test.local/jogo/'
report={'browser':'Chromium Android emulation, 390x844','tests':[],'errors':[]}
def fulfill(route):
 u=urlparse(route.request.url)
 if u.hostname!='v27-test.local':return route.abort('failed')
 if u.path.startswith('/api/'):return route.fulfill(status=200,body='{}',content_type='application/json')
 p=(ROOT/unquote(u.path).lstrip('/')).resolve()
 if not p.is_relative_to(ROOT) or not p.is_file():return route.fulfill(status=404,body='')
 return route.fulfill(status=200,body=p.read_bytes(),content_type=mimetypes.guess_type(p.name)[0] or 'application/octet-stream')
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 page.route('**/*',fulfill)
 page.on('pageerror',lambda e:report['errors'].append(str(e)))
 page.on('dialog',lambda d:d.accept())
 page.evaluate("""() => {const m=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear()}})}""")
 html=(ROOT/'jogo/index.html').read_text().replace('<head>',f'<head><base href="{BASE}">',1)
 page.set_content(html,wait_until='domcontentloaded',timeout=30000)
 page.wait_for_function('window.emeraldTrainers?.length>0&&window.emeraldLiveDraw&&window.EmeraldContinuousHoenn',timeout=25000)
 report['tests'].append('20 trainer sprites intact and continuous module loads on Android')
 page.locator('#landingSolo').click()
 page.wait_for_function('document.getElementById("page-jogador")?.hidden===false',timeout=20000)
 fixture=page.evaluate('''() => {
  const off=window.emeraldOfficialWorld,W=20,H=20;
  function make(name,edge){
   const block=new DataView(new ArrayBuffer(W*H*2));
   return {name,width:W,height:H,meta:{map_type:'MAP_TYPE_TOWN',connections:edge,object_events:[],warp_events:[]},
    blocks:block,primaryAttrs:new DataView(new ArrayBuffer(2048)),secondaryAttrs:new DataView(new ArrayBuffer(2048)),
    layout:{primary_tileset:'gTileset_General'}};
  }
  off.cache.set('LittlerootTown',{value:make('LittlerootTown',[{direction:'up',offset:0,map:'Route101'}])});
  off.cache.set('Route101',{value:make('Route101',[{direction:'down',offset:0,map:'LittlerootTown'}])});
  const colors={LittlerootTown:'#38ac62',Route101:'#438bd0'};
  window.__v26Chunks=[];
  off.ensureChunk=(name,cx,cy)=>{
   window.__v26Chunks.push(name+':'+cx+':'+cy);
   const m=off.cache.get(name)?.value;
   if(!m)return {value:null};
   const base=document.createElement('canvas');
   base.width=Math.min(16,m.width-cx*16)*16;base.height=Math.min(16,m.height-cy*16)*16;
   const c=base.getContext('2d');c.fillStyle=colors[name];c.fillRect(0,0,base.width,base.height);
   return {value:{base,foreground:null,width:base.width,height:base.height}};
  };
  const settings=window.emeraldOptions;
  const st=window.emeraldExport();
  const leader=settings.gameMode==='player'?st.trainers.find(t=>t.isUserBot):st.trainers[st.selected];
  const matching=window.emeraldTrainers.find(t=>t.id===leader?.id)||window.emeraldTrainers[0];
  matching.officialMap='LittlerootTown';matching.walkMap='official:LittlerootTown';
  matching.walkX=0;matching.walkY=10;matching.walkPrevX=0;matching.walkPrevY=10;
  matching.walkStepSeq=1;matching.officialSpawn=false;
  window.emeraldLiveDraw();
  return {debug:window.emeraldLiveDebug(),requestedChunks:window.__v26Chunks,id:leader?.id,match:matching.id};
 }''')
 report['fixture']=fixture
 assert page.evaluate('!!window.EmeraldEdgeScenery'), 'Scenery module did not load'
 page.locator('#liveWorld').screenshot(path=str(ROOT/'tests/v27_tree_edges_android_mock.png'))
 assert fixture['debug']['continuous']['located']>=2,fixture
 assert fixture['debug']['continuous']['chunkTiles']==16
 assert 'LittlerootTown' in fixture['debug']['officialMap']
 assert any(n.startswith('LittlerootTown:') for n in fixture['requestedChunks']),fixture
 assert any(n.startswith('Route101:') for n in fixture['requestedChunks']),fixture
 report['tests'].append('adjacent synthetic outdoor maps share one canvas without screen transition')
 from PIL import Image
 im=Image.open(ROOT/'tests/v27_tree_edges_android_mock.png').convert('RGB')
 # The canvas is scaled by CSS on mobile; inspect the actual canvas's left edge pixels instead.
 # Pixel source is a browser screenshot rather than canvas.getImageData(),
 # since official trainer sprites can taint canvas when mock origins differ.
 sample=im.crop((2,2,min(80,im.width),max(3,im.height-4)))
 uniqueColors=len(sample.getcolors(maxcolors=100000) or [])
 scenery={'uniqueColors':uniqueColors,'mode':page.evaluate("window.EmeraldEdgeScenery.biomeForName('LittlerootTown')")}
 report['scenery']=scenery
 assert uniqueColors>15,scenery
 report['tests'].append('landscape fills world void with varied tree sprites at map edge')
 biomeAudit=page.evaluate('''() => {
  const output={};
  for(const [name,key] of [['Route124','sea'],['SootopolisCity','rocky'],['Route101','forest']]){
   const c=document.createElement('canvas');c.width=640;c.height=416;
   const ctx=c.getContext('2d');
   const stats=window.EmeraldEdgeScenery.draw(ctx,{x:-152,y:64,width:320,height:208},
      [{name,x:0,y:0,width:20,height:20}],{width:640,height:416,scale:2});
   const rgba=[...ctx.getImageData(12,10,1,1).data];
   output[key]={...stats,rgba};
  }
  return output;
 }''')
 assert biomeAudit['forest']['trees']>0,biomeAudit
 assert biomeAudit['sea']['sea']>0,biomeAudit
 assert biomeAudit['rocky']['rocks']>0,biomeAudit
 assert biomeAudit['sea']['rgba'][2]>biomeAudit['sea']['rgba'][0],biomeAudit
 report['biomeAudit']=biomeAudit
 report['tests'].append('sea gets decorative waves, Sootopolis crater gets rocky cliffs')
 report['tests'].append('no load all: 16x16 chunks + camera-local images')
 report['tests'].append('existing solo setup and player interface still work')
 perf=page.evaluate("""() => {
  const st=window.emeraldExport(),list=window.emeraldTrainers;
  const originalCount=list.length,previousMode=st.settings.gameMode;
  const sample=list[0];
  for(let i=originalCount;i<100;i++){
   list.push({...sample,id:i,name:'Teste '+i,officialMap:i%2?'Route101':'LittlerootTown',
    walkMap:i%2?'official:Route101':'official:LittlerootTown',walkX:i%16,walkY:18,
    team:sample.team?.slice()||[],isUserBot:false,battle:null});
  }
  st.settings.gameMode='simulator';
  const t0=performance.now();
  for(let n=0;n<12;n++)window.emeraldLiveDraw();
  const ms=performance.now()-t0;
  st.settings.gameMode=previousMode;list.length=originalCount;
  return {bots:100,frames:12,totalMs:+ms.toFixed(2),avgFrameMs:+(ms/12).toFixed(2)};
 }""")
 report['performanceSynthetic']=perf
 assert perf['bots']==100 and perf['frames']==12 and perf['avgFrameMs']<1500,perf
 report['tests'].append('100 simulated trainer records rendered with camera culling; time recorded')
 report['horizontalOverflow']=page.evaluate('document.documentElement.scrollWidth>window.innerWidth+3')
 assert not report['horizontalOverflow']
 assert not report['errors'],report['errors']
 (ROOT/'tests/v27_tree_edges_browser_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False,indent=2))
 browser.close()
