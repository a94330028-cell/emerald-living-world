# 🌿 Emerald Living World 3.0 RC6 — Gen III & Frontier Pass LAB

## Correções realmente implementadas

- Golpes de uso próprio **Recover, Swords Dance, Calm Mind, Wish, Rain Dance, Sunny Day, Sandstorm, Hail, Howl, Protect e Follow Me** não são bloqueados pelo Protect do adversário nem dependem da evasão dele.
- Em Double, **Recover, Swords Dance, Calm Mind, Wish e Howl** agora selecionam o próprio Pokémon, não um adversário.
- O usuário de **Explosion e Selfdestruct** desmaia mesmo que o alvo se proteja; Explosion também foi corrigido contra Wonder Guard.
- **Wish** de um segundo adversário em Double é atribuído ao lado correto do campo.
- Adicionado **Frontier Pass LAB** com progresso individual das sete instalações e pontuação demonstrativa até 1.000. Os pontos não são ranking mundial, não concedem BP oficial e não representam Símbolos oficiais.
- O cálculo da pontuação LAB mantém ouro substituindo prata, usa o melhor registro entre Level 50 e Open, e considera **40 vitórias** para a meta de 10 torneios do Dome.
- A Frontier ganhou barras de progresso no celular, sem alterar as tabelas de Pokémon.

## Preservação

Os seis arquivos cobertos pelo manifesto SHA-256, incluindo catálogo nacional, habitats de encontros dos bots, Arena e espécies, permaneceram intactos.

## Validação local

**265 testes Node aprovados, nenhum reprovado.** `npm run audit:release` confirmou os seis hashes protegidos.

## Ainda não finalizado

A Battle Frontier é uma adaptação. Continuam pendentes a reprodução integral da ROM (golpes, scripts, regras das sete instalações), concessão legítima de símbolos oficiais, eventos completos da história e homologação pública da autenticação e dos dispositivos móveis.

O ZIP **não publica** alterações na hospedagem, no Supabase ou no site online.
