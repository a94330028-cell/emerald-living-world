# 🌿 EMERALD LIVING WORLD V9.5 — CORREÇÕES DE NAVEGAÇÃO E CAPTURA

- ✅ Política individual de localização para **1.025 espécies** do catálogo Quetzal (localizações adaptadas, não oficiais).
- ✅ Encontros com limites de rota, habitat e progresso; áreas urbanas continuam seguras.
- ✅ Iniciais das 9 gerações e sistemas anteriores preservados.
- ✅ Sistema central de sprite Brendan/May e debug de colisões, caminhos e hitboxes preservados e ampliados ao online.
- ✅ Caminhos de IAs reaproveitados em memória e reconstruídos ao mudar destino, mapa ou permissões.
- ✅ Route103 agora conectada a Oldale nos mapas adaptados do servidor.
- ✅ NPCs fixos de história usados como obstáculos nas áreas de teste.
- ✅ Interior compartilhado retorna à origem; novas verificações automáticas das portas.
- ✅ API `/api/habitats/:dex` e `/api/encounters`, além de consulta de locais na Pokédex.
- ✅ 89 testes automatizados e 61 transições auditadas, sem falhas na rodada final.

**Ainda pendente:** ROM com todas as camadas, sprites e NPCs oficiais; Hoenn inteira; conflito físico entre dezenas de bots no mesmo tile; campanha online além da terceira insígnia; golpes/evoluções/itens integrais do Quetzal; autenticação de lançamento público.

**Publicação:** ZIP completo pronto para instalação, site publicado não alterado.
