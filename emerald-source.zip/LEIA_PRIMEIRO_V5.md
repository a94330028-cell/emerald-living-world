# 🌿 Emerald Living World V5 — Fase 1: estabilidade

**Esta entrega é uma atualização real e incremental da V4, NÃO é a edição MMO completa.**
O escopo foi deliberadamente limitado para não instalar multiplayer, contas ou
funcionalidades amplas sobre uma base que ainda requer testes de mapas reais.

## Como publicar no celular

1. Faça backup do seu save pela tela de exportação do jogo (os saves são locais ao domínio).
2. Envie **todo o conteúdo extraído deste ZIP** para a sua hospedagem, mantendo
   `index.html` na raiz e a pasta `jogo/`. Não publique apenas o `index.html`.
3. Abra `/jogo/#jogo`; use `⚙️ Mundo` para configurar ou continuar.
4. Atualizações na mesma origem normalmente reutilizam o save. **Trocar de domínio não transfere
   automaticamente os dados locais**; importe o arquivo salvo no novo endereço.
5. Se o GitHub não carregar os mapas originais, o jogo apresenta **mapas adaptados**,
   identificados visualmente. Eles **não** reproduzem os interiores e puzzles da ROM.

## Arquivos alterados ou criados

- `jogo/game/navigation/core.js` — módulo independente de colisão, movimento,
  busca de caminho e pouso no terreno.
- `jogo/js/official-runtime.js` — usa o núcleo testado; verifica transições por
  porta, índice de warp recíproco, faixa de conexão e destino caminhável.
- `jogo/client/animation/trainer-frames.js` — seleciona animações sem trocar a
  orientação quando o personagem fica parado.
- `jogo/js/world.js` — passa a usar seleção de quadros separada do renderizador.
- `jogo/rom/validation/gba-header.js` — análise **local** da assinatura e do
  checksum do cabeçalho GBA, identifica arquivos Emerald candidatos.
- `jogo/js/engine.js` — mensagem de validação do `.gba` sem afirmar que extrai gráficos.
- `jogo/index.html`, `index.html` — carrega os módulos e atualiza as versões do cache.
- `tests/` — testes de navegação, animação, cabeçalho e navegador, capturas e relatório.

## Testes executados nesta entrega

| Teste | Resultado | Limitação |
|---|---|---|
| Testes unitários (`node --test ...`) | 15/15 aprovados | Malhas sintéticas e mapas adaptados |
| Transições por portas nos oito ginásios | 8 mapas sem porta inválida no teste | Somente modo adaptado offline |
| Simulação real de código no Chromium | 20/20 bots movimentaram-se em 720 turnos | Não valida toda a história nem a navegação real da ROM |
| Verificação de posições | Nenhuma coordenada fora dos limites nos mapas carregados | Não prova que todos os mapas são acessíveis |
| Save/reload | Contagem, turnos e insígnias preservados | Armazenamento local simulado no navegador de teste |
| Interface mobile 390×844 | Sem erro de JavaScript ou overflow horizontal no teste | Emulação de viewport, não um Android físico |
| ROM local | Cabeçalho válido/ausente/alterado testados | Não extrai gráficos e não executa ROM |

Testes automatizados incluídos: `node --test tests/maps/*.test.cjs tests/animations/*.test.cjs tests/rom-header.test.cjs`

Teste visual (requer Python com Playwright e Chromium): `python tests/browser-smoke.py`.
Relatório: `tests/browser_report.json`. Imagens: `tests/smoke_desktop.png` e
`tests/smoke_android.png`. O teste deliberadamente bloqueia a rede do GitHub.

## O que ainda não está completo

- As colisões oficiais de **todas** as cidades, casas, cavernas e puzzles não foram
  verificadas. NPCs móveis, scripts, elevadores, bicicletas e HMs permanecem adaptações.
- A aventura humana ainda é uma campanha por eventos, sem movimentação manual de mundo aberto.
- O motor de Pokémon conserva limitações da V4 (catálogo parcial, movimentos,
  habilidades, duplas e Battle Frontier não integrais).
- Bots persistem em `localStorage` e não continuam no servidor com a página fechada.
- Não existe backend MMO, contas, canais, chat em tempo real ou sincronização autoritativa.
- Leitura de ROM atualmente verifica **somente o cabeçalho**; não extrai recursos.
- Não há testes em dispositivos Android reais nem campanha completa validada em mapas oficiais.

## Próximas fases (dependem de testes da fase anterior)

1. **Fase 1, restante:** testes topológicos de mapas reais por cidade, caminho de
   entrada/saída para cada interior, puzzles e ocupação de NPCs, sem teleportes.
2. **Fase 2, gráficos:** Atlas licenciados e renderer/câmera isolados, controles
   manuais mobile e snapshots de mapa reproduzíveis.
3. **Fase 3, regras Pokémon:** dataset completo, testes por mecânica Gen III,
   captura, evolução e batalha dupla com motor comum a humano e bot.
4. **Fase 4, IA:** objetivos em grafo de eventos, busca de rotas, inventário,
   diagnóstico de derrota e campanha completa com teste de longa duração.
5. **Fase 5, MMO:** Node.js + TypeScript e WebSocket no backend autoritativo,
   PostgreSQL para progresso, contas autenticadas, canais independentes,
   reconexão, proteção de inventário e simulação persistente (hospedagem não estática).
6. **Fase 6, ROM opcional:** leitura local de versões suportadas, extração
   validada, licenças apropriadas e fallback independente sem upload da ROM.
7. **Fase 7, acabamento:** testes Android físicos, carga de servidor, correções
   de acessibilidade, responsividade, áudio autorizado e performance.

### Aviso
O pacote é para **publicação manual**. Nenhuma hospedagem foi modificada
nesta etapa. Fonte anterior preservada e saves V4 não foram alterados no disco.
