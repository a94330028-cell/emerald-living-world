# 🌿 Emerald Living World V9.10 — Mundo e páginas restaurados

## Atualização sobre a V9.9

O menu inferior continua com apenas **Jogo, Pokémon e Rank**. O botão **☰ Outras páginas** no cabeçalho abre um menu secundário agrupado por assunto.

### Páginas restauradas no menu secundário

- Recuperação e saves
- Histórico de eventos
- Campanha
- Mapa de Hoenn
- Hall da Fama
- Corrida Top 10
- Rankings de força
- Treinadores
- Torneios
- Desafios
- Battle Frontier
- Configurações
- Editor de regras
- Créditos

O menu principal continua tendo exatamente três destinos. Os links para as páginas anteriores não foram excluídos; elas apenas deixaram de aparecer todas na barra principal.

### Mapas

Os arquivos oficiais da região continuam sendo buscados pelo visualizador, quando há acesso aos arquivos gráficos compatíveis. Se eles não forem encontrados, a V9.10 usa um **mapa adaptado redesenhado**, com casas, flores, árvores, caminhos e interiores desenhados no canvas. Esse cenário é **original do projeto e não corresponde a um mapa extraído da ROM**.

As estruturas do modo alternativo usam a mesma grade de colisão usada pela navegação. Os pontos de entrada não podem ser pintados dentro de paredes, e as portas do fallback recebem destinos verificáveis. O projeto continua com limite conhecido: o modo adaptado não implementa todos os scripts, eventos, portas e interiores do Emerald original.

### Recuperação e saves

A nova página mostra a equipe do treinador e seus HPs. Permite exportar e importar o progresso em JSON com confirmação antes de substituir o save local. Ela **não oferece cura gratuita**: a recuperação de HP permanece ligada aos Centros Pokémon no motor existente.

### Testes

- `npm test` (Node.js) — **97/97 na última execução**.
- Houve **uma falha intermitente em teste anterior de experiência da IA**, que passou na repetição. Esse teste não é apresentado como garantia de estabilidade total.
- `python tests/browser-v9-10.py` — teste no Chromium com largura Android e desktop, sem erros de JS observados.
- 20 treinadores caminharam em 650 turnos acelerados de teste; nenhum foi encontrado ocupando tile bloqueado dos mapas carregados.
- Validada a navegação entre Jogo, Créditos, Recuperação, Histórico, volta ao jogo e o menu secundário.
- Os testes no navegador usaram cenários adaptados e fontes externas bloqueadas. Não comprovam a fidelidade de toda a região original de Hoenn.

### Instalação

O pacote contém **`index.html` na raiz**, a pasta `jogo/` e o servidor `server/`. Publique a estrutura toda preservando os caminhos e os arquivos, sem mover apenas o `index.html` sozinho. A versão local/simulação funciona em hospedagem estática; o modo online necessita executar o backend Node.js.

Faça backup do progresso antes de atualizar. A V9.10 **não remove nem redefine os saves por conta própria**.

Para testar localmente:

```bash
npm test
npm start
```

A ROM Pokémon Quetzal não está incluída no pacote; seus recursos só devem ser usados dentro das permissões cabíveis.
