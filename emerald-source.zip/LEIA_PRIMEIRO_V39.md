# 🌿 Emerald Living World 3.9 — Integração incremental Gen III, bots e Frontier

## Leia antes de publicar

Esta versão parte do ZIP 3.8 e mantém a campanha existente, a Arena Competitiva, o conteúdo de capturas nacionais (incluindo Pokémon de gerações posteriores) e os arquivos do Supabase. A atualização do motor de batalhas é **parcial** e não pretende que os 54 estudos estejam integralmente implementados.

**Garantia de preservação das capturas dos bots:** os arquivos `jogo/game/pokemon/national-pools.js`, `national-habitats.js`, `national-catalog.js` e `jogo/data/quetzal-catalog.json` não foram alterados, comparados byte a byte com o ZIP anterior. O comportamento de captura e os encontros fixos seguem disponíveis. A modificação no módulo de IA limita-se à seleção de golpes com PP e ao fallback Struggle.

## Mudanças efetivas

- `server/gen3-mechanics.cjs`: mecânicas iniciais de PP, ações ordenadas por prioridade e velocidade, condições e impedimentos básicos, itens/berries, habilidades pontuais, clima e efeitos residuais. Não é um emulador perfeito de Emerald e exige validação de exceções.
- `server/battle.cjs`: integração incremental dessas regras nas batalhas do servidor, com migração conservadora dos Pokémon de saves existentes e distinção `gen3_emerald` / `gen3_extended` para preservar encontros de espécies modernas.
- `server/gen3-doubles.cjs`: auxiliares para selecionar alvos, Helping Hand, Follow Me e propriedade do Pokémon em Multi; ainda não existe batalha Double/Multi jogável integrada à interface.
- `server/frontier.cjs`: catálogo das sete instalações e **protótipo de Battle Tower Single** por API; oponentes gerados pelo servidor, escolha de três Pokémon, desafios consecutivos e registro de vitórias/derrotas/BP. Os demais seis edifícios são somente metadados e regras iniciais, não arenas prontas. Os Frontier Brains e seus símbolos não são concedidos sem batalhas autênticas.
- `server/app.cjs`: alvo de até 100 bots ativos em lotes, mais endpoints autenticados de estado e desafio Frontier.
- `jogo/js/engine.js`: prioridade e resolução residual básica ajustadas no simulador local. A campanha local permanece um motor próprio, ainda parcialmente simplificado.
- `server/autonomy.cjs`: escolha de golpes considerando PP disponível; não altera habitats, lista de Pokémon disponíveis nem taxas de captura.
- `tests/multiplayer/gen3-integration-v39.test.cjs`: verificações de regressão dos encontros, capturas e componentes novos.

## O que NÃO foi concluído

1. O motor Gen III não cobre todas as exceções históricas e **não** possui fidelidade bit a bit validada contra a ROM de Emerald.
2. As batalhas Double/Multi não foram conectadas integralmente à interface ou ao resolvedor principal.
3. A Battle Tower é experimental, via servidor/API e com desbloqueio pós-Liga; a campanha online existente não oferece ainda o caminho completo até a Liga. Não há Frontier Brain, 7 instalações completas, símbolos autênticos ou Frontier Pass completo.
4. A campanha completa de Hoenn com os oito ginásios, todos os eventos/colisões/rotas e 100 bots com progresso fiel ainda não está concluída.
5. Supabase e PvP não foram migrados nem publicados; é necessário configurar backend e hospedagem compatíveis para usar funções online. Upload de um ZIP em site estático, sozinho, não inicia o servidor Node.
6. Não houve publicação automática no site. As versões do jogo online e do ZIP podem divergir.

## Como executar localmente

Requer Node.js 20+.

```sh
npm test
npm start
```

Para o modo offline no navegador, abra `jogo/index.html` por um servidor estático local. Para as APIs e bots do servidor, `npm start` inicia o backend Node. Confirme a configuração segura de autenticação e variáveis de ambiente antes de disponibilizar uma instância pública.

API de teste da Frontier (servidor; exige sessão e progresso compatíveis):

- `GET /api/frontier`
- `POST /api/frontier/start`
- `POST /api/frontier/next`
- `POST /api/frontier/retire`

## Validação

- `npm test` — **200 testes aprovados**, nenhum reprovado, nesta versão de trabalho antes do empacotamento.
- `node --check` dos módulos novos e do motor offline — aprovado.
- Arquivos dos catálogos nacionais e habitats comparados byte a byte com o ZIP 3.8 — idênticos.
- Teste visual amplo do navegador não foi concluído neste ambiente (excedeu o tempo de execução); não consta como aprovado.

## Próximas implementações recomendadas

Concluir e certificar o motor Gen III com casos de referência; terminar Double/Multi integradas; adicionar interface de acesso e progressão completa da Battle Tower; depois implementar Dome, Palace, Arena, Factory, Pike e Pyramid com suas mecânicas reais. Só então emitir símbolos e pontuações mundiais definitivas. Manter permanentemente os testes de regressão de capturas nacionais.
