# 🌿 Emerald Living World V9.15 — Passos laterais e velocidade

Base: V9.14 (20 personagens com quadros 32×48 e NPCs desafiantes). A V9.15 preserva os arquivos e recursos anteriores.

## O que mudou

**Caminhada lateral:** antes, o renderizador mostrava basicamente um único quadro de passo por deslocamento. Agora, em cada passo confirmado, alterna **os dois quadros de caminhada**, primeiro numa metade do tile e depois na outra. O começo da caminhada alterna os pés de um passo para o seguinte. Ao parar, o quadro parado da última direção é preservado. Isso usa os **mesmos sprites 32×48** fornecidos e não inventa uma nova imagem ou substitui as folhas originais.

**Seleção de velocidade:** agora é possível escolher diretamente **1×, 3×, 10×, 20×, 40×, 60×, 80×, 100×, 150× e 200×**.
- No modo pessoal, use **Minha Jornada → Velocidade da simulação**, acima da equipe.
- No modo de observação, use **⚡ Velocidade** na transmissão.
- A seleção é guardada nas configurações locais e sincronizada entre os dois modos.
- Velocidade ajusta o número de eventos/decisões simulados por segundo, **não** o atributo Speed dos Pokémon, a velocidade de ataque, a duração visual de cada passo, nem a taxa de ticks do servidor Node.js multiplayer.
- 100× e 200× são **velocidades solicitadas**. Em um Android ou com 100 bots, o ritmo efetivo poderá ser menor; o jogo limita o trabalho de cada frame para manter o toque e a interface responsivos. Comece em 10× ou 20× se houver lentidão.

## Testes realizados

- `npm test`: **108/108 aprovados** na rodada final. Houve uma falha intermitente de progressão/evolução de IA em uma rodada anterior, mas o teste passou isoladamente e na rodada final; **não é declarado como definitivamente resolvido**.
- `python tests/browser-v9-15.py`: teste Chromium em resolução Android (390×844), opções 100× e 200× salvas, modos sincronizados, frames esquerda/direita alternando, sem erros JS observados nem rolagem horizontal. Os mapas originais externos não foram verificados nessa execução.
- `tests/v9_15_side_frames_audit.json`: análise dos **20 sprites 32×48**; todos possuem quadros de pernas distintos para esquerda e direita. Isso comprova a presença dos quadros, **não** uma avaliação visual completa da animação em todos os aparelhos.

## Arquivos principais alterados

- `jogo/client/animation/trainer-frames.js`
- `jogo/game/simulation/speed.js` (novo)
- `jogo/js/engine.js`
- `jogo/js/refresh.js`
- `jogo/js/my-bot.js`
- `jogo/index.html`, `jogo/online.html`, `jogo/mapas-oficiais.html`
- `tests/simulation/speed.test.cjs` e `tests/browser-v9-15.py` (novos)

## Publicação

O ZIP contém o site estático e os arquivos do servidor. Publicação na hospedagem **não foi feita**. Faça backup do save antes de atualizar. O multiplayer do servidor Node.js requer hospedagem adequada, e a aceleração de 200× aqui não controla automaticamente seu servidor remoto.
