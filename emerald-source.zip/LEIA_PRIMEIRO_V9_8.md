# 🌿 Emerald Living World V9.8 — Mundo da V9.6 restaurado na Jornada Solo

## O que foi restaurado
- A tela inicial agora utiliza o **próprio canvas do mapa animado** da versão V9.6 em vez da imagem estática do mapa de recuperação presente na V9.7.
- A página **Minha Jornada** agora exibe o **mesmo canvas oficial** dentro do painel pessoal, antes das informações de equipe, rival e batalha.
- Ao escolher observar IAs, o mesmo canvas é devolvido à página **Jogo**. Não há um segundo motor gráfico nem um mapa inventado para a tela solo.
- Quando o jogador entra no modo solo, a câmera deixa a prévia de Littleroot e acompanha o treinador real. O botão **Ver no mapa** leva ao mapa da própria jornada; **Ampliar** expande o painel.
- Quando o modo solo está ativo, os outros bots permanecem ocultos/pausados como na V9.7, sem apagar seus saves.

## Preservado da V9.7
- Escolha entre os 27 iniciais (nove gerações).
- Treinar ou enfrentar rivais importantes.
- Escolha manual de golpes, itens e trocas disponíveis; opção de golpes automáticos.
- Equipe, experiência, capturas, evolução, rankings e simulação com até 100 IAs.
- Sprites centralizados de Brendan e May da V9.6.

## Mapas oficiais vs. mapas adaptados
O motor da V9.6 usa os dados de `pret/pokeemerald` no navegador para renderizar as camadas de arte, com tilesets, árvores, casas e outras decorações. Os recursos gráficos são **buscados sob demanda**, sem estarem todos embutidos neste ZIP.

Se os arquivos oficiais não carregarem (sem internet, GitHub indisponível, navegador bloqueando as requisições), o motor **mostra explicitamente um mapa adaptado**, que é menos decorado. Esta atualização corrige o desaparecimento do mapa **na interface solo**, mas não significa que todos os arquivos gráficos originais tenham sido baixados ou estejam disponíveis offline.

## Instalação
1. Faça um backup de seu save atual.
2. Extraia o ZIP completo, preservando `index.html`, `jogo/` e as demais pastas.
3. Abra `index.html` em um servidor local ou publique os arquivos completos na hospedagem.
4. Na tela inicial, confira o mapa animado, escolha seu inicial e clique **Jogar só com meu bot**.
5. O painel **Explorando Hoenn** aparece imediatamente acima do progresso do treinador e das batalhas.
6. Para usar o servidor MMO experimental, é necessário Node.js 20+; em hospedagem estática, apenas a simulação local funciona.

## Testes executados nesta versão
- `npm test`: **92/92** aprovações na execução registrada em `tests/v9_8_node.log`.
- `python tests/browser-v9-8-map.py`: mapa único movido entre entrada, solo e observação sem duplicação, sem rolagem horizontal no teste Android, sem erros de JavaScript observados.
- `python tests/browser-v9-7.py`: decisões de rival e golpes manuais preservados.
- Os testes de navegador usam mapas de recuperação e bloqueiam as requisições externas. A **arte oficial completa da V9.6 não foi testada nesse navegador isolado**, então não há garantia de que todos os mapas estarão decorados na ausência de conexão.

## Arquivos principais alterados
- `jogo/index.html`: área de mapa real na abertura; scripts com versão atualizada.
- `jogo/js/personal-landing.js`: transfere o mesmo canvas entre a entrada, solo e observador.
- `jogo/js/my-bot.js`: painel do mapa dentro de Minha Jornada; botão Ver no mapa e Ampliar.
- `jogo/js/world.js`: renderiza também na tela solo e na entrada, foca no próprio bot e identifica prévias adaptadas corretamente.
- `jogo/css/personal-landing.css`: estilo do mapa responsivo na entrada e no painel pessoal.
- `tests/browser-v9-8-map.py`: novo teste de integração visual.

## Limitações do projeto
A campanha online ainda não é uma reprodução completa de Hoenn; a V9.8 é uma **correção de apresentação e integração do mapa** na jornada pessoal, não a conclusão de todos os sistemas do MMO.
