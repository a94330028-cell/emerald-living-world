/* Account entry for all game modes. Supabase issues and validates the session. */
(()=>{'use strict';
const config=window.EMERALD_CLOUD_CONFIG||{};
const base=String(config.supabaseUrl||'').replace(/\/+$/,'');
const key=String(config.supabaseAnonKey||'');
const slots=window.ELWLocalSlots;
const $=id=>document.getElementById(id);
const destinations=['portal.html','online.html','index.html','arena.html','frontier.html','campanha.html','quetzal-pokedex.html','estatisticas.html'];
const page=new URL(location.href);
const destination=page.searchParams.get('next');
const next=destinations.includes(destination)?destination:'online.html';
const redirect=new URL(page.pathname,page.origin);
const verifierKey='elw_google_pkce_v1';

function status(message,isError=false){
 const el=$('authMessage');el.textContent=message;el.dataset.error=String(isError);
}
function save(data){
 if(!data?.access_token||!data?.refresh_token||!data?.user?.id||data.user.is_anonymous)throw Error('O provedor não enviou uma sessão de conta válida.');
 const value={access_token:data.access_token,refresh_token:data.refresh_token,expires_at:data.expires_at||Math.floor(Date.now()/1000)+Number(data.expires_in||3600),user:data.user};
 slots.switchOwner(value.user.id);
 localStorage.setItem(slots.SESSION,JSON.stringify(value));
 return value;
}
async function request(path,data,token){
 if(!base||!key)throw Error('O servidor de contas ainda não está configurado.');
 const headers={apikey:key};
 if(token)headers.Authorization='Bearer '+token;
 if(data!=null)headers['Content-Type']='application/json';
 let res;
 try{
  res=await fetch(base+path,{method:data!=null?'POST':'GET',headers,body:data!=null?JSON.stringify(data):undefined,cache:'no-store',signal:AbortSignal.timeout(12000)});
 }catch{throw Error('Sem conexão com o serviço de contas. Tente novamente em instantes.')}
 const value=await res.json().catch(()=>({}));
 if(!res.ok)throw Object.assign(Error('O serviço de contas recusou a solicitação.'),{code:value.error_code||value.code,status:res.status});
 return value;
}
function explain(error){
 switch(error.code){
  case 'invalid_credentials':return 'E-mail ou senha incorretos. Confira os dados ou redefina sua senha.';
  case 'email_not_confirmed':return 'Confirme o cadastro pelo link enviado ao seu e-mail. Confira também a pasta de spam.';
  case 'user_already_exists':case 'email_exists':return 'Use Entrar se você já tem uma conta com esse e-mail.';
  case 'weak_password':return 'Escolha uma senha mais forte com pelo menos 8 caracteres.';
  case 'email_address_invalid':return 'Confira se o endereço de e-mail está correto.';
  case 'signup_disabled':return 'O cadastro por e-mail está indisponível neste momento.';
  case 'over_email_send_rate_limit':return 'O serviço atingiu o limite de envios de e-mail. Aguarde antes de tentar novamente.';
  case 'provider_disabled':return 'O login pelo Google ainda não foi ativado.';
  default:return error.status===429?'Muitas tentativas. Aguarde um pouco e tente novamente.':error.message;
 }
}
function connected(value){
 $('accountConnected').hidden=false;$('loginOptions').hidden=true;
 $('connectedLabel').textContent='✓ Conta conectada: '+(value.user.user_metadata?.display_name||value.user.user_metadata?.name||'treinador');
 $('goGame').href=next;
 status('Sua conta está pronta para acessar os modos.');
 window.dispatchEvent(new Event('elw:session-changed'));
}
async function validateExisting(){
 const value=slots.session();if(!value)return null;
 try{
  if(Number(value.expires_at)*1000<=Date.now()+60000&&value.refresh_token){
   return save(await request('/auth/v1/token?grant_type=refresh_token',{refresh_token:value.refresh_token}));
  }
  const user=await request('/auth/v1/user',null,value.access_token);
  return save({...value,user});
 }catch(error){
  if(error.status===400||error.status===401||error.status===403){
   localStorage.removeItem(slots.SESSION);
   slots.switchOwner('guest');
  }
  return null;
 }
}
function gotoGame(target=next){location.replace(destinations.includes(target)?target:next)}
const base64url=bytes=>btoa(String.fromCharCode(...bytes)).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'');
async function beginGoogle(){
 if(!globalThis.crypto?.subtle)throw Error('Use a página HTTPS do Emerald para entrar com Google.');
 const verifier=base64url(crypto.getRandomValues(new Uint8Array(32)));
 const hash=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(verifier));
 sessionStorage.setItem(verifierKey,JSON.stringify({verifier,next}));
 const authorize=new URL(base+'/auth/v1/authorize');
 authorize.search=new URLSearchParams({provider:'google',redirect_to:redirect.href,code_challenge:base64url(new Uint8Array(hash)),code_challenge_method:'s256'});
 location.assign(authorize);
}
async function handleRedirect(){
 const fragment=new URLSearchParams(page.hash.slice(1));
 const code=page.searchParams.get('code');
 const error=page.searchParams.has('error')||fragment.has('error');
 if(!code&&!error&&!fragment.has('access_token'))return false;
 history.replaceState(null,'',redirect.pathname+redirect.search);
 sessionStorage.removeItem('elw_pending_auth_hash_v1');
 const attempt=sessionStorage.getItem(verifierKey);
 sessionStorage.removeItem(verifierKey);
 try{
  if(error)throw Error('O provedor encerrou a tentativa de login. Inicie novamente pela Central de Conta.');
  if(code){
   const pending=JSON.parse(attempt||'null');
   if(!pending?.verifier)throw Error('Abra o retorno do Google na mesma aba que iniciou o login.');
   save(await request('/auth/v1/token?grant_type=pkce',{auth_code:code,code_verifier:pending.verifier}));
   gotoGame(pending.next);return true;
  }else{
   const access_token=fragment.get('access_token');
   const refresh_token=fragment.get('refresh_token');
   const user=await request('/auth/v1/user',null,access_token);
   save({access_token,refresh_token,expires_in:Number(fragment.get('expires_in')||3600),user});
  }
  gotoGame();
 }catch(e){status(explain(e),true)}
 return true;
}
async function detectGoogleProvider(){
 try{
  const settings=await request('/auth/v1/settings');
  const active=settings.external?.google===true;
  $('googleLogin').disabled=!active;
  $('socialProviderStatus').textContent=active?'Entre com sua conta Google.':'O login pelo Google ainda não está disponível.';
 }catch{$('socialProviderStatus').textContent='Não foi possível verificar a disponibilidade do Google.'}
}
$('googleLogin').addEventListener('click',async()=>{
 try{await beginGoogle()}catch(e){status(explain(e),true)}
});
$('passwordForm').addEventListener('submit',async e=>{
 e.preventDefault();const button=$('submitPassword');button.disabled=true;status('Entrando…');
 try{
  save(await request('/auth/v1/token?grant_type=password',{email:$('email').value.trim(),password:$('password').value}));
  gotoGame();
 }catch(e){status(explain(e),true)}finally{button.disabled=false}
});
$('signupForm').addEventListener('submit',async e=>{
 e.preventDefault();const button=e.currentTarget.querySelector('button[type=submit]');button.disabled=true;status('Criando conta…');
 try{
  const value=await request('/auth/v1/signup?'+new URLSearchParams({redirect_to:redirect.href}),{email:$('signupEmail').value.trim(),password:$('signupPassword').value,data:{display_name:$('nickname').value.trim().slice(0,24)}});
  if(value.access_token&&value.user){save(value);gotoGame()}
  else status('Confira seu e-mail e a pasta de spam para confirmar o cadastro. Se já confirmou, use Entrar.');
 }catch(e){status(explain(e),true)}finally{button.disabled=false}
});
$('forgotPassword').addEventListener('click',async()=>{
 const field=$('email');if(!field.reportValidity())return;
 const button=$('forgotPassword');button.disabled=true;
 try{
  const recovery=new URL('index.html',redirect);
  await request('/auth/v1/recover?'+new URLSearchParams({redirect_to:recovery.href}),{email:field.value.trim()});
  status('Se esse e-mail estiver cadastrado, você receberá um link para redefinir a senha.');
 }catch(e){status(explain(e),true)}finally{button.disabled=false}
});
(async()=>{
 if(await handleRedirect()){detectGoogleProvider();return}
 const value=await validateExisting();
 if(value)connected(value);
 else if(!base||!key)status('O servidor de contas ainda não está configurado.',true);
 if(base&&key)detectGoogleProvider();
})();
})();
