import catalog from '../arena/species.mjs';
import {createBattle,validTeam,moves,active,resolveTurn,pickBotAction,division} from '../arena/core.mjs';
const $=id=>document.getElementById(id);
const byId=new Map(catalog.map(s=>[s[0],s]));
const slots={format:6,team:[6,9,25,94,130,448],mode:'bot',bot:null,online:null,waiting:false,busy:false,tab:'build'};
const preferenceKey='elw_arena_preferences_v36';
const owner=()=>window.ELWLocalSlots?.currentOwner?.()||'guest';
const storageKey=()=>`elw_arena_record_v36:${owner()}`;
const defaultRecord=()=>({wins:0,losses:0,draws:0});
function record(){
 try{
  const {wins=0,losses=0,draws=0}=JSON.parse(localStorage.getItem(storageKey())||'{}')||{};
  return {wins,losses,draws};
 }catch{return defaultRecord()}
}
function saveRecord(v){try{localStorage.setItem(storageKey(),JSON.stringify(v))}catch{}}
function savePreferences(){try{localStorage.setItem(preferenceKey,JSON.stringify({format:slots.format,team:slots.team,nick:$('arenaNick').value}))}catch{}}
function escapeHtml(x){return String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function art(s){
 const [first,...fallbacks]=window.EmeraldPokemonArt.sources(s[1],{dex:s[0],light:true});
 return `<img src="${first}" width="70" height="70" alt="${escapeHtml(s[1])}" loading="lazy" decoding="async" data-fallbacks="${fallbacks.join(' ')}">`;
}
function artId(id){return art(byId.get(id)||[id,'Pokémon'])}
function showTab(tab){slots.tab=tab;document.querySelectorAll('[data-tab]').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.tab===tab)));
 document.querySelectorAll('[data-panel]').forEach(el=>el.hidden=el.dataset.panel!==tab);
 if(tab==='rating')refreshRating();scrollTo({top:0,behavior:'smooth'});
}
function notice(text){$('arenaLaunchStatus').textContent=text;}
const session=()=>window.ELWLocalSlots?.session?.();
let queueStarted=0,queueFormat=0,polling=false,operation=0;
function showCount(){const ok=validTeam(slots.team,slots.format,catalog);$('teamCount').textContent=`${slots.team.length}/${slots.format}`;
 const authNeeded=slots.mode==='online'&&!session();
 $('arenaSignIn').hidden=!authNeeded;
 $('arenaLaunch').disabled=authNeeded||!ok||slots.busy||slots.waiting||Boolean(slots.online&&!slots.online.finished);
 if(!ok)notice(`Selecione ${slots.format} Pokémon diferentes para batalhar.`);
 else if(!slots.busy&&!slots.waiting&&!slots.online)notice(authNeeded?'Entre para procurar jogadores.':slots.mode==='online'?'Seu time está pronto para o PvP.':'Seu time está pronto para o treino.');
}
function paintTeam(){const html=Array.from({length:slots.format},(_,i)=>{const id=slots.team[i],spec=byId.get(id);return `<button type="button" class="teamSlot ${spec?'filled':''}" ${spec?`data-remove="${i}" title="Remover ${escapeHtml(spec[1])}"`:''}>
 ${spec?art(spec):'<b>＋</b>'}<span>${spec?escapeHtml(spec[1]):'Vazio '+(i+1)}</span></button>`;}).join('');$('arenaSlots').innerHTML=html;
 $('arenaSlots').querySelectorAll('[data-remove]').forEach(b=>b.addEventListener('click',()=>{slots.team.splice(Number(b.dataset.remove),1);paintTeam();paintSearch();savePreferences();}));showCount();
}
const batchSize=24;
let visibleSpecies=batchSize;
function paintSearch(){
 const query=$('arenaSearch').value.trim().toLocaleLowerCase('pt-BR');
 const matches=query?catalog.filter(s=>s[1].toLocaleLowerCase('pt-BR').includes(query)||s[0]===Number(query.replace(/^#/,''))):catalog;
 const entries=matches.slice(0,visibleSpecies);
 $('arenaTotal').textContent=matches.length?`${entries.length} de ${matches.length.toLocaleString('pt-BR')} espécies`:'Nenhuma espécie encontrada';
 $('arenaMore').hidden=entries.length===matches.length;
 $('arenaSpecies').innerHTML=entries.map(s=>`<button class="speciesButton" data-species="${s[0]}" ${slots.team.includes(s[0])||slots.team.length>=slots.format?'disabled':''}>${art(s)}<strong>${escapeHtml(s[1])}</strong><small>#${String(s[0]).padStart(3,'0')}</small></button>`).join('');
}

function randomize(){const ids=catalog.map(x=>x[0]);for(let i=ids.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[ids[i],ids[j]]=[ids[j],ids[i]]}slots.team=ids.slice(0,slots.format);paintTeam();paintSearch();savePreferences();}
function suggest(){const pool=[6,9,3,25,94,130,448,149,376,282,257,260,250,334,445,700];slots.team=pool.slice(0,slots.format);paintTeam();paintSearch();savePreferences();}
function setMode(mode){slots.mode=mode;document.querySelectorAll('[data-mode]').forEach(b=>b.classList.toggle('active',b.dataset.mode===mode));$('botDifficultyWrap').hidden=mode==='online';$('arenaTrainingStats').hidden=mode==='online';
 $('arenaLaunch').textContent=mode==='bot'?'🤖 Batalhar contra bot':'🌍 Procurar adversário real';showCount();
}
function showTrainingRecord(){
 const {wins,losses,draws}=record();
 $('arenaLocalRecord').textContent=`${wins} vitórias · ${losses} derrotas · ${draws} empates`;
}
function applyBotOutcome(battle){
 if(!battle||battle.winner===null||slots.bot?.recorded)return;
 const stats=record();
 if(battle.winner===0)stats.wins++;
 else if(battle.winner===1)stats.losses++;
 else stats.draws++;
 saveRecord(stats);slots.bot.recorded=true;showTrainingRecord();
}
const localBattle=()=>slots.bot?.battle||null;
function botStart(){const team=[...slots.team],pool=catalog.map(x=>x[0]).filter(id=>!team.includes(id));
 pool.sort(()=>Math.random()-.5);const opponents=pool.slice(0,slots.format);
 slots.bot={battle:createBattle(team,opponents,catalog),recorded:false};slots.online=null;slots.waiting=false;showTab('battle');renderBattle();
}
function updateScene(side,battle,mine,oppName){const s=battle.sides[side],mon=active(s);if(!mon)return;
 $(side===mine?'combatMine':'combatOther').innerHTML=`<strong>${escapeHtml(oppName)}</strong><small>${escapeHtml(mon.name)} · Nível 50</small>${artId(mon.id)}<div class="healthBar"><span style="width:${Math.round(100*mon.hp/mon.maxHp)}%"></span></div><small>${mon.hp} / ${mon.maxHp} HP</small><div class="teamAlive">${s.team.filter(m=>m.hp>0).length} Pokémon restantes</div>`;
}
function renderBattle(){const data=slots.online,online=!!data,waiting=slots.waiting,bat=online?data.battle:localBattle();const finished=bat?.winner!==null;
 $('matchWaiting').hidden=!waiting;$('matchArena').hidden=waiting||!bat;
 if(waiting){
  $('battleTitle').textContent='Fila ranqueada';
  $('battleLabel').textContent='🌍 PVP ONLINE';
  $('battleTurn').textContent=`${queueFormat}×${queueFormat}`;
  $('battleNotice').hidden=true;
  $('arenaCancelQueue').disabled=slots.busy;
  updateQueueTime();
  return;
 }
 $('battleNotice').hidden=false;
 if(!bat){
  $('battleTitle').textContent='Sua próxima batalha';
  $('battleLabel').textContent='ARENA · EM PREPARAÇÃO';
  $('battleNotice').textContent='Monte seu time e escolha um adversário na aba Montar time.';
  $('battleTurn').textContent='Rodada —';return;
 }
 const mine=online?data.side:0,other=1-mine;const names=online?data.users.map(x=>x.name):[$('arenaNick').value||'Você','Treinador IA'];

 $('battleTitle').textContent=online?'⚔️ Partida PvP ranqueada':'⚔️ Batalha contra bot';$('battleLabel').textContent=online?'🌍 ONLINE · ELO MUNDIAL':'🤖 TREINO CONTRA BOT';$('battleTurn').textContent=`Rodada ${bat.turn}`;
 updateScene(mine,bat,mine,names[mine]);updateScene(other,bat,mine,names[other]);
 const side=bat.sides[mine],mon=active(side),canAct=!finished&&(!online||!data.hasSubmitted)&&!slots.busy;
 $('battleNotice').textContent=finished?(bat.winner===-1?'Empate!':bat.winner===mine?'🏆 Você venceu!':'Você perdeu. Tente outra estratégia!')+(online&&Number.isInteger(data.ratingDelta)?` · ${data.ratingDelta>=0?'+':''}${data.ratingDelta} Elo`:''):
 online&&data.hasSubmitted?'Ação enviada. Aguardando a decisão do adversário.':'Escolha um ataque ou troque de Pokémon.';
 $('combatMoves').innerHTML=moves(mon).map((m,i)=>`<button type="button" data-attack="${i}" ${canAct&&mon.hp>0?'':'disabled'}>${escapeHtml(m.name)}<small>${escapeHtml(m.type)} · Poder ${m.power}${m.priority?' · prioridade':''}</small></button>`).join('');
 $('combatSwitch').innerHTML=side.team.map((m,i)=>`<button type="button" data-switch="${i}" ${canAct&&m.hp>0&&i!==side.active?'':'disabled'}>${artId(m.id)}<span>${escapeHtml(m.name)}</span></button>`).join('');
 $('combatMoves').querySelectorAll('[data-attack]').forEach(b=>b.addEventListener('click',()=>takeAction({kind:'attack',move:Number(b.dataset.attack)})));
 $('combatSwitch').querySelectorAll('[data-switch]').forEach(b=>b.addEventListener('click',()=>takeAction({kind:'switch',to:Number(b.dataset.switch)})));
 $('combatLog').innerHTML=(bat.log||[]).slice(-16).reverse().map(l=>`<p>${escapeHtml(l)}</p>`).join('');
 $('arenaRematch').hidden=!finished;$('arenaConcede').disabled=finished||slots.busy;
}
async function takeAction(act){if(slots.busy)return;slots.busy=true;operation++;let failure;
 try{
  if(slots.online){slots.online=await onlineRequest('move',{id:slots.online.id,move:act});}
  else if(slots.bot){const current=slots.bot.battle;
   const cpu=pickBotAction(current,1,$('botDifficulty').value);
   slots.bot.battle=resolveTurn(current,act,cpu);applyBotOutcome(slots.bot.battle);
  }
 }catch(e){failure=e;}finally{slots.busy=false;renderBattle();if(failure)$('battleNotice').textContent='⚠️ '+failure.message;}
}
function apiAddress(action,id){const base=window.EMERALD_CLOUD_CONFIG?.supabaseUrl?.replace(/\/$/,'')+'/functions/v1/arena-online';const q=new URLSearchParams();if(action)q.set('action',action);if(id)q.set('id',id);return base+'?'+q.toString();}
async function onlineRequest(action,body=null,matchId=null){const cfg=window.EMERALD_CLOUD_CONFIG;
 if(!cfg?.supabaseAnonKey||!cfg?.supabaseUrl)throw Error('Supabase não configurado.');
 const account=session(),needsAuth=action!=='leaderboard';
 if(needsAuth&&(!account?.access_token||account.expires_at*1000<Date.now()+15000)){
  throw Object.assign(Error('Entre novamente para usar o PvP.'),{status:401});
 }
 const response=await fetch(apiAddress(body?'':action,matchId),{method:body?'POST':'GET',signal:AbortSignal.timeout(12000),headers:{apikey:cfg.supabaseAnonKey, ...(needsAuth?{Authorization:'Bearer '+account.access_token}:{}), ...(body?{'Content-Type':'application/json'}:{})},...(body?{body:JSON.stringify({action,...body})}:{})});
 const result=await response.json().catch(()=>({error:'Resposta inesperada'}));if(!response.ok)throw Object.assign(Error(result.error||result.message||'Falha na conexão com o servidor'),{status:response.status});return result;
}
function updateQueueTime(){
 if(!slots.waiting)return;
 const seconds=Math.max(0,Math.floor((Date.now()-queueStarted)/1000));
 $('arenaQueueTime').textContent=`${Math.floor(seconds/60)}:${String(seconds%60).padStart(2,'0')}`;
}
function acceptQueueState(result){
 if(result.status==='matched'){
  const firstMatch=slots.online?.id!==result.id;
  slots.waiting=false;slots.online=result;slots.bot=null;
  if(firstMatch){setMode('online');showTab('battle');}
 }else if(result.status==='waiting'){
  const firstWait=!slots.waiting;
  slots.waiting=true;slots.online=null;slots.bot=null;
  queueFormat=result.format;
  queueStarted=Date.parse(result.queuedAt)||(firstWait?Date.now():queueStarted);
  $('arenaQueueDetail').textContent=`Buscando um jogador no formato ${queueFormat}×${queueFormat}.`;
  if(firstWait){setMode('online');showTab('battle');}
 }
 renderBattle();showCount();
}
function leaveQueue(message,error){
 slots.waiting=false;slots.online=null;
 showTab('build');renderBattle();showCount();
 if(message)notice(message);
 if(error?.status===401)$('arenaSignIn').hidden=false;
}
async function joinOnline(){
 if(slots.busy||slots.waiting)return;
 slots.busy=true;operation++;slots.waiting=true;slots.online=null;slots.bot=null;
 queueStarted=Date.now();queueFormat=slots.format;
 $('arenaQueueDetail').textContent='Entrando na fila PvP…';
 showTab('battle');renderBattle();$('arenaQueueTitle').focus({preventScroll:true});showCount();
 let result;
 try{
  result=await onlineRequest('join',{team:slots.team,format:slots.format,name:$('arenaNick').value||'Treinador'});
 }catch(e){
  slots.busy=false;
  leaveQueue('⚠️ '+(e.status?e.message:'A fila não respondeu. Tente novamente.'),e);
  return;
 }
 slots.busy=false;
 acceptQueueState(result);
}
async function poll(resume=false){
 if((document.hidden&&!resume)||slots.busy||polling||!session()||(!resume&&!slots.waiting&&(!slots.online||slots.online.finished)))return;
 polling=true;const before=operation;
 try{
  const result=await onlineRequest('status',null,slots.online?.id||null);
  if(before!==operation||slots.busy)return;
  if(result.status==='matched'||result.status==='waiting')acceptQueueState(result);
  else if(slots.waiting)leaveQueue('A busca expirou. Você pode procurar novamente.');
 }catch(e){
  if(before!==operation||resume)return;
  if(e.status===401&&slots.waiting)leaveQueue('⚠️ '+e.message,e);
  else if(slots.waiting)$('arenaQueueDetail').textContent='Reconectando à fila PvP…';
  else $('battleNotice').textContent='⚠️ '+e.message;
 }finally{polling=false;}
}
async function cancelQueue(){
 if(slots.busy||!slots.waiting)return;
 slots.busy=true;operation++;renderBattle();
 let result;
 try{result=await onlineRequest('cancel',{});}
 catch(e){
  slots.busy=false;
  if(e.status===401)leaveQueue('⚠️ '+e.message,e);
  else {
   $('arenaQueueDetail').textContent='Não foi possível cancelar a busca. Tente novamente.';
   renderBattle();
  }
  return;
 }
 slots.busy=false;
 if(result.status==='matched')acceptQueueState(result);
 else leaveQueue('Busca cancelada.');
}
async function concede(){if(!confirm('Deseja desistir desta partida?'))return;
 if(slots.online){
  if(slots.busy)return;
  slots.busy=true;operation++;renderBattle();let failure;
  try{slots.online=await onlineRequest('concede',{id:slots.online.id})}
  catch(e){failure=e;}
  finally{slots.busy=false;renderBattle();showCount();if(failure)$('battleNotice').textContent=failure.message;}
  return;
 }
 if(slots.bot&&!slots.bot.recorded){slots.bot.battle.winner=1;slots.bot.battle.log.push('Você desistiu da batalha.');applyBotOutcome(slots.bot.battle);renderBattle();}
}
async function refreshRating(){
 try{
  const {players=[]}=await onlineRequest('leaderboard');
  $('arenaLeaderboard').innerHTML=players.length?players.map((x,i)=>`<div class="leaderRow"><strong>${i+1}º</strong><span>${escapeHtml(x.display_name)}<small>${x.wins}V · ${x.losses}D · ${x.draws}E · ${escapeHtml(division(x.rating))}</small></span><b>${x.rating} Elo</b></div>`).join(''):'<p>O ranking ainda está vazio. Dispute uma partida PvP para entrar.</p>';
 }catch(e){$('arenaLeaderboard').innerHTML='<p>Ranking online indisponível: '+escapeHtml(e.message)+'</p>';}
 $('arenaMyRating').textContent='—';
 $('arenaPvPRecord').textContent='';
 if(!session()){$('arenaMyDivision').textContent='Entre na sua conta';return;}
 try{
  const {record}=await onlineRequest('my-rating');
  $('arenaMyRating').textContent=record?.rating??'—';
  $('arenaMyDivision').textContent=record?division(record.rating):'Aguardando sua primeira partida';
  if(record)$('arenaPvPRecord').textContent=`${record.wins} vitórias · ${record.losses} derrotas · ${record.draws} empates`;
 }catch(e){$('arenaMyDivision').textContent=e.status===401?'Entre novamente':'Elo indisponível';}
}
document.addEventListener('error',event=>{
 const img=event.target;
 if(!img.dataset?.fallbacks)return;
 const [next,...remaining]=img.dataset.fallbacks.split(' ');
 img.dataset.fallbacks=remaining.join(' ');
 img.src=next;
},true);

function setup(){const saved=(()=>{try{return JSON.parse(localStorage.getItem(preferenceKey))||{}}catch{return {}}})();
 if([1,3,6].includes(Number(saved.format)))slots.format=Number(saved.format);
 if(Array.isArray(saved.team))slots.team=[...new Set(saved.team.filter(id=>byId.has(id)))].slice(0,slots.format);
 else slots.team=slots.team.slice(0,slots.format);
 $('arenaFormat').value=String(slots.format);$('arenaNick').value=String(saved.nick||'Treinador').slice(0,24);
 $('arenaTheme').textContent=document.documentElement.dataset.pokeTheme==='dark'?'☀️ Claro':'🌙 Escuro';
 $('arenaTheme').addEventListener('click',()=>{const next=document.documentElement.dataset.pokeTheme==='dark'?'emerald':'dark';document.documentElement.dataset.pokeTheme=next;localStorage.setItem('elw_visual_theme_25',next);$('arenaTheme').textContent=next==='dark'?'☀️ Claro':'🌙 Escuro';});
 document.querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>showTab(b.dataset.tab)));
 $('arenaFormat').addEventListener('change',()=>{slots.format=Number($('arenaFormat').value);slots.team=slots.team.slice(0,slots.format);paintTeam();paintSearch();savePreferences();});
 $('arenaNick').addEventListener('change',savePreferences);$('arenaSearch').addEventListener('input',()=>{visibleSpecies=batchSize;paintSearch()});
 $('arenaMore').addEventListener('click',()=>{visibleSpecies+=batchSize;paintSearch()});
 $('arenaSpecies').addEventListener('click',event=>{
  const button=event.target.closest('[data-species]');
  if(!button||button.disabled)return;
  const id=Number(button.dataset.species);
  if(slots.team.includes(id)||slots.team.length>=slots.format)return;
  slots.team.push(id);paintTeam();paintSearch();savePreferences();
 });
 $('arenaRandom').addEventListener('click',randomize);$('arenaSuggested').addEventListener('click',suggest);
 $('arenaClear').addEventListener('click',()=>{slots.team=[];paintTeam();paintSearch();savePreferences()});
 document.querySelectorAll('[data-mode]').forEach(b=>b.addEventListener('click',()=>setMode(b.dataset.mode)));
 $('arenaLaunch').addEventListener('click',()=>slots.mode==='bot'?botStart():joinOnline());
 $('arenaCancelQueue').addEventListener('click',cancelQueue);$('arenaConcede').addEventListener('click',concede);
 $('arenaRematch').addEventListener('click',()=>{slots.online=null;slots.bot=null;slots.waiting=false;showTab('build');showCount()});
 $('arenaRefreshRank').addEventListener('click',refreshRating);
 paintTeam();paintSearch();setMode('bot');showTrainingRecord();poll(true);
 setInterval(updateQueueTime,1000);
 // Poll only when a live online match or queue exists, never for the offline mode.
 setInterval(poll,3000);
}
setup();
