# Emerald Living World 3.0.8

Atualização baseada no ZIP 3.0.7. Use Node.js 20 ou mais recente e execute `npm start` na raiz. Abra `http://127.0.0.1:8787/jogo/portal.html`.

- Simulação. A inicialização usa a rotina de fim de turno existente. Saves que apontam para uma célula bloqueada são ajustados, uma única vez, para uma célula caminhável do mesmo mapa. A movimentação normal continua sujeita às colisões.
- Arena. O servidor entrega os módulos JavaScript do catálogo e da batalha. A busca percorre as 1.025 espécies. Os resultados são exibidos em lotes e os sprites leves carregam sob demanda.
- Celular. A navegação global tem uma única barra. As abas do simulador ficam dentro do fluxo da página. O modo de economia usa sprites leves e limita o mapa a 15 FPS.
- Contas. O Mundo Compartilhado encaminha para a Central de Conta. O login por senha exibe erros em português e oferece recuperação. A Central usa PKCE para o Google. Os dados do mundo, do catálogo e da Frontier permanecem compatíveis com a base.

## Ativar o Google

1. No [Google Auth Platform](https://console.cloud.google.com/auth/clients), crie ou abra um cliente OAuth do tipo aplicativo da Web.
2. Adicione `https://emerald-node-production.up.railway.app` às origens JavaScript autorizadas. Adicione `https://hvujsnvyqydlmeyveuuf.supabase.co/auth/v1/callback` aos URIs de redirecionamento autorizados.
3. Informe o Client ID e o Client Secret diretamente no [provedor Google do Supabase](https://supabase.com/dashboard/project/hvujsnvyqydlmeyveuuf/auth/providers). Guarde o segredo somente no console.
4. Nas URLs permitidas de autenticação do Supabase, adicione `https://emerald-node-production.up.railway.app/jogo/entrar.html` para o retorno da conta e `https://emerald-node-production.up.railway.app/jogo/index.html` para recuperação de senha.
5. Teste com uma conta Google em uma aba nova. O Supabase deve entregar a sessão à Central, que abre o modo escolhido. Se o cliente OAuth estiver em modo de testes, use uma conta de teste autorizada no Google Cloud.

As regras de confirmação de cadastro por e-mail e senha são definidas no Supabase. O fluxo Google usa a autenticação do provedor. [Documentação oficial](https://supabase.com/docs/guides/auth/social-sign-in/auth-google)

## Validação e publicação

- `npm run verify:local` roda os testes Node, a verificação de preservação e o smoke HTTP.
- `npm run test:browser:release` usa Python, Playwright e Chromium para simular uma tela Pixel 7. O teste usa um provedor de autenticação local e um diretório temporário para saves. É possível selecionar o binário Chromium com `CHROMIUM_PATH`.
- A produção na Railway inicializa um ZIP antigo com checksum fixado e aplica remendos de interface. Prepare uma versão de teste com este pacote consolidado e confira o comando de inicialização antes de trocar a origem da produção.
- Antes de publicar, valide a conta real e a recuperação de senha no Supabase, o Google, o fluxo em um Android físico e a restauração de um backup. Preserve o volume existente em `/data`, a réplica única e `AUTH_MODE=required`.
