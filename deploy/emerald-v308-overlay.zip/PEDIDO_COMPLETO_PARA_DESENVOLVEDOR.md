# 🌿 Emerald Living World — Descrição completa, novidades e correções solicitadas

Quero continuar o desenvolvimento do **Emerald Living World**, um jogo/simulador de Pokémon inspirado em Emerald e em Hoenn, acessível pelo navegador, com experiência boa no Android e no computador. **Estou enviando o ZIP com o código-fonte**, porque quero corrigir os problemas de verdade, sem reconstruir tudo ou perder os sistemas existentes.

## 1. O que já existe no projeto

### Estrutura do site e modos

- **Central Emerald (`jogo/portal.html`):** menu principal para navegar pelo mesmo domínio, com modos, ajuda, páginas institucionais e identidade visual comum.
- **Simulação de treinadores (`jogo/index.html`):** treinadores de IA com rotas, exploração, escolhas, memória/estratégias, equipes, confrontos, evolução, eventos e classificação. Existem controles de iniciar/continuar, pausar, velocidade, câmera, saves e número de IAs. O motor local foi projetado para até 100 bots, mas a estabilidade precisa de validação no celular.
- **Mundo compartilhado (`jogo/online.html`):** servidor Node.js, treinador persistente, mapa, movimento, colisões, eventos, encontros e capturas por habitat, status de sessão e sincronização. O servidor pode operar com bots e conexão entre jogadores; precisa de testes reais de rede e autenticação.
- **Jornada de Hoenn (`jogo/campanha.html`):** progressão por rotas/cidades, ginásios, Liga, registro de Campeão e Hall da Fama em versão adaptada. Não afirmar que todos os eventos originais da ROM estão reproduzidos.
- **Arena Competitiva (`jogo/arena.html`):** escolha ou sorteio de equipe, formatos de batalha, catálogo de Pokémon, golpes/atributos, bots adversários, Elo local e estrutura de PvP online/ranking. O PvP público ainda precisa de homologação.
- **Battle Frontier LAB (`jogo/frontier.html`):** Tower, Dome, Palace, Arena, Factory, Pike e Pyramid; confrontos e regras adaptadas, desafios/Frontier Pass experimentais. Não confundir com os símbolos/regras oficiais completos da ROM.
- **Pokédex (`jogo/quetzal-pokedex.html`):** catálogo nacional ampliado, espécies, tipos, atributos, golpes e imagens; o catálogo vai além da terceira geração.
- **Mapa de Hoenn (`jogo/mapas-oficiais.html`):** regiões, conexões, rotas, colisões e transições; objetivo de continuidade entre áreas externas, carregando interiores quando necessário.
- **Estatísticas (`jogo/estatisticas.html`):** dados de progresso e rankings/placares existentes no projeto.
- **Central de Conta (`jogo/entrar.html`):** autenticação por e-mail/senha e interface para entrar com Google via Supabase, com uma sessão reaproveitada nos modos online.
- **Páginas de documentação e novidades:** sobre, privacidade, atualizações e tutoriais.

### Mecânicas já previstas ou parcialmente implementadas

- Escolha de iniciais e formação de equipe; diferentes gerações no catálogo.
- HP, níveis, experiência, evolução, tipos, golpes, PP, status e regras adaptadas de batalha Gen III.
- Estratégias das IAs, encontros selvagens, capturas, decisões de equipe, NPCs e eventos raros.
- PC/armazenamento, equipe de seis Pokémon, Pokédex e progresso do treinador.
- Ginásios de Hoenn, Liga, pós-jogo experimental, Frontier e Arena em modos distintos.
- Perfil do jogador, histórico, placares, Elo, saves e rankings — conferir quais se mantêm sincronizados no servidor, pois alguns recursos ainda são protótipos ou locais.
- Sprites de treinadores e Pokémon, cenários pixel-art, mapas, telas de inventário, responsividade e controles por toque.
- Backend Node.js, APIs, Supabase para autenticação, Railway para hospedagem contínua, volume persistente e testes automatizados.

## 2. O que entrou nas atualizações recentes

- **3.0.1:** revisão do motor de batalha Gen III, auditorias de integridade, início da infraestrutura para Railway e saves persistentes.
- **3.0.2:** Central única, navegação interligando todos os modos, Central de Conta, temas por área e botão Google preparado — **provedor ainda não ativado**.
- **3.0.3:** interface premium: cabeçalhos, cartões, busca, identidade esmeralda, destaques para Arena/Frontier/Jornada/Pokédex, layouts responsivos.
- **3.0.4:** tentativa de corrigir visual do botão Frontier e continuidade da simulação.
- **3.0.5:** tentativa de remover cabeçalhos repetidos em páginas internas.
- **3.0.6:** tentativas de consolidar menus no Android e corrigir sobreposição/contraste.
- **3.0.7:** motor local deixa de exigir comando manual a cada turno, modo pessoal passa a solicitar 20 treinadores em modo misto e legenda do mapa indica IAs **na área**, não no mundo inteiro.

**Atenção:** 3.0.4–3.0.6 foram publicadas como camadas extras na inicialização da Railway, o que gerou risco de duplicação CSS/JS. No ZIP-base, use os links do arquivo `CAMADAS_UI_PUBLICADAS_NA_RAILWAY.md` apenas como referência para refatoração. Evitar colar novamente as mesmas camadas.

## 3. Problemas atuais — PRIORIDADE MÁXIMA

### P0 — Login quebrado

No Android, o formulário retorna **“Invalid login credentials”** ao tentar entrar. O botão **“Continuar com Google”** aparece desativado porque o provedor social ainda não foi configurado no Supabase.

**Corrigir:** conferir se a conta realmente existe no mesmo projeto Supabase usado pela Railway; validar signup/sign-in, confirmação por e-mail, mensagens para usuário e restauração de sessão. Configurar OAuth Google no Google Cloud + Supabase, URLs de redirecionamento do domínio Railway, e testar login/retorno da sessão no Android. Não deixar o front afirmar que um cadastro foi concluído se não recebeu confirmação da API. Não liberar saves privados anonimamente. Não colocar `service_role` em código público.

### P0 — Simulação não anda

Mesmo após apertar para iniciar, os treinadores continuam parados; o contador na tela não evidencia progresso. Em uma captura, o mapa mostra a casa do Brendan com **0 IAs naquela sala**. A 3.0.7 tentou corrigir bloqueio do motor, mas **não há confirmação de que isso resolveu em um Android real**.

**Corrigir:** reproduzir ao escolher *Meu treinador* e *Assistir às IAs*; verificar `paused`, `bootAuthorized`, `settings.gameMode`, número real de treinadores, loop `tick`, `requestAnimationFrame`/timers, renderização, geração de rotas, colisões, interiores/warps e saves antigos. Medir turnos e posições por pelo menos 60 segundos, confirmar movimentos fora do interior e progresso entre cidades. Distinguir o motor local (`jogo/js/engine.js`) do motor compartilhado do servidor (`server/autonomy.cjs`, `/api/health` com `simulationTick`), pois ambos podem falhar por motivos diferentes. A quantidade de IAs no mesmo interior não representa o total do mundo.

### P0 — Pokémon não aparecem na Arena Competitiva

A criação do time/seleção de espécies falha ou fica sem os cards desejados no Android. Os botões de sorteio e a contagem de espécies aparecem, mas é necessário testar se a lista e as imagens carregam e se o time permite começar a batalha.

**Corrigir:** abrir `jogo/arena.html`, conferir erros JavaScript e requisições de catálogo/sprites, buscar e escolher espécies, montar seis Pokémon, sortear equipe e iniciar batalhas contra bots. Confirmar que os dados da Arena vêm dos módulos corretos (`jogo/arena/`) e que filtros, scroll e event handlers funcionam no celular. Validar as batalhas e atualização de Elo; não depender apenas de a página renderizar.

### P1 — UI duplicada, sobreposta e visual inconsistente

As capturas do Android mostram menus inferiores em duplicidade, cabeçalhos com o nome Emerald repetido até três vezes, botões cobrindo conteúdo, alguns textos escuros sobre fundo escuro, marcações de versão inconsistentes e mistura de estilos entre Arena, simulação e Pokédex.

**Corrigir:** refatorar a navegação global em **um único componente**, com **uma barra superior e uma barra inferior no celular**. As abas internas de cada modo devem ficar no fluxo normal da página. Remover cabeçalhos e docks legados em vez de esconder conflitos com dezenas de regras `!important`. Garantir cores, espaçamentos, tipografia, contraste AA, foco de teclado, áreas de toque, safe-area no Android e ausência de rolagem horizontal.

### P1 — Desempenho e qualidade mobile

O projeto usa muitos sprites e mapas. Otimizar carregamento inicial, lazy-load de imagens, cache de assets, tamanhos responsivos, mudança entre modos e movimentação em mapas, sem recarregar o mundo todo e sem efeitos pesados forçados. Adicionar modo leve funcional.

### P1 — Contas, saves e placares

Verificar login compartilhado entre os modos, vínculo entre conta Supabase e dados do perfil, ranking global, partidas PvP, separação de Elo local contra bots e Elo público, e persistência após recarregar, reiniciar o servidor e mudar de aparelho. Implementar métricas de usuários/visitas/admin apenas com permissões adequadas; não inventar números nem expor informações privadas de outros jogadores.

## 4. Critérios de aceite (testar ANTES de publicar)

1. Cadastro e login válidos; Google OAuth funcional quando configurado; sessão permanece ao trocar de página. Erros de senha são compreensíveis.
2. Iniciar simulação com 20 IAs; pelo menos algumas caminham e mudam posições/rotas no período de teste, sem teleporte ou ficar girando indefinidamente. Pausa interrompe, continuar retoma e salvar/carregar mantém progresso.
3. Arena mostra o catálogo e sprites, permite equipe de 6, sorteio e batalha contra bot; resultado e Elo são atualizados corretamente.
4. Só um cabeçalho e **uma única barra de navegação global** por página no Android. Nenhum botão encobre controles ou cartas; legibilidade em tema claro/escuro.
5. Campanha, capturas, Pokédex, Frontier LAB, mapas, conta e ranking continuam acessíveis. Preservar os oito arquivos protegidos e os dados de produção.
6. Executar `npm test`, `npm run audit:preservation` e testes reais em Chrome Android; observar console, rede e requisições HTTP. Verificar `/api/health`, login, SSE e persistência do volume `/data`.
7. Publicar apenas após testes. Criar backup do volume e plano de retorno à versão anterior.

## 5. Infraestrutura e onde está publicado

- **Código e patches:** https://github.com/a94330028-cell/emerald-living-world
- **Servidor Railway:** https://railway.com/project/04472cd6-3834-4500-a935-88c8ae2deef0
- **Site:** https://emerald-node-production.up.railway.app/jogo/portal.html
- **Stack:** Node.js >=20, HTML/CSS/JS, Supabase Auth e Railway.
- **Dados persistentes:** volume `/data` (não substituir nem remover em upgrades).
- **Autenticação:** `AUTH_MODE=required`; configurações e chaves publicáveis no ambiente do servidor (não no ZIP).

## 6. O que NÃO quero

- Não criar um site novo vazio, não apagar funcionalidades, sprites, capturas, habitats ou saves.
- Não declarar bugs corrigidos só porque `/api/health` responde OK.
- Não publicar correções CSS empilhando novas barras ou duplicando componentes.
- Não exigir confirmação de e-mail própria do jogo para entrar com Google quando o OAuth estiver habilitado. Não contornar autenticação de usuários para facilitar acesso.
- Não fingir que Frontier LAB, ROM Emerald integral, PvP público e regras Gen III estão 100% finalizados; trabalhar com prioridades e validação real.

**Meta final:** um Emerald Living World com interface profissional, único domínio, login confiável, treinadores que andam de verdade, Arena jogável com catálogo visível e boa experiência no celular — sem perder o que já foi desenvolvido.
