'use strict';
/** Optional local HTTP smoke test: uses temporary saves and never contacts Supabase. */
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const assert=require('node:assert/strict');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'elw-3-local-smoke-'));
process.env.DATA_DIR=dir;
process.env.AUTH_MODE='guest';
process.env.BOT_TICK_MS='60000';
process.env.BOT_COUNT='5';
const app=require('../server/app.cjs');
(async()=>{
 const server=await app.start(0,'127.0.0.1');
 try{
  const base=`http://127.0.0.1:${server.address().port}`;
  for(const [uri,content] of [['/','text/html'],['/jogo/online.html','text/html'],['/jogo/frontier.html','text/html'],['/jogo/campanha.html','text/html'],['/jogo/arena.html','text/html'],['/jogo/arena/core.mjs','text/javascript'],['/jogo/arena/species.mjs','text/javascript']]){
   const r=await fetch(base+uri);assert.equal(r.status,200,uri);assert.ok(r.headers.get('content-type')?.includes(content));
  }
  const asset=await fetch(base+'/jogo/assets/pokemon_fit/pikachu.png',{method:'HEAD'});
  assert.equal(asset.status,200);assert.equal(await asset.text(),'');
  const etag=asset.headers.get('etag');assert.ok(etag);
  assert.equal((await fetch(base+'/jogo/assets/pokemon_fit/pikachu.png',{headers:{'if-none-match':etag}})).status,304);
  const health=await fetch(base+'/api/health');assert.equal(health.status,200);
  const h=await health.json();assert.equal(h.version,require('../package.json').version);assert.equal(h.bots,5);
  let r=await fetch(base+'/api/frontier');assert.equal(r.status,401);
  r=await fetch(base+'/api/session',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name:'Teste local',starter:'Mudkip'})});
  assert.equal(r.status,200);const cookie=r.headers.get('set-cookie')?.split(';')[0];assert.ok(cookie);
  const session=await r.json();assert.ok(session.profile?.id);
  r=await fetch(base+'/api/frontier',{headers:{cookie}});assert.equal(r.status,200);
  const frontier=await r.json();assert.equal(frontier.facilities?.length,7);
  console.log('OK: páginas, health, sessão, 401 sem sessão e Frontier autenticada no servidor local.');
 }finally{await app.stop();fs.rmSync(dir,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exitCode=1;});
