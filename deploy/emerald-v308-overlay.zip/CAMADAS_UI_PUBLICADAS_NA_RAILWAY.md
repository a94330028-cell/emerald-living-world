# Camadas adicionais de interface atualmente publicadas via Railway

A origem do servidor é o `emerald-source.zip` (base 3.0.1), mais overlays e scripts adicionados durante a inicialização. O pacote-fonte desta exportação já inclui toda a base premium 3.0.3 e as três correções locais do motor 3.0.7.

**Atenção:** os seguintes arquivos foram aplicados por hotfix à versão pública e **não estão embutidos nativamente como arquivos completos neste ZIP**, para não empilhar os mesmos scripts e perpetuar o bug de menus duplicados. O desenvolvedor pode consultar as referências abaixo e **integrar/refatorar** o que for útil em um único layout:

- `jogo/js/premium-v303.js`: https://github.com/a94330028-cell/emerald-living-world/blob/main/jogo/js/premium-v303.js
- `jogo/css/premium-v303.css`: https://github.com/a94330028-cell/emerald-living-world/blob/main/jogo/css/premium-v303.css
- `jogo/js/hotfix-v304.js`: https://github.com/a94330028-cell/emerald-living-world/blob/main/jogo/js/hotfix-v304.js
- `jogo/js/one-header-v305.js`: https://github.com/a94330028-cell/emerald-living-world/blob/main/jogo/js/one-header-v305.js
- `jogo/css/mobile-stability-v306.css`: https://github.com/a94330028-cell/emerald-living-world/blob/main/jogo/css/mobile-stability-v306.css
- `jogo/css/mobile-safeguards-v306.css`: https://github.com/a94330028-cell/emerald-living-world/blob/main/jogo/css/mobile-safeguards-v306.css
- `deploy/simulation-repair-v307.cjs`: https://github.com/a94330028-cell/emerald-living-world/blob/main/deploy/simulation-repair-v307.cjs

O script de reparo 3.0.7 está **aplicado** no código deste ZIP: não o execute novamente por cima desta versão, pois seu patch foi escrito para a origem antiga e rejeita arquivos já corrigidos.

## Orientação para o desenvolvedor

1. Começar pela base do ZIP; confirmar estrutura, caminhos e funcionamento local.
2. Revisar os scripts premium e eliminar a dependência de inserção dinâmica de múltiplas barras.
3. Manter apenas um `unified-shell` de navegação e CSS consistente. A barra interna da simulação deve ser um conjunto de abas no conteúdo, não um dock flutuante competindo com a navegação global.
4. Consolidar o resultado no código-fonte e testar Chrome Android em telas estreitas, em vez de adicionar regras `!important` em cascata.
5. Preparar commit testado, gerar release e fazer deploy com backup. O serviço atual usa um volume; não substituí-lo.
