# Emerald Living World 3.0.3 — Interface Premium Unificada

- Identidade premium comum nas páginas do jogo e nas páginas institucionais.
- Menu flutuante unificado existente preservado.
- Barra superior com identificação da área e botão **Explorar**.
- Busca rápida de todas as áreas (atalhos `/` e `Ctrl+K`), navegação por teclado, foco visível, pesquisa com filtro e fechamento via Esc.
- Acessos rápidos premium na Central: Mundo, Arena e Pokédex.
- Harmonização por temas: esmeralda, dourado Arena, violeta Frontier, azul Jornada, verde Pokédex, turquesa Mapas e tons de ouro nas estatísticas.
- Layout adaptado para celular e respeito à preferência de movimento reduzido.
- Segurança: sem mudanças no login, nas configurações Supabase, nos saves ou na lógica de combate/captura.

## Observações
A interface é uma camada de apresentação progressiva em CSS/JS; ela não deve alterar IDs dos elementos do jogo nem assumir que recursos em laboratório já estão completos.
