# Emerald Living World — pacote completo para transferência e correção

**Objetivo:** enviar todos os arquivos-base do projeto para o ambiente onde o jogo foi desenvolvido, junto com a última correção local do motor (3.0.7) e uma especificação do que deve ser revisado.

## O que este ZIP contém, exatamente

- Todos os arquivos da distribuição completa **3.0.3**: HTML, CSS, JavaScript, sprites/recursos, servidores Node.js, testes, scripts, modos, Arena e Battle Frontier LAB.
- As **três alterações do motor 3.0.7** aplicadas aos arquivos `jogo/js/engine.js`, `jogo/js/personal-landing.js` e `jogo/js/world.js`: o modo de treinador deixa de exigir comandos constantes, o início do modo pessoal solicita 20 treinadores em modo misto, e o contador da cena diferencia IAs próximas de IAs globais.
- `PEDIDO_COMPLETO_PARA_DESENVOLVEDOR.md`: escopo completo de funcionalidades, novidades e bugs em aberto.
- `CAMADAS_UI_PUBLICADAS_NA_RAILWAY.md`: referências para os patches visuais 3.0.4–3.0.6 que foram aplicados por scripts no servidor e não são parte nativa desta distribuição.

**Importante:** este ZIP é um pacote-fonte de transferência, **não uma extração binária exata do container Railway**. O servidor público aplica camadas adicionais de interface na inicialização por meio de arquivos do GitHub. Essas camadas são identificadas no documento de referências; elas precisam ser consolidadas ou substituídas, não empilhadas novamente.

## Status das funcionalidades

- Existe código para as páginas, modos, autenticação e simulação, mas **o usuário reportou problemas reais** no login, no movimento de IAs, na exibição de Pokémon na Arena e na interface mobile. Os testes automatizados não equivalem à validação de uso real no navegador.
- **Não desative a autenticação ou as proteções de saves** para contornar erros de login. A entrada por Google exige configuração OAuth no Supabase/Google Cloud; um botão de interface não ativa o provedor automaticamente.
- A campanha, as regras Gen III e a Frontier LAB são **adaptações parciais**, não uma cópia completa e fiel do jogo Pokémon Emerald nem uma homologação de PvP público.

## Como rodar e verificar

Requer **Node.js 20+** e servidor ativo; **não basta abrir `index.html` sozinho**.

```sh
npm test
npm run audit:preservation
npm start
```

Acesse `http://localhost:8787/jogo/portal.html` ou `http://localhost:8787/jogo/index.html`, de acordo com o modo. Para o mundo online em produção, configure `AUTH_MODE=required`, `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, `HOST`, `DATA_DIR` e HTTPS corretamente.

## Saves e segurança

- **Faça backup antes de qualquer publicação** do volume Railway `/data` (`world.json` e backups) e das tabelas Supabase usadas pelo projeto. Não apague perfis nem bases durante uma atualização de interface.
- O ZIP não contém chaves secretas, senhas de jogadores nem arquivos `.env` de produção.
- O repositório principal é `https://github.com/a94330028-cell/emerald-living-world`, e o serviço atual está em `https://emerald-node-production.up.railway.app`.
- O mundo persistente em Railway deve ter **uma única réplica**, pois utiliza escrita em arquivo no volume.

## Verificações realizadas nesta exportação

- `node --check` dos três arquivos de JavaScript modificados: aprovado.
- `npm test`: **291 testes passaram; zero falhas**.
- `npm run audit:preservation`: **8 arquivos protegidos preservados**.
- **Ainda faltam** testes de ponta a ponta reais em Android para login, movimento contínuo das IAs, cards de espécies da Arena e todos os menus.

**Leia também:** `PEDIDO_COMPLETO_PARA_DESENVOLVEDOR.md` e `CAMADAS_UI_PUBLICADAS_NA_RAILWAY.md`.
