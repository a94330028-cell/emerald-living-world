# Emerald Living World 3.0.2 — Central Unificada

Acesso principal: `/jogo/portal.html`. Todos os modos são apresentados em um mesmo site com navegação e identidade visual contínuas. Login social Google disponível somente após ativação do provedor e configuração da URL de redirecionamento no Supabase. O cadastro por senha respeita as regras de confirmação configuradas no provedor.

# 🌿 Emerald Living World 3.0.1 — Edição jogável revisada

**Versão do pacote: 3.0.1.** É uma simulação e adaptação de Hoenn. O conteúdo não é uma cópia completa da ROM de Pokémon Emerald e o multiplayer público ainda não passou por homologação.

## O que você pode jogar

- Mundo compartilhado com treinador, até **100 bots configuráveis**, captura de Pokémon nacionais por habitat, batalhas e saves no servidor.
- Jornada adaptada por Hoenn: oito ginásios, Liga Pokémon com cinco adversários e registro de Campeão/Hall da Fama.
- Tate e Liza em batalha Double jogável.
- Battle Frontier **LAB**: sete instalações, Frontier Brains em confrontos adaptados, Tower, Dome, Palace, Arena, Factory, Pike e Pyramid; escolha de equipes, exploração e Frontier Pass de demonstração.
- Arena Competitiva separada, com o conteúdo anterior preservado.
- Catálogo de espécies, encontros e habitats originais protegido por hashes SHA-256.

## Como iniciar no computador

Requer **Node.js 20+**. Depois de extrair o ZIP:

```bash
npm run verify:local
npm start
```

Abra `http://127.0.0.1:8787/jogo/online.html`.

Páginas principais: `/jogo/index.html` (portal e simulação), `/jogo/online.html` (mundo compartilhado), `/jogo/campanha.html` (jornada), `/jogo/frontier.html` (Frontier LAB), `/jogo/arena.html` (Arena).

Para rodar com **12 bots** no computador de teste, copie `.env.local.example` para `.env` e execute `npm run start:env`. O arquivo `.env` não é enviado ao Git pelo `.gitignore`.

### Se estiver no Android

O ZIP é o código-fonte: **extrair o ZIP ou abrir apenas o HTML no celular não inicia o servidor multiplayer**. Para jogar o mundo compartilhado no Android, o backend Node precisa estar hospedado e acessível via HTTPS. Na hospedagem estática, apenas as partes que não precisam de servidor podem funcionar.

## Ambiente público e autenticação

- Para publicar: processo Node contínuo, disco persistente para saves, HTTPS, `AUTH_MODE=required`, chaves públicas do Supabase e testes reais de login.
- `.env.example` é um modelo de produção; não utilize `service_role`/secret no navegador nem no ZIP.
- `npm run audit:production` ainda retorna bloqueios até os testes de segurança, dispositivos e regras ficarem concluídos.
- Faça backup de `server/data/world.json` antes de instalar uma nova versão; não sobreponha a pasta de saves com arquivos de outro ZIP.

## Integridade e testes

`npm test` executa os testes. `npm run audit:preservation` verifica byte a byte, via SHA-256, os oito arquivos protegidos (nacional/habitats/capturas e Arena). `npm run smoke:local` confere respostas HTTP, sessão e páginas essenciais. O pacote não contém dados reais de jogadores.

## Limites conhecidos

- O motor Gen III não implementa todos os movimentos, itens, habilidades e exceções de Double/Multi. Algumas equipes usam golpes genéricos do catálogo ampliado.
- A Frontier LAB e seus Brains são jogáveis, mas não equivalentes aos scripts da ROM; **não são concedidos os Símbolos oficiais**.
- Nem todos os eventos, mapas ou diálogos oficiais de Hoenn foram recriados.
- PvP público e logins Supabase precisam de teste em produção. Este ZIP não altera a hospedagem existente.

Veja `LEIA_PRIMEIRO_3_0_1.md`, `PATCH_NOTES_3_0_1.md` e `CHECKLIST_LANCAMENTO_3_0_1.md`.
