# Emerald Living World 3.0.2 — Central Unificada

## O que mudou
- Nova Central em `jogo/portal.html`, com acesso ao mesmo domínio para mundo, simulação, Arena, Frontier, Jornada, Pokédex, Mapas e Estatísticas.
- Barra persistente visual, responsiva e acessível, em páginas internas e institucionais.
- Cada área tem uma cor de destaque: Mundo (verde água), Simulação (verde), Arena (ouro), Frontier (violeta), Jornada (azul), Pokédex (verde claro), Mapas (turquesa), Estatísticas (coral).
- Nova Central de Conta em `jogo/entrar.html`, com login por senha e entrada social Google (depende de Google OAuth habilitado no Supabase).
- Login é compartilhado pela chave de sessão já usada pelo simulador e Mundo Online.
- Nunca finge cadastro concluído se o servidor não devolver sessão autenticada. Nenhuma política do Supabase, regras RLS ou autenticação do backend é desabilitada.
- Diretórios e arquivos de habitats, capturas, bots e Arena continuam preservados.

## Dependências do provedor
Para usar a entrada com Google sem aguardar e-mail do jogo, habilite um provedor social Google no Supabase, configure o OAuth com credenciais próprias, autorize o retorno `https://emerald-node-production.up.railway.app/jogo/entrar.html` em Auth > URL Configuration. A integração desta tarefa não permite editar as configurações de autenticação hospedada; não afirme que o provedor foi habilitado.

## Hospedagem
O serviço existente na Railway utiliza um ZIP de código fonte hospedado no GitHub. Atualizar este pacote local não altera automaticamente a implantação. Para atualizar a hospedagem, publique o ZIP revisado no repositório com acesso de escrita e verifique a implementação no Railway.

## Limites
A versão mantém as regras Gen III adaptadas e a Frontier LAB, não uma reprodução integral da ROM.
