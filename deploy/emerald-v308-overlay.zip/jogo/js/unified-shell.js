/* Shared, same-origin navigation across the Emerald World. No third-party scripts. */
(()=>{'use strict';
function init(){
  if(document.getElementById('elw-world-dock'))return;
  const source=document.querySelector('script[data-elw-unified]');
  const base=source?new URL('../',new URL(source.src)):new URL('/jogo/',location.href);
  const to=path=>new URL(path,base).href;
  const path=location.pathname.split('/').pop()||'index.html';
  const rootPage=!location.pathname.includes('/jogo/');

  const sectionMap={
    'portal.html':'hub',
    'index.html':rootPage?'hub':'simulacao',
    'online.html':'mundo',
    'campanha.html':'jornada',
    'arena.html':'arena',
    'frontier.html':'frontier',
    'quetzal-pokedex.html':'pokedex',
    'mapas-oficiais.html':'mapas',
    'estatisticas.html':'estatisticas',
    'entrar.html':'conta',
    'sobre.html':'hub',
    'atualizacoes.html':'hub',
    'privacidade.html':'hub'
  };
  const infoPages=new Set(['sobre.html','atualizacoes.html','privacidade.html','estatisticas.html']);
  const simpleAppPages=new Set(['campanha.html','frontier.html','mapas-oficiais.html','online.html']);
  const current=sectionMap[path]||'hub';

  document.body.dataset.elwSection=current;
  document.body.dataset.elwShellReady='1';
  document.body.dataset.elwLayout=infoPages.has(path)?'info':(path==='portal.html'?'portal':(path==='entrar.html'?'account':(simpleAppPages.has(path)?'simple-app':'app')));

  const pageMeta={
    hub:{label:'Central',icon:'🏡',blurb:'O mesmo Emerald Living World em um só lugar.'},
    simulacao:{label:'Simulação',icon:'🤖',blurb:'Observe as IAs, o mapa e as jornadas automáticas de Hoenn.'},
    mundo:{label:'Mundo',icon:'🌍',blurb:'Entre no mundo compartilhado e acompanhe progresso em tempo real.'},
    jornada:{label:'Jornada',icon:'📖',blurb:'Veja sua campanha de Hoenn e o avanço até a Liga.'},
    arena:{label:'Arena',icon:'⚔️',blurb:'Monte times, batalhe e suba no Elo.'},
    frontier:{label:'🏆 Frontier',icon:'🏆',blurb:'Desafios especiais inspirados na Battle Frontier.'},
    pokedex:{label:'Pokédex',icon:'📗',blurb:'Espécies, dados e habitats em um catálogo próprio.'},
    mapas:{label:'Mapas',icon:'🗺️',blurb:'Consulte rotas e áreas conectadas de Hoenn.'},
    estatisticas:{label:'Estatísticas',icon:'📊',blurb:'Veja números da comunidade e do progresso agregado.'},
    conta:{label:'Conta',icon:'👤',blurb:'Uma conta para acessar todos os modos.'}
  };

  const makeLink=(kind,label,url)=>{
    const el=document.createElement('a');
    el.href=to(url);
    el.setAttribute('aria-label',label);
    if(kind===current)el.setAttribute('aria-current','page');
    return el;
  };

  const links=[
    ['hub','🏡','Central','portal.html'],
    ['mundo','🌍','Mundo','online.html'],
    ['simulacao','🤖','Simulação','index.html#jogo'],
    ['arena','⚔️','Arena','arena.html'],
    ['frontier','🏆','Frontier','frontier.html']
  ];

  const nav=document.createElement('nav');
  nav.id='elw-world-dock';
  nav.className='elw-dock';
  nav.setAttribute('aria-label','Navegação principal do Emerald Living World');

  links.forEach(([kind,icon,label,url])=>{
    const el=makeLink(kind,label,url);
    const ico=document.createElement('span');
    ico.className='elw-ico';
    ico.setAttribute('aria-hidden','true');
    ico.textContent=icon;
    const txt=document.createElement('span');
    txt.className='elw-label';
    txt.textContent=label;
    el.append(ico,txt);
    nav.append(el);
  });

  const menu=document.createElement('aside');
  menu.id='elw-extra-pages';
  menu.className='elw-menu';
  menu.hidden=true;
  menu.setAttribute('aria-label','Outras áreas do Emerald');

  const heading=document.createElement('h2');
  heading.textContent='🌿 Navegação completa';
  menu.append(heading);

  const grid=document.createElement('div');
  grid.className='elw-menu-grid';
  [
    ['📖','Jornada','campanha.html'],
    ['📗','Pokédex','quetzal-pokedex.html'],
    ['🗺️','Mapas','mapas-oficiais.html'],
    ['📊','Estatísticas','estatisticas.html'],
    ['👤','Minha conta','entrar.html'],
    ['📰','Atualizações','../atualizacoes.html'],
    ['ℹ️','Sobre','../sobre.html'],
    ['🔐','Privacidade','../privacidade.html']
  ].forEach(([icon,label,url])=>{
    const el=makeLink('',label,url);
    el.innerHTML='<span class="menu-icon" aria-hidden="true">'+icon+'</span><span><strong>'+label+'</strong></span>';
    grid.append(el);
  });
  menu.append(grid);

  const hint=document.createElement('small');
  hint.textContent='Menu unificado premium · uma identidade visual para todas as páginas.';
  menu.append(hint);

  const more=document.createElement('button');
  more.className='elw-more';
  more.type='button';
  more.setAttribute('aria-label','Abrir outras áreas');
  more.setAttribute('aria-expanded','false');
  more.setAttribute('aria-controls','elw-extra-pages');
  more.innerHTML='<span class="elw-ico" aria-hidden="true">☰</span><span class="elw-label">Mais</span>';

  const toggle=flag=>{
    menu.hidden=!flag;
    more.setAttribute('aria-expanded',String(flag));
  };
  more.addEventListener('click',()=>toggle(menu.hidden));
  nav.append(more);
  document.body.append(menu,nav);

  document.addEventListener('keydown',e=>{if(e.key==='Escape')toggle(false)});
  document.addEventListener('pointerdown',e=>{if(!menu.hidden&&!menu.contains(e.target)&&!more.contains(e.target))toggle(false)});

  if(infoPages.has(path)){
    const meta=pageMeta[current]||pageMeta.hub;
    const main=document.querySelector('main');
    if(main&&!main.querySelector('.elw-page-banner')){
      const banner=document.createElement('section');
      banner.className='elw-page-banner';
      banner.innerHTML='\
        <div class="elw-page-banner-copy">\
          <span class="elw-banner-kicker">'+meta.icon+' INTERFACE UNIFICADA</span>\
          <h2>'+meta.label+'</h2>\
          <p>'+meta.blurb+'</p>\
        </div>\
        <div class="elw-banner-links">\
          <a href="'+to('portal.html')+'">Central Emerald</a>\
          <a href="'+to('entrar.html')+'">Minha conta</a>\
          <a href="https://discord.gg/6r9w3kA4sh" target="_blank" rel="noopener noreferrer">Discord</a>\
        </div>';
      main.prepend(banner);
    }
  }
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
