import catalog from '../arena/species.mjs';
import {createBattle,validTeam,moves,active,alive,resolveTurn,pickBotAction,eloChange,division} from '../arena/core.mjs';
const $=id=>document.getElementById(id);
const byId=new Map(catalog.map(s=>[s[0],s]));
const slots={format:6,team:[6,9,25,94,130,448],mode:'bot',bot:null,online:null,waiting:false,busy:false,tab:'build',rankLoaded:false};
const preferenceKey='elw_arena_preferences_v36';
const owner=()=>window.ELWLocalSlots?.currentOwner?.()||'guest';
const storageKey=()=>`elw_arena_record_v36:${owner()}`;
const defaultRecord=()=>({rating:1000,wins:0,losses:0,draws:0,history:[]});
function record(){try{return {...defaultRecord(),...JSON.parse(localStorage.getItem(storageKey())||'null')}}catch{return defaultRecord()}}
function saveRecord(v){try{localStorage.setItem(storageKey(),JSON.stringify(v))}catch{}}
function savePreferences(){try{localStorage.setItem(preferenceKey,JSON.stringify({format:slots.format,team:slots.team,nick:$('arenaNick').value}))}catch{}}
function escapeHtml(x){return String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function art(s){
 const [first,...fallbacks]=window.EmeraldPokemonArt.sources(s[1],{dex:s[0],light:true});
 return `<img src="${first}" width="70" height="70" alt="${escapeHtml(s[1])}" loading="lazy" decoding="async" data-fallbacks="${fallbacks.join(' ')}">`;
}
function artId(id){return art(byId.get(id)||[id,'Pokémon'])}
function showTab(tab){slots.tab=tab;document.querySelectorAll('[data-tab]').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.tab===tab)));
 document.querySelectorAll('[data-panel]').forEach(el=>el.hidden=el.dataset.panel!==tab);
 if(tab==='rating')refreshRating();scrollTo({top:0,behavior:'smooth'});
}
function notice(text){$('arenaLaunchStatus').textContent=text;}
function showCount(){const ok=validTeam(slots.team,slots.format,catalog);$('teamCount').textContent=`${slots.team.length}/${slots.format}`;
 $('arenaLaunch').disabled=!ok||slots.busy||slots.waiting||Boolean(slots.online&&!slots.online.finished);
 if(!ok)notice(`Selecione ${slots.format} Pokémon diferentes para batalhar.`);
 else if(!slots.busy&&!slots.waiting&&!slots.online)notice(slots.mode==='online'?'O PvP requer uma conta autenticada.':'Seu time está pronto para batalhar.');
}
function paintTeam(){const html=Array.from({length:slots.format},(_,i)=>{const id=slots.team[i],spec=byId.get(id);return `<button type="button" class="teamSlot ${spec?'filled':''}" ${spec?`data-remove="${i}" title="Remover ${escapeHtml(spec[1])}"`:''}>
 ${spec?art(spec):'<b>＋</b>'}<span>${spec?escapeHtml(spec[1]):'Vazio '+(i+1)}</span></button>`;}).join('');$('arenaSlots').innerHTML=html;
 $('arenaSlots').querySelectorAll('[data-remove]').forEach(b=>b.addEventListener('click',()=>{slots.team.splice(Number(b.dataset.remove),1);paintTeam();paintSearch();savePreferences();}));showCount();
}
const batchSize=24;
let visibleSpecies=batchSize;
function paintSearch(){
 const query=$('arenaSearch').value.trim().toLocaleLowerCase('pt-BR');
 const matches=query?catalog.filter(s=>s[1].toLocaleLowerCase('pt-BR').includes(query)||s[0]===Number(query.replace(/^#/,''))):catalog;
 const entries=matches.slice(0,visibleSpecies);
 $('arenaTotal').textContent=matches.length?`${entries.length} de ${matches.length.toLocaleString('pt-BR')} espécies`:'Nenhuma espécie encontrada';
 $('arenaMore').hidden=entries.length===matches.length;
 $('arenaSpecies').innerHTML=entries.map(s=>`<button class="speciesButton" data-species="${s[0]}" ${slots.team.includes(s[0])||slots.team.length>=slots.format?'disabled':''}>${art(s)}<strong>${escapeHtml(s[1])}</strong><small>#${String(s[0]).padStart(3,'0')}</small></button>`).join('');
}

function randomize(){const ids=catalog.map(x=>x[0]);for(let i=ids.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[ids[i],ids[j]]=[ids[j],ids[i]]}slots.team=ids.slice(0,slots.format);paintTeam();paintSearch();savePreferences();}
function suggest(){const pool=[6,9,3,25,94,130,448,149,376,282,257,260,250,334,445,700];slots.team=pool.slice(0,slots.format);paintTeam();paintSearch();savePreferences();}
function setMode(mode){slots.mode=mode;document.querySelectorAll('[data-mode]').forEach(b=>b.classList.toggle('active',b.dataset.mode===mode));$('botDifficultyWrap').hidden=mode==='online';
 $('arenaLaunch').textContent=mode==='bot'?'🤖 Batalhar contra bot':'🌍 Procurar adversário real';showCount();
}
function myRecord(){const r=record();$('arenaLocalElo').textContent=r.rating;$('arenaLocalDivision').textContent=division(r.rating);$('arenaLocalRecord').textContent=`${r.wins} vitórias · ${r.losses} derrotas`;
 $('arenaHistory').innerHTML=r.history.length?r.history.map(h=>`<div class="historyRow"><b>${escapeHtml(h.result)}</b><span>${escapeHtml(h.opponent)} · <small>${escapeHtml(h.time)}</small></span></div>`).join(''):'<p>Nenhuma batalha contra bot registrada neste aparelho.</p>';
}
function applyBotOutcome(battle){if(!battle||battle.winner===null||slots.bot?.recorded)return;
 const result=battle.winner===0?1:battle.winner===1?0:.5,r=record(),eloBot={easy:850,normal:1000,hard:1200}[$('botDifficulty').value]||1000;
 r.rating=Math.max(100,r.rating+eloChange(r.rating,eloBot,result));
 if(result===1)r.wins++;else if(result===0)r.losses++;else r.draws++;
 r.history.unshift({result:result===1?'Vitória':result===0?'Derrota':'Empate',opponent:'Bot · '+$('botDifficulty').selectedOptions[0].textContent,time:new Date().toLocaleDateString('pt-BR')});r.history=r.history.slice(0,20);
 saveRecord(r);slots.bot.recorded=true;myRecord();
}
const localBattle=()=>slots.bot?.battle||null;
function botStart(){const team=[...slots.team],pool=catalog.map(x=>x[0]).filter(id=>!team.includes(id));
 pool.sort(()=>Math.random()-.5);const opponents=pool.slice(0,slots.format);
 slots.bot={battle:createBattle(team,opponents,catalog),recorded:false};slots.online=null;slots.waiting=false;showTab('battle');renderBattle();
}
function updateScene(side,battle,mine,oppName){const s=battle.sides[side],mon=active(s);if(!mon)return;
 $(side===mine?'combatMine':'combatOther').innerHTML=`<strong>${escapeHtml(oppName)}</strong><small>${escapeHtml(mon.name)} · Nível 50</small>${artId(mon.id)}<div class="healthBar"><span style="width:${Math.round(100*mon.hp/mon.maxHp)}%"></span></div><small>${mon.hp} / ${mon.maxHp} HP</small><div class="teamAlive">${s.team.filter(m=>m.hp>0).length} Pokémon restantes</div>`;
}
function renderBattle(){const data=slots.online,online=!!data,waiting=slots.waiting,bat=online?data.battle:localBattle();const finished=bat?.winner!==null;
 $('matchWaiting').hidden=!waiting;$('matchArena').hidden=waiting||!bat;
 if(waiting){$('battleTitle').textContent='Fila ranqueada · jogadores reais';$('battleNotice').textContent='Procurando um jogador do mesmo formato. A busca não usa bots.';return;}
 if(!bat){$('battleNotice').textContent='Monte seu time e escolha um adversário na aba Montar time.';$('battleTurn').textContent='Rodada —';return;}
 const mine=online?data.side:0,other=1-mine;const names=online?data.users.map(x=>x.name):[$('arenaNick').value||'Você','Treinador IA'];
 if(online){const rating=data.users?.[mine]?.rating;if(Number.isInteger(rating)){$('arenaMyRating').textContent=rating;$('arenaMyDivision').textContent=division(rating)+' · PvP';}}
 $('battleTitle').textContent=online?'⚔️ Partida PvP ranqueada':'⚔️ Batalha contra bot';$('battleLabel').textContent=online?'🌍 ONLINE · ELO MUNDIAL':'🤖 BOT · ELO LOCAL';$('battleTurn').textContent=`Rodada ${bat.turn}`;
 updateScene(mine,bat,mine,names[mine]);updateScene(other,bat,mine,names[other]);
 const side=bat.sides[mine],mon=active(side),canAct=!finished&&(!online||!data.hasSubmitted)&&!slots.busy;
 $('battleNotice').textContent=finished?(bat.winner===-1?'Empate!':bat.winner===mine?'🏆 Você venceu!':'Você perdeu. Tente outra estratégia!')+(online&&Number.isInteger(data.ratingDelta)?` · ${data.ratingDelta>=0?'+':''}${data.ratingDelta} Elo`:''):
 online&&data.hasSubmitted?'Ação enviada. Aguardando a decisão do adversário.':'Escolha um ataque ou troque de Pokémon.';
 $('combatMoves').innerHTML=moves(mon).map((m,i)=>`<button type="button" data-attack="${i}" ${canAct&&mon.hp>0?'':'disabled'}>${escapeHtml(m.name)}<small>${escapeHtml(m.type)} · Poder ${m.power}${m.priority?' · prioridade':''}</small></button>`).join('');
 $('combatSwitch').innerHTML=side.team.map((m,i)=>`<button type="button" data-switch="${i}" ${canAct&&m.hp>0&&i!==side.active?'':'disabled'}>${artId(m.id)}<span>${escapeHtml(m.name)}</span></button>`).join('');
 $('combatMoves').querySelectorAll('[data-attack]').forEach(b=>b.addEventListener('click',()=>takeAction({kind:'attack',move:Number(b.dataset.attack)})));
 $('combatSwitch').querySelectorAll('[data-switch]').forEach(b=>b.addEventListener('click',()=>takeAction({kind:'switch',to:Number(b.dataset.switch)})));
 $('combatLog').innerHTML=(bat.log||[]).slice(-16).reverse().map(l=>`<p>${escapeHtml(l)}</p>`).join('');
 $('arenaRematch').hidden=!finished;$('arenaConcede').disabled=finished||slots.busy;
}
async function takeAction(act){if(slots.busy)return;slots.busy=true;
 try{
  if(slots.online){slots.online=await onlineRequest('move',{id:slots.online.id,move:act});}
  else if(slots.bot){const current=slots.bot.battle;
   const cpu=pickBotAction(current,1,$('botDifficulty').value);
   slots.bot.battle=resolveTurn(current,act,cpu);applyBotOutcome(slots.bot.battle);
  }
 }catch(e){$('battleNotice').textContent='⚠️ '+e.message;}finally{slots.busy=false;renderBattle();}
}
function apiAddress(action,id){const base=window.EMERALD_CLOUD_CONFIG?.supabaseUrl?.replace(/\/$/,'')+'/functions/v1/arena-online';const q=new URLSearchParams();if(action)q.set('action',action);if(id)q.set('id',id);return base+'?'+q.toString();}
async function onlineRequest(action,body=null,matchId=null){const cfg=window.EMERALD_CLOUD_CONFIG;
 if(!cfg?.supabaseAnonKey||!cfg?.supabaseUrl)throw Error('Supabase não configurado.');
 const session=window.ELWLocalSlots?.session?.();const needsAuth=action!=='leaderboard';
 if(needsAuth&&(!session||!session.access_token))throw Error('Entre na sua conta no site para usar PvP online.');
 if(needsAuth&&session.expires_at*1000<Date.now()+15000)throw Error('Sessão vencida. Faça login novamente pela página Conta.');
 const response=await fetch(apiAddress(body?'':action,matchId),{method:body?'POST':'GET',headers:{apikey:cfg.supabaseAnonKey, ...(needsAuth?{Authorization:'Bearer '+session.access_token}:{}), ...(body?{'Content-Type':'application/json'}:{})},...(body?{body:JSON.stringify({action,...body})}:{})});
 const result=await response.json().catch(()=>({error:'Resposta inesperada'}));if(!response.ok)throw Error(result.error||'Falha na conexão com o servidor');return result;
}
async function joinOnline(){if(slots.busy||slots.waiting)return;slots.busy=true;showCount();notice('Conectando à fila online...');
 try{const result=await onlineRequest('join',{team:slots.team,format:slots.format,name:$('arenaNick').value||'Treinador'});
  slots.waiting=result.status==='waiting';slots.online=result.status==='matched'?result:null;
  showTab('battle');renderBattle();
 }catch(e){slots.waiting=false;slots.online=null;notice('⚠️ '+e.message);showTab('build');}finally{slots.busy=false;showCount()}
}
async function poll(){if(document.hidden||slots.busy||!(slots.waiting||slots.online&&!slots.online.finished))return;
 try{const r=await onlineRequest('status',null,slots.online?.id||null);if(r.status==='matched'){slots.waiting=false;slots.online=r;renderBattle();}else if(slots.waiting&&r.status==='idle'){slots.waiting=false;renderBattle();}
 }catch(e){$('battleNotice').textContent='⚠️ '+e.message;}
}
async function cancelQueue(){try{await onlineRequest('cancel',{id:null});slots.waiting=false;slots.online=null;renderBattle();showTab('build')}catch(e){$('battleNotice').textContent=e.message}}
async function concede(){if(!confirm('Deseja desistir desta partida?'))return;
 if(slots.online){try{slots.online=await onlineRequest('concede',{id:slots.online.id});renderBattle()}catch(e){$('battleNotice').textContent=e.message}return}
 if(slots.bot&&!slots.bot.recorded){slots.bot.battle.winner=1;slots.bot.battle.log.push('Você desistiu da batalha.');applyBotOutcome(slots.bot.battle);renderBattle();}
}
async function refreshRating(){myRecord();if(slots.rankLoaded&&slots.tab!=='rating')return;
 slots.rankLoaded=true;try{
  const r=await onlineRequest('leaderboard');const entries=r.players||[];
  $('arenaLeaderboard').innerHTML=entries.length?entries.map((x,i)=>`<div class="leaderRow"><strong>${i+1}º</strong><span>${escapeHtml(x.display_name)}<small>${x.wins}V · ${x.losses}D · ${x.draws}E · ${escapeHtml(division(x.rating))}</small></span><b>${x.rating} Elo</b></div>`).join(''):'<p>O ranking ainda está vazio. Seja o primeiro a disputar uma partida PvP!</p>';
  const me=window.ELWLocalSlots?.session?.()?.user?.id;
  // O backend não expõe IDs ou e-mails de outros jogadores nas classificações públicas.
  const myElo=slots.online?.users?.[slots.online.side]?.rating;
  $('arenaMyRating').textContent=Number.isInteger(myElo)?String(myElo):'1000';
  $('arenaMyDivision').textContent=me?division(myElo||1000)+' · PvP':'Bronze · entre na conta';
 }catch(e){$('arenaLeaderboard').innerHTML='<p>Ranking online indisponível: '+escapeHtml(e.message)+'</p>'}
}
document.addEventListener('error',event=>{
 const img=event.target;
 if(!img.dataset?.fallbacks)return;
 const [next,...remaining]=img.dataset.fallbacks.split(' ');
 img.dataset.fallbacks=remaining.join(' ');
 img.src=next;
},true);

function setup(){const saved=(()=>{try{return JSON.parse(localStorage.getItem(preferenceKey))||{}}catch{return {}}})();
 if([1,3,6].includes(Number(saved.format)))slots.format=Number(saved.format);
 if(Array.isArray(saved.team))slots.team=[...new Set(saved.team.filter(id=>byId.has(id)))].slice(0,slots.format);
 else slots.team=slots.team.slice(0,slots.format);
 $('arenaFormat').value=String(slots.format);$('arenaNick').value=String(saved.nick||'Treinador').slice(0,24);
 $('arenaTheme').textContent=document.documentElement.dataset.pokeTheme==='dark'?'☀️ Claro':'🌙 Escuro';
 $('arenaTheme').addEventListener('click',()=>{const next=document.documentElement.dataset.pokeTheme==='dark'?'emerald':'dark';document.documentElement.dataset.pokeTheme=next;localStorage.setItem('elw_visual_theme_25',next);$('arenaTheme').textContent=next==='dark'?'☀️ Claro':'🌙 Escuro';});
 document.querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>showTab(b.dataset.tab)));
 $('arenaFormat').addEventListener('change',()=>{slots.format=Number($('arenaFormat').value);slots.team=slots.team.slice(0,slots.format);paintTeam();paintSearch();savePreferences();});
 $('arenaNick').addEventListener('change',savePreferences);$('arenaSearch').addEventListener('input',()=>{visibleSpecies=batchSize;paintSearch()});
 $('arenaMore').addEventListener('click',()=>{visibleSpecies+=batchSize;paintSearch()});
 $('arenaSpecies').addEventListener('click',event=>{
  const button=event.target.closest('[data-species]');
  if(!button||button.disabled)return;
  const id=Number(button.dataset.species);
  if(slots.team.includes(id)||slots.team.length>=slots.format)return;
  slots.team.push(id);paintTeam();paintSearch();savePreferences();
 });
 $('arenaRandom').addEventListener('click',randomize);$('arenaSuggested').addEventListener('click',suggest);
 $('arenaClear').addEventListener('click',()=>{slots.team=[];paintTeam();paintSearch();savePreferences()});
 document.querySelectorAll('[data-mode]').forEach(b=>b.addEventListener('click',()=>setMode(b.dataset.mode)));
 $('arenaLaunch').addEventListener('click',()=>slots.mode==='bot'?botStart():joinOnline());
 $('arenaCancelQueue').addEventListener('click',cancelQueue);$('arenaConcede').addEventListener('click',concede);
 $('arenaRematch').addEventListener('click',()=>{slots.online=null;slots.bot=null;slots.waiting=false;showTab('build');showCount()});
 $('arenaRefreshRank').addEventListener('click',()=>{slots.rankLoaded=false;refreshRating()});
 paintTeam();paintSearch();setMode('bot');myRecord();
 // Poll only when a live online match or queue exists, never for the offline mode.
 setInterval(poll,3000);
}
setup();
