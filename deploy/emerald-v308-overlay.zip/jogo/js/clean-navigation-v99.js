/* Emerald Living World 9.9 — purely presentational views of existing saved teams.
 * No writes to Pokémon, badges, battles, or legacy saves. */
(()=>{'use strict';
const $=id=>document.getElementById(id);
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const all=()=>Array.isArray(window.emeraldTrainers)?window.emeraldTrainers:[];
const solo=()=>document.body.dataset.worldMode==='player';
const ownBot=()=>window.emeraldMyBot?.()||all().find(t=>t.isUserBot)||all()[0];
const selected=()=>solo()?ownBot():(all().find(t=>t.id===Number($('pokemonTrainerPicker')?.value))||all()[Number(window.emeraldExport?.()?.selected||0)]||all()[0]);
const monScore=m=>Math.max(0,Math.round(Number(window.emeraldPower?.(m)||0)));
const teamScore=t=>Math.max(0,Math.round(Number(window.emeraldStrength?.(t)||0)));
const path=name=>'assets/pokemon_fit/'+encodeURIComponent(String(name).toLowerCase())+'.png';
const image=(species,cls='')=>`<img class="${cls}" data-clean-mon="${esc(species)}" src="${path(species)}" alt="${esc(species)}" loading="lazy" decoding="async">`;
let catalogPromise=null;
function applyArt(root){
 if(!root)return;
 const art=window.EmeraldPokemonArt;
 const paint=()=>root.querySelectorAll('img[data-clean-mon]').forEach(img=>{
  if(img.dataset.artApplied)return;
  img.dataset.artApplied='1';
  if(art?.apply)art.apply(img,img.dataset.cleanMon,{pixel:true,eager:false});
  else img.onerror=()=>{img.onerror=null;img.src='assets/ui/pokemon_missing.svg'};
 });
 if(!art?.loadCatalog){paint();return}
 if(!catalogPromise)catalogPromise=Promise.resolve().then(()=>art.loadCatalog()).catch(()=>null);
 catalogPromise.then(()=>{if(root.isConnected)paint()});
}
function fillTrainerSelect(){
 const selectEl=$('pokemonTrainerPicker'),wrapper=$('pokemonTrainerPickerWrap');if(!selectEl)return;
 wrapper.hidden=solo();if(solo())return;
 const list=all();const signature=list.map(t=>`${t.id}:${t.name}`).join('|');
 if(selectEl.dataset.trainers===signature)return;
 const prev=selectEl.value,def=window.emeraldExport?.()?.selected;
 selectEl.replaceChildren(...list.map(t=>{const o=document.createElement('option');o.value=String(t.id);o.textContent=t.name;return o}));
 selectEl.dataset.trainers=signature;
 selectEl.value=list.some(t=>String(t.id)===prev)?prev:String(list[Number(def)||0]?.id??list[0]?.id??0);
}
let lastPokemonKey='',lastWatchKey='',lastForceKey='';
function card(m){const hp=Math.max(0,Math.round(Number(m.hp)||0)),maxHp=Math.max(1,Math.round(Number(m.maxHp)||1));
 const details=window.EmeraldMonDetails?.html(m,{open:true})||'';
 return `<article class="cleanPokemonCard fullPokemonCard"><div class="cleanMonIdentity">${image(m.species)}<div><b>${esc(m.shiny?'✨ '+m.species:m.species)}</b><small>Nv. ${Math.round(m.level||1)} · ⚡ ${monScore(m)}</small><small>HP ${hp}/${maxHp}</small><meter min="0" max="${maxHp}" value="${Math.min(hp,maxHp)}" aria-label="Vida de ${esc(m.species)}"></meter></div></div>${details}</article>`;
}
function renderPokemon(){const target=$('pokemonTeamCards');if(!target||$('page-pokedex').hidden)return;
 fillTrainerSelect();const t=selected();
 const team=t?.team||[];
 const key=[solo(),t?.id,t?.name,team.map(m=>[m.species,m.level,m.hp,m.maxHp,m.atk,m.def,m.spAtk,m.spDef,m.speed,(m.moves||[]).join(','),JSON.stringify(m.pp||{})].join(':')).join('|')].join('|');
 if(key===lastPokemonKey)return;lastPokemonKey=key;
 $('pokemonTeamHeading').textContent=solo()?'Meu time Pokémon':'Equipe de '+(t?.name||'treinador');
 $('pokemonTeamMeta').textContent=`${team.length}/6 Pokémon · ${(t?.badges||0)}/8 insígnias`;
 target.innerHTML=team.length?team.slice(0,6).map(card).join(''):'<p class="cleanEmpty">A equipe aparecerá aqui depois que o treinador escolher seu primeiro Pokémon.</p>';
 applyArt(target);
}
function renderWatch(){
 const minis=$('watchPartyCards'),grid=$('watchFullTeamCards');
 if((!minis&&!grid)||$('gamePage').hidden)return;
 const world=window.emeraldExport?.(),t=world?.trainers?.[world.selected]||all()[0];
 const team=(t?.team||[]).slice(0,6);
 const key=[t?.id,t?.name,t?.badges,team.map(m=>[m.species,m.level,m.hp,m.maxHp,m.exp,m.atk,m.def,m.spAtk,m.spDef,m.speed,(m.moves||[]).join('~'),JSON.stringify(m.pp||{})].join(':')).join('|')].join('|');
 if(key===lastWatchKey)return;
 lastWatchKey=key;
 if($('watchFullTeamCount'))$('watchFullTeamCount').textContent=`${team.length}/6 Pokémon`;
 if(minis){
  minis.innerHTML=team.length?team.map(m=>`<div class="cleanMini">${image(m.species)}<b>${esc(m.species)}</b><small>Nv.${Math.round(m.level||1)}</small></div>`).join('')
   :'<p class="cleanEmpty">O treinador ainda não escolheu seu parceiro.</p>';
  applyArt(minis);
 }
 if(!grid)return;
 // Keep expanded stat panels open even when the simulation updates a Pokémon's HP.
 const expanded=new Set([...grid.querySelectorAll('details[data-team-slot]')].filter(d=>d.open).map(d=>d.dataset.teamSlot));
 const blocks=Array.from({length:6},(_,i)=>{
  const m=team[i];if(!m)return `<div class="homeMonEmpty"><span>+</span><small>Espaço ${i+1} vazio</small></div>`;
  const hp=Math.max(0,Number(m.hp)||0),maxHp=Math.max(1,Number(m.maxHp)||1),pct=Math.min(100,Math.max(0,Math.round(hp*100/maxHp)));
  const moves=(Array.isArray(m.moves)?m.moves:[]).slice(0,4);
  const chips=moves.length?moves.map(x=>`<span>${esc(x)}</span>`).join(''):'<span>Golpes ainda não registrados</span>';
  const stats=`<span>ATQ <b>${Math.round(Number(m.atk)||0)}</b></span><span>DEF <b>${Math.round(Number(m.def)||0)}</b></span><span>VEL <b>${Math.round(Number(m.speed)||0)}</b></span>`;
  const details=window.EmeraldMonDetails?.html(m)||'<p class="homeTeamNoDetails">Atributos não disponíveis.</p>';
  return `<article class="homeFullMon"><div class="homeMonTop">${image(m.species,'homeMonImage')}<div class="homeMonIdentity"><strong>${esc(m.shiny?'✨ '+m.species:m.species)}</strong><small>Nv. ${Math.round(Number(m.level)||1)} · Poder ${monScore(m).toLocaleString('pt-BR')}</small><small>HP ${Math.round(hp)} / ${Math.round(maxHp)}</small><div class="homeHpBar" role="progressbar" aria-label="HP de ${esc(m.species)}" aria-valuemin="0" aria-valuemax="${Math.round(maxHp)}" aria-valuenow="${Math.round(hp)}"><span style="width:${pct}%"></span></div></div></div><div class="homeMonStats">${stats}</div><div class="homeMoveChips" aria-label="Ataques de ${esc(m.species)}">${chips}</div><div class="homeMoreStats" data-team-details="${i}">${details}</div></article>`;
 }).join('');
 grid.innerHTML=blocks;
 for(const box of grid.querySelectorAll('[data-team-details]')){
  const d=box.querySelector('details');if(d){d.dataset.teamSlot=box.dataset.teamDetails;if(expanded.has(d.dataset.teamSlot))d.open=true;}
 }
 applyArt(grid);
}

// Two trainer-centered rankings: active team strength and actual story progression.
const rankingApi=()=>window.EmeraldTrainerRankings;
function renderForce(){
 const inRank=!$('page-ranking')?.hidden;
 if(!inRank)return;
 const data=rankingApi()?.ranks(all(),teamScore,10);
 if(!data)return;
 const signature=data.strength.map(x=>`${x.t.id}:${x.score}:${x.t.team?.map(m=>m.species+':'+m.level).join('|')}`).join(';')+'||'+data.story.map(x=>`${x.t.id}:${x.stage}:${x.round}:${x.badges}:${!!x.t.champion}`).join(';');
 if(signature===lastForceKey)return;lastForceKey=signature;
 const strengthRows=data.strength.map((x,i)=>{
  const party=(x.t.team||[]).slice(0,6);
  return `<article class="elwTrainerRow"><span class="elwRankMedal">${i+1}º</span><div class="elwTrainerBody"><div class="elwTrainerTitle"><strong>${esc(x.t.name||'Treinador')}</strong><b>${x.score.toLocaleString('pt-BR')} pts</b></div><small>🎒 ${party.length}/6 Pokémon · 🏅 ${Number(x.t.badges)||0}/8 insígnias</small><div class="elwMiniParty" aria-label="Time de ${esc(x.t.name||'treinador')}">${party.map(m=>image(m.species,'elwMiniPoke')).join('')}</div></div></article>`;
 }).join('')||'<p class="cleanEmpty">Os times aparecerão depois da escolha dos iniciais.</p>';
 const storyRows=data.story.map((x,i)=>
  `<article class="elwTrainerRow"><span class="elwRankMedal">${i+1}º</span><div class="elwTrainerBody"><div class="elwTrainerTitle"><strong>${esc(x.t.name||'Treinador')}</strong><b>${x.t.champion?'👑 Campeão':`Etapa ${x.stage+1}/28`}</b></div><small>${esc(x.chapter)} · 🏅 ${x.badges}/8 insígnias</small><div class="elwStoryBar" role="progressbar" aria-label="Progresso de ${esc(x.t.name||'treinador')}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${x.percent.toFixed(1)}"><span style="width:${x.percent.toFixed(2)}%"></span></div></div></article>`
 ).join('')||'<p class="cleanEmpty">Aguardando os treinadores iniciarem a jornada.</p>';
 const strengthTarget=$('rankStrongTeams'),storyTarget=$('rankStoryProgress');
 if(strengthTarget)strengthTarget.innerHTML=strengthRows;
 if(storyTarget)storyTarget.innerHTML=storyRows;
 applyArt(strengthTarget);
}
document.querySelectorAll('[data-elw-rank-scroll]').forEach(btn=>btn.addEventListener('click',()=>document.getElementById(btn.dataset.elwRankScroll)?.scrollIntoView({behavior:'smooth',block:'start'})));
$('rankBackToGame')?.addEventListener('click',()=>window.emeraldShowPage?.('jogo'));
$('pokemonTrainerPicker')?.addEventListener('change',()=>{
 const id=Number($('pokemonTrainerPicker').value);
 const t=all().find(x=>x.id===id);if(t)window.emeraldSelectTrainer?.(t.id);
 lastPokemonKey='';renderPokemon();
});
window.addEventListener('emerald:pagechange',e=>{
 if(e.detail.page==='pokedex'){lastPokemonKey='';renderPokemon()}
 if(e.detail.page==='forca'||e.detail.page==='ranking'){lastForceKey='';renderForce()}
 if(e.detail.page==='jogo'){lastWatchKey='';renderWatch()}
});
// The live simulation is already timer-based; refresh only the visible light panels.
setInterval(()=>{if(!document.hidden){renderPokemon();renderWatch();renderForce()}},1200);
renderPokemon();renderForce();
})();
