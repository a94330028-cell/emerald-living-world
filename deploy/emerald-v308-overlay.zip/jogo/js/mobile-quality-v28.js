(()=>{'use strict';const KEY='elw_quality_v28',opts=new Set(['auto','economy','high']);
 const read=()=>{try{const v=localStorage.getItem(KEY);return opts.has(v)?v:'auto'}catch{return 'auto'}};
 const select=document.getElementById('elwQuality'),info=document.getElementById('elwQualityStatus');
 function render(){const q=read();if(select)select.value=q;if(info)info.textContent=q==='economy'?'Até 15 FPS no mapa e sprites leves. A jornada continua no mesmo ritmo.':q==='high'?'Limite: 60 FPS quando o aparelho conseguir.':'Taxa adaptativa conforme dispositivo e número de IAs.'}
 select?.addEventListener('change',()=>{if(opts.has(select.value)){try{localStorage.setItem(KEY,select.value)}catch{}render();document.querySelectorAll('img[data-art-name]').forEach(img=>window.EmeraldPokemonArt?.apply(img,img.dataset.artName,{eager:false}))}});
 window.ELWQuality={get:read};render();
})();
