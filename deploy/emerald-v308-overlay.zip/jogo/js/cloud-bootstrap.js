/* Executado no <head> ANTES do motor: isola saves por conta neste navegador. */
(function(){'use strict';
 try{if(/^#(?:access_token|error)=/.test(location.hash))sessionStorage.setItem('elw_pending_auth_hash_v1',location.hash)}catch{}
 const KEYS=['emerald_living_world_v26','emerald_living_world_v25','emerald_living_world_v24','emerald_living_world_v23','emerald_living_world_v22','emerald_living_world_v21','emerald_living_world_v20','emerald_living_world_v19','emerald_human_campaign_v1','emerald_my_auto_bot_v2','emerald_v21_options','emerald_v2_world_setup','emerald_sim_view_v1','emerald_living_world_v8_records'];
 const OWNER='elw_active_save_owner_v1',SESSION='elw_cloud_session_v1',PREFIX='elw_local_slot_v1:';
 const safeGet=k=>{try{return localStorage.getItem(k)}catch{return null}};
 function capture(){const o={};for(const k of KEYS){const value=safeGet(k);if(value!==null)o[k]=value}return o}
 function store(who){try{localStorage.setItem(PREFIX+who,JSON.stringify(capture()));return true}catch(e){console.warn('Não foi possível proteger o save local:',e);return false}}
 function restore(who){let data={};try{data=JSON.parse(safeGet(PREFIX+who)||'{}')||{}}catch{}for(const k of KEYS){try{localStorage.removeItem(k);if(typeof data[k]==='string')localStorage.setItem(k,data[k])}catch(e){console.warn('Não foi possível restaurar a chave',k,e)}}}
 function switchOwner(who){who=who||'guest';let active=safeGet(OWNER)||'guest';if(active===who)return; if(!store(active))throw Error('Sem espaço para salvar a conta atual. Libere espaço no navegador antes de trocar de conta.');restore(who);localStorage.setItem(OWNER,who)}
 function currentOwner(){return safeGet(OWNER)||'guest'}
 function session(){try{const x=JSON.parse(safeGet(SESSION)||'null');return x?.user?.id&&x.access_token?x:null}catch{return null}}
 if(!safeGet(OWNER)){try{store('guest');localStorage.setItem(OWNER,'guest')}catch(e){console.warn(e)}}
 const existing=session();if(existing?.user?.id && currentOwner()!==existing.user.id){try{switchOwner(existing.user.id)}catch(e){console.warn(e)}}
 window.ELWLocalSlots={KEYS,SESSION,OWNER,capture,store,restore,switchOwner,currentOwner,session,hasGame:data=>!!(data?.emerald_living_world_v26||data?.emerald_human_campaign_v1||KEYS.some(k=>/^emerald_living_world_v2[0-5]$/.test(k)&&data?.[k]))};
 window.addEventListener('pagehide',()=>{try{store(currentOwner())}catch{}});
})();
