(()=>{'use strict';
const $=id=>document.getElementById(id);
const dlg=$('worldSetupDialog'),count=$('setupBotCount'),hint=$('setupPerfHint'),notice=$('setupActionStatus'),stats=$('setupWorldStats');
const modes=['mixed','watch','player'];
if(!dlg||!count||!window.emeraldStartWorld||!window.emeraldResizeBots)return;
const current=()=>dlg.querySelector('input[name="worldMode"]:checked')?.value||'mixed';
const storageRead=k=>{try{return localStorage.getItem(k)}catch{return null}};
const storageWrite=(k,v)=>{try{localStorage.setItem(k,v)}catch{}};
const getSave=()=>['26','25','24','23','22','21','20','19'].map(v=>storageRead('emerald_living_world_v'+v)).find(Boolean)||null;
const safePrefs=()=>({name:$('setupBotName')?.value,starter:$('setupStarter')?.value,goal:$('setupBotGoal')?.value,style:$('setupBotStyle')?.value});
const hasStarted=()=>storageRead('emerald_v2_world_setup')==='1';
function activate(mode){document.body.dataset.worldMode=mode;window.emeraldShowPage?.('jogo');}
function update(){const n=Number(count.value);hint.textContent=n===1?'Um treinador ativo: apenas seu bot toma decisões nesta jornada.':n>=80?'⚠️ 80–100 treinadores exigem mais do celular; os cálculos são distribuídos entre atualizações.':n>=40?'Com 40+ treinadores, o sistema distribui as decisões para reduzir travamentos.':'5 a 20 treinadores é a faixa mais leve para celular.';}
function refreshStats(){const n=window.emeraldTrainers?.length||0;const mode=window.emeraldOptions?.gameMode||'mixed';const names={mixed:'Seu bot + IAs',watch:'Só assistir',player:'Seu bot solo'};stats.textContent=`Mundo atual: ${n} treinadores · ${names[mode]||names.mixed}`;}
function updateStarterChoices(){const el=$('setupStarter'),names=window.EmeraldStarters?.ALL||[];
 if(!el||!names.length)return;const selected=el.value;el.replaceChildren(...names.map(name=>{const option=document.createElement('option');option.value=name;option.textContent=name+' · Geração '+window.EmeraldStarters.GENERATION[name];return option}));
 el.value=names.includes(selected)?selected:'Mudkip';}
updateStarterChoices();
function open(options={}){
 const pref=window.emeraldGetBotPrefs?.()||{};
 for(const [id,key] of [['setupBotName','name'],['setupStarter','starter'],['setupBotGoal','goal'],['setupBotStyle','style']]){const el=$(id);if(el&&pref[key])el.value=pref[key];}
 const n=Number(options.count||window.emeraldTrainers?.length||20);count.value=String([...count.options].some(x=>Number(x.value)===n)?n:20);
 const mode=window.emeraldOptions?.gameMode||'mixed';const radio=dlg.querySelector('input[name="worldMode"][value="'+mode+'"]');if(radio)radio.checked=true;
 refreshStats();update();notice.textContent=options.restart?'Escolha as opções e confirme em “Recomeçar mundo”.':'';
 $('setupClose').hidden=!(hasStarted()||!!getSave()||document.body.classList.contains('landing-active'));
 $('setupStart').textContent=(hasStarted()||!!getSave())?'↻ Recomeçar mundo':'🌿 Criar mundo e começar';
 if(!dlg.open)dlg.showModal();
}
function closeAndShow(mode){storageWrite('emerald_v2_world_setup','1');dlg.close();if(window.emeraldEnterWorld)window.emeraldEnterWorld(mode);else activate(mode);}
count.addEventListener('change',update);
$('setupClose').addEventListener('click',()=>{if(hasStarted()||getSave()||document.body.classList.contains('landing-active')){dlg.close();if(!document.body.classList.contains('landing-active')&&window.emeraldBootAuthorized&&window.emeraldPaused){window.emeraldResumeWorld?.();}}});
$('setupKeep').addEventListener('click',()=>{
 const n=Number(count.value),mode=current();if(!modes.includes(mode))return;
 try{
  const result=window.emeraldResizeBots(n);
  window.emeraldChooseMode(mode);
  window.emeraldSetMyBotSettings?.(safePrefs());
  closeAndShow(mode);
  if(result.changed){const toast=$('worldControlMessage');if(toast){toast.textContent=`✓ Modo atualizado · ${n} treinadores · progresso preservado`;toast.hidden=false;setTimeout(()=>{toast.hidden=true},3600)}}
 }catch(error){notice.textContent='Não foi possível aplicar: '+error.message;}
});
$('setupStart').addEventListener('click',()=>{
 const n=Number(count.value),mode=current();if(!modes.includes(mode))return;
 if((hasStarted()||getSave())&& !confirm(`Recomeçar o mundo com ${n} treinadores? As jornadas e insígnias das IAs (incluindo seu bot) serão zeradas. A campanha manual separada será preservada.`))return;
 try{
  // Primeiro guardar as escolhas; o reset cria o bot 0 com essas preferências.
  window.emeraldSetMyBotSettings?.(safePrefs());
  window.emeraldStartWorld(n,mode);
  window.emeraldSetMyBotSettings?.(safePrefs());
  closeAndShow(mode);
 }catch(error){notice.textContent='Não foi possível recomeçar: '+error.message;}
});
function wire(){
 $('openWorldSetup')?.addEventListener('click',()=>open());
 $('worldControlFab')?.addEventListener('click',()=>open());
 document.querySelectorAll('.openWorldControl').forEach(b=>b.addEventListener('click',()=>open()));
 document.querySelectorAll('.restartWorldControl').forEach(b=>b.addEventListener('click',()=>open({restart:true})));
}
wire();window.emeraldOpenWorldControl=open;
dlg.addEventListener('cancel',e=>{if(!hasStarted()&&!getSave()&&!document.body.classList.contains('landing-active'))e.preventDefault()});
if(!hasStarted()){if(!window.emeraldPaused)$('pause')?.click();if(!document.body.classList.contains('landing-active'))open();}
})();
