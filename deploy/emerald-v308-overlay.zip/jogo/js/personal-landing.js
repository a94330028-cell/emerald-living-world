(()=>{'use strict';
const $=id=>document.getElementById(id);
const panel=$('personalLanding');if(!panel)return;
// Reuse the ACTUAL canvas and overlay from V9.6: no static screenshot,
// duplicate renderer, or separate empty map. Moving DOM nodes preserves
// event listeners, draw state, official tile layers, and collision diagnostics.
const canvas=$('liveWorld');
const originalStage=canvas?.parentElement;
const originalAnchor=originalStage?.querySelector('#liveBattleCinema');
const sharedParts=[originalStage?.querySelector('.directorOverlay'),canvas,originalStage?.querySelector('.directorFooter')].filter(Boolean);
function placeWorld(where){
 const host=where==='landing'?$('landingMapMount'):where==='personal'?$('myBotMapMount'):originalStage;
 if(!host||sharedParts.length!==3)return false;
 const scenes=$('scenePreview');
 // The public entrance opens on decorated Littleroot, not on a random saved interior.
 // Entering a real journey clears the preview so the camera follows the trainer.
 if(scenes){
  if(where==='landing'&&[...scenes.options].some(o=>o.value==='Littleroot'))scenes.value='Littleroot';
  else if(where!=='landing'&&scenes.value==='Littleroot')scenes.value='';
 }
 for(const part of sharedParts){
  if(where==='world'){
   // The illustrated UI moves the battle broadcast out of the map stage.
   // Never use an anchor that is no longer a child; doing so throws and
   // strands the live canvas inside the hidden landing screen.
   const anchor=originalAnchor?.parentElement===originalStage
     ? originalAnchor : originalStage.querySelector('#classicMapReplan');
   originalStage.insertBefore(part,anchor||null);
  }else host.appendChild(part);
 }
 document.body.dataset.liveMapHost=where;
 window.requestAnimationFrame?.(()=>window.emeraldLiveDraw?.());
 return true;
}
window.emeraldPlaceSharedWorld=placeWorld;

const names=window.EmeraldStarters?.ALL||['Treecko','Torchic','Mudkip'];
const start=$('landingStarter');
for(const species of names){const item=document.createElement('option');item.value=species;item.textContent=species+' · Geração '+(window.EmeraldStarters?.GENERATION[species]||3);start.appendChild(item)}
const prefs=window.emeraldGetBotPrefs?.()||{};start.value=names.includes(prefs.starter)?prefs.starter:'Mudkip';
const saveExists=()=>{try{return ['26','25','24','23','22','21','20','19'].some(v=>!!localStorage.getItem('emerald_living_world_v'+v))}catch{return false}};
const modes=['player','watch','mixed'];
const viewKey='emerald_sim_view_v1';
const goPage=page=>window.emeraldShowPage?.(page);
function exit(mode){document.body.classList.remove('landing-active');panel.hidden=true;try{localStorage.setItem('emerald_v2_world_setup','1');localStorage.setItem(viewKey,mode)}catch{}
 window.ELWTelemetry?.event('session_play');document.body.dataset.worldMode=mode;goPage('jogo');placeWorld(mode==='player'?'personal':'world');window.scrollTo?.(0,0)
}
window.emeraldEnterWorld=mode=>exit(modes.includes(mode)?mode:'watch');
window.emeraldShowEntry=()=>{panel.hidden=false;document.body.classList.add('landing-active');placeWorld('landing');window.scrollTo?.(0,0)};
const continueButton=$('landingContinue');
function syncContinue(){if(continueButton)continueButton.hidden=!saveExists()}
syncContinue();
if(continueButton)continueButton.onclick=()=>{
 if(!saveExists()){$('landingMessage').textContent='Ainda não há uma jornada salva. Escolha Nova Jornada.';syncContinue();return;}
 try{const prior=localStorage.getItem(viewKey)||window.emeraldOptions?.gameMode;window.emeraldResumeWorld?.();exit(modes.includes(prior)?prior:'watch')}
 catch(e){$('landingMessage').textContent='Não foi possível continuar: '+e.message}
};
$('landingNew')?.addEventListener('click',()=>window.emeraldOpenWorldControl?.({restart:saveExists()}));
function beginSolo(){const hadSave=saveExists();if(!hadSave)window.ELWTelemetry?.event('campaign_start');
 try{
  if(hadSave){if((window.emeraldTrainers?.length||0)<20)window.emeraldResizeBots?.(20);window.emeraldChooseMode('mixed');window.emeraldSetMyBotSettings?.({...prefs,...window.emeraldGetBotPrefs?.(),starter:start.value});}
  else{window.emeraldSetMyBotSettings?.({...prefs,starter:start.value});window.emeraldStartWorld(20,'mixed');window.emeraldSetMyBotSettings?.({...prefs,starter:start.value})}
  exit('player');
 }catch(e){$('landingMessage').textContent='Não consegui começar: '+e.message}
}
function beginWorld(){const hadSave=saveExists();if(!hadSave)window.ELWTelemetry?.event('campaign_start');try{
 if(hadSave)window.emeraldChooseMode('watch');else window.emeraldStartWorld(20,'watch');
 exit('watch');
 }catch(e){$('landingMessage').textContent='Não consegui começar: '+e.message}
}
$('landingSolo').onclick=beginSolo;$('landingWorld').onclick=beginWorld;
$('landingSettings').onclick=()=>{window.emeraldOpenWorldControl?.();};
// Changing mode later (or returning from settings) never strands the canvas.
document.addEventListener('click',event=>{
 const page=event.target.closest?.('[data-page]')?.dataset.page;
 if(page==='jogo'||page==='jogador')placeWorld(document.body.dataset.worldMode==='player'?'personal':'world');
});
placeWorld('landing');
// Entry screen intentionally stays minimal. Engine and saves remain available underneath.
})();
