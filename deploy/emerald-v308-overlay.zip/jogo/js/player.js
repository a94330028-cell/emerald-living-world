/* Emerald Living World - campanha jogável (sem backend).
   O treinador humano existe em paralelo às IAs; batalhas usam as regras locais do motor.
   Estado isolado na chave v1; mapas futuros podem trocar ROUTES por dados convertidos do Emerald. */
(()=>{'use strict';
const root=document.getElementById('legacyManualCampaign');
const D=window.emeraldDiagnostics, DX=window.emeraldDexAPI, SPEC=window.emeraldSpecies;
if(!root||!D||!DX){console.error('Modo jogador: motor não carregado');return}
const $=id=>document.getElementById(id), esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const rng=a=>a[Math.floor(Math.random()*a.length)], clamp=(x,l,h)=>Math.max(l,Math.min(h,x));
const KEY='emerald_human_campaign_v1';
// Cada posição é uma etapa da campanha. No futuro pode ser expandida com caminhos,
// entradas, warps e colisão obtidos de data/maps e data/layouts do pokeemerald.
const ROUTES=window.EMERALD_CAMPAIGN_STEPS||[];
const PHASES=window.EMERALD_CAMPAIGN_PHASES||[];
const OLD_ROUTE_KEYS=[null,
 ['Route 101','wild'],['Oldale Town','story'],['Route 103','trainer'],['Route 102','trainer'],
 ['Petalburg City','story'],['Petalburg Woods','trainer'],['Rustboro City','gym'],
 ['Rusturf Tunnel','trainer'],['Granite Cave','story'],['Dewford Town','gym'],
 ['Route 110','trainer'],['Mauville City','gym'],['Route 111','story'],['Mt. Chimney','trainer'],
 ['Lavaridge Town','gym'],['Petalburg City','gym'],['Route 119','story'],['Fortree City','gym'],
 ['Mt. Pyre','story'],['Mossdeep City','gym'],['Seafloor Cavern','trainer'],
 ['Sootopolis City','gym'],['Victory Road','trainer'],['Liga Pokémon','league'],
 ['Liga Pokémon','league'],['Liga Pokémon','league'],['Liga Pokémon','league'],['Liga Pokémon','league']];
function migrateLegacyPosition(pos){
 const old=Math.trunc(Number(pos)||0);if(old>=29)return ROUTES.length;
 const key=OLD_ROUTE_KEYS[Math.max(0,Math.min(28,old))];if(!key)return 0;
 const possibilities=ROUTES.map((s,i)=>({...s,i})).filter(s=>s.place===key[0]&&s.kind===key[1]);
 if(!possibilities.length){const any=ROUTES.findIndex(s=>s.place===key[0]);return Math.max(0,any)}
 if(key[0]==='Petalburg City'&&key[1]==='gym')return possibilities.find(s=>s.chapter===5)?.i??possibilities[0].i;
 if(key[0]==='Liga Pokémon')return possibilities[Math.max(0,old-24)]?.i??possibilities[0].i;
 return possibilities[0].i;
}
const BATTLE_TYPES={wild:'Encontro selvagem',trainer:'Batalha com treinador',gym:'Líder de ginásio',league:'Liga Pokémon'};
function activeChapter(){return PHASES[Math.max(0,Math.min(7,(here()?.chapter||8)-1))]||PHASES[0]}
function opponentRoster(route){
 const chosen=p?.starter||p?.dexCaught?.find(s=>['Treecko','Torchic','Mudkip'].includes(s))||'Mudkip';
 const rival={Treecko:['Torchic','Combusken','Blaziken'],Torchic:['Mudkip','Marshtomp','Swampert'],Mudkip:['Treecko','Grovyle','Sceptile']}[chosen];
 return (route.roster||[]).map(([name,level])=>[name==='RIVAL_STARTER'?rival[0]:name==='RIVAL_MIDDLE'?rival[1]:name==='RIVAL_EVOLVED'?rival[2]:name,level]);
}

const ITEMS={
 'Oran Berry':{desc:'Restaura até 10 HP quando o Pokémon fica com metade da vida.',kind:'berry'},
 'Sitrus Berry':{desc:'Restaura 25% do HP quando fica com metade da vida.',kind:'berry'},
 'Leftovers':{desc:'Recupera 1/16 do HP ao final do turno.',kind:'regen'},
 'Choice Band':{desc:'Aumenta o Ataque em 15% neste simulador.',kind:'atk'},
 'Mystic Water':{desc:'Aumenta Ataque Especial em 10% neste simulador.',kind:'spa'},
 'Charcoal':{desc:'Aumenta Ataque Especial em 10% neste simulador.',kind:'spa'},
 'Quick Claw':{desc:'25% de chance de agir primeiro neste simulador.',kind:'quick'}
};
const initialBag=()=>({Potion:5,SuperPotion:1,Pokeball:8,GreatBall:1,'Oran Berry':2,'Sitrus Berry':0,'Leftovers':0,'Choice Band':0,'Mystic Water':0,'Charcoal':0,'Quick Claw':1});
const EV_KEYS=['maxHp','atk','def','spAtk','spDef','speed'];const EV_LABEL=['HP','Ataque','Defesa','At. Esp.','Def. Esp.','Velocidade'];
const sprite=m=>`<img loading="lazy" alt="${esc(m.species)}" src="assets/pokemon_fit/${encodeURIComponent(m.species.toLowerCase())}.png" onerror="if(!this.dataset.f){this.dataset.f=1;this.src='assets/pokemon_fit/${encodeURIComponent(m.species.toLowerCase())}.gif'}else if(!this.dataset.official){this.dataset.official=1;this.src='https://raw.githubusercontent.com/pret/pokeemerald/master/graphics/pokemon/${encodeURIComponent(m.species.toLowerCase())}/front.png'}else{this.onerror=null;this.src='assets/ui/pokemon_missing.svg'}">`;
let p=null;let panel='team';let info='';let selectedMon=0;
const create=species=>{const mon=D.createMon(species,5);mon.evs=Object.fromEntries(EV_KEYS.map(k=>[k,0]));mon.heldItem=null;return mon};
function sanitizeSave(data){
 if(!data||!Array.isArray(data.team)||!data.team.length||!Array.isArray(data.pc))return null;
 const valid=m=>m&&SPEC[m.species]&&Number.isFinite(m.level)&&m.level>=1&&m.level<=100;
 data.team=data.team.filter(valid).slice(0,6);data.pc=data.pc.filter(valid).slice(0,240);if(!data.team.length)return null;
 for(const m of [...data.team,...data.pc]){m.evs??=Object.fromEntries(EV_KEYS.map(k=>[k,0]));for(const k of EV_KEYS)m.evs[k]=clamp(Number(m.evs[k])||0,0,252);m.heldItem=ITEMS[m.heldItem]?m.heldItem:null;m.pp??={};m.moves??=DX.learnedMoves(m.species,m.level);m.hp=clamp(Number(m.hp)||0,0,Number(m.maxHp)||1)}
 data.dexSeen=Array.isArray(data.dexSeen)?data.dexSeen.filter(s=>SPEC[s]):[];
 data.dexCaught=Array.isArray(data.dexCaught)?data.dexCaught.filter(s=>SPEC[s]):[];
 data.bag={...initialBag(),...data.bag};for(const k of Object.keys(data.bag))data.bag[k]=clamp(Math.floor(Number(data.bag[k])||0),0,9999);
 if((data.schema||1)<2){data.pos=migrateLegacyPosition(data.pos);data.schema=2;}
 data.pos=clamp(Math.trunc(Number(data.pos)||0),0,ROUTES.length);
 data.starter=String(data.starter||data.dexCaught?.find(s=>['Treecko','Torchic','Mudkip'].includes(s))||'Mudkip');data.active=clamp(Math.trunc(Number(data.active)||0),0,data.team.length-1);
 data.name=String(data.name||'Treinador').slice(0,24);data.money=clamp(Number(data.money)||0,0,999999);data.badges=clamp(Number(data.badges)||0,0,8);data.wins=Number(data.wins)||0;data.losses=Number(data.losses)||0;data.log=Array.isArray(data.log)?data.log.slice(0,45):[];
 if(data.battle){const b=data.battle;b.team=Array.isArray(b.team)?b.team.filter(valid).slice(0,6):[];b.foe=clamp(Number(b.foe)||0,0,Math.max(0,b.team.length-1));if(!b.team.length)data.battle=null;else{b.active=clamp(Number(b.active)||0,0,data.team.length-1);b.lines=Array.isArray(b.lines)?b.lines.slice(0,25):[];}}
 return data;
}
try{p=sanitizeSave(JSON.parse(localStorage.getItem(KEY)||'null'))}catch(e){console.warn('Save da campanha inválido',e)}
function save(){if(!p)return;try{localStorage.setItem(KEY,JSON.stringify(p))}catch(e){info='Sem espaço para salvar. Exporte o save em Configurações.'}}
function note(s){info=s;p.log.unshift(s);p.log=p.log.slice(0,45)}
function registerSeen(s){if(!p.dexSeen.includes(s))p.dexSeen.push(s)}
function registerCaught(s){registerSeen(s);if(!p.dexCaught.includes(s))p.dexCaught.push(s)}
function here(){return ROUTES[Math.min(ROUTES.length-1,Math.max(0,p.pos))]||ROUTES[ROUTES.length-1]}
function calcStats(m){const base=D.levelStats(m.species,m.level);const currentHp=m.hp||0;const oldMax=m.maxHp||base.maxHp;for(const key of EV_KEYS){const add=Math.floor(Math.floor((m.evs?.[key]||0)/4)*m.level/100);base[key]+=add}
 Object.assign(m,base);m.hp=currentHp>0?clamp(currentHp+m.maxHp-oldMax,1,m.maxHp):0;
}
function grantExp(m,foe){const gain=Math.max(20,Math.round(foe.level*14*(foe.species===m.species?1:1.1)));m.exp=(Number(m.exp)||0)+gain;let ups=0;
 while(m.level<100&&m.exp>=m.level*12){m.exp-=m.level*12;m.level++;calcStats(m);ups++;const newer=DX.learnedMoves(m.species,m.level);m.moves=newer;m.pp=Object.fromEntries(newer.map(n=>[n,20]));const evolution=SPEC[m.species];if(evolution?.[7]&&m.level>=evolution[8]){const before=m.species;m.species=evolution[7];calcStats(m);m.type=SPEC[m.species][0];m.moves=DX.learnedMoves(m.species,m.level);m.pp=Object.fromEntries(m.moves.map(n=>[n,20]));registerCaught(m.species);note(`✨ ${before} evoluiu para ${m.species}!`)} }
 if(ups)note(`⭐ ${m.species} subiu ${ups} nível(is), agora Nv. ${m.level}.`);
 note(`${m.species} recebeu ${gain} XP.`)
}
function earnEvs(m,foe){const stats=SPEC[foe.species]||SPEC.Zigzagoon;const base=[stats[1],stats[2],stats[3],stats[5],stats[6],stats[4]];let ix=base.indexOf(Math.max(...base));m.evs??=Object.fromEntries(EV_KEYS.map(k=>[k,0]));const total=EV_KEYS.reduce((sum,k)=>sum+(m.evs[k]||0),0);const add=Math.min(foe.level>=35?2:1,252-(m.evs[EV_KEYS[ix]]||0),510-total);if(add>0){m.evs[EV_KEYS[ix]]+=add;calcStats(m);note(`💪 ${m.species} ganhou +${add} EV em ${EV_LABEL[ix]}.`)}}
function heal(){if(p.battle){info='Não é possível usar o Centro Pokémon durante uma batalha.';return}for(const m of p.team){m.hp=m.maxHp;m.status=null;m.pp=Object.fromEntries(m.moves.map(x=>[x,20]))}note('🏥 Equipe curada no Centro Pokémon.');save();render()}
function activeOwn(){if(!p?.battle)return null;const b=p.battle;return p.team[b.active]}
function activeFoe(){if(!p?.battle)return null;return p.battle.team[p.battle.foe]}
function start(kind,foes,title,opt={}){
 if(p.battle)return;const first=p.team.findIndex(m=>m.hp>0);if(first<0){info='Sua equipe está sem condições de lutar. Visite o Centro Pokémon.';render();return}
 const enemy=foes.map(([s,lv])=>D.createMon(SPEC[s]?s:'Zigzagoon',clamp(lv,2,100)));enemy.forEach(m=>registerSeen(m.species));
 p.battle={kind,team:enemy,foe:0,active:first,lines:[`⚔️ Desafio iniciado: ${title}.`],title,round:0,aiId:opt.aiId??null,progress:!!opt.progress,weather:window.emeraldWeather?.().world||'clear',weatherTurns:5};p.active=first;note(`⚔️ ${title}`);save();render();
}
function challenge(){if(!p)return;if(p.battle)return; if(p.pos>=ROUTES.length){info='Você já venceu a Liga! Procure Pokémon ou desafie outras IAs.';render();return}
 let route=here(); if(route.kind==='wild'){
 const eligible=(route.pool||[]).filter(s=>SPEC[s]);const specie=rng(eligible.length?eligible:['Zigzagoon']);
 start('wild',[[specie,route.level||5]],`Pokémon selvagem em ${route.place}`,{progress:true})
 } else if(route.kind==='gym'||route.kind==='league'||route.kind==='trainer'){
 const roster=opponentRoster(route);start(route.kind,roster,route.name+' • '+route.place,{progress:true});
 }else{
 if(route.reward){for(const [item,n] of Object.entries(route.reward))p.bag[item]=(p.bag[item]||0)+n}
 if(route.rewardMon){const [species,level]=route.rewardMon;const mon=D.createMon(species,level);mon.evs=Object.fromEntries(EV_KEYS.map(k=>[k,0]));mon.heldItem=null;registerCaught(species);(p.team.length<6?p.team:p.pc).push(mon)}
 p.pos=Math.min(ROUTES.length,p.pos+1);
 note(`📜 ${route.title} — ${route.place}.${route.reward?' Itens recebidos!':''}`);
 save();render()
 }
}
function hunt(){if(!p||p.battle)return;const spot=ROUTES[Math.min(p.pos,ROUTES.length-1)];const previous=[...ROUTES].slice(0,Math.min(p.pos+1,ROUTES.length)).reverse().find(r=>r.kind==='wild')||ROUTES[1];const pool=(spot.pool||previous.pool||['Poochyena']).filter(s=>SPEC[s]);const lv=clamp((spot.level||previous.level||6)+Math.round((Math.random()-.5)*4),2,55);start('wild',[[rng(pool.filter(n=>SPEC[n])),lv]],'Encontro livre • '+spot.place,{progress:false})}
function aiFight(id){const ai=window.emeraldTrainers?.[id];if(!ai||!ai.team?.some(m=>m.hp>0))return;
 const mons=ai.team.filter(m=>m.hp>0).slice(0,6).map(m=>[m.species,m.level]);start('ai',mons,`IA ${ai.name} • ${ai.location}`,{aiId:id,progress:false});}
function heldEffect(m,line){if(!m||m.hp<=0||!m.heldItem)return;const item=m.heldItem;
 if((item==='Oran Berry'||item==='Sitrus Berry')&&m.hp<=m.maxHp/2){const heal=Math.min(m.maxHp-m.hp,item==='Oran Berry'?10:Math.max(1,Math.floor(m.maxHp/4)));m.hp+=heal;m.heldItem=null;line(`${m.species} consumiu ${item} e recuperou ${heal} HP.`)}
}
function hit(att,def,move){const prevA=att.atk,prevSp=att.spAtk;
 if(att.heldItem==='Choice Band')att.atk=Math.round(att.atk*1.15);
 if(['Mystic Water','Charcoal'].includes(att.heldItem))att.spAtk=Math.round(att.spAtk*1.1);
 let res;try{res=D.attack(att,def,move,p.battle.weather)}finally{att.atk=prevA;att.spAtk=prevSp}
 return res.txt;
}
function enemyAction(){const b=p.battle,own=activeOwn(),foe=activeFoe();if(!own||own.hp<=0||!foe||foe.hp<=0)return;
 const move=D.chooseMove(foe,own,{strategy:.68},null,b.weather);line('🤖 '+hit(foe,own,move));}
function line(s){p.battle?.lines.unshift(s);if(p.battle)p.battle.lines=p.battle.lines.slice(0,26)}
function settleFoe(){const b=p.battle;if(!b)return false;while(b.team[b.foe]&&b.team[b.foe].hp<=0){const defeated=b.team[b.foe];const survivor=p.team[b.active]?.hp>0?p.team[b.active]:p.team.find(m=>m.hp>0);if(survivor){earnEvs(survivor,defeated);grantExp(survivor,defeated)}b.foe++;}if(b.foe>=b.team.length){finish(true);return true}registerSeen(b.team[b.foe].species);return false}
function finish(won,caught=false){const b=p.battle;if(!b)return;if(won){p.wins++;
 const cash=b.kind==='wild'?25:b.kind==='gym'?1500:b.kind==='league'?1800:350;p.money+=cash;
 if(b.progress){const route=here();if(route.kind==='gym'){p.badges=Math.min(8,p.badges+1);window.ELWTelemetry?.event('gym_win',String(route.badge||p.badges));p.bag.GreatBall=(p.bag.GreatBall||0)+2;note(`🏅 Você recebeu a insígnia ${route.badge}!`)}p.pos=Math.min(p.pos+1,ROUTES.length)}
 if(b.kind==='league'&&p.pos>=ROUTES.length){p.champion=true;window.ELWTelemetry?.event('campaign_complete')}
 if(b.kind==='ai')window.emeraldPlayerDuelResult?.(b.aiId,p.name,true);
 if(p.wins%3===0)p.bag.Pokeball=(p.bag.Pokeball||0)+2;
 if(p.wins%6===0)p.bag.Potion=(p.bag.Potion||0)+1;
 note(`🏆 Vitória! +${cash} moedas.${caught?' Captura realizada!':''}`);
 }else{p.losses++;if(b.kind==='gym')window.ELWTelemetry?.event('gym_loss',String(here()?.badge||''));if(b.kind==='ai')window.emeraldPlayerDuelResult?.(b.aiId,p.name,false);note('💥 Derrota. Sua equipe pode ser curada no Centro Pokémon.');}
 p.battle=null;save();render();}
function endRound(){const b=p.battle;if(!b)return;const own=activeOwn(),foe=activeFoe();if(own&&foe){const entry={weather:b.weather,history:[],weatherTurns:b.weatherTurns};D.resolveBattleResidual(own,foe,entry);b.weather=entry.weather;b.weatherTurns=entry.weatherTurns;entry.history.forEach(s=>line(s));heldEffect(own,line);heldEffect(foe,line)}
 if(p.team.every(m=>m.hp<=0)){finish(false);return true}if(settleFoe())return true;
 if(p.team[b.active].hp<=0){const next=p.team.findIndex(m=>m.hp>0);if(next>=0){b.active=next;p.active=next;line('🔁 Você enviou '+p.team[next].species+'.')}}save();return false}
function useMove(name){const b=p.battle,own=activeOwn(),foe=activeFoe();if(!b||!own||own.hp<=0||!foe||!own.moves.includes(name)||own.pp?.[name]===0)return;
 b.round++;const quick=own.heldItem==='Quick Claw'&&Math.random()<.25;const foeMove=D.chooseMove(foe,own,{strategy:.68},null,b.weather);
 const playerFirst=quick||D.battleSpeed(own,b.weather)>=D.battleSpeed(foe,b.weather);
 if(playerFirst){line('🎮 '+hit(own,foe,name));if(!settleFoe())enemyAction()}
 else{line('🤖 '+hit(foe,own,foeMove));if(own.hp>0){line('🎮 '+hit(own,foe,name));settleFoe()}}
 if(p.battle){endRound();render()}
}
function switchTo(i){const b=p.battle;if(!b)return;const mon=p.team[i];if(!mon||mon.hp<=0||i===b.active)return;const fainted=p.team[b.active].hp<=0;b.active=i;p.active=i;line(`🔁 Você enviou ${mon.species}.`);if(!fainted){enemyAction();endRound()}save();render()}
function itemDuringBattle(item){const b=p.battle,own=activeOwn(),foe=activeFoe();if(!b||!p.bag[item])return;
 if(['Potion','SuperPotion'].includes(item)){if(own.hp===own.maxHp){info='HP já está cheio.';render();return}p.bag[item]--;const heal=Math.min(own.maxHp-own.hp,item==='Potion'?20:50);own.hp+=heal;line(`🧪 ${item}: +${heal} HP em ${own.species}.`);enemyAction();endRound()}
 else if(['Pokeball','GreatBall'].includes(item)){if(b.kind!=='wild'){info='Não é possível capturar Pokémon de outro treinador.';render();return}p.bag[item]--;const hpRatio=foe.hp/foe.maxHp;const chance=clamp(D.captureChance(foe)*(item==='GreatBall'?1.5:1),.01,.99);
 if(Math.random()<chance){const caught=structuredClone(foe);caught.evs=Object.fromEntries(EV_KEYS.map(k=>[k,0]));caught.heldItem=null;caught.status=null;caught.hp=Math.max(1,caught.hp);registerCaught(caught.species);window.ELWTelemetry?.event('pokemon_capture',caught.species);(p.team.length<6?p.team:p.pc).push(caught);note(`🎉 ${caught.species} foi capturado e enviado ${p.team.length<=6&&!p.pc.includes(caught)?'à equipe':'ao PC'}!`);finish(true,true);return}
 line(`🔴 ${item} falhou (${Math.round(chance*100)}% de chance).`);enemyAction();endRound()}
 save();render();}
function runAway(){const b=p.battle;if(!b||b.kind!=='wild')return;note('🏃 Você fugiu do encontro selvagem.');p.battle=null;save();render()}
function pcMove(direction,i){if(p.battle){info='O PC fica indisponível durante batalhas.';render();return}
 if(direction==='deposit'){if(p.team.length<=1){info='Você precisa manter pelo menos um Pokémon na equipe.';render();return}if(!p.team[i])return;p.pc.push(p.team.splice(i,1)[0])}
 else{if(p.team.length>=6){info='Seu time já tem seis Pokémon. Deposite um primeiro.';render();return}if(!p.pc[i])return;p.team.push(p.pc.splice(i,1)[0])}p.active=0;save();render()}
function equip(i,item){if(p.battle){info='Itens equipados só podem ser trocados fora das batalhas.';render();return}const m=p.team[i];if(!m)return;
 if(item&&(!ITEMS[item]||!p.bag[item])){info='Você não tem esse item na mochila.';render();return}
 if(m.heldItem)p.bag[m.heldItem]=(p.bag[m.heldItem]||0)+1;
 if(item){p.bag[item]--;m.heldItem=item}else m.heldItem=null;save();render()}
function details(i){selectedMon=i;panel='details';render()}
function makeLead(i){if(p.battle||i<0||i>=p.team.length)return;const m=p.team.splice(i,1)[0];p.team.unshift(m);p.active=0;selectedMon=0;save();render()}
function starter(s){if(p||!['Treecko','Torchic','Mudkip'].includes(s))return;const name=($('playerNameInput')?.value||'Treinador').trim().slice(0,24)||'Treinador';const mon=create(s);
 window.ELWTelemetry?.event('campaign_start');window.ELWTelemetry?.event('starter_choose',s);p={schema:2,starter:s,name,team:[mon],pc:[],active:0,pos:0,badges:0,wins:0,losses:0,money:3000,bag:initialBag(),dexSeen:[s],dexCaught:[s],log:[`🌿 ${name} escolheu ${s} e começou a jornada.`],battle:null,champion:false};save();render()}
function menuPanel(){if(!p)return'';const mon=p.team[selectedMon]||p.team[0];return `<div class="humanTabbar"><button data-action="tab" data-tab="team" ${panel==='team'?'aria-current="page"':''}>🎒 Meu time</button><button data-action="tab" data-tab="pc" ${panel==='pc'?'aria-current="page"':''}>💻 PC (${p.pc.length})</button><button data-action="tab" data-tab="pokedex" ${panel==='pokedex'?'aria-current="page"':''}>📖 Pokédex</button><button data-action="tab" data-tab="bag" ${panel==='bag'?'aria-current="page"':''}>🧳 Mochila</button></div>
 ${panel==='pc'?`<div class="humanPcTrainer"><div class="humanPcTrainerPortrait" role="img" aria-label="Retrato do treinador"></div><div><strong>${esc(p.name)} · Meu PC</strong><small>${p.team.length}/6 Pokémon na equipe · ${p.pc.length} guardados</small></div><div class="humanPcTrainerParty">${p.team.slice(0,6).map(m=>`<span title="${esc(m.species)} Nv.${m.level}">${sprite(m)}</span>`).join('')}</div></div><div class="humanGrid"><section><h3>Equipe (máx. 6)</h3>${p.team.map((m,i)=>miniMon(m,i,'deposit')).join('')}</section><section><h3>Armazenamento — ${p.pc.length} Pokémon</h3>${p.pc.length?p.pc.map((m,i)=>miniMon(m,i,'withdraw')).join(''):'<p>Seu PC está vazio. Capture Pokémon para armazenar aqui.</p>'}</section></div>`:
 panel==='pokedex'?`<div class="humanDex"><p>${p.dexSeen.length} vistos • ${p.dexCaught.length} capturados • ${Object.keys(SPEC).length} espécies cadastradas no motor.</p><div class="humanDexGrid">${Object.keys(SPEC).filter(s=>p.dexSeen.includes(s)).map(s=>`<article class="humanDexEntry">${sprite({species:s})}<b>${esc(s)}</b><small>${p.dexCaught.includes(s)?'✅ Capturado':'👁️ Visto'}</small></article>`).join('')}</div><p>Abra também a Pokédex geral para ver as espécies ainda não encontradas.</p><button data-action="globalDex">📖 Ver catálogo completo</button></div>`:
 panel==='bag'?`<div class="humanBag">${Object.keys(initialBag()).map(k=>`<div><b>${esc(k)}</b><span>×${p.bag[k]||0}</span>${ITEMS[k]?`<small>${esc(ITEMS[k].desc)}</small>`:''}</div>`).join('')}</div>`:
 panel==='details'?`<button data-action="tab" data-tab="team">← Voltar à equipe</button>${mon?`<div class="humanDetails"><div class="humanDetailHead">${sprite(mon)}<div><h3>${esc(mon.species)} • Nv. ${mon.level}</h3><p>${esc(DX.monTypes(mon).join(' / '))} · ${esc(DX.ability(mon)||'Sem habilidade especial')}</p><small>${mon.shiny?'✨ Shiny • ':''}${mon.hp}/${mon.maxHp} HP • ${mon.exp}/${mon.level*12} XP</small></div></div><h4>Status</h4><div class="humanStats">${EV_KEYS.map((k,i)=>`<div><span>${EV_LABEL[i]}</span><b>${k==='maxHp'?mon.maxHp:mon[k]}</b><small>${mon.evs?.[k]||0} EVs</small></div>`).join('')}</div><p>EVs totais: ${EV_KEYS.reduce((n,k)=>n+(mon.evs?.[k]||0),0)}/510 · Limite 252 por atributo.</p><h4>Golpes</h4><p>${mon.moves.map(x=>`${esc(x)} (${mon.pp?.[x]??20} PP)`).join(' • ')}</p><button data-action="lead" data-index="${p.team.indexOf(mon)}" ${p.battle?'disabled':''}>⭐ Colocar como primeiro Pokémon do time</button><label>Held item <select data-action="held" data-index="${p.team.indexOf(mon)}" ${p.battle?'disabled':''}><option value="">Nenhum</option>${Object.keys(ITEMS).map(item=>`<option value="${esc(item)}" ${mon.heldItem===item?'selected':''} ${!p.bag[item]&&mon.heldItem!==item?'disabled':''}>${esc(item)} (${p.bag[item]||0})</option>`).join('')}</select></label><p>${mon.heldItem?esc(ITEMS[mon.heldItem]?.desc||''):'Escolha um item da mochila para equipar.'}</p></div>`:''}`:
 `<div class="humanParty">${p.team.map((m,i)=>`<button class="humanMon" data-action="details" data-index="${i}">${sprite(m)}<div><b>${esc(m.species)} <small>Nv.${m.level}</small></b><div class="humanMeter"><span style="width:${clamp(100*m.hp/Math.max(1,m.maxHp),0,100)}%"></span></div><small>❤️ ${m.hp}/${m.maxHp} · ${esc(m.heldItem||'Sem item')}</small></div><span>Ver status →</span></button>`).join('')}</div>`}`}
function miniMon(m,i,direction){return `<div class="humanPcMon">${sprite(m)}<div><b>${esc(m.species)} Nv.${m.level}</b><small>HP ${m.hp}/${m.maxHp} · ${esc(m.heldItem||'Sem item')}</small></div><button data-action="${direction}" data-index="${i}" ${p.battle?'disabled':''}>${direction==='deposit'?'Depositar':'Retirar'}</button></div>`}
function battleCard(){const b=p.battle;if(!b)return'';const own=activeOwn(),foe=activeFoe();return `<section class="humanBattle" aria-label="Batalha do jogador"><div class="humanBattleTop"><b>⚔️ ${esc(b.title)}</b><span>Turno ${b.round+1} · ${b.kind==='wild'?'Pokémon selvagem':b.kind==='ai'?'Contra IA':'Campanha'}</span></div><div class="humanFightScene"><div class="humanCombatant">${sprite(foe)}<b>${esc(foe.species)} Nv.${foe.level}</b><div class="humanMeter"><span style="width:${100*foe.hp/Math.max(1,foe.maxHp)}%"></span></div><small>${foe.hp}/${foe.maxHp} HP</small></div><span class="humanVs">VS</span><div class="humanCombatant">${sprite(own)}<b>${esc(own.species)} Nv.${own.level}</b><div class="humanMeter"><span style="width:${100*own.hp/Math.max(1,own.maxHp)}%"></span></div><small>${own.hp}/${own.maxHp} HP</small></div></div>
 <h3>🎮 Escolha sua ação</h3><div class="humanMoves">${own.moves.map((name,i)=>`<button class="humanMoveChoice" data-action="move" data-move="${esc(name)}" ${own.hp<=0||own.pp?.[name]===0?'disabled':''}><span class="humanMoveIndex">0${i+1}</span><b>${esc(name)}</b><small>${own.pp?.[name]??20} PP restantes</small></button>`).join('')}</div>
 <div class="humanBattleMenu"><label>Trocar Pokémon <select data-action="switch"><option value="">Selecione...</option>${p.team.map((m,i)=>`<option value="${i}" ${m.hp<=0||i===b.active?'disabled':''}>${esc(m.species)} Nv.${m.level} (${m.hp} HP)</option>`).join('')}</select></label><label>Usar item <select data-action="useItem"><option value="">Selecione...</option>${['Potion','SuperPotion','Pokeball','GreatBall'].map(k=>`<option value="${k}" ${!p.bag[k]||(b.kind!=='wild'&&k.includes('ball'))?'disabled':''}>${k} ×${p.bag[k]||0}</option>`).join('')}</select></label>${b.kind==='wild'?'<button data-action="run">🏃 Fugir</button>':''}</div><div class="humanBattleChronicle"><h4>📺 Narração do combate</h4><div class="humanLog" role="log" aria-live="polite">${b.lines.slice(0,10).map((s,i)=>`<p class="${i===0?'latest':''}">${esc(s)}</p>`).join('')}</div></div></section>`}
function aiList(){const roster=(window.emeraldTrainers||[]).filter(x=>x.team?.some(m=>m.hp>0));const location=here()?.place||'';return roster.sort((a,b)=>Number(b.location===location)-Number(a.location===location)).slice(0,12).map(t=>`<button data-action="ai" data-index="${t.id}" ${p.battle?'disabled':''}><strong>🤖 ${esc(t.name)}</strong><small>${esc(t.location)} · ${t.team.length} Pokémon · ${t.badges} insígnias · ${esc(t.personality||'IA')}</small></button>`).join('')||'<p>Os bots estão começando a jornada. Acompanhe o mundo por alguns instantes e tente novamente.</p>'}
function render(){if(!root)return;
 if(!p){root.innerHTML=`<div class="pageHero"><h2>🎮 Sua campanha em Hoenn</h2><small>Você escolhe os comandos nas batalhas. Os caminhos avançam automaticamente, enquanto as IAs continuam vivendo suas próprias jornadas.</small></div><section class="card humanStart"><h3>Comece sua própria história</h3><label>Nome do treinador <input id="playerNameInput" maxlength="24" placeholder="Seu nome" value="Dezin"></label><h3>Escolha um Pokémon inicial</h3><div class="humanStarters">${['Treecko','Torchic','Mudkip'].map(s=>`<button data-action="starter" data-species="${s}">${sprite({species:s})}<b>${s}</b><small>Começar jornada</small></button>`).join('')}</div><p>O jogador não precisa mover o personagem manualmente. A campanha tem oito capítulos, batalhas com treinadores e ginásios. A viagem ocorre por eventos; a movimentação manual não está habilitada.</p></section>`;return}
 const route=here();const title=p.pos>=ROUTES.length?'Campeão de Hoenn':route.title;
 // Ponte visual entre a etapa da campanha e os layouts oficiais (não altera a exploração automática).
 const OFFICIAL={
 'Littleroot Town':'LittlerootTown','Oldale Town':'OldaleTown','Route 101':'Route101',
 'Route 102':'Route102','Route 103':'Route103','Route 110':'Route110','Route 111':'Route111',
 'Route 119':'Route119','Petalburg City':'PetalburgCity','Petalburg Woods':'PetalburgWoods',
 'Rustboro City':'RustboroCity','Rusturf Tunnel':'RusturfTunnel','Granite Cave':'GraniteCave_1F',
 'Dewford Town':'DewfordTown','Mauville City':'MauvilleCity','Mt. Chimney':'MtChimney',
 'Lavaridge Town':'LavaridgeTown','Fortree City':'FortreeCity','Mt. Pyre':'MtPyre_1F',
 'Mossdeep City':'MossdeepCity','Seafloor Cavern':'SeafloorCavern_Entrance',
 'Sootopolis City':'SootopolisCity','Victory Road':'VictoryRoad_1F',
 'Liga Pokémon':'EverGrandeCity_PokemonLeague_1F'
 };
 const officialMap=route.map||OFFICIAL[p.pos>=ROUTES.length?'Liga Pokémon':route.place]||window.emeraldOfficialWorld?.resolve?.(route.place);
 const mapLink=officialMap?`<a class="humanOfficialMapLink" href="mapas-oficiais.html?map=${encodeURIComponent(officialMap)}">🗺️ Ver mapa original de ${esc(route.place)} ↗</a>`:'';
 const chapter=activeChapter();const currentChapter=route?.chapter||8;
 const chapterSteps=ROUTES.map((s,i)=>({...s,index:i})).filter(s=>s.chapter===currentChapter);
 const chapterStart=chapterSteps[0]?.index||0,chapterEnd=(chapterSteps.at(-1)?.index??(ROUTES.length-1))+1;
 const chapterDone=clamp(100*(p.pos-chapterStart)/(chapterEnd-chapterStart||1),0,100);
 const upcoming=ROUTES.slice(Math.max(0,p.pos-1),Math.min(ROUTES.length,p.pos+4));
 const timeline=`<section class="humanStoryBook" aria-label="Capítulos da campanha"><div class="humanChapterTop"><span>CAPÍTULO ${currentChapter} / 8</span><b>${esc(chapter.icon||'🗺️')} ${esc(chapter.title||'Jornada de Hoenn')}</b><small>${esc(chapter.subtitle||'')}</small></div><div class="humanChapterBar"><span style="width:${chapterDone}%"></span></div><div class="humanPhaseTrack">${PHASES.map((ph,i)=>`<span class="${i<currentChapter-1?'done':i===currentChapter-1?'now':''}" title="${esc(ph.title)}">${i+1}</span>`).join('')}</div><div class="humanNextSteps"><strong>📍 Linha da história</strong>${upcoming.map((s,i)=>`<div class="humanQuest ${(Math.max(0,p.pos-1)+i)===p.pos?'current':''}"><span>${i===0&&p.pos>0?'✓':(Math.max(0,p.pos-1)+i)===p.pos?'▶':'·'}</span><div><b>${esc(s.title)}</b><small>${esc(s.place)} · ${esc(BATTLE_TYPES[s.kind]||'Evento da história')}</small></div></div>`).join('')}</div></section>`;
 root.innerHTML=`<div class="pageHero"><h2>🎮 ${esc(p.name)} — Jornada de Hoenn</h2><small>O caminho entre as cenas avança automaticamente; você controla golpes, trocas, itens e capturas nas batalhas. Salvo neste aparelho.</small></div>
 ${timeline}<section class="card humanOverview"><div class="humanHighlights"><div><small>📍 Local atual</small><b>${esc(p.pos>=ROUTES.length?'Liga Pokémon':route.place)}</b></div><div><small>🏅 Insígnias</small><b>${p.badges}/8</b></div><div><small>⚔️ Vitórias / derrotas</small><b>${p.wins} / ${p.losses}</b></div><div><small>🪙 Moedas</small><b>${p.money}</b></div></div><div class="humanMeter"><span style="width:${Math.floor(p.pos/ROUTES.length*100)}%"></span></div><p><strong>Próximo desafio:</strong> ${esc(title)} · Etapa ${Math.min(p.pos+1,ROUTES.length)}/${ROUTES.length}</p>${p.champion?'<p>👑 Você conquistou a Liga! Agora pode capturar Pokémon e disputar batalhas com os treinadores da simulação.</p>':''}
 ${mapLink}<div class="humanActions"><button data-action="challenge" class="humanPrimary" ${p.battle||p.pos>=ROUTES.length?'disabled':''}>⚔️ ${route.kind==='story'?'Continuar a história':route.kind==='wild'?'Encontro selvagem':'Entrar na batalha'}</button><button data-action="hunt" ${p.battle?'disabled':''}>🌿 Procurar Pokémon</button><button data-action="heal" ${p.battle?'disabled':''}>🏥 Centro Pokémon</button><button data-action="tab" data-tab="pc">💻 Abrir PC</button></div></section>
 ${p.battle?battleCard():''}<section class="card humanTeamCard">${menuPanel()}</section>
 <section class="card"><h3>🤖 Desafiar treinadores do mundo</h3><p>As mesmas IAs que exploram Hoenn podem ser seus adversários. A batalha usa uma cópia da equipe atual delas; o resultado entra no histórico da simulação, sem interromper suas outras jornadas.</p><div class="humanAiList">${aiList()}</div></section>
 <section class="card"><h3>📜 Diário do treinador</h3><div class="humanLog">${p.log.slice(0,12).map(s=>`<p>${esc(s)}</p>`).join('')}</div></section><section class="card"><h3>💾 Seus dados</h3><button data-action="export">Exportar campanha (.json)</button> <label class="importButton">Importar campanha <input id="humanImport" type="file" accept="application/json,.json" hidden></label> <button data-action="restart">Recomeçar campanha</button><p>Se limpar os dados do navegador, o progresso local também será apagado. Exporte um backup antes de mudar de aparelho.</p></section>`;
 if(info){const node=document.createElement('p');node.className='humanToast';node.setAttribute('role','status');node.textContent=info;root.querySelector('.humanOverview')?.append(node);info=''}
}
root.addEventListener('click',e=>{const button=e.target.closest('button[data-action]');if(!button||button.disabled)return;const action=button.dataset.action,idx=Number(button.dataset.index);
 if(action==='starter')return starter(button.dataset.species);
 if(!p)return;
 if(action==='tab'){panel=button.dataset.tab;render()}
 else if(action==='details')details(idx);
 else if(action==='deposit'||action==='withdraw')pcMove(action,idx);
 else if(action==='lead')makeLead(idx);
 else if(action==='challenge'){challenge();requestAnimationFrame(()=>root.querySelector('.humanBattle')?.scrollIntoView({behavior:'smooth',block:'start'}));}
 else if(action==='hunt'){hunt();requestAnimationFrame(()=>root.querySelector('.humanBattle')?.scrollIntoView({behavior:'smooth',block:'start'}));}
 else if(action==='heal')heal();
 else if(action==='move')useMove(button.dataset.move);
 else if(action==='run')runAway();
 else if(action==='ai'){aiFight(idx);requestAnimationFrame(()=>root.querySelector('.humanBattle')?.scrollIntoView({behavior:'smooth',block:'start'}));}
 else if(action==='globalDex')document.querySelector('.siteNav [data-page="pokedex"]')?.click();
 else if(action==='export'){const b=new Blob([JSON.stringify(p,null,2)],{type:'application/json'}),u=URL.createObjectURL(b),a=document.createElement('a');a.href=u;a.download='emerald-minha-campanha.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000)}
 else if(action==='restart'&&confirm('Apagar toda sua campanha pessoal e escolher o inicial novamente?')){localStorage.removeItem(KEY);p=null;panel='team';render()}
});
root.addEventListener('change',e=>{const el=e.target;if(el.dataset.action==='held')equip(Number(el.dataset.index),el.value);
 else if(el.dataset.action==='switch'&&el.value!=='')switchTo(Number(el.value));
 else if(el.dataset.action==='useItem'&&el.value!=='')itemDuringBattle(el.value);
 else if(el.id==='humanImport'&&el.files?.[0]){const file=el.files[0];if(file.size>2_000_000){info='Arquivo muito grande.';render();return}file.text().then(text=>{const parsed=sanitizeSave(JSON.parse(text));if(!parsed)throw Error('Formato de campanha inválido');p=parsed;panel='team';save();render()}).catch(err=>{info='Não foi possível importar: '+err.message;render()})}
});
window.emeraldHuman={getState:()=>p?structuredClone(p):null,getRoutes:()=>ROUTES.map(x=>({...x})),getLocation:()=>p?{name:p.name,place:here().place,map:window.emeraldOfficialWorld?.resolve(here().place)}:null,render};
render();
})();
