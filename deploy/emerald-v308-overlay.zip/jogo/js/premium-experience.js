/* ELW Premium Experience 3.0.3 — UI only, no gameplay or authentication changes. */
(()=>{'use strict';
const pages=[
 ['🏡','Central Emerald','portal.html','Todos os modos em uma única página'],
 ['🌍','Mundo Compartilhado','online.html','Explore Hoenn com treinadores e IAs'],
 ['🤖','Simulação IA','index.html#jogo','Acompanhe bots, decisões e a Liga'],
 ['⚔️','Arena Competitiva','arena.html','Monte equipes e dispute Elo'],
 ['🏆','Battle Frontier','frontier.html','Desafios e instalações especiais'],
 ['📖','Jornada de Hoenn','campanha.html','Ginásios e progresso da campanha'],
 ['📗','Pokédex','quetzal-pokedex.html','Espécies, formas e habitats'],
 ['🗺️','Mapas','mapas-oficiais.html','Rotas e conexões de Hoenn'],
 ['📊','Estatísticas','estatisticas.html','Ranking e indicadores da comunidade'],
 ['👤','Minha conta','entrar.html','Sessão e acesso a todos os modos'],
 ['📰','Atualizações','../atualizacoes.html','Novidades e notas de versão'],
 ['✨','Sobre o projeto','../sobre.html','Conheça o Emerald Living World'],
 ['🔒','Privacidade','../privacidade.html','Como os dados dos treinadores são tratados']
];
function init(){if(document.querySelector('.elw-premium-command'))return;
 const script=document.querySelector('script[data-elw-premium]');const base=script?new URL('../',script.src):new URL('/jogo/',location.href);
 const go=s=>new URL(s,base).href;
 const all=document.createElement('div');all.className='elw-premium-command';all.hidden=true;all.setAttribute('role','dialog');all.setAttribute('aria-modal','true');all.setAttribute('aria-label','Buscar áreas do Emerald');
 const panel=document.createElement('div');panel.className='elw-command-panel';
 const head=document.createElement('div');head.className='elw-command-head';const title=document.createElement('h2');title.textContent='Explorar Emerald Living World';const close=document.createElement('button');close.className='elw-command-close';close.type='button';close.setAttribute('aria-label','Fechar busca');close.textContent='✕';head.append(title,close);
 const input=document.createElement('input');input.className='elw-command-input';input.type='search';input.placeholder='Buscar modo, área ou recurso…';input.setAttribute('aria-label','Buscar por nome de área');input.autocomplete='off';
 const list=document.createElement('div');list.className='elw-command-list';const foot=document.createElement('div');foot.className='elw-command-foot';foot.textContent='Selecione uma área para navegar. Atalho: / ou Ctrl + K';panel.append(head,input,list,foot);all.append(panel);document.body.append(all);
 let previousFocus=null;
 function render(){const value=input.value.trim().toLocaleLowerCase('pt-BR');list.replaceChildren();let count=0;for(const [icon,label,href,description] of pages){if(value&&!`${label} ${description}`.toLocaleLowerCase('pt-BR').includes(value))continue;count++;const a=document.createElement('a');a.className='elw-command-link';a.href=go(href);const img=document.createElement('span');img.textContent=icon;img.setAttribute('aria-hidden','true');const details=document.createElement('span');const bold=document.createElement('strong');bold.textContent=label;const small=document.createElement('small');small.textContent=description;details.append(bold,small);a.append(img,details);list.append(a)}if(!count){const none=document.createElement('div');none.className='elw-command-empty';none.textContent='Nenhuma área encontrada. Tente outro nome.';list.append(none)}}
 function open(){previousFocus=document.activeElement;input.value='';render();all.hidden=false;document.body.style.setProperty('--elw-search-open','1');input.focus({preventScroll:true})}function hide(){all.hidden=true;if(previousFocus&&typeof previousFocus.focus==='function')previousFocus.focus({preventScroll:true})}
 input.addEventListener('input',render);input.addEventListener('keydown',e=>{if(e.key==='Enter'){const first=list.querySelector('a');if(first)location.assign(first.href)}});close.addEventListener('click',hide);all.addEventListener('pointerdown',e=>{if(e.target===all)hide()});document.addEventListener('keydown',e=>{const t=e.target;if(e.key==='Escape'&&!all.hidden){e.preventDefault();hide();return}if((e.key==='/'||((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'))&&!(t&&(/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)||t.isContentEditable))){e.preventDefault();open()}});
 const header=document.querySelector('body > header');
 if(header){
  const search=document.createElement('button');
  search.type='button';
  search.className='elw-premium-action';
  search.textContent='⌕ Explorar';
  search.addEventListener('click',open);
  (header.querySelector('.headerRight,.arenaHeaderRight')||header).append(search);
 }
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
