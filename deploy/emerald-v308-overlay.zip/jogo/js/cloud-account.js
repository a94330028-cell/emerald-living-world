/* Emerald Living World — contas, save privado e ranking global via Supabase REST.
   Não requer SDK, Node ou service_role. RLS é aplicada pelo SQL incluído. */
(()=>{'use strict';
const $=id=>document.getElementById(id), slots=window.ELWLocalSlots;
const config=window.EMERALD_CLOUD_CONFIG||{};
const URL_BASE=String(config.supabaseUrl||'').trim().replace(/\/+$/,'');
const API_KEY=String(config.supabaseAnonKey||'').trim();
const configured=/^https:\/\/[^\s/]+\.supabase\.co$/.test(URL_BASE)&&API_KEY.length>15;
const AUTO_INTERVAL=60000;
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=n=>Number(n||0).toLocaleString('pt-BR');
const summaryDate=s=>s?new Date(s).toLocaleString('pt-BR'):'—';
const sameMoment=(a,b)=>!!a&&!!b&&Number.isFinite(Date.parse(a))&&Math.abs(Date.parse(a)-Date.parse(b))<1000;
const cleanNick=s=>String(s||'Treinador').replace(/[<>"'`]/g,'').trim().slice(0,24)||'Treinador';
const sessionKey=slots.SESSION;
let session=slots.session(), syncReady=false, saving=false, loginBusy=false, conflict=false;
let lastSent='', cloudMessage='', rankingBusy=false, rankData=[], speedData=[];
const syncMetaKey=uid=>'elw_cloud_synced_v1:'+uid;
const nickKey=uid=>'elw_cloud_nickname_v1:'+uid;
const getMeta=uid=>{try{return JSON.parse(localStorage.getItem(syncMetaKey(uid))||'null')}catch{return null}};
const setMeta=(uid,meta)=>{try{localStorage.setItem(syncMetaKey(uid),JSON.stringify(meta))}catch{}};
const fingerprint=value=>{const s=JSON.stringify(value);let h=2166136261;for(let i=0;i<s.length;i++)h=Math.imul(h^s.charCodeAt(i),16777619);return (h>>>0).toString(16)+':'+s.length};
function nickname(){if(!session?.user?.id)return '';return cleanNick(localStorage.getItem(nickKey(session.user.id))||session.user.user_metadata?.display_name||session.user.user_metadata?.nickname||session.user.email?.split('@')[0]||'Treinador')}
function notify(msg,err=false){cloudMessage=msg;for(const id of ['accountStatus','cloudMainStatus','cloudSyncStatus','accountModalStatus']){const el=$(id);if(el){el.textContent=msg;el.dataset.error=String(err)}}}
const errorOf=data=>String(data?.msg||data?.message||data?.error_description||data?.error||'Não foi possível completar a solicitação.').slice(0,220);
async function request(path,{method='GET',data=null,token=null,prefer=null}={}){
 if(!configured)throw Error('Login mundial ainda não configurado. Veja CONFIGURAR_LOGIN_E_TOP_MUNDIAL.md no ZIP.');
 const headers={'apikey':API_KEY};
 if(token)headers['Authorization']='Bearer '+token;else if(API_KEY.startsWith('eyJ'))headers['Authorization']='Bearer '+API_KEY;
 if(data!==null)headers['Content-Type']='application/json';if(prefer)headers['Prefer']=prefer;
 const resp=await fetch(URL_BASE+path,{method,headers,body:data===null?undefined:JSON.stringify(data),cache:'no-store'});
 const txt=await resp.text();let json=null;try{json=txt?JSON.parse(txt):null}catch{json={message:txt.slice(0,240)}}
 if(!resp.ok){
  const code=json?.error_code||json?.code;
  const messages={
   invalid_credentials:'E-mail ou senha incorretos. Confira os dados ou redefina sua senha.',
   email_not_confirmed:'Confirme o cadastro pelo link enviado ao seu e-mail.',
   over_email_send_rate_limit:'O serviço atingiu o limite de envios. Aguarde antes de tentar novamente.'
  };
  throw Error(Object.hasOwn(messages,code)?messages[code]:errorOf(json));
 }
 return json;
}
function setSession(s){if(!s?.access_token||!s?.user?.id)throw Error('O servidor não retornou uma sessão válida.');session={access_token:s.access_token,refresh_token:s.refresh_token,expires_at:s.expires_at||(Math.floor(Date.now()/1000)+Number(s.expires_in||3600)),user:s.user};localStorage.setItem(sessionKey,JSON.stringify(session))}
async function access(){if(!session?.user?.id)throw Error('Entre na sua conta primeiro.');if((Number(session.expires_at)||0)*1000>Date.now()+90000)return session.access_token;
 if(!session.refresh_token)throw Error('Sessão vencida. Faça login novamente.');
 const response=await request('/auth/v1/token?grant_type=refresh_token',{method:'POST',data:{refresh_token:session.refresh_token}});if(!response.user)response.user=session.user;setSession(response);return session.access_token}
function localSnapshot(diskOnly=false){const saves=slots.capture();if(!diskOnly){try{if(typeof window.emeraldExport==='function'&&(slots.hasGame(saves)||window.emeraldBootAuthorized)){saves.emerald_living_world_v26=JSON.stringify(window.emeraldExport());localStorage.setItem('emerald_living_world_v26',saves.emerald_living_world_v26)}}catch(e){console.warn('Save em execução não disponível, usando última cópia em disco',e)}
 try{const h=window.emeraldHuman?.getState?.();if(h){saves.emerald_human_campaign_v1=JSON.stringify(h);localStorage.setItem('emerald_human_campaign_v1',saves.emerald_human_campaign_v1)}}catch{}}
 return {version:1,saves};}
function extractSaves(payload){if(!payload||payload.version!==1||!payload.saves||typeof payload.saves!=='object')throw Error('Este save remoto não tem um formato compatível.');
 const o={};for(const key of slots.KEYS){const v=payload.saves[key];if(typeof v==='string'){if(v.length>10485760)throw Error('Save ultrapassa o limite permitido.');if(key.endsWith('_v26')||key==='emerald_human_campaign_v1'){try{JSON.parse(v)}catch{throw Error('Save remoto inválido.')}}o[key]=v}}return o}
function applySnapshot(payload){const saves=extractSaves(payload);for(const key of slots.KEYS){localStorage.removeItem(key);if(typeof saves[key]==='string')localStorage.setItem(key,saves[key])}slots.store(slots.currentOwner())}
function ownTeam(){const world=typeof window.emeraldExport==='function'?window.emeraldExport():null;
 const bot=world?.trainers?.find(t=>t.isUserBot);
 const human=window.emeraldHuman?.getState?.();
 const t=bot?.team?.length?bot:(human?.team?.length?human:null);
 if(!t)return null;
 const team=(t.team||[]).slice(0,6).filter(x=>x&&typeof x.species==='string').map(m=>({species:m.species.slice(0,36),level:Math.max(1,Math.min(100,Math.round(Number(m.level)||1)))}));
 const power=(t.team||[]).slice(0,6).reduce((a,m)=>a+Math.max(0,Number(window.emeraldPower?.(m)||0)),0);
 const completed=!!t.champion;
 const bestTicks=bot?.champion&&Number.isInteger(bot.finishTick)&&bot.finishTick>0?bot.finishTick:null;
 return {team,team_power:Math.min(100000,Math.max(0,Math.round(power))),badges:Math.min(8,Math.max(0,Number(t.badges)||0)),is_champion:completed,best_ticks:bestTicks};
}
async function publishRanking(){if(!session||!syncReady)return;
 const rank=ownTeam();if(!rank)return;
 const token=await access(),userId=session.user.id;
 const existing=await request('/rest/v1/elw_leaderboard?user_id=eq.'+encodeURIComponent(userId)+'&select=best_ticks,team_power,team,badges,is_champion&limit=1',{token});
 const old=existing?.[0];const prev=Number(old?.best_ticks)||0;
 const record=rank.best_ticks?prev?Math.min(prev,rank.best_ticks):rank.best_ticks:prev||null;
 // O melhor tempo histórico permanece mesmo que o jogador reinicie a jornada.
 const body={user_id:userId,display_name:nickname(),...rank,best_ticks:record,updated_at:new Date().toISOString()};
 await request('/rest/v1/elw_leaderboard?on_conflict=user_id',{method:'POST',token,data:[body],prefer:'resolution=merge-duplicates,return=minimal'});
}
async function saveCloud(force=false){if(!configured||!session||!syncReady||conflict||saving)return;
 const payload=localSnapshot(),hash=fingerprint(payload);if(!force&&hash===lastSent)return;
 saving=true;renderHeader();notify('☁️ Enviando progresso para sua conta…');
 try{const text=JSON.stringify(payload);if(text.length>8_000_000)throw Error('Save muito grande para a nuvem (mais de 8 MB). Exporte o arquivo localmente.');
  const token=await access(),at=new Date().toISOString();
  await request('/rest/v1/elw_saves?on_conflict=user_id',{method:'POST',token,data:[{user_id:session.user.id,payload,updated_at:at}],prefer:'resolution=merge-duplicates,return=minimal'});
  lastSent=hash;setMeta(session.user.id,{hash,remoteUpdated:at});slots.store(slots.currentOwner());
  try{await publishRanking()}catch(err){console.warn('Ranking:',err);notify('Save salvo, mas não foi possível atualizar o ranking: '+err.message,true);return}
  notify('✓ Save sincronizado na nuvem em '+summaryDate(at));
 }catch(err){notify('⚠️ Falha no save online: '+err.message+'. O save local permanece preservado.',true)}finally{saving=false;renderHeader()}
}
async function remoteSave(){const token=await access();const rows=await request('/rest/v1/elw_saves?user_id=eq.'+encodeURIComponent(session.user.id)+'&select=payload,updated_at&limit=1',{token});return rows?.[0]||null}
function hasSave(s){return slots.hasGame(s)}
function promptChoice(title,detail,choices){return new Promise(resolve=>{
 const dlg=$('cloudConflictDialog'),head=$('cloudChoiceTitle'),desc=$('cloudChoiceDescription'),actions=$('cloudChoiceActions');
 head.textContent=title;desc.textContent=detail;actions.replaceChildren();let done=false;
 const finish=value=>{if(done)return;done=true;dlg.close();resolve(value)};
 for(const entry of choices){const b=document.createElement('button');b.type='button';b.className=entry.primary?'cloudPrimary':'cloudSecondary';b.textContent=entry.label;b.addEventListener('click',()=>finish(entry.value));actions.append(b)}
 dlg.addEventListener('cancel',e=>{e.preventDefault();finish(null)},{once:true});dlg.showModal();
 })}
function reloadForAccount(){slots.store(slots.currentOwner());location.replace(location.pathname+location.search+'#jogo')}
async function prepareProfile({guestCopy=null,newLogin=false}={}){
 if(!session)return;syncReady=false;conflict=true;renderHeader();
 const userId=session.user.id, local=localSnapshot(newLogin),forceOverwriteKey='elw_cloud_overwrite_v1:'+userId;
 try{
  const remote=await remoteSave();
  const meta=getMeta(userId),localHash=fingerprint(local),remoteHash=remote?fingerprint(remote.payload):null;
  if(remote){
   if(localStorage.getItem(forceOverwriteKey)==='1'){localStorage.removeItem(forceOverwriteKey);syncReady=true;conflict=false;await saveCloud(true);if(newLogin)reloadForAccount();return}
   // O save da nuvem corresponde ao último upload conhecido: manter alterações locais.
   if(sameMoment(meta?.remoteUpdated,remote.updated_at)){lastSent=meta.hash===localHash?localHash:'';syncReady=true;conflict=false;renderHeader();if(newLogin)reloadForAccount();return}
   if(remoteHash===localHash){lastSent=localHash;setMeta(userId,{hash:localHash,remoteUpdated:remote.updated_at});syncReady=true;conflict=false;renderHeader();if(newLogin)reloadForAccount();return}
   if(!hasSave(local.saves)||meta?.hash===localHash){applySnapshot(remote.payload);setMeta(userId,{hash:fingerprint(remote.payload),remoteUpdated:remote.updated_at});syncReady=true;conflict=false;reloadForAccount();return}
   const selection=await promptChoice('Qual progresso você quer usar?',
    'Existe um save desta conta na nuvem e outro neste aparelho. Nada será sobrescrito sem sua escolha.',
    [{label:'☁️ Carregar save da nuvem',value:'remote',primary:true},{label:'📱 Manter save deste aparelho',value:'local'},{label:'Decidir depois',value:null}]);
   if(selection==='remote'){applySnapshot(remote.payload);setMeta(userId,{hash:fingerprint(remote.payload),remoteUpdated:remote.updated_at});syncReady=true;conflict=false;reloadForAccount();return}
   if(selection==='local'){syncReady=true;conflict=false;if(newLogin){localStorage.setItem(forceOverwriteKey,'1');reloadForAccount()}else await saveCloud(true);return}
   notify('Escolha um save na Conta antes de sincronizar.',true);return;
  }
  if(!hasSave(local.saves)&&guestCopy&&hasSave(guestCopy)){
   const selection=await promptChoice('Sua jornada de visitante foi encontrada',
    'Quer levar o progresso deste aparelho para sua nova conta ou começar uma jornada separada?',
    [{label:'📱 Usar minha jornada atual',value:'guest',primary:true},{label:'🌱 Começar do zero',value:'blank'},{label:'Decidir depois',value:null}]);
   if(selection==='guest')applySnapshot({version:1,saves:guestCopy});
   if(selection===null){notify('Escolha qual progresso usar para concluir a entrada.',true);return}
   syncReady=true;conflict=false;reloadForAccount();return;
  }
  syncReady=true;conflict=false;renderHeader();if(newLogin)reloadForAccount();else if(hasSave(local.saves))saveCloud(true);
 }catch(err){syncReady=false;conflict=false;notify('⚠️ Sem conexão com o banco: '+err.message+'. Seu save local continua disponível.',true);renderHeader();if(newLogin)reloadForAccount()}
}
async function loggedIn(s){const old=slots.currentOwner(),guestHadProgress=slots.hasGame(slots.capture())||!!window.emeraldBootAuthorized;
 const guestCopy=old==='guest'&&guestHadProgress?localSnapshot().saves:null;
 setSession(s);try{slots.switchOwner(session.user.id)}catch(e){session=null;localStorage.removeItem(sessionKey);throw e}
 $('accountDialog').close();renderHeader();await prepareProfile({guestCopy,newLogin:true})}
async function signOut(){if(!session)return;
 localSnapshot();if(syncReady){try{await saveCloud(true)}catch{}}
 const old=session;await Promise.allSettled([
  request('/auth/v1/logout',{method:'POST',token:old.access_token}),
  fetch('/api/logout',{method:'POST',credentials:'same-origin'})
 ]);

 slots.store(old.user.id);localStorage.removeItem(sessionKey);session=null;syncReady=false;slots.switchOwner('guest');location.replace(location.pathname+location.search+'#jogo')}
async function loginAction(event){event.preventDefault();if(loginBusy)return;const mode=$('accountAuthMode').value,email=$('accountEmail').value.trim(),password=$('accountPassword').value,nick=cleanNick($('accountNickname').value);
 if(!email||!password){notify('Informe seu e-mail e senha.',true);return}if(!configured){notify('É necessário configurar o Supabase primeiro.',true);return}
 loginBusy=true;$('accountAuthSubmit').disabled=true;notify(mode==='signup'?'Criando conta…':'Entrando na conta…');
 try{
  if(mode==='signup'){
   if(nick.length<2)throw Error('Escolha um apelido com pelo menos 2 caracteres.');
   const response=await request('/auth/v1/signup',{method:'POST',data:{email,password,data:{display_name:nick}}});
   if(response?.access_token&&response?.user){localStorage.setItem(nickKey(response.user.id),nick);await loggedIn(response)}
   else notify('O provedor exige confirmação adicional antes de liberar o acesso. Você também pode entrar com Google na Central de Conta.');
  }else{
   const response=await request('/auth/v1/token?grant_type=password',{method:'POST',data:{email,password}});await loggedIn(response);
  }
 }catch(err){notify('⚠️ '+err.message,true)}finally{loginBusy=false;$('accountAuthSubmit').disabled=false;renderHeader()}
}
async function recoverPassword(){const email=$('accountEmail').value.trim();if(!email){notify('Informe seu e-mail no campo acima.',true);return}
 try{await request('/auth/v1/recover',{method:'POST',data:{email}});notify('Se esse endereço estiver cadastrado, as instruções de recuperação serão enviadas ao e-mail.')}catch(err){notify('Não foi possível pedir recuperação: '+err.message,true)}}
async function handleUrlAuth(){let hash=location.hash;try{if(!/^#(?:access_token|error)=/.test(hash))hash=sessionStorage.getItem('elw_pending_auth_hash_v1')||hash;sessionStorage.removeItem('elw_pending_auth_hash_v1')}catch{}
 if(!hash.startsWith('#access_token=')&&!hash.startsWith('#error='))return false;
 const params=new URLSearchParams(hash.slice(1));history.replaceState(null,'',location.pathname+location.search+'#jogo');
 if(params.has('error')){notify('Confirmação por e-mail: '+(params.get('error_description')||params.get('error')),true);openAccount();return true}
 const token=params.get('access_token'),refresh=params.get('refresh_token');if(!token||!refresh)return true;
 try{const user=await request('/auth/v1/user',{token});const next={access_token:token,refresh_token:refresh,expires_in:Number(params.get('expires_in')||3600),user};
  if(params.get('type')==='recovery')localStorage.setItem('elw_cloud_password_recovery','1');
  await loggedIn(next);
 }catch(err){notify('Não foi possível confirmar e-mail: '+err.message,true);openAccount()}
 return true}
function openAccount(){const dlg=$('accountDialog');if(!dlg.open)dlg.showModal();renderHeader()}
function openRecovery(){openAccount();$('accountResetBox').hidden=false;$('accountResetPassword').focus()}
async function setPassword(){const pass=$('accountResetPassword').value;if(pass.length<8){notify('A senha precisa ter pelo menos 8 caracteres.',true);return}
 try{await request('/auth/v1/user',{method:'PUT',token:await access(),data:{password:pass}});localStorage.removeItem('elw_cloud_password_recovery');$('accountResetBox').hidden=true;notify('✓ Sua senha foi atualizada.')}catch(err){notify('Não foi possível trocar sua senha: '+err.message,true)}}
function renderHeader(){
 const header=$('headerAccountOpen'),entry=$('landingAccountOpen');
 const text=session?'👤 '+nickname():'👤 Entrar / Cadastrar';if(header)header.textContent=text;
 if(entry)entry.textContent=session?'☁️ Minha conta':'👤 Entrar / Criar conta';
 const logged=!!session;
 for(const id of ['cloudLoggedIn','accountLoggedIn']){const el=$(id);if(el)el.hidden=!logged}
 for(const id of ['cloudLoggedOut','accountLoggedOut']){const el=$(id);if(el)el.hidden=logged}
 for(const id of ['accountModalSigned']){const el=$(id);if(el)el.hidden=!logged}
 for(const id of ['accountModalUnsigned']){const el=$(id);if(el)el.hidden=logged}
 for(const id of ['cloudAccountLabel','accountIdentity']){const el=$(id);if(el)el.textContent=logged?nickname()+' · '+session.user.email:'Sem conta conectada'}
 if($('cloudProfileNick')&&document.activeElement!==$('cloudProfileNick'))$('cloudProfileNick').value=nickname();
 if($('accountSyncNow'))$('accountSyncNow').disabled=!logged||!syncReady||saving;
 if($('cloudSyncNow'))$('cloudSyncNow').disabled=!logged||!syncReady||saving;
 if($('cloudMainStatus')&&!cloudMessage)$('cloudMainStatus').textContent=!configured?'Para ativar login e top mundial, configure o Supabase.':logged?'☁️ Conta conectada. O progresso é salvo localmente e sincronizado a cada minuto.':'O jogo funciona como visitante. Entre para salvar em vários dispositivos.';
}
function mode(val){$('accountAuthMode').value=val;$('accountNickWrap').hidden=val!=='signup';$('accountAuthSubmit').textContent=val==='signup'?'Criar conta':'Entrar';document.querySelectorAll('[data-auth-mode]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.authMode===val)))}
async function rankLoad(){if(!configured){for(const id of ['worldTeamsRows','worldSpeedRows']){const el=$(id);if(el)el.innerHTML='<p class="cloudHint">O ranking mundial aparece aqui após configurar o Supabase no ZIP.</p>'}return}
 if(rankingBusy)return;rankingBusy=true;try{
  const token=session?await access():null;
  const fields='display_name,team_power,badges,best_ticks,is_champion,team,updated_at';
  [rankData,speedData]=await Promise.all([
    request('/rest/v1/elw_leaderboard?select='+fields+'&team_power=gt.0&order=team_power.desc&limit=50',{token}),
    request('/rest/v1/elw_leaderboard?select='+fields+'&best_ticks=not.is.null&order=best_ticks.asc&limit=50',{token})
  ]);
  renderRank();
 }catch(err){for(const id of ['worldTeamsRows','worldSpeedRows'])if($(id))$(id).textContent='Ranking indisponível: '+err.message}finally{rankingBusy=false}}
function monImage(name){const key=String(name||'').toLowerCase().replace(/[^a-z0-9-]/g,'');return key?`<img loading="lazy" src="assets/pokemon_fit/${encodeURIComponent(key)}.png" alt="${esc(name)}" onerror="this.hidden=true">`:''}
function renderRank(){const teams=$('worldTeamsRows'),speeds=$('worldSpeedRows');if(teams)teams.innerHTML=rankData.length?rankData.map((r,i)=>`<div class="cloudRankRow"><strong class="cloudRankPosition">${i+1}º</strong><div class="cloudRankIdentity"><b>${esc(r.display_name)}</b><small>🏅 ${Number(r.badges)||0}/8 insígnias ${r.is_champion?'· 👑 Campeão':''}</small><div class="cloudMiniTeam">${(Array.isArray(r.team)?r.team:[]).slice(0,6).map(m=>`<span title="${esc(m.species)} Nv. ${Number(m.level)||1}">${monImage(m.species)}<small>Lv.${Number(m.level)||1}</small></span>`).join('')}</div></div><strong class="cloudRankNumber">${fmt(r.team_power)} pts</strong></div>`).join(''):'<p class="cloudHint">Nenhuma equipe publicada ainda. Entre, forme um time e sincronize.</p>';
 if(speeds)speeds.innerHTML=speedData.length?speedData.map((r,i)=>`<div class="cloudRankRow"><strong class="cloudRankPosition">${i+1}º</strong><div class="cloudRankIdentity"><b>${esc(r.display_name)}</b><small>👑 Liga conquistada · ${fmt(r.best_ticks)} rodadas simuladas</small></div><strong class="cloudRankNumber">${fmt(r.best_ticks)} ⏱️</strong></div>`).join(''):'<p class="cloudHint">Nenhum jogador registrou uma vitória com seu bot ainda.</p>'}
// Botões e formulários: a interface existe mesmo antes da configuração do Supabase.
$('headerAccountOpen')?.addEventListener('click',openAccount);
$('landingAccountOpen')?.addEventListener('click',openAccount);
$('openCloudAccount')?.addEventListener('click',openAccount);
$('accountDialogClose')?.addEventListener('click',()=>$('accountDialog').close());
$('accountAuthForm')?.addEventListener('submit',loginAction);
$('accountRecover')?.addEventListener('click',recoverPassword);
$('accountResetSubmit')?.addEventListener('click',setPassword);
$('accountSyncNow')?.addEventListener('click',()=>saveCloud(true));
$('cloudSyncNow')?.addEventListener('click',()=>saveCloud(true));
$('accountSignOut')?.addEventListener('click',signOut);
$('cloudSignOut')?.addEventListener('click',signOut);
$('cloudRefreshRanking')?.addEventListener('click',rankLoad);
$('cloudProfileSave')?.addEventListener('click',async()=>{if(!session)return;const nick=cleanNick($('cloudProfileNick').value);if(nick.length<2){notify('Apelido muito curto.',true);return}localStorage.setItem(nickKey(session.user.id),nick);renderHeader();try{await publishRanking();notify('✓ Apelido salvo.')}catch(err){notify('Não foi possível atualizar o ranking: '+err.message,true)}});
$('accountModeLogin')?.addEventListener('click',()=>mode('login'));
$('accountModeSignup')?.addEventListener('click',()=>mode('signup'));
window.addEventListener('emerald:pagechange',event=>{if(['ranking','mundial'].includes(event.detail.page))rankLoad();if(event.detail.page==='conta')renderHeader()});
window.EmeraldCloud={saveNow:()=>saveCloud(true),refreshRanking:rankLoad,openAccount};
mode('login');renderHeader();
(async()=>{
 if(!configured){notify('Login e top mundial ainda não configurados. Abra CONFIGURAR_LOGIN_E_TOP_MUNDIAL.md no ZIP.');rankLoad();return}
 const urlAuth=await handleUrlAuth();if(urlAuth)return;
 if(session){try{await access();await prepareProfile()}catch(err){notify('Não foi possível atualizar sua sessão: '+err.message,true)}}
 rankLoad();
 if(session&&localStorage.getItem('elw_cloud_password_recovery')==='1')openRecovery();
})();
setInterval(()=>{if(session&&syncReady&&document.visibilityState==='visible')saveCloud(false)},AUTO_INTERVAL);
setInterval(()=>{if(session&&syncReady&&document.visibilityState==='visible'&&!document.getElementById('page-mundial')?.hidden)rankLoad()},120000);
})();
