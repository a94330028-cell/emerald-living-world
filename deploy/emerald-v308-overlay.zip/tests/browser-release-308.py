"""Exercise the Node-served release in Chromium with an Android viewport and isolated saves."""
import json
import os
from pathlib import Path
import socket
import subprocess
import tempfile
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread
from urllib.parse import parse_qs, urlparse
from urllib.request import urlopen

from playwright.sync_api import expect, sync_playwright

ROOT = Path(__file__).resolve().parents[1]
USER = {"id": "1775d11c-2cf4-4f4a-b365-5f320497c2af", "user_metadata": {"display_name": "Teste local"}}
TOKEN = "local-browser-test-access-token"
SESSION = {"access_token": TOKEN, "refresh_token": "local-browser-test-refresh-token", "expires_in": 3600, "user": USER}


class AuthFixture(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def reply(self, data, code=200):
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "apikey,authorization,content-type")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())

    def do_OPTIONS(self):
        self.reply({})

    def do_GET(self):
        if self.path == "/auth/v1/settings":
            return self.reply({"external": {"google": True}})
        if self.path == "/auth/v1/user" and self.headers.get("Authorization") == "Bearer " + TOKEN:
            return self.reply(USER)
        self.reply([] if self.path.startswith("/rest/") else {}, 200 if self.path.startswith("/rest/") else 401)

    def do_POST(self):
        payload = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
        url = urlparse(self.path)
        if url.path == "/auth/v1/signup":
            return self.reply({"user": USER})
        if url.path == "/auth/v1/recover" or url.path.startswith("/rest/"):
            return self.reply({})
        if url.path == "/auth/v1/token":
            grant = parse_qs(url.query).get("grant_type", [""])[0]
            if grant == "password" and payload.get("password") == "local-test-password":
                return self.reply(SESSION)
            if grant == "pkce" and payload.get("auth_code") == "local-code" and len(payload.get("code_verifier", "")) == 43:
                return self.reply(SESSION)
        self.reply({"error_code": "invalid_credentials"}, 400)


def server_port():
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def check_navigation(page, base, name):
    page.goto(base + "/jogo/" + name, wait_until="domcontentloaded")
    expect(page.locator("#elw-world-dock")).to_have_count(1)
    expect(page.locator("body > header")).to_have_count(1)
    expect(page.locator(".bottomNav")).to_have_count(0)
    assert page.evaluate("document.documentElement.scrollWidth <= innerWidth"), name


def check_arena(page):
    page.locator("#arenaClear").click()
    for species in ["Pikachu", "Mudkip", "Ralts", "Treecko", "Torchic", "Absol"]:
        page.locator("#arenaSearch").fill(species)
        item = page.get_by_role("button", name=species + " #" , exact=False).first
        expect(item).to_be_enabled()
        if species == "Pikachu":
            assert item.locator("img").evaluate("(img) => img.complete && img.naturalWidth > 0")
        item.click()
    expect(page.locator(".teamSlot.filled")).to_have_count(6)
    page.locator("#arenaLaunch").click()
    page.locator("#combatMoves button").first.click()
    expect(page.locator("#battleTurn")).to_have_text("Rodada 2")
    page.locator('[data-tab="build"]').click()
    page.locator("#arenaRandom").click()
    expect(page.locator(".teamSlot.filled")).to_have_count(6)
    page.reload(wait_until="domcontentloaded")
    expect(page.locator(".teamSlot.filled")).to_have_count(6)


def check_simulation(page):
    assert page.evaluate("window.emeraldExport().turns") == 0
    page.locator("#landingSolo").click()
    page.wait_for_function("""() => {
      const s = window.emeraldExport();
      return s.turns > 30 && s.trainers.length === 20 &&
        s.trainers.every(t => t.walkCount > 0) && s.trainers.some(t => t.stage >= 2);
    }""", timeout=45000)
    before = page.evaluate("""() => {
      const s = window.emeraldExport();
      return {turns:s.turns, bots:s.trainers.filter(t=>t.walkCount>0).length,
              steps:s.trainers.reduce((sum,t)=>sum+t.walkCount,0),
              stage:Math.max(...s.trainers.map(t=>t.stage)),
              map:window.emeraldLiveDebug().officialMap};
    }""")
    expect(page.locator("#myBotMapMount canvas")).to_be_visible()
    assert before["map"], before
    page.reload(wait_until="domcontentloaded")
    expect(page.locator("#landingContinue")).to_be_visible()
    assert page.evaluate("window.emeraldExport().turns") >= before["turns"]
    page.locator("#landingContinue").click()
    page.wait_for_function("turn => window.emeraldExport().turns > turn", arg=before["turns"])
    expect(page.locator("#myBotMapMount canvas")).to_be_visible()
    assert page.locator(".simulationTabs").evaluate("(nav) => getComputedStyle(nav).position") in {"static", "relative"}
    return before


def main():
    provider = ThreadingHTTPServer(("127.0.0.1", 0), AuthFixture)
    Thread(target=provider.serve_forever, daemon=True).start()
    auth_url = f"http://127.0.0.1:{provider.server_port}"
    port = server_port()
    base = f"http://127.0.0.1:{port}"
    with tempfile.TemporaryDirectory() as saves, subprocess.Popen(
        ["node", "server/app.cjs"], cwd=ROOT, env={
            **os.environ, "PORT": str(port), "DATA_DIR": saves, "NODE_ENV": "test",
            "AUTH_MODE": "required", "SUPABASE_URL": auth_url, "SUPABASE_PUBLISHABLE_KEY": "local-public-test-key",
            "BOT_TICK_MS": "100", "BOT_STEPS_PER_TICK": "100",
        }
    ) as server:
        try:
            for _ in range(60):
                try:
                    with urlopen(base + "/api/health", timeout=1) as response:
                        assert response.status == 200
                    break
                except OSError:
                    time.sleep(0.2)
            with sync_playwright() as playwright:
                browser = playwright.chromium.launch(
                    executable_path=os.environ.get("CHROMIUM_PATH"),
                    args=["--no-sandbox", "--disable-gpu", "--disable-software-rasterizer", "--no-zygote", "--single-process"],
                )
                context = browser.new_context(**playwright.devices["Pixel 7"], ignore_https_errors=True)
                context.route("**/jogo/js/cloud-config.js*", lambda route: route.fulfill(
                    content_type="text/javascript",
                    body="window.EMERALD_CLOUD_CONFIG=" + json.dumps({"supabaseUrl": auth_url, "supabaseAnonKey": "local-public-test-key"}),
                ))
                # The browser runs the real login form, PKCE exchange and Node authorization.
                # The identity provider is isolated and cannot create real users or modify production.
                def authorize(route):
                    params = parse_qs(urlparse(route.request.url).query)
                    assert params["provider"] == ["google"] and params["code_challenge_method"] == ["s256"]
                    route.fulfill(status=302, headers={"Location": params["redirect_to"][0] + "?code=local-code"})

                context.route(auth_url + "/auth/v1/authorize*", authorize)
                page = context.new_page()
                errors = []
                page.on("pageerror", lambda error: errors.append(str(error)))
                assert page.request.post(base + "/api/session", data={}).status == 401
                check_navigation(page, base, "entrar.html")
                page.locator("#email").fill("teste@example.test")
                page.locator("#password").fill("incorreta")
                page.locator("#submitPassword").click()
                expect(page.locator("#authMessage")).to_contain_text("E-mail ou senha incorretos")
                page.locator("#forgotPassword").click()
                expect(page.locator("#authMessage")).to_contain_text("redefinir a senha")
                page.locator(".signup summary").click()
                page.locator("#nickname").fill("Teste local")
                page.locator("#signupEmail").fill("novo@example.test")
                page.locator("#signupPassword").fill("local-test-password")
                page.locator("#signupForm button").click()
                expect(page.locator("#authMessage")).to_contain_text("confirmar o cadastro")
                page.locator("#password").fill("local-test-password")
                page.locator("#submitPassword").click()
                expect(page).to_have_url(base + "/jogo/online.html")
                page.locator("#name").fill("Treinador de teste")
                page.locator("#enter").click()
                expect(page.locator("#game")).to_be_visible(timeout=15000)
                bots_before = page.request.get(base + "/api/bots").json()
                page.wait_for_timeout(1100)
                bots_after = page.request.get(base + "/api/bots").json()
                assert bots_after["tick"] > bots_before["tick"]
                check_navigation(page, base, "frontier.html")
                expect(page.locator("#facilityGrid button")).to_have_count(7)
                expect(page.locator("#connection")).to_have_text("Servidor conectado")
                for name in ["portal.html", "campanha.html", "quetzal-pokedex.html", "mapas-oficiais.html", "estatisticas.html", "arena.html"]:
                    check_navigation(page, base, name)
                check_arena(page)
                check_navigation(page, base, "index.html#jogo")
                simulation = check_simulation(page)
                page.goto(base + "/jogo/entrar.html?next=arena.html", wait_until="domcontentloaded")
                page.evaluate("localStorage.removeItem('elw_cloud_session_v1')")
                page.reload(wait_until="domcontentloaded")
                page.locator("#googleLogin").click()
                expect(page).to_have_url(base + "/jogo/arena.html")
                assert page.evaluate("window.ELWLocalSlots.session().user.id") == USER["id"]
                assert not errors, errors
                print(json.dumps({"simulation": simulation, "arena": "6 Pokémon e rodada 2",
                                  "shared": {"bots": bots_after["total"], "tick": bots_after["tick"]},
                                  "navigation": "Pixel 7 emulado", "auth": "provedor local isolado"}))
                browser.close()
        finally:
            server.terminate()
            server.wait(timeout=10)
            provider.shutdown()


if __name__ == "__main__":
    main()
