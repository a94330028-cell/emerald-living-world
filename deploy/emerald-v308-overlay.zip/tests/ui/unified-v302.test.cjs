const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');const path=require('node:path');
const root=path.resolve(__dirname,'../..');
const file=p=>fs.readFileSync(path.join(root,p),'utf8');
test('Central Emerald reúne oito modos em uma só origem',()=>{
 const s=file('jogo/portal.html');
 for(const url of ['online.html','index.html#jogo','arena.html','frontier.html','campanha.html','quetzal-pokedex.html','mapas-oficiais.html','estatisticas.html'])assert.ok(s.includes('href="'+url+'"'),url);
 assert.match(file('index.html'),/url=jogo\/portal\.html/);
});
test('Barra unificada nas páginas principais sem iframe, preservando cada jogo',()=>{
 for(const page of ['index','online','arena','frontier','campanha','quetzal-pokedex','mapas-oficiais','estatisticas']){
  const html=file('jogo/'+page+'.html');assert.ok(html.includes('css/unified-shell.css'),page);assert.ok(html.includes('js/unified-shell.js'),page);
 }
 const script=file('jogo/js/unified-shell.js');assert.match(script,/aria-current/);assert.match(script,/pointerdown/);assert.doesNotMatch(script,/<iframe/i);
});
test('Login não inventa sessão e reutiliza chave única com o mundo e simulador',()=>{
 const login=file('jogo/js/unified-account.js');const multiplayer=file('jogo/multiplayer/online-auth.js');const cloud=file('jogo/js/cloud-account.js');
 assert.match(login,/auth\/v1\/user/);assert.match(login,/auth\/v1\/token\?grant_type=password/);assert.match(login,/auth\/v1\/authorize/);assert.match(login,/provider:'google'/);assert.match(login,/grant_type=pkce/);
 assert.match(login,/access_token/);assert.match(login,/refresh_token/);assert.match(login,/slots\.SESSION/);
 assert.match(multiplayer,/elw_cloud_session_v1/);assert.match(cloud,/elw_cloud_session_v1|slots\.SESSION/);
 assert.doesNotMatch(login,/service_role|sb_secret_/i);
});
test('Mesma marca com temas específicos por região',()=>{
 const css=file('jogo/css/unified-shell.css');
 for(const area of ['arena','frontier','jornada','pokedex','mapas','estatisticas','conta','hub'])assert.ok(css.includes('data-elw-section="'+area+'"'));
 for(const name of ['.theme-online','.theme-sim','.theme-arena','.theme-frontier','.theme-story','.theme-dex','.theme-maps','.theme-ranking'])assert.ok(file('jogo/css/unified-portal.css').includes(name));
});
test('Servidor entrega imagens webp e JPEG com tipo correto',()=>{
 const app=file('server/app.cjs');assert.match(app,/'\.webp':'image\/webp'/);assert.match(app,/'\.jpg':'image\/jpeg'/);
});
